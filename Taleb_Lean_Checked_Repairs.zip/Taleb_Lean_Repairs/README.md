# Taleb Lean audit repairs

A companion to the audit of `mathlib-proofs-16.zip`. These are checked repairs, simplifications, and diagnostic counterexamples for the submitted statements. They are not a complete formalization of *Statistical Consequences of Fat Tails*.

## Build

Install Lean through elan, then run from this directory:

```sh
lake update
lake exe cache get
lake build
```

The included `lean-toolchain` selects Lean 4.24.0. The Mathlib requirement is pinned to commit `f897ebcf72cd16f89ab4577d0c826cd14afaafc7` (v4.24.0), and the lockfile pins transitive dependencies. The build requires network access to fetch dependencies and precompiled Mathlib artifacts.

## Contents and scope

- `AuditRepairs/RegularVariation.lean`: six repaired or simplified ratio-limit theorems for Proof01 through Proof06. Definitions retain the original ratio-only convention; the normalization theorem removes an unnecessary eventual-positivity hypothesis.
- `AuditRepairs/Tails.lean`: eleven results for Proof07 through Proof11, including an explicit finite-tail-index interface, a real-valued liminf pathology diagnostic, and an all-real piecewise Frechet formula.
- `AuditRepairs/Stable.lean`: twelve results for Proof12 through Proof16, including formal counterexamples to the submitted Gaussian and Cauchy specializations, corrected specializations, algebraic power identities, and a separate S1 expression with the alpha=1 logarithmic branch. These functions are not proved to be characteristic functions of probability measures.
- `AuditRepairs/ImplicitSetDiagnostic.lean`: a declaration-type probe and checked counterexample showing that the unqualified `univ` in Proof09 becomes an arbitrary implicit set.
- `AuditRepairs.lean`: imports all four modules together.
- `evidence/`: independent original-file compiler logs and the result matrix. Original files were checked unchanged; eight passed and eight failed in this explicitly pinned environment.

## Verification

The three main repair modules contain 29 theorems with `#print axioms` checks. The implicit-set diagnostic separately prints the axioms of its counterexample. These checks report only standard foundational axioms (`propext`, `Classical.choice`, and/or `Quot.sound`), with no `sorryAx`. The modules use separate namespaces and are checked together by the root import.

Compilation verifies each written Lean proposition. It does not establish that an algebraic expression is a probability distribution, or that the chosen statement exactly captures a theorem from Taleb's book. Those scope distinctions are documented in the PDF audit report.

## Input identity

Original archive SHA-256:

```text
b0132c09a8835107abaac916578e5e61a703b5a09a800c2e874c24d15d05b47c
```

Audit date: 2026-09-18. Lean compiler commit: `797c613eb9b6d4ec95db23e3e00af9ac6657f24b`.

## Controlled failure probes

The two `evidence/Proof05_*.patch` files show the minimal diagnostic changes to the original Proof05, with matching compiler logs. These probes are expected to fail: they expose errors masked by the missing import. They are evidence, not replacement proof modules. Use `AuditRepairs/RegularVariation.lean` for the successful repair.
