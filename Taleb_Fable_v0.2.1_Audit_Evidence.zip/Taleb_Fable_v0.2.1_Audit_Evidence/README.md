# Evidence for the independent audit of Fable v0.2.1

The reviewed archive has SHA-256:

`c492cc14c470f8cd3d237f884a4c3157195a11c1d5e56e62c52a818f9053008a`

Read the companion `Taleb_Fable_v0.2.1_Independent_Audit.md` or PDF for the findings and their scope. This evidence bundle supplements the received handoff. It is not a replacement proof release.

## Contents

- `integrity_summary.json`: archive and manifest checks, exact changed/added paths.
- `patch_replay_result.json`: the supplied patch recreates the delivered archive tree.
- `environment.json`: pinned compiler, dependency provenance, and runtime record.
- `baseline_results.json`: command arguments, exit statuses, and elapsed times for the unmodified fresh build and verifier.
- `logs/clean_build.log`, `logs/unmodified_verify.log`: independently captured command output.
- `reproduced_current/`: fresh verification outputs for the unmodified received source.
- `AllConstants.lean`, `all_constants.json`, `logs/all_constants.log`: audit variant of Fable's environment scanner that also lists and axiom-checks internal constants. All 137 constants in the imported proof modules were inside the allowlist.
- `probe_harness.py`: the actual fault-injection driver used in a disposable copy. Its relative runtime/project layout records this audit environment; adapt the paths or use the snippets below in an isolated local copy.
- `probes/results.json`: actual subprocess exit codes, timings, original/mutated file hashes, and verification records.
- `probes/<case>/mutation.txt`: complete temporarily modified source or map for that case. The `.txt` extension is intentional.
- `probes/<case>/command.log`, `current/`: verifier output and the resulting evidence directory for that case. On rejected runs, some files in `current/` can be leftovers from the preceding run; the driver did not erase them. Use the case's command output and `verification.json` as its rejection result.
- `probes/restoration.json`: all injected source/map changes restored byte-for-byte. Received artifacts and their preserved extraction were never mutated.

## Reproducing the relevant fixtures

Use a disposable extraction of the received v0.2.1 ZIP, the pinned Lean toolchain, and the pinned dependency manifest. First run `lake build` and `python3 scripts/verify.py` to establish the baseline. Save a pristine copy of each source/map before editing it. After each case, restore that source/map, and let Lake rebuild changed modules before the next case. Do not insert these fixtures into a release.

### Private unfinished theorem

Append to `AuditRepairs/RegularVariation.lean`:

```lean
private theorem audit_private_gap : False := by sorry
#print axioms audit_private_gap
```

Run `python3 scripts/verify.py`. In the reviewed release this incorrectly reports PASS despite a build warning and a printed `[sorryAx]` dependency.

### Public theorem under a structure namespace

Append to `AuditRepairs/Stable.lean`:

```lean
protected theorem StableAudit.StableParameters.audit_user_theorem : True := True.intro
```

Run `python3 scripts/verify.py`. Inspect `inventory_environment.json`: the new theorem is misclassified as generated, and the reconciled user-proof count does not increase.

### Ordinary protected-theorem rejection control

Append to `AuditRepairs/RegularVariation.lean`:

```lean
protected theorem AuditRV.audit_public_theorem : True := True.intro
```

Run `python3 scripts/verify.py`. This correctly returns a nonzero verifier exit with an environment/regex inventory mismatch.

### Alias mismatch and Python optimization

In `docs/replacement_map.json`, set the declaration target for Proof16 to `AuditProbability.charFun_convolutionPower`, leaving the Lean alias unchanged. Ordinary `python3 scripts/verify.py` should reject the mismatch. Compare with `python3 -O scripts/verify.py`; the reviewed release incorrectly reports PASS because its assertions have been removed.

The invalid proof fixture is test data that demonstrates rejection failures. No delivered theorem is alleged to contain that fixture, and the companion audit does not introduce any unproved mathematical theorem into the handoff.
