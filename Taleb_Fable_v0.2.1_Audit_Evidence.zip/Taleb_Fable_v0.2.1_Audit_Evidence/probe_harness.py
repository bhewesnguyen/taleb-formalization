"""Audit-only fault injection into a disposable copy of the received package.

This intentionally introduces invalid proof material to test rejection. It does
not modify the uploaded archive or the preserved received extraction.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "run_probes/Taleb_Lean_Repairs"
EVIDENCE = ROOT / "probes"
EVIDENCE.mkdir(exist_ok=True)
env = os.environ.copy()
env["PATH"] = str(ROOT / "runtime/lean-4.24.0-linux/bin") + os.pathsep + env["PATH"]
results = []


def probe(name, relative_path, transform, optimized=False):
    path = PROJECT / relative_path
    original = path.read_bytes()
    case = EVIDENCE / name
    case.mkdir(exist_ok=True)
    changed = transform(original.decode()).encode()
    (case / "mutation.txt").write_bytes(changed)
    args = ["python3"] + (["-O"] if optimized else []) + ["scripts/verify.py"]
    try:
        path.write_bytes(changed)
        start = time.monotonic()
        with (case / "command.log").open("w") as log:
            process = subprocess.run(args, cwd=PROJECT, env=env,
                                     stdout=log, stderr=subprocess.STDOUT)
        record = dict(name=name, command=args, modified_file=relative_path,
                      exit_code=process.returncode,
                      elapsed_seconds=round(time.monotonic() - start, 2),
                      original_sha256=hashlib.sha256(original).hexdigest(),
                      mutation_sha256=hashlib.sha256(changed).hexdigest())
        shutil.copytree(PROJECT / "evidence/current", case / "current",
                        dirs_exist_ok=True)
        record["verification"] = json.loads((case / "current/verification.json").read_text())
        results.append(record)
        print(json.dumps({k: record[k] for k in ["name", "exit_code", "elapsed_seconds"]}), flush=True)
    finally:
        path.write_bytes(original)
        assert path.read_bytes() == original
        (EVIDENCE / "results.json").write_text(json.dumps(results, indent=2))


probe("private_sorry", "AuditRepairs/RegularVariation.lean", lambda s: s +
      "\nprivate theorem audit_private_gap : False := by sorry\n"
      "#print axioms audit_private_gap\n")
probe("structure_namespace", "AuditRepairs/Stable.lean", lambda s: s +
      "\nprotected theorem StableAudit.StableParameters.audit_user_theorem : True := True.intro\n")
probe("protected_control", "AuditRepairs/RegularVariation.lean", lambda s: s +
      "\nprotected theorem AuditRV.audit_public_theorem : True := True.intro\n")


def wrong_alias(s):
    data = json.loads(s)
    row = next(r for r in data if r["proof"] == 16)
    row["declaration"] = "AuditProbability.charFun_convolutionPower"
    return json.dumps(data, indent=2) + "\n"


probe("alias_control", "docs/replacement_map.json", wrong_alias)
probe("optimized_alias", "docs/replacement_map.json", wrong_alias, optimized=True)

original_root = ROOT / "received/Taleb_Lean_Repairs"
different = []
for f in original_root.rglob("*"):
    if f.is_file():
        rel = f.relative_to(original_root)
        if str(rel).startswith("evidence/current/"):
            continue
        if f.read_bytes() != (PROJECT / rel).read_bytes():
            different.append(str(rel))
(EVIDENCE / "restoration.json").write_text(json.dumps({"differences": different}, indent=2))
assert not different, different
print("Every injected source/map change was restored byte-for-byte.", flush=True)
