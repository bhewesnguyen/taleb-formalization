# Changelog: Fable review

## v0.2.2 → v0.2.3 (first mathematics increment)

Delivers the three contained tasks recommended by the v0.2.1 review (§11) and by the
independent audit ("Recommended next pass", item 3). Details and exact statements:
`FABLE_REVIEW.md` §13.

### Mathematical statement changes

No pre-existing theorem, definition, instance, alias or proof was modified. **Added**
(all with axiom closure `{propext, Classical.choice, Quot.sound}`):

| Declaration | Kind | Content |
|---|---|---|
| `AuditTails.two_power_tail` (`AuditRepairs/Foundations.lean`) | theorem | `0 ≤ w₁ → 0 < w₂ → α₂ ≤ α₁ → HasFiniteTailExponent (fun z => w₁ z^{−α₁} + w₂ z^{−α₂}) α₂` — corrected content of the display under book Property 5.1 (G18). |
| `AuditTails.two_power_tail_min` | theorem | positive weights → exponent `min α₁ α₂`. |
| `AuditGaussian.varianceOfScale`, `coe_varianceOfScale` (`AuditRepairs/GaussianBridge.lean`, new) | def, theorem | `v = 2σ²` as an `ℝ≥0`. |
| `AuditGaussian.charFun_gaussianReal_eq_stableS1Expr` | theorem | `(v : ℝ) = 2σ² → charFun (gaussianReal μ v) t = stableS1Expr 2 β μ σ t` (zero scale included). |
| `AuditGaussian.gaussianParameters` | def | the admissible S1 tuple `(2, 0, μ, σ)`. |
| `AuditGaussian.convolutionPower_gaussianReal_scale` | theorem | `convolutionPower (gaussianReal m (2σ²)) n = gaussianReal (n m) (2 (n^{1/2} σ)²)`, proved **through** `stableS1_convolutionPower_eq` (non-vacuity of Proof16's premises at α = 2). |
| `AuditGaussian.convolutionPower_gaussianReal` | theorem | `convolutionPower (gaussianReal m v) n = gaussianReal (n m) (n v)`. |
| `AuditExtremes.maxLeEvent`, `maxLeEvent_eq_iInter` (`AuditRepairs/ExtremeValueBridge.lean`, new) | def, theorem | the event `∀ i, Xᵢ ≤ x` and its `⋂` form. |
| `AuditExtremes.measure_maxLeEvent` | theorem | `iIndepFun X P → P (maxLeEvent X x) = ∏ i, P (Xᵢ ⁻¹' Iic x)`. |
| `AuditExtremes.measure_maxLeEvent_of_forall_eq`, `measureReal_maxLeEvent_of_forall_eq` | theorems | the `p ^ card ι` forms in `ℝ≥0∞` and `ℝ`. |
| `AuditExtremes.measureReal_maxLeEvent_frechet`, `measureReal_maxLeEvent_gumbel` | theorems | max-stability for independent maxima whose coordinates have the Fréchet(ξ) resp. Gumbel distribution function. |

Counts: 52 → **64 theorems**, 1 instance, 16 aliases (**81** checked); trust scan 137 → **158**
constants (41 internal).

### Changed files

| File | Change |
|---|---|
| `AuditRepairs/Foundations.lean` | + section "Two-term power tails" with the two theorems above. |
| `AuditRepairs/GaussianBridge.lean` | **New** module (imports `AuditRepairs.ProbabilityBridge`, `Mathlib.Probability.Distributions.Gaussian.Real`). |
| `AuditRepairs/ExtremeValueBridge.lean` | **New** module (imports `AuditRepairs.Tails`, `Mathlib.MeasureTheory.Measure.Real`, `Mathlib.Probability.Independence.Basic`). |
| `AuditRepairs.lean` | Imports the two new modules. |
| `AuditVerification.lean` | Regenerated (+12 `#print axioms` lines, 81 total). |
| `docs/FORMALIZATION_BACKLOG.{json,md}`, `scripts/rebuild_curated_inventory.py` | T029 `source-check → partial`, T046 text (Gaussian half delivered; Cauchy open), T060 `missing → partial`; regenerated and synced (158/158). Statuses now 92 missing / 34 source-check / 10 partial. |
| `docs/REPLACEMENT_MAP.md`, `docs/replacement_map.json` | Rows 10, 11, 16: pointers to the new iid-maximum and Gaussian-instantiation theorems. |
| `docs/SOURCE_GATES.md` | G18: names the delivered lemmas. |
| `docs/MATHLIB_AND_WORK_ORDER.md` | CF, Gaussian, CDF rows and slice 4 updated with what is now done and what remains. |
| `README.md` | Version, counts (64/1/16, 81; 158 constants), module list, "What is still open". |
| `FABLE_REVIEW.md` | + §13 (statements, sources, scope, verification, next tasks). |
| `lakefile.toml` | `version = "0.2.3"`. |
| `SHA256SUMS`, `evidence/current/*`, `evidence/fable/v0.2.3/` | Regenerated / new evidence layer. |

Pins unchanged: `lean-toolchain`, `lake-manifest.json`, Mathlib `rev`.

### Compatibility implications

- Client code: none for existing declarations. `import AuditRepairs` now also brings in
  `Mathlib.Probability.Distributions.Gaussian.Real` and `Mathlib.Probability.Independence.Basic`
  (both were already transitively available through Mathlib; build time is unchanged in
  practice, +2 project modules).
- Verification: `verify.py` runtime ≈ 100 s (the trust scan now covers 158 constants).

### Validation performed (v0.2.3)

- `rm -rf .lake/build; lake build`: exit 0, no warnings.
- `python3 scripts/verify.py`: exit 0, `PASS: 64 theorems, 1 instance, 16 aliases; … trust scan:
  158 project constants (incl. 41 internal) all within allowlist; 81 public theorem/instance
  constants match the regex inventory`.
- `python3 scripts/harness_regression.py`: exit 0, 10/10 fixtures as expected.
- Documentation consistency: replacement map 16/16, backlog 158/158.
- Final ZIP validated from a fresh extraction (`deliverables/archive_validation_v0.2.3.log`).

---

## v0.2.1 → v0.2.2 (corrective pass after the independent audit of v0.2.1)

Trigger: `Taleb_Fable_v0.2.1_Independent_Audit.md` (SHA-256 `3f71049c08fdcaf6b4c73b8b91ab63447de2164b2a89787169683b8a7461f809`)
with evidence `Taleb_Fable_v0.2.1_Audit_Evidence.zip` (`a5553019a8693135356717831455385e0b9a89ce73c50ad9ee86fd8613e90f04`).
Every finding was reproduced before being repaired; see `FABLE_REVIEW.md` §12.

### Mathematical statement changes

**None.** No theorem, definition, instance, alias, proof body, `lean-toolchain`,
`lake-manifest.json` or Mathlib `rev` was touched. Counts are unchanged: 52 theorems,
1 instance, 16 aliases, 69 checked declarations.

### Changed files

| File | Change |
|---|---|
| `scripts/FableInventory.lean` | Rewritten. Lists **every** constant of the project modules (137: 102 public/generated + 35 internal) and collects each axiom closure **before** any visibility or provenance filtering (audit A1). Provenance is decided from Lean's bookkeeping — constructor/recursor kind, `Environment.isProjectionFn`, `isAuxRecursor`, `isNoConfusion`, or absence of a declaration range — never from a namespace prefix (audit A2); the rule that fired is recorded per row (`generatedBy`). Also emits `imported_project_modules` and `axiom_kind_constants`. Field names changed: `isInternal`, `generated`, `generatedBy`, `hasDeclarationRange`; top-level `constants` replaces `declarations`. |
| `scripts/verify.py` | Rewritten around explicit `check(cond, message)` calls raising `VerificationError` instead of `assert`, so `python3 -O` / `PYTHONOPTIMIZE` cannot disable acceptance (audit A3); report booleans are the validated conditions and `python_optimize` is recorded. New gates: the Lake build log must contain no `warning:`/`error:` line, `sorryAx` or `declaration uses 'sorry'`; every scanned constant must be within the allowlist and no project constant may be an `axiom` (trust scan, audit A1); every dependency checkout must have a clean working tree (`git status --porcelain`); every project module on disk (`AuditRepairs.lean`, `AuditRepairs/*.lean`, `Proofs/*.lean`) must be imported into the scanned environment. Public reconciliation now uses the provenance flag. Output line and `environment_inventory` fields extended. |
| `scripts/harness_regression.py` | **New.** Ten-fixture regression suite run in a disposable copy (sources + copied `.lake/packages` and `.lake/build`): valid package (must PASS), private `sorry` theorem, private `sorry` def, private axiom without compiler warning, user theorem inside the `StableParameters` namespace, `protected` theorem, wrong alias target (ordinary and `PYTHONOPTIMIZE=1`), orphan un-imported module, dirty dependency (all must FAIL with exit 1 and the expected message). Records exact command, verifier subprocess exit code, output tail and resulting `verification.json` per fixture into `evidence/current/harness_regression.{json,log}` (audit A4). For the two `sorry` fixtures it also runs the trust scan alone and checks the private constant is listed with `sorryAx`. |
| `docs/SOURCE_GATES.md` | G18 qualified with the cancellation counterexample (`X = EZ`, `Y = −2EZ`, `2X + Y = 0`) and the valid nonnegative-summand target (audit M1); new **G19** (p. 282 identifies regularly varying with α-stable; false, only the domain-of-attraction statement holds) (audit M2); intro sentence updated. |
| `scripts/rebuild_curated_inventory.py`, `docs/FORMALIZATION_BACKLOG.json`, `docs/FORMALIZATION_BACKLOG.md` | T029: target restricted to nonnegative variables with positive weights; gap text carries the counterexample. T093: `missing → source-check` with the G19 note. Regenerated JSON, hand-synced Markdown, 158/158 consistency re-verified. Status distribution now 93 missing / 35 source-check. |
| `FABLE_REVIEW.md` | Proof01 row: `x_min ≥ 1` → `x_min > 1`; §6.2 G18 sentence qualified; new §12 addendum (audit findings, reproduction, repairs, fixtures). |
| `evidence/fable/final/harness_negative_tests.NOTE.md` | **New.** Explains the stale-`PIPESTATUS` `exit=0` line in the preserved v0.2.1 log (audit A4). The log itself is unchanged. |
| `evidence/fable/v0.2.2/` | **New** evidence layer for this pass: clean build log, verify log, `current_after_verify/` (incl. `harness_regression.{json,log}`), `environment.md`, `declaration_inventory.md`, `RECEIVED_AUDIT_ARTIFACTS.sha256`. |
| `evidence/current/*` | Regenerated by the final v0.2.2 `verify.py` and `harness_regression.py` runs. |
| `README.md` | Version `v0.2.2`; verification description updated (trust scan of all constants, build-diagnostic gate, dependency cleanliness, import coverage, regression suite, no `assert`s). |
| `lakefile.toml` | `version = "0.2.1"` → `"0.2.2"`. |
| `SHA256SUMS` | Regenerated for the final tree. |

### Compatibility implications

- Client code: none.
- Verification workflow: `python3 scripts/verify.py` is stricter — any compiler warning in the
  build, any `private`/internal `sorry` or axiom, any un-imported project module, and any
  modified dependency checkout now fail it. Runtime ≈ 60 s. `python3 scripts/harness_regression.py`
  (≈ 11 min, needs ~6 GB scratch space under `/tmp` by default) is optional but is the
  intended acceptance test for changes to the harness itself.
- `evidence/current/inventory_environment.json` schema changed (see `FableInventory.lean` row).

### Validation performed (v0.2.2)

- `rm -rf .lake/build; lake build`: exit 0, 2643 jobs, 24 modules built, no warnings.
- `python3 scripts/verify.py`: exit 0 — `PASS: 52 theorems, 1 instance, 16 aliases; no extra
  axioms; trust scan: 137 project constants (incl. 35 internal) all within allowlist; 69 public
  theorem/instance constants match the regex inventory`.
- `python3 scripts/harness_regression.py`: exit 0; all 10 fixtures behaved as expected
  (`evidence/fable/v0.2.2/current_after_verify/harness_regression.log`).
- Documentation consistency (replacement map 16/16, backlog 158/158) re-checked.
- Final ZIP validated from a fresh extraction (`deliverables/archive_validation.log`).

---

## v0.2.0 (received) → v0.2.1

All changes relative to the received `Taleb_Lean_Implementation_Handoff.zip`
(SHA-256 `8a8fb28af0b492c34edd02275ace60b213eedac1f41ec2514505588157cab406`). The complete
unified diff, including new files, is `deliverables/fable_changes.patch` next to the final
ZIP (generated with `git diff` between the pristine-extraction commit and the final commit).
Toolchain and dependency pins are **unchanged**: `lean-toolchain`, `lake-manifest.json` and
the Mathlib `rev` in `lakefile.toml` are byte-identical to the received files.

## Mathematical statement changes

**None.** No theorem, definition, instance or alias of v0.2.0 was modified, removed,
renamed or weakened. No hypothesis was added to or removed from any existing declaration.
No proof body was edited.

Two theorems were **added** (both diagnostics, no new mathematical content):

| Declaration | Statement | Purpose |
|---|---|---|
| `AuditRV.isSlowlyVarying_neg_one` (`AuditRepairs/RegularVariation.lean`) | `IsSlowlyVarying (fun _ : ℝ => (-1 : ℝ))` | Pins the gap between the ratio-only predicate and the book's definition, whose `L` has codomain `(0, +∞)` (§2.2.1 p. 9, §E.1 p. 190, Def. 21.1 p. 380). |
| `AuditTails.frechetFormula_zero` (`AuditRepairs/Tails.lean`) | `ξ ≠ 0 → frechetFormula ξ 0 = 1` | Pins the boundary value that makes the raw formula unusable as a CDF at `x = 0` (Lean: `0 ^ (-1/ξ) = 0`), i.e. why `frechetCDF` is piecewise. |

Both depend only on `propext`, `Classical.choice`, `Quot.sound`.

## Changed files

| File | Change |
|---|---|
| `AuditRepairs/RegularVariation.lean` | + `isSlowlyVarying_neg_one` with docstring; + its `#print axioms` line. |
| `AuditRepairs/Tails.lean` | + `frechetFormula_zero` with docstring (placed between `frechetFormula` and `frechetCDF`); + its `#print axioms` line. |
| `AuditRepairs/Stable.lean` | Comment only: the remark above `submitted_alpha_one_ignores_skew` now states that the identity holds because Lean's `Real.tan (π/2) = 0` (`Real.tan_pi_div_two`), that `tan(π/2)` is mathematically undefined, that (7.2) is stated only for `α ≠ 1`, and points to `stableS1Expr` and G17. |
| `AuditVerification.lean` | Regenerated by the discovery function of `scripts/verify.py`: two `#print axioms` lines added (69 total). |
| `scripts/verify.py` | Docstring extended. After the axiom run it now executes `lake env lean scripts/FableInventory.lean`, stores `evidence/current/inventory_environment.json` and `.log`, and asserts: user-written theorem/instance constants in the environment == regex-discovered set; every project constant within the axiom allowlist; alias targets == `docs/replacement_map.json`. Report gains `environment_inventory`; PASS line extended. Failure modes are reported through the existing `FAIL` path. |
| `scripts/FableInventory.lean` | **New.** Enumerates every constant whose defining module is `AuditRepairs*`, `Proofs*` or `AuditVerification`; records kind, module, instance flag, Batteries alias target, structure-generated flag, axiom closure (`collectAxioms`) and pretty-printed type; prints one JSON document. `autoImplicit false`. Not a Lake target; run through `lake env lean`. |
| `scripts/rebuild_curated_inventory.py` | Raw rows for T007 and T029 edited (see backlog below). |
| `docs/FORMALIZATION_BACKLOG.json` | Regenerated by the script above: T007 pages `12-13;139-140;282`, anchor `2.2.9;7.2.1;15.2.1`, gap note on the 15.2.1 misprint; T029 pages `98-99`, status `missing → source-check`, target extended with the corrected formula-level statement, gap note on the sign error. Still 158 rows. |
| `docs/FORMALIZATION_BACKLOG.md` | The same two entries edited by hand to match the JSON (no shipped script generates the Markdown; JSON↔Markdown consistency of all 158 rows verified before and after). |
| `docs/SOURCE_GATES.md` | Intro sentence attributes G01–G16 to the handoff and G17–G18 to this review; + **G17** (15.2.1 S1 characteristic function printed with misplaced parentheses; α-range inconsistency) and **G18** (sign error in the displayed limit under Property 5.1). |
| `docs/REPLACEMENT_MAP.md`, `docs/replacement_map.json` | Rows 14 and 16: scope text extended ((7.2) excludes α = 1; α = 1 branch is standard S1, printed in the book only in misprinted 15.2.1). Declarations and source columns unchanged. |
| `README.md` | Title/version `v0.2.1 (Fable-reviewed)`; pointer paragraph to `FABLE_REVIEW.md`, `CHANGELOG_FABLE.md`, `evidence/fable/`; expected counts `52 theorems, 1 instance, 16 aliases (69)` with the v0.2.0 comparison; description of the environment cross-check; module list gains `scripts/FableInventory.lean`; provenance paragraph notes the reproduced 8/8 legacy result. |
| `lakefile.toml` | `version = "0.2.0"` → `"0.2.1"`. Nothing else. |
| `SHA256SUMS` | Regenerated for the final tree (all files except itself, excluding `.lake/`). The received manifest is preserved verbatim in the git history (commit `f6b1007`) and as `evidence/fable/received_current/SHA256SUMS_check_on_extracted_tree.log` records its verification. |
| `FABLE_REVIEW.md`, `CHANGELOG_FABLE.md` | **New.** |
| `evidence/current/*` | Regenerated by the final `scripts/verify.py` run (`axioms.log`, `build.log`, `declarations.json`, `verification.json`, new `inventory_environment.json`, `inventory_environment.log`). The received versions are preserved under `evidence/fable/received_current/`. |
| `evidence/fable/**` | **New** evidence tree: `README.md`; `received_current/` (received evidence + manifest checks + artifact hashes); `baseline/` (cache-get log, clean build log, verify log, `current_after_verify/`, `environment.md`, `originals_recheck/` with the 16 per-file logs and `summary.csv`); `final/` (clean build log, verify log, `current_after_verify/`, `environment.md`, `declaration_inventory.md`, `harness_negative_tests.log`). The archive-validation log cannot be inside the archive it validates; it is delivered alongside the ZIP as `deliverables/archive_validation.log`. |

Unchanged: `AuditRepairs.lean`, `AuditRepairs/Foundations.lean`, `AuditRepairs/ImplicitSetDiagnostic.lean`,
`AuditRepairs/ProbabilityBridge.lean`, all sixteen `Proofs/*.lean`, `lean-toolchain`,
`lake-manifest.json`, `docs/MATHLIB_AND_WORK_ORDER.md`, `docs/source_inventory/*`,
`scripts/build_handoff_pdf.py`, `scripts/index_book.py`, all legacy `evidence/Proof*.log`,
`evidence/aggregate.log`, `evidence/summary.json`, `evidence/build_environment.md`,
`evidence/proof09_probe.log`, `evidence/source/mathlib-proofs-16.zip`.

## Compatibility implications

- **Client code:** none. Every v0.2.0 declaration keeps its name, statement and namespace;
  `import AuditRepairs` and `Taleb.ProofNN.repaired` behave identically.
- **Verification workflow:** `python3 scripts/verify.py` takes about 40 s longer (the
  environment inventory) and now fails on three additional conditions (see `scripts/verify.py`
  docstring). Anyone adding a declaration must, as before, regenerate `AuditVerification.lean`;
  in addition, declarations written in a form the regex does not see (`protected`, attributes
  on the same line, `section`s) now cause a hard failure instead of silent omission.
- **Counts:** documents that quote "50 theorems / 67 checked" describe v0.2.0; the companion
  PDF `Taleb_Lean_Handoff_and_Formalization_Backlog.pdf` was not regenerated (it is a received
  artifact and would require `reportlab`), so its figures refer to v0.2.0.
- **Backlog:** status distribution changes from 95 missing / 33 source-check to
  94 missing / 34 source-check (T029). Total families unchanged at 158.

## Validation performed

- Baseline (received source, unmodified): clean `lake build` exit 0; `scripts/verify.py`
  exit 0, `PASS: 50 theorems, 1 instance, 16 aliases`; regenerated `verification.json`
  identical to the received one except `elapsed_seconds`; 16 original files re-checked with
  identical per-file results to `evidence/summary.json` (8 pass / 8 fail).
- Final (repaired source): `rm -rf .lake/build; lake build` exit 0 (26 s, 2643 jobs, 24
  modules built, no warnings/errors); `scripts/verify.py` exit 0,
  `PASS: 52 theorems, 1 instance, 16 aliases; … environment cross-check: 102 project
  constants, 69 user theorem/instance, all within allowlist`.
- Axioms: 69/69 exported declarations and 102/102 environment constants have exactly
  `{propext, Classical.choice, Quot.sound}`; no `sorryAx`.
- Harness negative tests: an appended `protected theorem` → `FAIL: Environment/regex
  inventory mismatch: ['AuditRV.regex_blind_spot']`; a wrong alias target in
  `docs/replacement_map.json` → `FAIL: Alias targets differ …`. Both reverted byte-identically.
- Documentation consistency: `docs/REPLACEMENT_MAP.md` ↔ `docs/replacement_map.json`
  (16/16) and `docs/FORMALIZATION_BACKLOG.md` ↔ `.json` (158/158) checked programmatically.
- Archive: the final ZIP was extracted into a fresh directory with no project build outputs,
  the pinned dependency checkouts and cache were copied in, `SHA256SUMS` verified, `lake build`
  and `scripts/verify.py` re-run there, and the resulting Lean source hashes compared with
  those of the working tree (`deliverables/archive_validation.log`, alongside the ZIP).
