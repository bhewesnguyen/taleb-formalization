/-
  Proof 10/16 — Fréchet max-stability.

  Mathlib submission candidate: for `ξ > 0` and `x > 0`,
  `G(x)^n = G(n^{-ξ}·x)` where `G(x) = exp(−x^{−1/ξ})` is the
  Fréchet CDF — the maximum of `n` i.i.d. Fréchet variables stays
  Fréchet up to scaling (the algebraic heart of extreme value theory).
  Proof body verified in `FatTails/Machinery/ExtremeValue.lean`.

  Note: stated for `x > 0` (the Fréchet support); a Mathlib version
  may want the CDF extended by `0` on `x ≤ 0`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Fréchet CDF (GEV with `ξ > 0`, standardized): `G(x) = exp(−x^{−1/ξ})`. -/
noncomputable def frechetCDF (ξ : ℝ) (x : ℝ) : ℝ :=
  Real.exp (-(x ^ (-1 / ξ)))

/-- Fréchet max-stability: `G(x)^n = G(n^{−ξ}·x)`. -/
theorem frechet_maxstable {ξ : ℝ} (hξ : 0 < ξ) {x : ℝ} (hx : 0 < x) (n : ℕ) :
    (frechetCDF ξ x) ^ n = frechetCDF ξ ((n : ℝ) ^ (-ξ) * x) := by
  simp only [frechetCDF]
  have hn : (0:ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
  -- (n^{-ξ} x)^{-1/ξ} = n · x^{-1/ξ}
  have e : ((n : ℝ) ^ (-ξ) * x) ^ (-1 / ξ) = n * x ^ (-1 / ξ) := by
    rw [Real.mul_rpow (Real.rpow_nonneg hn _) (le_of_lt hx)]
    -- (n^{-ξ})^{-1/ξ} = n^{(-ξ)(-1/ξ)} = n^1 = n
    have h1 : ((n : ℝ) ^ (-ξ)) ^ (-1 / ξ) = n := by
      have hξ0 : ξ ≠ 0 := ne_of_gt hξ
      rw [← Real.rpow_mul hn]
      have h2 : (-ξ) * (-1 / ξ) = 1 := by field_simp
      rw [h2, Real.rpow_one]
    rw [h1]
  rw [e, ← Real.exp_nat_mul]
  congr 1
  ring
