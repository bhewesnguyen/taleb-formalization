/-
  Proof 14/16 — the `α = 1, β = 0` case of the stable characteristic
  function is Cauchy-form.

  Mathlib submission candidate: for `σ > 0`, the `α = 1` case reduces
  to `exp(−σ|t|)` (the `β = 0` factor kills the `tan(π/2)` term).
  Proof body verified in `FatTails/Machinery/StableLaw.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Characteristic function of the α-stable law `S(α, β, μ, σ)`:
    `χ(t) = exp(−r + i(μt + rβw))` with `r = |σt|^α`,
    `w = tan(πα/2)·sgn(t)` (Zolotarev A parametrization). -/
noncomputable def stableCharFn (α β μ σ : ℝ) (t : ℝ) : ℂ :=
  let r : ℝ := |σ * t| ^ α
  let w : ℝ := Real.tan (Real.pi * α / 2) * Real.sign t
  Complex.exp ⟨-r, μ * t + r * β * w⟩

/-- The `α = 1` case of `stableCharFn` (for `σ > 0`) is Cauchy-form:
    `exp(−σ|t|)`. -/
theorem stableCharFn_cauchy {σ t : ℝ} (hσ : 0 < σ) :
    stableCharFn 1 0 σ 0 t = Complex.exp ⟨-(σ * |t|), 0⟩ := by
  unfold stableCharFn
  dsimp only
  congr 1
  apply Complex.ext
  · simp [Real.rpow_one, abs_mul, abs_of_pos hσ]
  · simp
