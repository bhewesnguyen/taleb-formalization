/-
  Proof 15/16 — Cauchy stability under sums.

  Mathlib submission candidate: `(exp(−σ|t|))^n = exp(−(nσ)|t|)` —
  sums of i.i.d. Cauchy stay Cauchy (the book's canonical `α = 1`
  example, Ch. 8).
  Proof body verified in `FatTails/Machinery/StableLaw.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Cauchy stability, real form: `φ(t)^n = φ_{nσ}(t)`. -/
theorem cauchy_stable {σ t : ℝ} (n : ℕ) :
    (Real.exp (-(σ * |t|))) ^ n = Real.exp (-((n * σ) * |t|)) := by
  rw [← Real.exp_nat_mul]
  congr 1
  push_cast
  ring
