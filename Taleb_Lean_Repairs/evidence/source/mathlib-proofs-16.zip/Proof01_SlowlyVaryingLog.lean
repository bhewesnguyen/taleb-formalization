/-
  Proof 1/16 — `Real.log` is slowly varying.

  Mathlib submission candidate. Regular variation does not yet exist in
  Mathlib, so this proposes the definition and the first lemma.
  Proposed location: new file `Mathlib/Analysis/Asymptotics/RegularVariation.lean`.

  Proof body verified in `FatTails/Machinery/RegularVariation.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- A function `L : ℝ → ℝ` is *slowly varying* (at `+∞`) if
    `L (b * x) / L x → 1` as `x → ∞` for every `b > 0`.
    (Karamata; see Bingham–Goldie–Teugels, *Regular Variation*.) -/
def IsSlowlyVarying (L : ℝ → ℝ) : Prop :=
  ∀ k : ℝ, 0 < k → Tendsto (fun x => L (k * x) / L x) atTop (𝓝 1)

/-- `Real.log` is slowly varying:
    `log (b * x) / log x = 1 + log b / log x → 1`. -/
theorem isSlowlyVarying_log : IsSlowlyVarying (fun x => Real.log x) := by
  intro b hb
  have e : (fun x => Real.log (b * x) / Real.log x) =ᶠ[atTop]
      (fun x => 1 + Real.log b / Real.log x) := by
    filter_upwards [eventually_gt_atTop 1] with x hx
    have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx
    have hlogx : Real.log x ≠ 0 := ne_of_gt (Real.log_pos hx)
    rw [Real.log_mul (ne_of_gt hb) (ne_of_gt hx0)]
    field_simp
    ring
  have hlog : Tendsto (fun x => Real.log x) atTop atTop := Real.tendsto_log_atTop
  have hdiv : Tendsto (fun x => Real.log b / Real.log x) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop hlog
  have hadd : Tendsto (fun x => (1:ℝ) + Real.log b / Real.log x) atTop (𝓝 (1 + 0)) :=
    tendsto_const_nhds.add hdiv
  rw [add_zero] at hadd
  exact Tendsto.congr' e.symm hadd
