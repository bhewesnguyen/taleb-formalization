/-
  Proof 4/16 — products of regularly varying functions add indices.

  Mathlib submission candidate: if `L₁ ∈ RV_{α₁}` and `L₂ ∈ RV_{α₂}`
  then `L₁·L₂ ∈ RV_{α₁+α₂}`.
  Proof body verified in `FatTails/Machinery/RegularVariation.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- A function `L : ℝ → ℝ` is *slowly varying* (at `+∞`) if
    `L (b * x) / L x → 1` as `x → ∞` for every `b > 0`.
    (Karamata; see Bingham–Goldie–Teugels, *Regular Variation*.) -/
def IsSlowlyVarying (L : ℝ → ℝ) : Prop :=
  ∀ k : ℝ, 0 < k → Tendsto (fun x => L (k * x) / L x) atTop (𝓝 1)

/-- `f` is *regularly varying of index `ρ`* (at `+∞`) if
    `f (b * x) / f x → b^ρ` as `x → ∞` for every `b > 0`.
    Slow variation is the case `ρ = 0`. -/
def IsRegularlyVarying (f : ℝ → ℝ) (ρ : ℝ) : Prop :=
  ∀ b : ℝ, 0 < b → Tendsto (fun x => f (b * x) / f x) atTop (𝓝 (b ^ ρ))

/-- Products of regularly varying functions add indices:
    `RV_{α₁} · RV_{α₂} ⊆ RV_{α₁+α₂}`. -/
theorem IsRegularlyVarying.mul {L₁ L₂ : ℝ → ℝ} {α₁ α₂ : ℝ}
    (h₁ : IsRegularlyVarying L₁ α₁) (h₂ : IsRegularlyVarying L₂ α₂) :
    IsRegularlyVarying (fun x => L₁ x * L₂ x) (α₁ + α₂) := by
  intro b hb
  have e : (fun x => (L₁ (b * x) * L₂ (b * x)) / (L₁ x * L₂ x)) =ᶠ[atTop]
      (fun x => (L₁ (b * x) / L₁ x) * (L₂ (b * x) / L₂ x)) := by
    filter_upwards with x
    rw [div_mul_div_comm]
  have hlim := (h₁ b hb).mul (h₂ b hb)
  rw [← Real.rpow_add hb] at hlim
  exact Tendsto.congr' e.symm hlim
