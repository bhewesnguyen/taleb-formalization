/-
  Proof 12/16 — the `α = 2` case of the stable characteristic function
  is Gaussian-form.

  Mathlib submission candidate: for the α-stable characteristic function
  `χ(t) = exp(−|σt|^α + i(μt + |σt|^α β tan(πα/2) sgn(t)))`,
  the `α = 2` case reduces to `exp(−(σt)²)`.
  Proof body verified in `FatTails/Machinery/StableLaw.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Characteristic function of the α-stable law `S(α, β, μ, σ)`:
    `χ(t) = exp(−r + i(μt + rβw))` with `r = |σt|^α`,
    `w = tan(πα/2)·sgn(t)` (Zolotarev A parametrization). -/
noncomputable def stableCharFn (α β μ σ : ℝ) (t : ℝ) : ℂ :=
  let r : ℝ := |σ * t| ^ α
  let w : ℝ := Real.tan (Real.pi * α / 2) * Real.sign t
  Complex.exp ⟨-r, μ * t + r * β * w⟩

/-- The `α = 2` case of `stableCharFn` is Gaussian-form: `exp(−(σt)²)`.
    Note: with this parametrization the variance is `2σ²`. -/
theorem stableCharFn_gaussian {σ t : ℝ} :
    stableCharFn 2 0 σ 0 t = Complex.exp ⟨-(σ * t) ^ 2, 0⟩ := by
  unfold stableCharFn
  dsimp only
  congr 1
  apply Complex.ext
  · simp [Real.rpow_two, sq_abs]
  · simp
