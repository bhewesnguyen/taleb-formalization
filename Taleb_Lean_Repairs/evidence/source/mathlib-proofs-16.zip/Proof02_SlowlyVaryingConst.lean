/-
  Proof 2/16 — nonzero constant functions are slowly varying.

  Mathlib submission candidate (companion to Proof 1).
  Proof body verified in `FatTails/Machinery/RegularVariation.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- A function `L : ℝ → ℝ` is *slowly varying* (at `+∞`) if
    `L (b * x) / L x → 1` as `x → ∞` for every `b > 0`.
    (Karamata; see Bingham–Goldie–Teugels, *Regular Variation*.) -/
def IsSlowlyVarying (L : ℝ → ℝ) : Prop :=
  ∀ k : ℝ, 0 < k → Tendsto (fun x => L (k * x) / L x) atTop (𝓝 1)

/-- Every nonzero constant function is slowly varying. -/
theorem isSlowlyVarying_const {c : ℝ} (hc : c ≠ 0) :
    IsSlowlyVarying (fun _ => c) := by
  intro b hb
  have e : (fun _ : ℝ => (1:ℝ)) =ᶠ[atTop]
      (fun x : ℝ => (fun _ => c) (b * x) / (fun _ => c) x) := by
    filter_upwards with x
    simp only []
    rw [div_self hc]
  exact Tendsto.congr' e tendsto_const_nhds
