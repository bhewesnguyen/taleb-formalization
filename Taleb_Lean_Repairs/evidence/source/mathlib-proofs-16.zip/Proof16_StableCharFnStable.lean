/-
  Proof 16/16 — general α-stability of the stable characteristic function.

  Mathlib submission candidate: the `n`-th power of the stable
  characteristic function is again stable-form, with `σ ↦ n^{1/α}·σ`
  and `μ ↦ n·μ`. In probabilistic language: the sum of `n` i.i.d.
  `S(α,β,μ,σ)` variables is `S(α,β,nμ,n^{1/α}σ)`.

  Holds for every `α > 0`; the `tan(πα/2)` skewness factor is carried
  through untouched by the algebra. (Proofs 12–15 are the Gaussian
  and Cauchy instances.)
  Proof body verified in `FatTails/Machinery/StableLaw.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Characteristic function of the α-stable law `S(α, β, μ, σ)`:
    `χ(t) = exp(−r + i(μt + rβw))` with `r = |σt|^α`,
    `w = tan(πα/2)·sgn(t)` (Zolotarev A parametrization). -/
noncomputable def stableCharFn (α β μ σ : ℝ) (t : ℝ) : ℂ :=
  let r : ℝ := |σ * t| ^ α
  let w : ℝ := Real.tan (Real.pi * α / 2) * Real.sign t
  Complex.exp ⟨-r, μ * t + r * β * w⟩

/-- General α-stability: `(χ_{α,β,μ,σ}(t))^n = χ_{α,β,nμ,n^{1/α}σ}(t)`. -/
theorem stableCharFn_stable {α β μ σ : ℝ} (n : ℕ) (t : ℝ)
    (hα : 0 < α) :
    (stableCharFn α β μ σ t) ^ n
      = stableCharFn α β (n * μ) ((n : ℝ) ^ (1/α) * σ) t := by
  have hn : (0:ℝ) ≤ (n:ℝ) := Nat.cast_nonneg n
  have hα0 : α ≠ 0 := ne_of_gt hα
  -- Key rpow identity: the scaled `|σ't|^α` equals `n * |σt|^α`.
  have key : |((n:ℝ)^(1/α) * σ) * t| ^ α = n * |σ * t| ^ α := by
    have h1 : |(n:ℝ)^(1/α)| = (n:ℝ)^(1/α) :=
      abs_of_nonneg (Real.rpow_nonneg hn _)
    have e1 : |((n:ℝ)^(1/α) * σ) * t| = (n:ℝ)^(1/α) * (|σ| * |t|) := by
      rw [abs_mul, abs_mul, h1]; ring
    rw [e1, Real.mul_rpow (Real.rpow_nonneg hn _)
      (mul_nonneg (abs_nonneg _) (abs_nonneg _)),
      ← Real.rpow_mul hn, show (1/α : ℝ) * α = 1 by field_simp,
      Real.rpow_one, ← abs_mul]
  unfold stableCharFn
  dsimp only
  rw [← Complex.exp_nat_mul, key]
  congr 1
  apply Complex.ext <;> simp <;> ring
