/-
  Proof 6/16 — regular variation iff the normalized function is slowly varying.

  Mathlib submission candidate: for eventually positive `L`,
  `L ∈ RV_α ↔ (fun x => L x / x^α)` is slowly varying.
  (Bingham–Goldie–Teugels, Theorem 1.4.1.)
  Proof body verified in `FatTails/Machinery/RegularVariation.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- A function `L : ℝ → ℝ` is *slowly varying* (at `+∞`) if
    `L (b * x) / L x → 1` as `x → ∞` for every `b > 0`.
    (Karamata; see Bingham–Goldie–Teugels, *Regular Variation*.) -/
def IsSlowlyVarying (L : ℝ → ℝ) : Prop :=
  ∀ k : ℝ, 0 < k → Tendsto (fun x => L (k * x) / L x) atTop (𝓝 1)

/-- `f` is *regularly varying of index `ρ`* (at `+∞`) if
    `f (b * x) / f x → b^ρ` as `x → ∞` for every `b > 0`.
    Slow variation is the case `ρ = 0`. -/
def IsRegularlyVarying (f : ℝ → ℝ) (ρ : ℝ) : Prop :=
  ∀ b : ℝ, 0 < b → Tendsto (fun x => f (b * x) / f x) atTop (𝓝 (b ^ ρ))

/-- Regular variation of index `α` iff `L(x)/x^α` is slowly varying
    (for eventually positive `L`). -/
theorem isRegularlyVarying_iff_slowlyVarying {L : ℝ → ℝ} {α : ℝ}
    (hpos : ∀ᶠ x in atTop, 0 < L x) :
    IsRegularlyVarying L α ↔ IsSlowlyVarying (fun x => L x / x ^ α) := by
  have hmul : ∀ {b : ℝ}, 0 < b → Tendsto (fun x => b * x) atTop atTop :=
    fun hb => Filter.Tendsto.const_mul_atTop hb tendsto_id
  constructor
  · intro h b hb
    have hL := h b hb
    have hpos' : ∀ᶠ x in atTop, 0 < L (b * x) := (hmul hb).eventually hpos
    have e : (fun x => (L (b * x) / (b * x) ^ α) / (L x / x ^ α)) =ᶠ[atTop]
        (fun x => (L (b * x) / L x) / (b ^ α)) := by
      filter_upwards [eventually_gt_atTop 1, hpos, hpos'] with x hx hx1 hx2
      have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx
      have hbα : b ^ α ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hb α)
      have hxα : x ^ α ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hx0 α)
      have hLx : L x ≠ 0 := ne_of_gt hx1
      rw [Real.mul_rpow (le_of_lt hb) (le_of_lt hx0)]
      field_simp
      ring
    have hbα : b ^ α ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hb α)
    have hlim := hL.div_const (b ^ α)
    rw [div_self hbα] at hlim
    exact Tendsto.congr' e.symm hlim
  · intro h b hb
    have hS := h b hb
    have hpos' : ∀ᶠ x in atTop, 0 < L (b * x) := (hmul hb).eventually hpos
    have e : (fun x => L (b * x) / L x) =ᶠ[atTop]
        (fun x => ((L (b * x) / (b * x) ^ α) / (L x / x ^ α)) * b ^ α) := by
      filter_upwards [eventually_gt_atTop 1, hpos, hpos'] with x hx hx1 hx2
      have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx
      have hbα : b ^ α ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hb α)
      have hxα : x ^ α ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hx0 α)
      have hLx : L x ≠ 0 := ne_of_gt hx1
      rw [Real.mul_rpow (le_of_lt hb) (le_of_lt hx0)]
      field_simp
      ring
    have hlim := hS.mul tendsto_const_nhds
    rw [one_mul] at hlim
    exact Tendsto.congr' e.symm hlim
