/-
  Proof 7/16 — exact Pareto tails have tail exponent `α`.

  Mathlib submission candidate: for `S(x) = C·x^{-α}` with `C, α > 0`,
  `liminf_{x→∞} −log S(x)/log x = α`.
  Proof body verified in `FatTails/Machinery/TailCalculus.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- The *tail exponent* of a survival function `S`, via the log-ratio
    `liminf −log S(x) / log x` (book §2.2.1: `α = −lim log S(x)/log x`). -/
noncomputable def tailExponent (S : ℝ → ℝ) : ℝ :=
  Filter.liminf (fun x => -Real.log (S x) / Real.log x) atTop

/-- For an exact Pareto tail `S(x) = C·x^{-α}`, the log-ratio converges to `α`. -/
theorem tailExponent_pareto {C α : ℝ} (hC : 0 < C) (hα : 0 < α) :
    Tendsto (fun x => -Real.log (C * x ^ (-α)) / Real.log x) atTop (𝓝 α) := by
  have e : (fun x => -Real.log (C * x ^ (-α)) / Real.log x) =ᶠ[atTop]
      (fun x => α + -Real.log C / Real.log x) := by
    filter_upwards [eventually_gt_atTop 1] with x hx
    have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx
    have hxα : x ^ (-α) ≠ 0 := ne_of_gt (Real.rpow_pos_of_pos hx0 _)
    have hlogx : Real.log x ≠ 0 := ne_of_gt (Real.log_pos hx)
    rw [Real.log_mul (ne_of_gt hC) hxα, Real.log_rpow hx0]
    field_simp
    ring
  have hlog : Tendsto (fun x => Real.log x) atTop atTop := Real.tendsto_log_atTop
  have hdiv : Tendsto (fun _ : ℝ => -Real.log C / Real.log _) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop hlog
  have hadd : Tendsto (fun _ : ℝ => α + -Real.log C / Real.log _) atTop (𝓝 (α + 0)) :=
    tendsto_const_nhds.add hdiv
  rw [add_zero] at hadd
  exact Tendsto.congr' e.symm hadd
