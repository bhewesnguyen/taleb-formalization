/-
  Proof 3/16 — a function tending to a nonzero constant is slowly varying.

  Mathlib submission candidate (companion to Proofs 1–2).
  Proof body verified in `FatTails/Machinery/RegularVariation.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- A function `L : ℝ → ℝ` is *slowly varying* (at `+∞`) if
    `L (b * x) / L x → 1` as `x → ∞` for every `b > 0`.
    (Karamata; see Bingham–Goldie–Teugels, *Regular Variation*.) -/
def IsSlowlyVarying (L : ℝ → ℝ) : Prop :=
  ∀ k : ℝ, 0 < k → Tendsto (fun x => L (k * x) / L x) atTop (𝓝 1)

/-- If `L x → c ≠ 0` then `L` is slowly varying
    (the ratio `L(bx)/L(x)` inherits the limit `c/c = 1`). -/
theorem IsSlowlyVarying.of_tendsto_const {L : ℝ → ℝ} {c : ℝ} (hc : c ≠ 0)
    (hL : Tendsto L atTop (𝓝 c)) : IsSlowlyVarying L := by
  intro b hb
  have hmul : Tendsto (fun x => b * x) atTop atTop :=
    Filter.Tendsto.const_mul_atTop hb tendsto_id
  have h1 : Tendsto (fun x => L (b * x)) atTop (𝓝 c) := hmul.comp hL
  have h2 : Tendsto (fun x => L (b * x) / L x) atTop (𝓝 (c / c)) :=
    h1.div hL hc
  rw [div_self hc] at h2
  exact h2
