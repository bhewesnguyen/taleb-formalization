/-
  Proof 8/16 — subexponential sums preserve the tail exponent.

  Mathlib submission candidate: if `S₂(x)/S(x) → 2` (subexponentiality)
  and the log-ratio for `S` converges to `α`, the log-ratio for `S₂`
  also converges to `α` — the "single big jump" principle at the level
  of tail exponents (book §2.2.12).
  Proof body verified in `FatTails/Machinery/Subexponential.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Subexponentiality: `S₂(x)/S(x) → 2` as `x → ∞`, where `S` is a
    survival function and `S₂` the survival function of the sum of two
    independent copies. When the sum is large, asymptotically exactly
    one summand is large (book §2.2.12, Eq. (2.7)). -/
def IsSubexponential (S S₂ : ℝ → ℝ) : Prop :=
  Tendsto (fun x => S₂ x / S x) atTop (𝓝 2)

/-- Subexponential sums preserve the tail exponent: the log-ratio
    `−log S₂(x)/log x` converges to the same `α` as for `S`. -/
theorem IsSubexponential.tailExponent {S S₂ : ℝ → ℝ} {α : ℝ}
    (hsub : IsSubexponential S S₂)
    (hS : Tendsto (fun x => -Real.log (S x) / Real.log x) atTop (𝓝 α))
    (hS₂ : ∀ᶠ x in atTop, S₂ x ≠ 0)
    (hSpos : ∀ᶠ x in atTop, 0 < S x) :
    Tendsto (fun x => -Real.log (S₂ x) / Real.log x) atTop (𝓝 α) := by
  -- −log S₂/log x = (−log(S₂/S) − log S)/log x
  have e : (fun x => -Real.log (S₂ x) / Real.log x) =ᶠ[atTop]
      (fun x => (-Real.log (S₂ x / S x) - Real.log (S x)) / Real.log x) := by
    filter_upwards [eventually_gt_atTop 1, hS₂, hSpos] with x hx hx2 hx1
    have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx
    have hlogx : Real.log x ≠ 0 := ne_of_gt (Real.log_pos hx)
    rw [Real.log_div hx2 (ne_of_gt hx1)]
    field_simp
    ring
  -- −log(S₂/S)/log x → −log 2 / ∞ = 0
  have hlog : Tendsto (fun x => Real.log x) atTop atTop := Real.tendsto_log_atTop
  have hratio : Tendsto (fun x => S₂ x / S x) atTop (𝓝 2) := hsub
  have hlog2 : Tendsto (fun x => Real.log (S₂ x / S x)) atTop (𝓝 (Real.log 2)) :=
    (Real.continuousAt_log (by norm_num : (2:ℝ) ≠ 0)).tendsto.comp hratio
  have hzero : Tendsto (fun x => -Real.log (S₂ x / S x) / Real.log x) atTop (𝓝 0) :=
    hlog2.neg.div_atTop hlog
  -- (−log(S₂/S) − log S)/log x = (−log(S₂/S))/log x + (−log S)/log x → 0 + α
  have esplit : (fun x => (-Real.log (S₂ x / S x) - Real.log (S x)) / Real.log x) =ᶠ[atTop]
      (fun x => -Real.log (S₂ x / S x) / Real.log x + -Real.log (S x) / Real.log x) := by
    filter_upwards [eventually_gt_atTop 1] with x hx
    have hx0 : (0:ℝ) < x := lt_trans zero_lt_one hx
    have hlogx : Real.log x ≠ 0 := ne_of_gt (Real.log_pos hx)
    field_simp
    ring
  have hsum : Tendsto
      (fun x => -Real.log (S₂ x / S x) / Real.log x + -Real.log (S x) / Real.log x)
      atTop (𝓝 (0 + α)) := hzero.add hS
  rw [zero_add] at hsum
  exact Tendsto.congr' e.symm (Tendsto.congr' esplit hsum)
