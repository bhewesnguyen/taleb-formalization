/-
  Proof 13/16 — Gaussian stability under sums.

  Mathlib submission candidate: `(exp(−(σt)²))^n = exp(−(√n·σ·t)²)` —
  the `n`-th power of the Gaussian characteristic function is again
  Gaussian-form with scaled parameter (sums of i.i.d. Gaussians stay
  Gaussian).
  Proof body verified in `FatTails/Machinery/StableLaw.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Gaussian stability, real form: the `n`-th power of the Gaussian
    ch.f. is again Gaussian-form with scaled parameter. -/
theorem gaussian_stable_real {σ t : ℝ} (n : ℕ) :
    (Real.exp (-(σ * t) ^ 2)) ^ n
      = Real.exp (-(((n : ℝ) ^ (1 / 2 : ℝ)) * σ * t) ^ 2) := by
  rw [← Real.exp_nat_mul]
  congr 1
  have hn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
  have h1 : (((n : ℝ) ^ (1 / 2 : ℝ)) * σ * t) ^ 2 = n * (σ * t) ^ 2 := by
    have h2 : ((n : ℝ) ^ (1 / 2 : ℝ)) ^ 2 = n := by
      rw [← Real.sqrt_eq_rpow, Real.sq_sqrt hn]
    calc (((n : ℝ) ^ (1 / 2 : ℝ)) * σ * t) ^ 2
        = ((n : ℝ) ^ (1 / 2 : ℝ)) ^ 2 * (σ * t) ^ 2 := by ring
      _ = n * (σ * t) ^ 2 := by rw [h2]
  push_cast
  rw [h1]
  ring
