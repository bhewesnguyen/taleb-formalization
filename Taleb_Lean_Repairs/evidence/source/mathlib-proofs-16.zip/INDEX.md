# Mathlib submission candidates — missing foundations for the Taleb fat-tails formalization

16 labeled, self-contained proofs. Each file has uniform Mathlib-only imports,
docstrings, and the needed definitions; no project dependencies.
Proof bodies are the verified versions from `FatTails/Machinery/`.

| # | File | Theorem | What it says |
|---|------|---------|--------------|
| 1 | Proof01_SlowlyVaryingLog.lean | `isSlowlyVarying_log` | `Real.log` is slowly varying |
| 2 | Proof02_SlowlyVaryingConst.lean | `isSlowlyVarying_const` | nonzero constants are slowly varying |
| 3 | Proof03_SlowlyVaryingOfTendsto.lean | `IsSlowlyVarying.of_tendsto_const` | limit of nonzero constant → slowly varying |
| 4 | Proof04_RegularlyVaryingMul.lean | `IsRegularlyVarying.mul` | products add indices |
| 5 | Proof05_RegularlyVaryingRpow.lean | `IsRegularlyVarying.rpow` | powers scale the index |
| 6 | Proof06_RVIffSlowlyVarying.lean | `isRegularlyVarying_iff_slowlyVarying` | `RV(α) ↔` normalized `L(x)/x^α` slowly varying |
| 7 | Proof07_TailExponentPareto.lean | `tailExponent_pareto` | Pareto tail exponent = `α` |
| 8 | Proof08_SubexponentialTailExponent.lean | `IsSubexponential.tailExponent` | subexp sums keep the tail exponent |
| 9 | Proof09_ConvexOnRpowNeg.lean | `convexOn_rpow_neg_right` | `α ↦ c^(-α)` convex for `c > 0` |
| 10 | Proof10_FrechetMaxstable.lean | `frechet_maxstable` | Fréchet max-stability |
| 11 | Proof11_GumbelMaxstable.lean | `gumbel_maxstable` | Gumbel max-stability |
| 12 | Proof12_StableCharFnGaussian.lean | `stableCharFn_gaussian` | `α=2` case is Gaussian-form |
| 13 | Proof13_GaussianStable.lean | `gaussian_stable_real` | Gaussian stability under sums |
| 14 | Proof14_StableCharFnCauchy.lean | `stableCharFn_cauchy` | `α=1,β=0` case is Cauchy-form |
| 15 | Proof15_CauchyStable.lean | `cauchy_stable` | Cauchy stability under sums |
| 16 | Proof16_StableCharFnStable.lean | `stableCharFn_stable` | general α-stability |

Reviewer notes (for Jake):
- Proofs 1–6 propose the `IsSlowlyVarying` / `IsRegularlyVarying` definitions
  (regular variation is not yet in Mathlib).
- Proofs 10–11 are stated on the natural support (`x > 0` for Fréchet);
  a Mathlib version may extend the CDFs by 0.
- Proofs 12–16 use the Zolotarev-A parametrization documented in each file.
