/-
  Proof 9/16 — convexity of the exponent map `α ↦ c^{-α}`.

  Mathlib submission candidate: for fixed `c > 0`, the map
  `α ↦ c^(-α)` is convex on all of `ℝ`. This is the analytic core
  behind the book's Chapter 21 convexity results (Propositions 21.1–21.4).
  Proof body verified in `FatTails/Machinery/Convexity.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- For fixed `c > 0`, the exponent map `α ↦ c^(-α)` is convex on `ℝ`.
    (Compare `convexOn_exp`, `ConvexOn.comp_affineMap`.) -/
theorem convexOn_rpow_neg_right {c : ℝ} (hc : 0 < c) :
    ConvexOn ℝ univ (fun α : ℝ => c ^ (-α)) := by
  -- c^{-α} = exp(−α · log c), an affine reparameterization of exp
  have e : (fun α : ℝ => c ^ (-α)) = (fun α : ℝ => Real.exp ((-Real.log c) * α)) := by
    funext α
    rw [Real.rpow_def_of_pos hc]
    congr 1
    ring
  rw [e]
  have hexp : ConvexOn ℝ univ (fun x : ℝ => Real.exp x) := convexOn_exp
  -- exp ∘ (affine) is convex
  have haff : ConvexOn ℝ univ (fun α : ℝ => (-Real.log c) * α) := by
    constructor
    · exact convex_univ
    · intro x _ y _ a b ha hb hab
      simp only [smul_eq_mul]
      show (-Real.log c) * (a * x + b * y) ≤ a * ((-Real.log c) * x) + b * ((-Real.log c) * y)
      rw [mul_add]
      congr 1 <;> ring
  exact hexp.comp_affineMap haff
