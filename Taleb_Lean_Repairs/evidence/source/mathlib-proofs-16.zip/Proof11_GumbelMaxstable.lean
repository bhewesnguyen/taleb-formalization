/-
  Proof 11/16 — Gumbel max-stability.

  Mathlib submission candidate: `G(x)^n = G(x − log n)` where
  `G(x) = exp(−e^{−x})` is the Gumbel CDF — the maximum of `n`
  i.i.d. Gumbel variables stays Gumbel up to location shift.
  Proof body verified in `FatTails/Machinery/ExtremeValue.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- Gumbel CDF (GEV with `ξ = 0`): `G(x) = exp(−e^{−x})`. -/
noncomputable def gumbelCDF (x : ℝ) : ℝ :=
  Real.exp (-Real.exp (-x))

/-- Gumbel max-stability: `G(x)^n = G(x − log n)`. -/
theorem gumbel_maxstable {x : ℝ} (n : ℕ) (hn : 0 < n) :
    (gumbelCDF x) ^ n = gumbelCDF (x - Real.log n) := by
  simp only [gumbelCDF]
  have hn0 : (0:ℝ) < n := Nat.cast_pos.mpr hn
  have e : Real.exp (-(x - Real.log n)) = n * Real.exp (-x) := by
    have h1 : -(x - Real.log n) = -x + Real.log n := by ring
    rw [h1, Real.exp_add, Real.exp_log hn0]
    ring
  rw [e, ← Real.exp_nat_mul]
  congr 1
  ring
