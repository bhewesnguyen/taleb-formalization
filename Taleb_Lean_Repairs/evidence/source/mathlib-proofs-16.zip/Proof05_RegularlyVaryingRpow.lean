/-
  Proof 5/16 — powers of regularly varying functions scale the index.

  Mathlib submission candidate: if `L ∈ RV_α` (eventually positive)
  then `L^p ∈ RV_{pα}`.
  Proof body verified in `FatTails/Machinery/RegularVariation.lean`.
-/

import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Real.Sign
import Mathlib.Topology.Algebra.Order.Field

open Filter Topology

/-- A function `L : ℝ → ℝ` is *slowly varying* (at `+∞`) if
    `L (b * x) / L x → 1` as `x → ∞` for every `b > 0`.
    (Karamata; see Bingham–Goldie–Teugels, *Regular Variation*.) -/
def IsSlowlyVarying (L : ℝ → ℝ) : Prop :=
  ∀ k : ℝ, 0 < k → Tendsto (fun x => L (k * x) / L x) atTop (𝓝 1)

/-- `f` is *regularly varying of index `ρ`* (at `+∞`) if
    `f (b * x) / f x → b^ρ` as `x → ∞` for every `b > 0`.
    Slow variation is the case `ρ = 0`. -/
def IsRegularlyVarying (f : ℝ → ℝ) (ρ : ℝ) : Prop :=
  ∀ b : ℝ, 0 < b → Tendsto (fun x => f (b * x) / f x) atTop (𝓝 (b ^ ρ))

/-- Powers scale the index: `L ∈ RV_α` (eventually positive)
    implies `L^p ∈ RV_{pα}`. -/
theorem IsRegularlyVarying.rpow {L : ℝ → ℝ} {α p : ℝ}
    (hL : IsRegularlyVarying L α) (hpos : ∀ᶠ x in atTop, 0 < L x) :
    IsRegularlyVarying (fun x => (L x) ^ p) (p * α) := by
  have hmul : ∀ {b : ℝ}, 0 < b → Tendsto (fun x => b * x) atTop atTop :=
    fun hb => Filter.Tendsto.const_mul_atTop hb tendsto_id
  intro b hb
  have hL' := hL b hb
  have hpos' : ∀ᶠ x in atTop, 0 < L (b * x) := (hmul hb).eventually hpos
  have e : (fun x => (L (b * x)) ^ p / (L x) ^ p) =ᶠ[atTop]
      (fun x => (L (b * x) / L x) ^ p) := by
    filter_upwards [hpos, hpos'] with x hx1 hx2
    rw [Real.div_rpow (le_of_lt hx2) (le_of_lt hx1)]
  have hnn : ∀ᶠ x in atTop, 0 ≤ L (b * x) / L x := by
    filter_upwards [hpos, hpos'] with x hx1 hx2
    exact le_of_lt (div_pos hx2 hx1)
  have hlim := hL'.rpow tendsto_const_nhds hnn
  rw [← Real.rpow_mul (le_of_lt hb)] at hlim
  exact Tendsto.congr' e.symm hlim
