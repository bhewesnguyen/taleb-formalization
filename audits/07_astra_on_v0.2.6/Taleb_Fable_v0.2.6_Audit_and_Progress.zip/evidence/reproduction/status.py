from pathlib import Path
import json,time,re
base=Path(__file__).resolve().parent
for name in ['cache.log','run_progress.log','clean_build.log','verify.log','schema_probes.log','regression_A.log','regression_B.log','regression_C.log']:
 p=base/name
 if p.exists():
  lines=p.read_text(errors='replace').splitlines()
  print(name, 'age_s=',round(time.time()-p.stat().st_mtime), 'last=', repr(lines[-1] if lines else ''))
p=base/'reproduction.json'
if p.exists():
 for row in json.loads(p.read_text()):print('completed:',row['name'],'exit',row['exit_code'],'seconds',row['seconds'])

for key in 'ABC':
 p=base/('regression_'+key+'.log')
 if p.exists():
  print('completed fixtures',key,[s for s in p.read_text().splitlines() if re.match(r'^\w+\s+exit=',s)])
