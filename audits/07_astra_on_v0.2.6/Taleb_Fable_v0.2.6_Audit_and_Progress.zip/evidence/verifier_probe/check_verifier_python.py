#!/usr/bin/env python3
"""Bounded independent v0.2.6 Python-only probes, never a Lean reproduction.

The received source tree is only read. CLI probes exercise real Python commands.
Verifier integration cases replace every external command result with recorded
received evidence so as to test Python acceptance logic alone. Discovery probes
exercise the unchanged function on small source texts, not Lean elaboration.
"""
import argparse
import ast
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def digest(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file() and '.lake' not in p.parts}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', type=Path, required=True)
    ap.add_argument('--previous', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    source = a.project.resolve()
    before = digest(source)
    evidence = source / 'evidence/current'
    inventory = json.loads((evidence / 'inventory_environment.json').read_text())
    ledger = json.loads((source / 'docs/FORMALIZATION_BACKLOG.json').read_text())
    manifest = json.loads((source / 'lake-manifest.json').read_text())
    received = json.loads((evidence / 'verification.json').read_text())
    axioms = (evidence / 'axioms.log').read_text()
    results = dict(scope=__doc__, project=str(source), cli=[], schema_replay=[], discovery=[], generator=[])

    with tempfile.TemporaryDirectory(prefix='taleb_v026_python_probe_') as tmp:
        temp = Path(tmp)
        for name, selection in [('unknown', 'unknown_fixture'), ('mixed', 'valid,unknown_fixture'),
                                ('empty', ''), ('empty_element', 'valid,,')]:
            scratch, out = temp / (name + '_scratch'), temp / (name + '_out')
            proc = subprocess.run([sys.executable, str(source / 'scripts/harness_regression.py'),
                '--only', selection, '--scratch', str(scratch), '--out', str(out)],
                cwd=temp, text=True, capture_output=True)
            results['cli'].append(dict(case=name, exit_code=proc.returncode,
                scratch_created=scratch.exists(), out_created=out.exists(), stderr=proc.stderr.strip(),
                matches_expected=proc.returncode == 2 and not scratch.exists() and not out.exists()))

        staged = temp / 'project'
        shutil.copytree(source, staged, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
        mod = load_module('taleb_verify_probe', staged / 'scripts/verify.py')
        deps = {d['name']: d['rev'] for d in manifest['packages']}

        def replay_run(args, log=None):
            if args == ['lake', 'env', 'lean', '--version']:
                output = received['lean']
            elif args[:2] == ['git', '-C'] and args[3:] == ['rev-parse', 'HEAD']:
                output = deps[Path(args[2]).name]
            elif args[:2] == ['git', '-C'] and args[3:] == ['status', '--porcelain']:
                output = ''
            elif args == ['lake', 'build']:
                output = 'Python-only replay of a clean build. No Lean process executed.'
            elif args == ['lake', 'env', 'lean', 'AuditVerification.lean']:
                output = axioms
            elif args == ['lake', 'env', 'lean', 'scripts/FableInventory.lean']:
                output = json.dumps(inventory)
            else:
                raise RuntimeError('Unexpected subprocess request: ' + repr(args))
            if log:
                (mod.OUT / log).write_text(output)
            return output.strip()
        mod.run = replay_run

        # One control, the three previous actual false accepts, and six bounded
        # independent checks of new field/sequence handling and fail-closedness.
        cases = [('valid', copy.deepcopy(ledger), True)]
        def mutation(name, mutate):
            value = copy.deepcopy(ledger)
            mutate(value)
            cases.append((name, value, False))
        mutation('duplicate_T002_omits_T003', lambda r: r[2].update(id='T002'))
        mutation('contradictory_discharged_boolean', lambda r: r[59].update(discharged=False))
        mutation('numeric_delivery_scope', lambda r: r[0].update(delivery_scope=123))
        mutation('reordered_ids', lambda r: r.reverse())
        mutation('boolean_pdf_anchor', lambda r: r[0].update(pdf_anchor_page=True))
        mutation('blank_supported_scope', lambda r: r[0].update(delivery_scope='   '))
        mutation('dangling_declaration', lambda r: r[0]['declarations'].__setitem__(0, 'AuditRV.no_such_theorem'))
        mutation('non_string_state', lambda r: r[0]['states'].append(42))
        mutation('unhashable_id', lambda r: r[0].update(id=[]))
        for name, rows, expected_acceptance in cases:
            (staged / 'docs/FORMALIZATION_BACKLOG.json').write_text(json.dumps(rows))
            accepted, error, error_type = False, None, None
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    mod.main()
                    accepted = True
                except Exception as exc:
                    error, error_type = str(exc), type(exc).__name__
            results['schema_replay'].append(dict(case=name, accepted=accepted,
                expected_acceptance=expected_acceptance, error=error, error_type=error_type,
                matches_expected=accepted == expected_acceptance))
        (staged / 'docs/FORMALIZATION_BACKLOG.json').write_text(json.dumps(ledger))

        shipped_out = temp / 'shipped_probes'
        proc = subprocess.run([sys.executable, str(staged / 'scripts/backlog_schema_probes.py'),
            '--out', str(shipped_out)], cwd=staged, text=True, capture_output=True)
        record = json.loads((shipped_out / 'backlog_schema_probes.json').read_text())
        results['shipped_probes'] = dict(exit_code=proc.returncode, stdout=proc.stdout,
            result=record, matches_expected=proc.returncode == 0 and record['all_probes_behaved_as_expected'])

        # Verify shared validator use on generator's write path, including -O.
        gen = staged / 'scripts/rebuild_curated_inventory.py'
        gen_original = gen.read_text()
        shipped_bytes = (source / 'docs/FORMALIZATION_BACKLOG.json').read_bytes()
        proc = subprocess.run([sys.executable, str(gen)], cwd=staged, text=True, capture_output=True)
        generated = (staged / 'docs/FORMALIZATION_BACKLOG.json').read_bytes()
        results['generator'].append(dict(case='unmodified_generator', exit_code=proc.returncode,
            matches_shipped_bytes=generated == shipped_bytes,
            matches_expected=proc.returncode == 0 and generated == shipped_bytes))
        needle = '|RV|P1|partial|states='
        assert needle in gen_original
        gen.write_text(gen_original.replace(needle, '|RV|BAD_PRIORITY|partial|states=', 1))
        for flags in ([], ['-O']):
            before_ledger = (staged / 'docs/FORMALIZATION_BACKLOG.json').read_bytes()
            proc = subprocess.run([sys.executable] + flags + [str(gen)], cwd=staged, text=True, capture_output=True)
            unchanged = before_ledger == (staged / 'docs/FORMALIZATION_BACKLOG.json').read_bytes()
            results['generator'].append(dict(case='invalid_priority' + ('_optimized' if flags else ''),
                exit_code=proc.returncode, stderr=proc.stderr.strip(), output_unchanged=unchanged,
                matches_expected=proc.returncode != 0 and unchanged and 'unknown priority' in proc.stderr))

        # Reproduce old bug from its actual source function, without importing it.
        old_ast = ast.parse((a.previous.resolve() / 'scripts/verify.py').read_text())
        old_fn = next(n for n in old_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'declarations')
        old_globals = dict(re=re, ROOT=None)
        exec(compile(ast.Module(body=[old_fn], type_ignores=[]), '<v025 declarations>', 'exec'), old_globals)
        discovery_root = temp / 'discovery'
        (discovery_root / 'AuditRepairs').mkdir(parents=True)
        (discovery_root / 'Proofs').mkdir()
        testfile = discovery_root / 'AuditRepairs/Probe.lean'
        mod.ROOT = discovery_root
        old_globals['ROOT'] = discovery_root
        fixtures = [
            ('named_section', 'namespace A\nsection Inner\ntheorem inside : True := True.intro\nend Inner\ntheorem after : True := True.intro\nend A\n',
             ['A.inside', 'A.after']),
            ('nested_sections_and_namespaces', 'noncomputable section\nnamespace A\nsection\nnamespace B\nsection S\ntheorem inner : True := True.intro\nend S\ntheorem afterS : True := True.intro\nend B\nend\ntheorem afterAnon : True := True.intro\nend A\nend\ntheorem rootDecl : True := True.intro\n',
             ['A.B.inner', 'A.B.afterS', 'A.afterAnon', 'rootDecl']),
            ('qualified_namespace', 'namespace A.B\nnoncomputable section S\ntheorem inner : True := True.intro\nend S\ntheorem after : True := True.intro\nend A.B\n',
             ['A.B.inner', 'A.B.after'])]
        for name, src, expected in fixtures:
            testfile.write_text(src)
            old_names = [d['name'] for d in old_globals['declarations']()]
            names = [d['name'] for d in mod.declarations()]
            results['discovery'].append(dict(case=name, source=src, names=names,
                v025_names=old_names, expected=expected, matches_expected=names == expected))

    results['original_tree_unchanged'] = before == digest(source)
    results['all_probes_matched_expected_observations'] = (
        results['original_tree_unchanged'] and results['shipped_probes']['matches_expected'] and
        all(r['matches_expected'] for group in ('cli', 'schema_replay', 'generator', 'discovery') for r in results[group]))
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({k: results[k] for k in ('original_tree_unchanged', 'all_probes_matched_expected_observations')}, indent=2))
    return 0 if results['all_probes_matched_expected_observations'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
