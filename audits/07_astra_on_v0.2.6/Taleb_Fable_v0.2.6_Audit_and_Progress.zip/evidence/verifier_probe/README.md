# v0.2.6 bounded verifier probes

Run from the audit workspace:

```sh
python3 audit_v026/verifier_probe/check_verifier_python.py \
  --project audit_v026/received/Taleb_Lean_Repairs \
  --previous audit_v025/received/Taleb_Lean_Repairs \
  --out audit_v026/verifier_probe/python_probe_results.json
```

The script leaves both received trees unchanged and runs no Lean process. All mutations occur in temporary copies.

- Four real harness CLI invocations test invalid, mixed and empty selections before filesystem actions.
- Ten calls to the actual v0.2.6 `verify.main` function test Python acceptance logic: one clean control and nine malformed ledgers. All external command outputs are substituted with received v0.2.6 records. These are replay tests, not independent build or theorem evidence.
- The shipped schema probe CLI is rerun in a temporary copy: one valid control and all twelve malformed ledgers.
- Three real generator CLI invocations check exact reproduction of the shipped JSON, then refusal to write an invalid priority in normal and optimized Python modes.
- Three small source texts test the actual v0.2.6 discovery function. The actual v0.2.5 function is extracted by Python AST and replayed for comparison, showing the former namespace loss. These tests check source discovery only, not Lean elaboration.

`python_probe_results.json` records the independent observations. Every expected observation occurred. For `unhashable_id`, the observed result is a `TypeError`, which the verifier entry point catches as failure; it is not a structured schema diagnostic. Full compiler, trust-scan and regression-suite evidence is maintained separately by the runtime audit.
