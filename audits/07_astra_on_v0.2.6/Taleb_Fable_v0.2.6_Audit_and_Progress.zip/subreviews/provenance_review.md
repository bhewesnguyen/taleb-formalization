# v0.2.6 release provenance review

Verdict: no packaging or provenance blocker. The supplied archive, committed project tree, both patch replays, and prior release boundaries agree exactly. These checks do not rely on Fable's recorded build results and do not execute the supplied project verification scripts.

## Independently reproduced checks

| Check | Result |
|---|---|
| ZIP SHA-256 | `d684d0ef3c3d17f9ceb5cd456969559674c1ac86e21bbd6a27505cf22d4fb3f3`, matches supplied checksum and brief |
| Archive contents | 205 regular files, 232 entries including directories; no duplicate file paths, traversal/absolute paths, symlinks, `.lake`, compiled Lean outputs or Python bytecode |
| `SHA256SUMS` | All 204 entries pass; unique paths; all archive files covered except the manifest itself; no extras |
| Immutable audit extraction | All 205 files equal the supplied ZIP; no missing or extra files |
| Bundle | `git bundle verify` passes and reports complete history; `git fsck --full` passes; 27 commits visible |
| Packaged commit | `83ef501d87a1c910cc166f880ed44b7094e6f5d3`; all 205 tracked project files equal ZIP bytes exactly |
| Packaged project tree | `bc7e860417078d412a43338e970605a02d4042a6` |
| Full patch | 153 changed files; exact `git diff` from pristine v0.2.0 commit `f6b100762540655184b96dd4e0c8f8fd0233da28`; applies and reproduces the packaged project tree hash and all ZIP bytes |
| Incremental patch | 44 changed files; exact `git diff` from v0.2.5 commit `579f0d69d77c21e36a4b8bbd288cd57438a688ab`; applies and reproduces the same tree hash and bytes |
| Toolchain/dependency pins | `lean-toolchain` and `lake-manifest.json` byte-identical to both v0.2.0 and v0.2.5; Lean 4.24.0 and Mathlib `f897ebcf72cd16f89ab4577d0c826cd14afaafc7` |
| Historical baselines | Bundled v0.2.0 archive has 73 files and bundled v0.2.5 archive 186 files; both match their respective committed project trees exactly |
| Retained audit manifest | All 15 retained-artifact checksums pass |
| Actual v0.2.5 auditor outputs | Preserved PDF, progress Markdown and audit ZIP all byte-identical to the files independently produced in the prior audit |
| Earlier retained audit artifacts | All 12 pre-v0.2.5 audit artifacts unchanged from the previously audited v0.2.5 bundle |

## Existing mathematics and scope of comparison

There were 25 mathematics modules under `AuditRepairs/` and `Proofs/` in v0.2.5. Twenty-three are byte-identical in v0.2.6. `ExtremeValueBridge.lean` changes only explanatory comments. `ExtremeValueLaws.lean` adds the reverse-Weibull section and five axiom-print commands; after removing those additions, its non-comment text is unchanged. Existing declarations were not altered. `ExtremeValueAffine.lean` is the sole new mathematics module. The root import module and generated verifier inventory are outside this mathematical-module comparison.

The repeatable check removes nested Lean comments and normalizes whitespace. For `ExtremeValueLaws.lean` it explicitly excludes `section ReverseWeibull` through `end ReverseWeibull` and the five new reverse-Weibull axiom-print commands. This is a textual preservation check, not a Lean AST or semantic-equivalence proof. The added code's mathematical correctness and runtime verification are reviewed separately.

## Bounds on historical claims

The bundle has four commits after the v0.2.5 packaged commit, but only three after the v0.2.5 deliverables commit `014ae32949fe45fbc9352872e92defc0390679ad`. Fable's message says four since the deliverables; this can include the subsequent v0.2.6 deliverables commit that the audit brief explicitly says the bundle predates. That final commit is not present here and cannot be independently confirmed from this bundle. No inconsistency in the packaged project snapshot follows.

The bundle advertises `refs/heads/main` but has no symbolic remote HEAD. A plain clone may warn that remote HEAD refers to a nonexistent ref; `git clone --branch main` or checking out `origin/main` selects the advertised commit correctly. This is a convenience issue, not a history or integrity defect.

A clean independent checkout confirms only that checkout's state. The bundle cannot establish whether the author's working tree was clean, whether any remote exists, or whether anything was pushed. The brief correctly states those limits.

The previous v0.2.4 audit noted a PDF representation mismatch with identical rendered pages. That retained PDF is unchanged from v0.2.5. In contrast, all three newly retained v0.2.5 audit deliverables match the original audit outputs byte for byte, so no new PDF representation issue arises this round.

## Evidence

- `provenance/check_provenance.py`: repeatable independent checks, with patch applications confined to its own detached worktrees.
- `provenance/provenance.json`: full machine-readable hashes, checks and history.
- `provenance/check_provenance.log`: concise results from the successful run.

The archive validation log is a supplied Fable record. It is hashed as an input, but its runtime claims are not counted as independently executed by this provenance review.
