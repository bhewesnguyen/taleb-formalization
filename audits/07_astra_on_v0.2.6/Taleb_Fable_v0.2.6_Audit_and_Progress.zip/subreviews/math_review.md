# Independent mathematics review of v0.2.6

Review scope: the new reverse-Weibull section of `AuditRepairs/ExtremeValueLaws.lean`, the new `AuditRepairs/ExtremeValueAffine.lean`, their exact dependence on the existing extrema bridge and formula identities, and the proposed T061 discharge. This is source and mathematical review. The separate runtime review supplies independent build and axiom-scan results.

## Verdict

Accept the mathematical increment, subject to the independent runtime checks. No mathematical defect was found in the new Lean statements or proofs. T061 can be discharged against its original target and the positive location/scale child recorded in v0.2.5. The omission of a unified GEV parameterization and its shape-to-zero limit does not reopen this narrowly stated family. It remains an unformalized claim from the source and should stay visible in the broader source ledger.

There are several concrete documentation defects, including a mathematically false description of continuity and a stale generated Markdown ledger. These affect the handoff's accuracy, not the validity of the new proofs.

## Source and dependency checks

- Compared the received v0.2.5 and v0.2.6 `ExtremeValueLaws.lean` files directly. The reverse-Weibull section and five axiom-print lines are appended; every old theorem, definition and proof in this module is unchanged. `ExtremeValueAffine.lean` is a new module.
- Inspected `ExtremeValueBridge.lean`, including the actual `maxRV` definition by nonempty finite supremum, measurability, and `cdf_map_maxRV`; inspected `Tails.lean` formula definitions and maximum identities.
- Checked the locally retained book text for printed pages 172 and 173, PDF pages 186 and 187. The maximum law is Eq. (9.1) on printed page 172. The three displayed family CDFs are on page 173. Reverse-Weibull is the family with an upper endpoint, with shape alpha > 0 and extreme-value index xi = -1/alpha.
- Inspected exact pinned Mathlib source, commit `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`, under `/tmp/taleb_v026_audit_project/.lake/packages/mathlib`. `StieltjesFunction.isProbabilityMeasure` requires the 0 and 1 endpoint limits; `cdf_measure_stieltjesFunction` identifies the entire bundled CDF; `Measure.eq_of_cdf` requires both measures to be probability measures; `Measure.isProbabilityMeasure_map`, `iIndepFun_pi`, and `measurePreserving_eval` have the hypotheses used here. No interpretation gap was found.

## Reverse-Weibull construction

The new definitions are `AuditEVTLaws.reverseWeibullCDF`, `reverseWeibullStieltjes` and `reverseWeibullMeasure`. The formula is

\[
W_\alpha(x)=\begin{cases}\exp(-(-x)^\alpha),&x<0,\\1,&x\geq0,\end{cases}\qquad \alpha>0.
\]

This matches the book's standardized upper-endpoint family. It is not the positive-support Weibull lifetime distribution.

`reverseWeibullCDF_monotone` correctly reverses the order twice on the negative half-line: if x <= y < 0, then -y <= -x; the positive power increases; negation reverses the resulting order; exponential preserves it. When y >= 0, `reverseWeibullCDF_le_one` supplies the comparison with the constant branch.

`reverseWeibullCDF_continuousWithinAt_Ici` really is valid for every real alpha. For a negative evaluation point the positive base -x is locally bounded away from zero, so real powers are continuous for any exponent. At and above zero, the restriction to the right neighborhood is identically 1. This theorem does not assert left continuity at zero for arbitrary alpha. The positive shape restriction is correctly retained for monotonicity, the limit at minus infinity, the Stieltjes object, and the probability measure.

`reverseWeibullCDF_tendsto_atBot` uses -x tending to positive infinity, positive real power tending to positive infinity, then the negative exponential tending to zero. `reverseWeibullCDF_tendsto_atTop` uses the eventual constant branch 1. These limits and the bundled monotonicity/right continuity supply `reverseWeibullMeasure_isProbabilityMeasure` through Mathlib's Stieltjes theorem.

`cdf_reverseWeibullMeasure` and `cdf_reverseWeibullMeasure_apply` identify the actual probability measure's CDF globally, including at and beyond the upper endpoint. The measure is not merely postulated through a CDF hypothesis.

`reverseWeibullCDF_maxstable` proves

\[
W_\alpha(x)^n=W_\alpha(n^{1/\alpha}x)
\]

for every natural n. The n = 0 branch is valid: the left side is 1, the positive exponent gives zero for the scaling coefficient, and W(0) = 1. For n > 0 and x < 0, the product and iterated real-power identities are applied only to positive/nonnegative bases, and `(1 / alpha) * alpha = 1` uses alpha nonzero. The nonnegative x branch is constant 1 on both sides.

This zero-size formula does not construct the maximum of an empty family. Both `cdf_map_maxRV_reverseWeibull` and `cdf_map_maxRV_pi_reverseWeibull` require a finite nonempty index type. The former instantiates the existing generic maximum theorem with the constructed law. The latter supplies a concrete probability model on the finite product, with independent coordinate evaluations and exactly the required coordinate pushforward laws. It closes the realization premise rather than hiding it in an impossible hypothesis.

The section adds exactly 12 theorems, 1 probability-measure instance, and 3 definitions.

## Affine laws and equality of maximum laws

`AuditEVTLaws.affineLaw nu mu sigma` is the actual pushforward by `z -> mu + sigma * z`. Measurability is proved directly. Probability normalization holds for every real mu and sigma, which is correct: sigma = 0 gives a degenerate law and a negative sigma gives a reflected law. The classical location/scale CDF and maximum statements correctly require sigma > 0. The definitions and probability instances themselves do not need that restriction.

`affine_preimage_Iic` proves the exact preimage of a non-strict threshold under a positive affine map. `cdf_affineLaw` applies this identity to `cdf_eq_real` and `Measure.map_apply`, giving

\[
\operatorname{cdf}(\operatorname{affineLaw}(\nu,\mu,\sigma))(x)
=\operatorname{cdf}(\nu)((x-\mu)/\sigma).
\]

There is no missing boundary or atom correction: the event is Iic throughout. `affineLaw_zero_one` supplies the identity normalization. The three definitions `gumbelLaw`, `frechetLaw`, and `reverseWeibullLaw`, their instances, and `cdf_gumbelLaw`, `cdf_frechetLaw`, and `cdf_reverseWeibullLaw` instantiate the generic rule with the already constructed standard laws.

For n = cardinality of the finite nonempty index type, the new law equalities are:

| Declaration | Coordinates' parameters | Maximum's parameters |
|---|---|---|
| `map_maxRV_gumbelLaw` | mu, sigma | mu + sigma log n, sigma |
| `map_maxRV_frechetLaw` | xi > 0, lower endpoint mu, sigma | xi, mu, sigma n^xi |
| `map_maxRV_reverseWeibullLaw` | alpha > 0, upper endpoint mu, sigma | alpha, mu, sigma n^(-1/alpha) |

All three prove equality of measures, not just agreement at an arbitrary threshold. They establish that the maximum's pushforward is a probability measure, use `Measure.eq_of_cdf`, compare CDFs at every real x, and reduce to the previously proved analytic maximum identities. The new output scales are proved positive. The ordinary assumptions are mutual independence (`iIndepFun`), measurable coordinates, a common pushforward law, and finite nonempty index. The ambient law is a probability measure. No additional impossible or tautological assumption was found.

The endpoint conventions are essential. Here mu is the Fréchet lower endpoint or reverse-Weibull upper endpoint, not the location coordinate of a unified GEV parameterization with kernel `exp(-(1 + xi z)^(-1/xi))`. In these conventions the displayed parameter rules are correct. The book's three separate displayed family formulas use the same endpoint convention.

There are no separately named product-space versions of the three new affine measure-equality theorems, but this is not a vacuity or closure gap: each affine family is an actual probability measure, and Mathlib's finite product construction supplies its independent coordinate realization just as it does for the standard laws. Named convenience wrappers could be added later without changing the result.

The affine module adds exactly 10 theorems, 4 probability-measure instances, and 4 definitions. Together with the reverse-Weibull section, this is 22 theorems, 5 instances, and 7 definitions.

## T061 closure and explicit limits

The original target is: "Construct global Gumbel, Frechet and reverse-Weibull CDFs and prove validity." Its recorded hypotheses concern support branches, positive scale, shape domains, right continuity and endpoint limits. The v0.2.5 remaining obligations were precisely the reverse-Weibull probability measure and positive affine pushforwards with their CDF transformation rules. These are delivered. The equality-of-measures maximum rules go beyond the minimal construction target in a useful direction.

Accepting T061 does not assert a Fisher-Tippett-Gnedenko theorem, convergence of normalized arbitrary maxima, density formulas or with-density identifications, a unified xi-parameter law, or its xi -> 0 limit. The unified display and limit are present in the book and merit explicit outstanding source tasks; they were not part of this family's stated acceptance condition. They should not be added retroactively as a reason to reject this completed construction milestone.

## Concrete documentation findings

### M026-D1: false global-continuity statement in T061 JSON

`docs/FORMALIZATION_BACKLOG.json`, T061 `hypotheses_and_gaps`, says:

> Frechet and reverse-Weibull are not globally continuous in the totalised rpow reading at the endpoint from one side, only right-continuous

This is false for the support-correct CDFs under their admitted positive shapes. The Fréchet piecewise formula is zero on the nonpositive side and tends to zero from above, as its existing right-continuity proof establishes. Reverse-Weibull tends to exp(-0) = 1 from below when alpha > 0 and is 1 on the nonnegative side. Both are globally continuous. The raw unguarded `frechetFormula` has the known totalization issue at zero; `frechetCDF` repairs that issue.

Repair the prose to say: "Right continuity and endpoint limits are formally proved. The support-correct CDFs are globally continuous for the admitted positive shapes; a separate global-continuity theorem is not needed for this Stieltjes construction." No new continuity proof is a closure gate.

### M026-D2: stale generated Markdown ledger and module introduction

The received `docs/FORMALIZATION_BACKLOG.md` T061 section still reports `P1 / partial`, credits only the v0.2.5 declarations, and lists reverse-Weibull and positive location/scale as remaining obligations. The JSON reports `discharged` and the implemented new content. This is a human/machine handoff inconsistency; synchronize the generated Markdown and make generation consistency a release check.

`ExtremeValueLaws.lean` lines 28-29 likewise still say the reverse-Weibull family and the location/scale wrappers are "Not done (remaining T061 children)". Update the module overview to identify the new section and `ExtremeValueAffine.lean`, or mark the paragraph explicitly as v0.2.5 history. The title still says children 1-2 although the module now also supplies child 3.

### M026-D3: density task routed to an unrelated existing ID

FABLE_REVIEW sections 16.3 and 16.6, and T061 `remaining_obligations`, describe densities as T062. The actual unchanged T062 is "Frechet and Gaussian maximum domains", targeting regular-variation-to-Fréchet convergence and Gaussian Gumbel normalizers. T011 is the general maximum-domain/convergence formulation task. Route density work to an explicit new child/task or its correct existing inventory location without overwriting the convergence scope of T062. This is not an extra T061 obligation.

## Review boundary

No new Lean source was edited or compiled by this reviewer. Source mathematical review and exact pinned-library inspection are complete. The overall audit must report the separate reproduction results and any verifier or packaging findings independently of this source verdict.
