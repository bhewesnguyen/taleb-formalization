# v0.2.6 ledger and scope review

**Accept T061 as the second discharged family, subject to the independent build and axiom checks.** The delivered mathematical scope matches the original target. The human-facing Markdown ledger is stale and needs repair; two other documentation corrections concern continuity and the routing of future EVT work. None reopens the mathematics of T061.

## Scope and the unified GEV question

The original v0.2.0 archive and the v0.2.5 JSON have the same T061 target: "Construct global Gumbel, Frechet and reverse-Weibull CDFs and prove validity." Their hypotheses are "Correct piecewise support; scale>0; shape domains; right continuity and endpoint limits." The v0.2.6 JSON preserves both sentences verbatim at the start of the fields and appends delivery details. No target was deleted or weakened to obtain closure.

The v0.2.5 remaining scope expressly required the reverse-Weibull measure and positive affine location/scale pushforwards with CDF transformation rules for all three laws. These are delivered. The standard-law maximum results have explicit finite product-space realizations. The location/scale maximum theorems identify actual probability measures and have the ordinary hypotheses of independence, measurable coordinates, a common named law, positive scale and a finite nonempty index type. The maximum parameter rules also exceed the minimum construction target in a useful way.

The supplied book, printed p. 173 / PDF p. 187, displays the three named families separately with positive scale and the same support branches. It also discusses the unified GEV expression and the Gumbel limit as xi tends to zero. Those further statements are unproved here, but they were never part of T061's recorded three-family target. They should remain explicitly recorded supplemental work; adding them now as a closure gate would move the agreed boundary. T061 closure does not claim that all mathematics on that page, or all of extreme-value theory, is formalized.

The three parameter conventions are internally correct: Gumbel location shifts by sigma log n; the Fréchet lower endpoint remains mu and scale is multiplied by n^xi; the reverse-Weibull upper endpoint remains mu and scale is multiplied by n^(-1/alpha). These are the book's separate-family affine coordinates. They are not automatically the location and scale coordinates of a unified GEV parameterization.

## Independently tallied progress

| Status | v0.2.5 | v0.2.6 |
|---|---:|---:|
| Discharged | 1 | 2 |
| Partial | 10 | 9 |
| Reuse available, not instantiated | 4 | 4 |
| Missing | 91 | 91 |
| Source check required | 34 | 34 |
| Model needed | 15 | 15 |
| Empirical | 3 | 3 |
| Total | 158 | 158 |

There are 140 formal-proof families and 18 model/empirical families. Eleven families have credited Lean support, of which two are closed and nine partial. The other 147 families have no credited project declaration. T047 and T118 are explicitly prerequisite-only support. These counts are neither an effort-completion percentage nor a count of independent book theorems.

The current JSON has 107 family/declaration citation pairs over 106 distinct names, up from 83/82. The only shared name is `AuditGaussian.charFun_gaussianReal_eq_stableS1Expr`, credited to T007 and T046. There are no duplicate pairs and every cited name occurs in the supplied environment inventory. This cross-reference uses supplied inventory evidence; the independent runtime audit establishes that inventory afresh.

T061 adds 24 credited names, moving from 21 to 45. All 157 other JSON rows are identical to v0.2.5. The nonexclusive delivery-facet counts are: formula_proved 8, source_reviewed 7, actual_law_constructed 3, conditional_law_theorem 3, law_theorem 2, discharged 2. Facets overlap and must not be added as independent completed work.

The attached JSON preserves all 158 received rows exactly, records all 22 dependency-group counts, and provides an audited scope for each supported family.

## All eleven supported families

| Family | Audited status | Delivered scope and remaining boundary |
|---|---|---|
| T001 Regular variation API | Partial | Ratio predicates, examples and closure lemmas. Positive measurable conventions and the bridge to them remain. Uniform convergence, Potter and Karamata have separate families. |
| T007 Stable law existence | Partial | Actual Gaussian slice at alpha = 2, including zero scale. The rest of the admissible S1 family remains open. |
| T008 Subexponential API | Partial | A definition and finite-tail-exponent transport under assumed subexponentiality. No concrete subexponential law or n-fold characterization is delivered. |
| T029 Unequal-index sums | Partial | Two-term formula-level minimum exponent. The nonnegative random-variable sum theorem remains. A finite log-exponent theorem must not be advertised as full tail equivalence. |
| T032 Power transformation | Partial | Analytic alpha/p formula. Pushforward law, inverse-event identity and distribution identification remain. |
| T046 Stable specializations | Partial | Actual Gaussian characteristic-function identification and convolution equality; Cauchy remains expression-level. Adding law_theorem for the Gaussian equality is optional conservative bookkeeping. |
| T047 Stable averages | Partial, prerequisite only | Conditional stable convolution/sum bridge. No sample-average law, rescaling correction or convergence is proved. |
| T060 iid extrema | Discharged | Generic maximum CDF and minimum survival laws, all four threshold-event conventions. Specific EVT construction is separate. |
| T061 EVT laws | Discharged | Three standard probability laws and CDFs, standard maximum laws/product models, positive affine CDF API, named location/scale families and maximum equalities of measures. |
| T118 Pareto moment convexity | Partial, prerequisite only | Tail-kernel convexity. The moment integral, actual moment-function convexity and integrated Jensen remain. |
| T124 Gamma-index mean | Partial | Correct rational excess expression and positivity as algebra. The inverse gamma moment, threshold and probabilistic mixture identity remain. |

All eleven family statuses and the JSON delivery scopes are proportionate. The mathematical claims do not need reducing. The documentation changes below prevent contradictory or misleading descriptions.

## Findings and exact repairs

### D026-L1: stale current Markdown ledger (medium documentation priority)

`docs/FORMALIZATION_BACKLOG.md` is byte-for-byte identical to v0.2.5. Its T061 section, beginning at line 561, still says partial, credits only 21 names, and lists reverse-Weibull and location/scale as open. JSON records discharged, 45 names and the completed scope. Seven rendered fields disagree: status, target, hypotheses, states, declarations, delivery scope and remaining obligations.

An isolated execution of `scripts/rebuild_curated_inventory.py` returns exit 0 and reproduces the received JSON byte-exactly. The script only writes JSON and leaves the old Markdown untouched. Therefore the changelog's claim that both formats were regenerated/synced is false for this package. Probe evidence is `audit_v026/ledger_probe/ledger_consistency.json`.

Generate both forms from the same validated row objects, regenerate the Markdown, and add a deterministic consistency gate. Update the current module header in `ExtremeValueLaws.lean`, which also still labels reverse-Weibull and affine wrappers unfinished. The addenda in `FABLE_REVIEW.md` are intentionally historical; their old release states need not all be rewritten.

This issue understates delivery in the human-facing ledger. It is not evidence of an invalid theorem or an incorrect T061 closure.

### D026-M1: false continuity explanation (low documentation priority)

The new T061 `hypotheses_and_gaps` text, in JSON and in the generator's row, says Fréchet and reverse-Weibull are "not globally continuous" in the totalized real-power reading and "only right-continuous". That is false for the actual piecewise CDFs under their stated positive-shape hypotheses.

For xi > 0, the Fréchet CDF is 0 on x <= 0 and its right limit at 0 is 0. The positive-side formula is continuous away from 0. For alpha > 0, the reverse-Weibull CDF approaches exp(0) = 1 from below 0 and is 1 on x >= 0. Both piecewise CDFs are globally continuous. The raw unguarded `frechetFormula` does have a misleading endpoint value, but this is why the delivered `frechetCDF` is piecewise.

Replace the sentence with: "Right-continuity, sufficient for the Stieltjes construction, is proved pointwise. The piecewise CDFs are in fact continuous under their positive-shape assumptions; full continuity is not separately exported here." No new continuity theorem is needed to accept the current construction.

### D026-R1: future-work routing and shape notation (low documentation priority)

The repeated assignment "densities (T062)" is wrong. The unchanged T062 target is "Prove regular-variation-to-Frechet convergence and Gaussian Gumbel normalizers." T011 is the setup/source-repair family for normalized maxima convergence. T062 carries the concrete Fréchet and Gaussian/Gumbel domain-of-attraction targets. No current family explicitly asks for density identifications of all three EVT laws.

This is a carried-forward routing error, including prior independent audit guidance. Fable should not be assigned sole responsibility. Record the density/withDensity identifications as named supplemental tasks and correct references in T060/T061 remaining text, README and FABLE_REVIEW. Do not silently rewrite T062's target to make the old reference fit.

The suggested next theorem in FABLE_REVIEW section 16.6 says Pareto maxima converge to `frechetMeasure alpha`. If alpha is the Pareto tail exponent, the project requires `frechetMeasure (1 / alpha)`: its parameter is xi, and the CDF is exp(-x^(-1/xi)). The book explicitly identifies xi = 1/alpha. Use distinct alpha and xi names to keep this boundary clear.

## Prior findings

D025-1 is repaired: the strict/non-strict differences are the exact extremum boundary events, and the union of coordinate-equality events is described only as a superset. D025-2 is repaired in the named replacement-map rows 10/11 and the round-4 audit-history response, which now names both Gumbel and Fréchet. T061 now carries law_theorem. V025-L1's implementation and mutation probes are reviewed separately by the verifier auditor.

Two small prose qualifications can be fixed alongside the above without separate findings: 13/13 schema-probe checks can mean the valid control plus 12 rejected mutations, matching the user's 12/12 malformed-ledger summary; positive scale is required for the stated CDF/max-law rules, but the affine pushforward definition and probability instance intentionally work for every real scale.

## Recommended next work

1. Repair the current ledger rendering and mathematical documentation above.
2. T029: prove the finite log-tail exponent of nonnegative positive-weight sums via event inclusions and squeezing, with no independence assumption. Keep the finite-exponent conclusion distinct from exact convolution or regular-variation asymptotics.
3. Exact Pareto slice against the pinned `paretoMeasure`: survival, exact moments and divergence threshold, threshold excess, power pushforwards. The generic affine API is useful infrastructure, but does not by itself discharge these integrals or event identities.
4. If continuing EVT, make supplemental density/unified-GEV work visible, and route actual convergence correctly to T011/T062. Keep T061 closed.

This is substantial reusable progress: the formalization now has a complete small EVT-law API. The bulk of the book remains ahead, particularly asymptotic convergence, moment theorems, regular variation, stable-law existence and application-specific modeling. Local Lean results are not upstream Mathlib acceptance or evidence that the separate quantum/classical software is runnable.
