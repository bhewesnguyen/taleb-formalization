# v0.2.6 verifier and harness review

The v0.2.5 V025-L1 repairs are accepted. The namespace/section discovery repair H026-1 addresses the reported regression, and its new positive fixture is appropriate. No new verifier false-acceptance defect was found in this bounded review. Runtime reproduction is reported separately; none of the Python replay evidence below substitutes for a fresh Lean run.

## Scope and evidence

Reviewed the received v0.2.6 `scripts/verify.py`, `scripts/backlog_schema.py`, `scripts/backlog_schema_probes.py`, `scripts/rebuild_curated_inventory.py`, `scripts/harness_regression.py` and unchanged `scripts/FableInventory.lean`, including diffs against v0.2.5. The received project was read only.

Reproducible independent probes and their exact results are in `verifier_probe/check_verifier_python.py` and `verifier_probe/python_probe_results.json`. They completed with exit 0 in under one second, and the before/after digest of every received file was identical. This completion means all recorded expected observations occurred, not that Lean was run by this probe script.

## V025-L1: all three actual gaps closed

The shared schema validator now requires the exact ordered ID sequence T001 through T158. It validates field types, forbids unknown fields, requires selected source and target fields to be nonblank, limits enumerated values, excludes duplicate states/declarations, requires the four delivery fields together and checks equivalence of discharged status, state and Boolean. Python's Boolean/integer subtype relationship is explicitly handled.

Both generator and verifier import this module. `verify.py` lines 132-136 validate shape before checking declaration existence. The generator calls the same validator before its sole JSON write at lines 191-193. The existing generator assertions are no longer its only protection.

| Prior counterexample | Independent v0.2.6 result |
|---|---|
| Replace T003's ID with a second T002 | Rejected: exact ID sequence violation, duplicate T002, missing T003 |
| Set T060 `discharged` to false while its status and state remain discharged | Rejected: status, states and Boolean disagree |
| Set T001 `delivery_scope` to 123 | Rejected: expected string |

These were checked by calling the actual verifier function in an isolated copy while replaying its external-command results from received evidence. The clean replay accepted. Other bounded replay cases rejected reordered IDs, a Boolean PDF anchor, blank supported scope, a nonexistent credited declaration, an integer state and an unhashable ID. The nonexistent declaration is rejected by the existing environment-reference gate rather than by the schema gate, as intended.

The shipped probe suite was independently executed as real Python: the unmodified ledger validated and all twelve malformed inputs were rejected with their expected diagnostic fragments. Thus its 12/12 rejection count and 13/13 count including the clean control are consistent.

The generator reproduced the shipped JSON byte for byte. Changing its first raw priority to `BAD_PRIORITY` made it exit 1 with `unknown priority` and left the existing JSON unchanged, both in normal Python and with `-O`. This checks the common validator's actual write-path protection, independently of source inspection.

## H026-1: section endings preserve the enclosing namespace

The old discovery function used only a namespace stack. An `end Inner` closing a section popped the enclosing namespace. Replaying the actual old function on a minimal namespace A / section Inner example reports `A.inside` followed by the incorrectly unqualified `after`. The v0.2.6 function reports `A.inside` and `A.after`.

The repair keeps one ordered scope stack and uses `None` for sections, so an `end` removes the innermost scope without contributing a false name component. Independent source-discovery probes passed for named sections, nested namespaces mixed with named/anonymous/noncomputable sections, and a dotted namespace with a named noncomputable section. These are Python parser checks; the supplied `namespace_section_theorem` fixture supplies the relevant actual Lean positive control in the full harness.

That fixture is well chosen. It creates a new imported module with a theorem inside a section and another theorem after the section, regenerates `AuditVerification.lean` using the tested discovery function, and expects verifier PASS. The previous discovery behavior misnames the latter theorem and fails its generated `#print axioms`. The independent environment/public-inventory equality also prevents a successful run from silently omitting a normally declared theorem. There is no need to add another expensive fixture for each incidental syntax variant examined by the small Python probes.

The discovery code deliberately remains a narrow line recognizer, not a full Lean parser. Its section fix should not be described as supporting arbitrary Lean command formatting. Unrecognized public theorem/instance syntax is independently compared with the Lean environment. Trust checks apply before visibility/provenance filtering, so the narrow recognizer does not exempt private/internal constants from axiom review.

## Existing trust and harness protections

The all-constant environment scan is unchanged. It collects axiom closures before filtering, rejects project axiom declarations, checks that all modules under the defined project roots on disk are imported, matches public theorem/instance names, checks every alias target against the replacement map and verifies every ledger-cited declaration exists. The new schema gate does not replace these checks.

The harness retains separate pristine source and project-build restoration for every fixture, checks the restored source hash, and runs the verifier as a subprocess. The new duplicate-ID negative fixture specifically covers the previous schema false acceptance through the full verifier. The namespace/section fixture is a positive control, so adding it requires the runner to accept legitimate supported syntax as well as reject defective inputs.

Four independent real CLI probes reconfirmed that unknown, mixed known/unknown, empty and empty-element `--only` values exit 2 without creating either the supplied scratch or output directory. Relative-path behavior and all 14 full fixtures are covered by the separate runtime reproduction.

## Bounded limitations and editorial observations

There is no additional mathematics or release-blocking verifier finding here.

1. For malformed nested values, `validate` does not always fulfill its documented interface of returning a list of diagnostics. Setting an ID to `[]` reaches the ID set construction first and raises `TypeError: unhashable type: 'list'`. The verifier's outer exception handler records FAIL and exits 1; the generator also exits before writing. This is a diagnostic-quality limitation, not a false acceptance, and does not reopen V025-L1.
2. The shared validator validates the JSON ledger's structure and cited declaration existence. It does not validate mathematical source correspondence or synchronize the Markdown ledger. The independently found T061 Markdown/JSON inconsistency therefore requires a documentation repair and a synchronization check if desired, not further schema vocabulary restrictions.
3. `harness_regression.py` lines 22-23 still say there are two positive controls; there are now three, including `namespace_section_theorem`. The actual fixture table and execution semantics are correct. This can be corrected along with other documentation work.

No optional schema-hardening patch is supplied. The targeted old gaps have been repaired, the bounded useful probes are sufficient, and further effort should focus on the identified documentation discrepancies and the next mathematical milestone.
