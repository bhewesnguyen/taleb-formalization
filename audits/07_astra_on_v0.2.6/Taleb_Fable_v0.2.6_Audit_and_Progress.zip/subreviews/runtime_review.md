# v0.2.6 independent runtime reproduction

**Verdict: all execution checks passed.** The supplied project was built and verified in an isolated copy with the supplied compiler and exact dependency pins. No project source, verifier, harness, fixture or trust policy was modified.

| Check | Independently observed outcome |
|---|---|
| Clean `lake build` | Exit 0; 106.49 seconds; 2743 Lake jobs; no compiler warnings or errors |
| Normal `verify.py` | Exit 0; 217.96 seconds; 125 theorems, 8 instances, 16 aliases, 149 public checks |
| Full project trust inventory | 270 constants, including 69 internal; only `propext`, `Classical.choice`, `Quot.sound`; no project axioms |
| Inventory and ledger checks | 27 imported project modules; 158 families, 2 discharged; 107 citations over 106 distinct declarations; coverage, alias, schema and citation checks passed |
| Schema probes | Exit 0; 0.06 seconds; unmodified ledger valid, all 12 deliberate mutations rejected |
| Regression coverage | All 14 fixtures exactly once, 3 positive controls and 11 negative fixtures; all behaved as expected; 1253.09 seconds aggregate wall time |
| Final source equality | All 196 received files outside regenerated `evidence/current` equal the tested copy byte for byte |
| Final dependencies | All nine actual Git revisions equal the manifest pins; all nine worktrees clean |

The regression ran as three concurrent, disjoint `--only` selections of the original harness, not as one sequential invocation. Each used its own complete dependency copy, source snapshot and project build snapshot. Both `--scratch` and `--out` were genuinely relative in all three invocations. Every per-fixture restored-source hash matches its pristine hash, and every fixture reset the project build directory from the pristine snapshot. The final pristine restoration also succeeded in every shard. Exact commands and individual records are in `execution_summary.json`, `reproduction.json`, `regression_A/`, `regression_B/` and `regression_C/`; `regression_aggregate.json` proves exact once-only coverage against the harness fixture list.

| Fixture | Expected verifier outcome | Observed | Regression verdict |
|---|---|---|---|
| `valid` | PASS | Exit 0, PASS | PASS |
| `private_sorry_theorem` | FAIL | Exit 1, FAIL | PASS |
| `private_sorry_def` | FAIL | Exit 1, FAIL | PASS |
| `private_axiom` | FAIL | Exit 1, FAIL | PASS |
| `structure_namespace_theorem` | FAIL | Exit 1, FAIL | PASS |
| `protected_theorem` | FAIL | Exit 1, FAIL | PASS |
| `alias_map_mismatch` | FAIL | Exit 1, FAIL | PASS |
| `alias_map_mismatch_optimized` | FAIL | Exit 1, FAIL | PASS |
| `orphan_module` | FAIL | Exit 1, FAIL | PASS |
| `nested_orphan_module` | FAIL | Exit 1, FAIL | PASS |
| `nested_imported_module` | PASS | Exit 0, PASS | PASS |
| `namespace_section_theorem` | PASS | Exit 0, PASS | PASS |
| `backlog_duplicate_id` | FAIL | Exit 1, FAIL | PASS |
| `dirty_dependency` | FAIL | Exit 1, FAIL | PASS |

The two private-sorry fixtures were rejected by compiler diagnostic checks; the harness then separately scanned their Lean environments and confirmed `sorryAx` on the private constant. The new `namespace_section_theorem` positive control passed with the theorem following the section end discovered correctly. The new `backlog_duplicate_id` negative fixture failed for schema violations. The alias mismatch was rejected in both ordinary Python and optimized Python execution.

Compiler installation and cache restoration are documented in `setup_notes.md`. The official Lean 4.24.0 archive SHA-256 matches the prior verified archive, extraction completed cleanly, and all exact pinned dependency repositories were fetched. The targeted Mathlib cache restoration completed in 321.74 seconds before the independent clean project build.

This execution evidence establishes the compiled propositions and recorded trust dependencies. It does not establish adequacy of a book-family target, semantic correctness of every scope description, mathematical novelty against current upstream Mathlib, or readiness of the separate quantum/classical software. Those are separate audit questions.
