# Taleb Lean v0.2.6 independent audit

Reviewed release ZIP SHA-256:
`d684d0ef3c3d17f9ceb5cd456969559674c1ac86e21bbd6a27505cf22d4fb3f3`.

Accept the mathematical increment and T061 discharge against its original construction
scope. Three documentation findings should be corrected before the next handoff:
stale Markdown ledger/module overview, false global-continuity prose, and task/parameter
routing. No new Lean proof repair was identified. The uploaded release is unchanged.

The PDF and editable Markdown contain the consolidated audit. The progress Markdown
contains a full 158-family index; JSON preserves every received row and adds reviewed
scopes, all four completed T061 children and supplemental open EVT obligations. Original
rows deliberately retain the prose errors identified by the audit; read their audit
annotations rather than treating preservation as endorsement. The Fable handoff specifies
the corrections and the bounded next T029/Pareto steps; it is not an applied code patch.

## Evidence

`evidence/reproduction/` contains actual independent build, verification and regression
records, exact commands and timings. All fourteen shipped fixtures are covered using three
concurrent, disjoint --only invocations of the unchanged harness, each with a separate
scratch copy and output directory. This is partitioned full coverage, not a claim that one
sequential full-suite invocation was run. Relative scratch/output arguments exercise the
path normalization during real restoration. Negative fixtures must reject for the expected
reason. Aggregate evidence checks exactly-once coverage and every restoration marker.

`evidence/verifier_probe/` contains real Python schema/generator/CLI checks and source-parser
checks. The verifier mutation cases replay recorded external-command outputs to isolate
Python control flow; they do not run Lean and are not extra proof evidence.
`evidence/ledger_probe/` records the stale Markdown and generator reproduction.
`evidence/provenance/` verifies the archive, bundle, patches and prior artifacts.

Consolidated finding IDs correspond to subreview IDs as follows:

- D026-1: ledger D026-L1, mathematics M026-D2.
- D026-2: ledger D026-M1, mathematics M026-D1.
- D026-3: ledger D026-R1, mathematics M026-D3, plus the reciprocal-shape correction.

## Scope and reproducibility

Use the supplied Lean 4.24.0 toolchain and unchanged dependency manifest. The usual project
gates are lake build, python3 scripts/verify.py, python3 scripts/backlog_schema_probes.py
and python3 scripts/harness_regression.py, after the pinned dependency cache is available.
Audit setup scripts retain workspace-specific paths; they are evidence, not portable
installers. The standalone bounded Python probe documents its own arguments.

The bundle proves committed history and archive equality, not original author worktree or
remote push state. The retained v0.2.5 PDF, progress Markdown and audit ZIP match the original
audit outputs byte for byte. The T062 density routing correction also corrects prior audit
guidance; it is not attributed solely to Fable.

This audit does not certify upstream Mathlib integration, exhaustive atomic book coverage,
numerical software or deployment of the quantum/classical application. Compiler binaries,
dependency caches, source-book bytes and duplicate release archives are excluded.
SHA256SUMS covers every included file except itself.
