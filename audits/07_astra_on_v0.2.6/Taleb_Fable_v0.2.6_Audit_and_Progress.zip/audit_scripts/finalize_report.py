from pathlib import Path
import json,subprocess,sys
b=Path(__file__).resolve().parent
s=json.loads((b/'reproduction/execution_summary.json').read_text())
v=s['verification'];inv=v['environment_inventory'];r=s['regression'];commands={c['name']:c for c in s['commands']}
assert all(c['exit_code']==0 for c in commands.values())
assert v['status']=='PASS' and v['build_diagnostics_clean']
assert r['fixture_count']==14 and r['all_expected_fixtures_exactly_once'] and r['all_fixtures_behaved_as_expected']
assert s['all_source_restoration_hashes_match'] and s['all_build_snapshots_restored']
assert s['all_received_files_except_generated_evidence_identical']
assert len(s['dependency_revision_and_cleanliness'])==9
assert all(d['revision_matches'] and d['working_tree_clean'] for d in s['dependency_revision_and_cleanliness'])
assert s['schema_probes']['all_probes_behaved_as_expected']
assert len(s['schema_probes']['results'])==13
assert all(x['scratch_argument_is_relative'] and x['out_argument_is_relative'] and x['suite_exit_code']==0 for x in s['relative_path_reproduction'])
seconds=s['regression_wall_time']['seconds'];minutes=round(seconds/60,1);n=s['compared_file_count']
x={'complete':True,'verdict':'Independent reproduction passed: clean build, 149 public checks, all 270 project constants within the allowed axioms, all schema probes, and all 14 regression fixtures. The regression coverage used three isolated, disjoint invocations of the unchanged harness.',
'rows':[['Clean build',f"PASS; exit 0, {commands['clean_build']['seconds']:.2f} s; 2743 Lake jobs and no compiler warnings/errors."],
['Normal verifier',f"PASS; exit 0, {commands['verify']['seconds']:.2f} s; 125 theorems, 8 instances, 16 aliases."],
['Trust and ledger','270 constants, 69 internal; only propext, Classical.choice, Quot.sound. 158 families; 107 citations over 106 names.'],
['Schema probes','PASS; all 12 malformed cases rejected and the valid control accepted.'],
['Regression coverage',f'PASS 14/14, exactly once; {minutes:.1f} min elapsed across three concurrent, isolated harness invocations. All restoration checks pass.'],
['Final source/dependencies',f'All {n} received files outside generated evidence match byte for byte. All nine dependency revisions match and worktrees are clean.']],
'detail':'Official Lean 4.24.0 and all nine exact pinned dependencies were restored after the previous temporary cache was removed. The project build began without project build outputs. All three unchanged harness commands used relative scratch/output arguments and distinct copies. Both private-sorry fixtures also exposed sorryAx in standalone scans. This is partitioned full fixture coverage, not one sequential invocation; complete commands and individual results are retained.',
'counts':{'public_checks':149,'theorems':125,'instances':8,'aliases':16,'constants':270,'internal_constants':69,'generated_constants':88,'public_definitions':32,'imported_project_modules':27,'families':158,'discharged_families':2,'citation_pairs':107,'distinct_citations':106,'regression_fixtures':14,'source_files_compared':n},
'regression_elapsed_seconds':seconds,'regression_mode':r['execution_mode'],
'fixture_results':r['results'],'all_source_restoration_hashes_match':True,'all_build_snapshots_restored':True,
'independent_raw_record':'evidence/reproduction/execution_summary.json'}
(b/'execution_summary.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
subprocess.run([sys.executable,str(b/'build_report.py')],check=True)
print(json.dumps({'complete':True,'regression_seconds':seconds,'compared_files':n},indent=2))
