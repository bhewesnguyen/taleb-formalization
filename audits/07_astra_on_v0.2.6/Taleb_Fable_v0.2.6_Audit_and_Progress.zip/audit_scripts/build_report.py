from pathlib import Path
import collections, hashlib, json, re, html, sys
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from report_content import make_pages
OUT=BASE.parent/'output'
OUT.mkdir(exist_ok=True)
ROOT=BASE/'received/Taleb_Lean_Repairs'
execution_path=BASE/'execution_summary.json'
execution=json.loads(execution_path.read_text()) if execution_path.exists() else {
 'verdict':'Independent execution is pending. Mathematical and release-identity reviews support acceptance; this draft does not assert a final runtime pass.',
 'rows':[['Clean build','Pending final record'],['Verifier','Pending final record'],['Sequential regression','Pending']],
 'detail':'The received release is unchanged. Final independent results will be inserted after the full sequential run.'}
pages=make_pages(execution)
def md_inline(s): return s
md = []
for i,p in enumerate(pages):
    md += [('# ' if i == 0 else '## ') + p['title'], '', p['subtitle'], '']
    for typ, val in p['blocks']:
        if typ == 'p': md += [val, '']
        elif typ == 'h': md += ['### ' + val, '']
        elif typ == 'b': md += ['- ' + x for x in val] + ['']
        else:
            headers, rows, widths = val
            esc = lambda x: x.replace('|', '/')
            md += ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---']*len(headers)) + '|']
            md += ['| ' + ' | '.join(esc(x) for x in row) + ' |' for row in rows]
            md += ['']
md_text = '\n'.join(md)
assert '\u2014' not in md_text
(OUT/'Taleb_Fable_v0.2.6_Independent_Audit.md').write_text(md_text)

for n, f in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(n, '/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
styles = {
    'p': ParagraphStyle('p',fontName='Body',fontSize=9.1,leading=13.3,spaceAfter=8,textColor=colors.HexColor('#263445')),
    'h': ParagraphStyle('h',fontName='Bold',fontSize=11,leading=14,spaceBefore=6,spaceAfter=6,textColor=colors.HexColor('#0B5269')),
    'cell': ParagraphStyle('cell',fontName='Body',fontSize=8.2,leading=11.7,textColor=colors.HexColor('#263445')),
    'th': ParagraphStyle('th',fontName='Bold',fontSize=8.2,leading=11.7,textColor=colors.white),
    'title': ParagraphStyle('title',fontName='Bold',fontSize=24,leading=28,spaceAfter=9,textColor=colors.HexColor('#12283C')),
    'subtitle': ParagraphStyle('subtitle',fontName='Body',fontSize=9.2,leading=13,spaceAfter=18,textColor=colors.HexColor('#526878')),
}
def fmt(s):
    s=html.escape(s)
    s=re.sub(r'\[([^]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#0B5269">\1</link>',s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`(.+?)`',lambda m:'<font name="Mono" size="7.6">'+m.group(1)+'</font>',s)
    return s
def P(s,sty='p'): return Paragraph(fmt(s),styles[sty])
story=[]
for i,p in enumerate(pages):
    if i: story.append(PageBreak())
    story += [P(p['title'],'title'),P(p['subtitle'],'subtitle')]
    for typ,val in p['blocks']:
        if typ in ('p','h'): story.append(P(val,typ))
        elif typ=='b':
            for item in val:
                story.append(Paragraph('• '+fmt(item),styles['p']))
        else:
            headers,rows,widths=val
            data=[[P(x,'th') for x in headers]]+[[P(x,'cell') for x in row]for row in rows]
            t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
            row_padding=4 if headers[0]=='Fixture' else 8
            t.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#16445B')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F0F5F8'),colors.white]),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),
                ('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),row_padding),
                ('BOTTOMPADDING',(0,0),(-1,-1),row_padding),
                ('LINEBELOW',(0,-1),(-1,-1),0.4,colors.HexColor('#C9D5DF'))]))
            story += [t,Spacer(1,10)]
def decor(c,doc):
    c.saveState()
    c.setFillColor(colors.HexColor('#16445B')); c.rect(0,813.89,595.28,28,fill=1,stroke=0)
    c.setFillColor(colors.white);c.setFont('Bold',8)
    c.drawString(48,823,'INDEPENDENT AUDIT  /  TALEB LEAN v0.2.6')
    c.setStrokeColor(colors.HexColor('#C9D5DF'));c.line(48,42,547,42)
    c.setFont('Body',8);c.setFillColor(colors.HexColor('#526878'))
    c.drawString(48,28,'20 September 2026  |  Scope and evidence reviewed independently')
    c.drawRightString(547,28,str(doc.page));c.restoreState()
doc=SimpleDocTemplate(str(OUT/'Taleb_Fable_v0.2.6_Independent_Audit.pdf'),pagesize=(595.28,841.89),leftMargin=48,rightMargin=48,topMargin=49,bottomMargin=54,title='Taleb Lean v0.2.6 Independent Audit',author='Independent audit')
doc.build(story,onFirstPage=decor,onLaterPages=decor)

ledger=json.loads((ROOT/'docs/FORMALIZATION_BACKLOG.json').read_text())
review=json.loads((BASE/'ledger_review.json').read_text())
by_id={r['id']:r for r in review['families']}
groups=collections.defaultdict(collections.Counter)
for r in ledger: groups[r['dependency_group']][r['status']]+=1
children=[
 {'child':'Standard Gumbel','audit_state':'complete','delivered':'Concrete probability measure, exact CDF, maximum law and finite product iid model.','remaining':'None within this child.'},
 {'child':'Standard Frechet, xi > 0','audit_state':'complete','delivered':'Support-correct probability measure, exact CDF, maximum law and finite product iid model.','remaining':'None within this child.'},
 {'child':'Standard reverse-Weibull, alpha > 0','audit_state':'complete','delivered':'Upper-endpoint probability measure, exact CDF, max-stability and finite product iid model.','remaining':'None within this child.'},
 {'child':'Positive location/scale, all three laws','audit_state':'complete','delivered':'Generic affine probability law and CDF rule; three named families and exact maximum-law measure equalities.','remaining':'None within this child.'}]
progress={
 'release':'v0.2.6','audit_date':'2026-09-20',
 'source_archive_sha256':'d684d0ef3c3d17f9ceb5cd456969559674c1ac86e21bbd6a27505cf22d4fb3f3',
 'family_count':len(ledger),'status_counts':dict(collections.Counter(r['status'] for r in ledger)),
 'supported_families':11,'discharged_families':['T060','T061'],
 'citation_pairs':107,'distinct_cited_declarations':106,
 'caution':'Unequal curated families, not an exhaustive atomic theorem census or an effort-completion percentage. Original rows are preserved, including documentation errors that the audit identifies separately.',
 'execution':execution,'t061_children':children,
 'supplemental_open_evt_tasks':review['supplemental_open_EVT_tasks'],
 'dependency_group_counts':{g:dict(c) for g,c in sorted(groups.items())},
 'findings':[dict(f,consolidated_id={'D026-L1':'D026-1','D026-M1':'D026-2','D026-R1':'D026-3'}.get(f['id'],f['id'])) for f in review['findings']],
 'families':[{'original':r,'audit':by_id.get(r['id'],{'audited_status':r['status'],'scope':'Status tallied; no new full-family correctness audit or proof credit.'})} for r in ledger]}
(OUT/'Taleb_Proof_Progress_v0.2.6.json').write_text(json.dumps(progress,indent=2,ensure_ascii=False)+'\n')
clean=lambda s:str(s).replace('\u2014','-').replace('\u2013','-').replace('\u2011','-').replace('|','/')
lines=['# Taleb proof progress, v0.2.6','','Independent assessment, 20 September 2026. The companion JSON preserves all 158 received family rows and adds audited scopes, findings and supplemental obligations.','','## Current position','',execution['verdict'],'',
 '**T061 closure is accepted.** The three named EVT probability laws and their positive location/scale scope are complete. T060 remains discharged. The release Markdown ledger is stale; the tally below uses the reviewed JSON and the accepted mathematical scope.','','| Status | Families |','|---|---:|']
for status in ['discharged','partial','reuse','missing','source-check','model-needed','empirical']:
 lines.append(f'| {status} | {progress["status_counts"][status]} |')
lines += ['','The change from v0.2.5 is one closure: 1 to 2 discharged, 10 to 9 partial. Eleven families have credited Lean work, with 107 family/declaration pairs over 106 distinct names. There are 140 formal-proof families: 2 closed and 138 open. The other 18 require models or empirical work. Counts do not measure effort completed, and the inventory is not an exhaustive atomic census of every book claim.','','## Completed T061 children','','| Child | Audit state | Delivered |','|---|---|---|']
for r in children:lines.append('| '+' | '.join(clean(r[k]) for k in ['child','audit_state','delivered'])+' |')
lines += ['','The unified GEV parametrization and its xi -> 0 Gumbel limit were not part of the original three-family construction target. They remain explicit source obligations. No new global-continuity theorem is required to close this Stieltjes construction.','','## Documentation repairs before the next handoff','','1. Generate Markdown and JSON from the same validated records; update T061 in the stale Markdown and the module header. Add a fast consistency check.','2. Correct the claim that the support-correct Frechet and reverse-Weibull CDFs are not globally continuous. Under positive shapes they are continuous; only right continuity needed to be proved for construction.','3. Correct the carried-forward density-to-T062 mapping, including prior audit guidance. T062 is a convergence family. Correct the Pareto-to-Frechet shape to xi = 1/alpha.','','## Supplemental open EVT obligations','','These are visible work items, not extra rows in the fixed 158-family count and not reasons to reopen T061.','']
lines += ['- '+clean(x) for x in review['supplemental_open_EVT_tasks']]
lines += ['','## Audited supported families','']
for r in review['families']:
 lines += [f'### {r["id"]}: {r["title"]}','',f'**Status: {r["audited_status"]}.** Recorded states: '+', '.join(r['states'])+'.','',
  '**Assessment:** '+clean(r['audit_verdict']).replace('_',' '),'','**Delivered scope:** '+clean(r['audited_scope']),'',
  '**Recommended clarification:** '+clean(r['recommendation']),'','**Remaining target:** '+clean(r['remaining_target']),'']
lines += ['## Dependency-group position','','Remaining formal combines reuse, missing and source-check. The source-check column is a subset, not an additional category.','','| Group | Families | Discharged | Partial | Source-check subset | Remaining formal | Model / empirical |','|---|---:|---:|---:|---:|---:|---:|']
for g,c in sorted(groups.items()):
 vals=[g,sum(c.values()),c['discharged'],c['partial'],c['source-check'],sum(c[s] for s in ['reuse','missing','source-check']),c['model-needed']+c['empirical']]
 lines.append('| '+' | '.join(str(v) for v in vals)+' |')
lines += ['','## Full 158-family index','','Unsupported rows are tallied here without a new full-family mathematical audit. Source locators are the release anchors.','','| ID | Unit | Status | Group | Priority | Family | Printed pages |','|---|---|---|---|---|---|---|']
for r in ledger:lines.append('| '+' | '.join(clean(r[k]) for k in ['id','unit','status','dependency_group','priority','title','printed_pages'])+' |')
lines += ['','## Next acceptance sequence','','1. Correct the three documentation findings without altering the proved scope.','2. T029: actual nonnegative weighted sums and finite log-tail exponent min(alpha, beta), via event inclusions and a general exponent squeeze; no independence.','3. Exact Pareto probability-law slice: global survival, finite moments and divergence, conditioning/excess, positive-power pushforward. Credit only the relevant slices of larger families.','4. Pareto maxima convergence under T011/T062 with reciprocal shape; separately scoped EVT densities and unified GEV work.','','Mathematical declarations do not establish a Mathlib upstream merge or readiness of the separate quantum/classical application. Those software outcomes need their own implementation evidence.']
text='\n'.join(lines)+'\n'
assert not any(ch in text for ch in ['\u2014','\u2013','\u2011'])
(OUT/'Taleb_Proof_Progress_v0.2.6.md').write_text(text)
print(json.dumps({'pages_planned':len(pages),'families':len(ledger),'statuses':progress['status_counts'],'out':str(OUT)},indent=2))
