from pathlib import Path
import collections,hashlib,json,re,zipfile
import fitz
BASE=Path(__file__).resolve().parent;OUT=BASE.parent/'output'
x=json.loads((OUT/'Taleb_Proof_Progress_v0.2.6.json').read_text())
r=json.loads((BASE/'received/Taleb_Lean_Repairs/docs/FORMALIZATION_BACKLOG.json').read_text())
assert [f['original'] for f in x['families']]==r
assert [f['original']['id'] for f in x['families']]==[f'T{i:03}' for i in range(1,159)]
assert x['status_counts']==dict(collections.Counter(f['status'] for f in r))
assert x['discharged_families']==['T060','T061']
assert len(x['t061_children'])==4 and all(c['audit_state']=='complete' for c in x['t061_children'])
assert sum(sum(v.values()) for v in x['dependency_group_counts'].values())==158
assert sum(bool(f['original']['declarations']) for f in x['families'])==11
pairs={(f['id'],d) for f in r for d in f['declarations']}
assert len(pairs)==107 and len({d for _,d in pairs})==106
assert x['execution']['complete'] is True
for name in ['Taleb_Fable_v0.2.6_Independent_Audit.md','Taleb_Proof_Progress_v0.2.6.md','Taleb_Fable_v0.2.6_Review_Handoff.md']:
 text=(OUT/name).read_text()
 assert not any(ch in text for ch in ['\u2014','\u2013','\u2011']),name
 assert 'pending final' not in text.lower() and 'execution is pending' not in text.lower(),name
pdf=fitz.open(OUT/'Taleb_Fable_v0.2.6_Independent_Audit.pdf')
assert len(pdf)==8,len(pdf)
for page in pdf:
 text=page.get_text();assert '\ufffd' not in text
 # Main content must fit clear of the footer. Manual visual review is additional.
 for block in page.get_text('blocks'):
  if block[1]<780 and block[4].strip() and block[1]>45:assert block[3]<786,block
zpath=OUT/'Taleb_Fable_v0.2.6_Audit_and_Progress.zip'
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
checksum=(OUT/(zpath.name+'.sha256')).read_text().split()[0]
assert hashlib.sha256(zpath.read_bytes()).hexdigest()==checksum
print(json.dumps({'all_checks_passed':True,'pages':len(pdf),'original_family_rows_preserved':158,'supported_scopes':11,'completed_t061_children':4,'zip_sha256':checksum},indent=2))
