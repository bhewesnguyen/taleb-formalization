# Fable handoff after the v0.2.6 independent review

Use the accompanying audit and evidence as the reference. The mathematics milestone and T061 closure are accepted against the original three-family target. Preserve the Lean 4.24.0/Mathlib pins and the proved statements. This handoff is an implementation specification, not a patch already applied to the release.

## First commit: synchronize and correct the handoff

1. **D026-1: generate both ledgers from one validated source.** `docs/FORMALIZATION_BACKLOG.md` is still byte-identical to v0.2.5. Its T061 row says partial and lists 21 old declarations; JSON correctly says discharged and lists 45. The present generator writes JSON only. Make it render the Markdown rows from the same validated records, regenerate both, and add a fast consistency check. Preserve all 158 IDs and existing targets. Verify the check catches a stale T061 status or scope in either rendering. Update the `ExtremeValueLaws.lean` title and obsolete 'Not done' paragraph to describe reverse-Weibull and refer to `ExtremeValueAffine.lean` for location/scale.
2. **D026-2: correct continuity prose at the authoritative source.** The positive-shape, support-correct Fréchet and reverse-Weibull CDFs are globally continuous. The implementation proves the right continuity sufficient for the Stieltjes construction. Delete the claim that they lack global continuity; distinguish the raw unguarded `frechetFormula` from `frechetCDF`. No new continuity theorem is required for T061 acceptance. Also make 'positive scale in every statement' precise: the affine definitions and probability instances permit any real scale, while the displayed positive-scale CDF and maximum rules require it.
3. **D026-3: correct task routing and the reciprocal shape.** The density-to-T062 mapping is a carried-forward error, including earlier auditor guidance. Preserve T062's actual target, 'Frechet and Gaussian maximum domains'. Route convergence setup to T011, regular-variation/Fréchet and Gaussian/Gumbel work to T062, and record density/withDensity work in a separate clearly identified supplemental task. Do not silently redefine a parent ID. For Pareto tail exponent alpha, the project's Fréchet parameter is xi = 1/alpha, so the proposed limit law is `frechetMeasure (1 / alpha)`, with the appropriate positive proof. Track unified GEV coordinates and the xi -> 0 Gumbel limit explicitly as supplemental source obligations; do not reopen T061.
4. Fold in the minor harness docstring correction: it now has three positive controls. The schema suite has twelve malformed cases plus one valid control, so 12/12 rejected and 13/13 expected outcomes are consistent. A caught TypeError for a deeply malformed nested schema value is fail-closed and does not demand another hardening project.

Check generation consistency, run the existing schema probes and normal verification, and retain exact evidence. Add only a focused regression for the concrete generation mismatch. Do not add expensive fixtures that merely repeat the same schema/discovery cases. Keep a correction history and distinguish the original v0.2.6 archive from the corrected next release.

## Next mathematics commit: T029 probabilistic half

Target actual measurable random variables with nonnegative values (pointwise or almost surely, explicitly stated), positive weights, and the project's finite log-tail exponents. For two coordinates, prove the exponent of the weighted sum is the minimum of the two exponents. Independence is not needed.

For Z = aX + bY, a,b > 0, and t > 0, establish the event/probability bounds:

- P(X > t/a) <= P(Z > t).
- P(Y > t/b) <= P(Z > t).
- P(Z > t) <= P(X > t/(2a)) + P(Y > t/(2b)).

Prove the reusable analytic rules for positive argument rescaling, eventual positivity, and the finite-exponent squeeze or sum. Account for the sign of log(t) and the reversal under minus log. The existing `two_power_tail_min` covers exact power formulas; do not assume arbitrary survival functions have those formulas. No survival-ratio asymptotic, independence-based convolution asymptotic, or regular-variation-of-the-sum claim follows from exponent equality alone.

Connect the conclusion to the actual sum pushforward law or an explicitly defined survival function of the random variable. If extending to finite families, retain a nonempty index and positive weights. Keep the signed-cancellation counterexample and the book's missing-minus-sign repair visible. Record the exact theorem scope before deciding whether T029's remaining target is fully met.

## Following milestone: exact Pareto slice

Use the pinned `paretoMeasure` API, with lower endpoint L > 0 and shape alpha > 0. First identify the global CDF/survival. For p >= 0, show finite moments exactly for p < alpha with value alpha * L^p / (alpha - p); prove divergence at and above alpha using an extended nonnegative integral or a precise non-integrability statement. Do not infer finiteness from Lean's totalized real integral.

Then address threshold conditioning/excess and positive-power pushforwards. Credit only delivered slices of T005/T021/T028/T032; those parent targets are broader. `affineLaw` supplies a reusable pushforward definition and positive-scale CDF rule, not the moment or conditioning proofs automatically.

Report exact declarations, source pages, hypotheses, proof trust results and remaining scope. Do not infer a book-completion percentage from theorem counts, or claim upstream Mathlib/software deployment from these local formal proofs.
