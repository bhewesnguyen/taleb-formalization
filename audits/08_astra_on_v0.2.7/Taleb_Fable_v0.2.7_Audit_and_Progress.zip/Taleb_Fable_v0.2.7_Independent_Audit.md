# Taleb Lean v0.2.7

Independent audit | 20 September 2026 | Mathematics, verification and proof progress

### Assessment

**Accept the mathematical increment and the agreed weighted-sum milestone. Keep T029 partial against its inherited, stronger regular-variation target.** No defect was found in the new Lean proofs. Three low-priority documentation corrections remain; none requires rewriting the mathematics.

Independent reproduction passed: clean build, 164 public checks, all 296 project constants within the allowed axioms, 18 schema/rendering probes and all 14 shipped regression fixtures. An additional real stale-Markdown mutation was correctly rejected.

| Area | Independent assessment |
|---|---|
| Weighted sums | The binary, nonnegative, positive-weight finite-log-exponent result is correct. Its event bounds require no independence; a measurable pushforward version supplies the ordinary law statement. |
| Reusable mathematics | Seven general analytic lemmas support the argument. The new global-continuity results for the two support-correct EVT CDFs are also correct. |
| T029 scope | The prior audit asked for this exponent theorem, and it is delivered. A stronger historical regular-variation target remains explicit, without treating the completed milestone as a failed proof. |
| Earlier repairs | The shared Markdown renderer and verifier gate repair D026-1. The continuity prose and supplemental EVT task routing repair D026-2/3, subject to the small S001 clarification below. |
| Release identity | ZIP, manifest, bundled snapshot and both patch routes agree. Pins are unchanged and all pre-existing mathematical content is preserved. |

### Broader progress

**2 discharged / 9 partial / 4 reuse / 91 missing / 34 source-check / 15 model-needed / 3 empirical = 158 families.** T060 and T061 remain discharged. Eleven families have credited Lean support. This release completes a substantial child milestone inside T029 without closing another parent family.

The ledger rises from 107 to **123 family/declaration pairs**, covering **122 distinct names**. Public verification rises from 149 to 164 checks. These are inventories of unequal tasks and declarations, not percentages of effort or independent book theorems completed.

## Analytic bridge and continuity

The general finite-exponent argument handles positivity and logarithm signs correctly

HasFiniteTailExponent S α requires eventual strict positivity of S and the finite limit -log(S(t))/log(t) → α as t → +∞. It does not itself assert monotonicity, measurability, probability normalization or regular variation. This general analytic interface is appropriate here.

| New analytic rule | Reviewed reasoning |
|---|---|
| Log-ratio antitonicity | For t > 1 and positive tail values, dividing by log t preserves order, while minus log reverses it. All later squeezes use this direction. |
| Positive argument rescaling | For c > 0, log(ct)/log t → 1. The cancellation of log(ct) occurs only eventually where ct > 1, established from t > max(1, 1/c). |
| Maximum of two tails | For eventual positive inputs and t > 1, the exponent expression of max(S1,S2) equals the minimum of the two exponent expressions. Continuity of minimum gives min(α,β). |
| Sum of two tails | max(S1,S2) ≤ S1+S2 ≤ 2 max(S1,S2). The log-ratio bounds differ by log 2 / log t, which tends to zero. |
| General squeeze | If L ≤ S ≤ U eventually and L,U share a finite exponent, S inherits positivity from L. The reversed log-ratio inequalities give the same limit. |

These rules comprise seven declarations, including two logarithm helper lemmas. They cover equal and zero exponents; arbitrary negative exponents are also legitimate for the analytic interface. Negative exponents cannot arise for actual probability tails satisfying this limit. No zero-log cancellation or totalized log-at-zero shortcut was found.

### Two checked global-continuity facts

For ξ > 0, continuous_frechetCDF joins the zero branch at and below the lower endpoint to the positive-base formula above it. The previously proved right limit at zero supplies the delicate boundary. For α > 0, continuous_reverseWeibullCDF joins exp(-(-x)^α) below zero to 1 above, using 0^α = 0 at the endpoint.

The positive-shape restrictions are substantive. At reverse-Weibull shape zero, the negative branch is exp(-1) and jumps to 1 at zero; the global continuity claim would fail. The earlier right-continuity statement without that shape restriction remains correct. Monotonicity, right continuity and endpoint limits 0/1 suffice for the Stieltjes probability construction; global continuity is an additional valid result.

**No Lean repair is requested in these nine declarations.** They meet the proposed general route and should not be rewritten merely for style.

## The probability theorem

The event argument works without independence and the law interface is explicit

Let Z = aX + bY, where a,b > 0 and X,Y are pointwise nonnegative on a probability space P. Write S_X(t) = P.real {ω : t < X(ω)}. The three underlying event inclusions give, for real t:

| Bound | Why it holds |
|---|---|
| S_X(t/a) ≤ S_Z(t) | If aX > t, then adding the nonnegative term bY preserves the strict inequality. |
| S_Y(t/b) ≤ S_Z(t) | The symmetric argument uses nonnegativity of aX. |
| S_Z(t) ≤ S_X(t/(2a)) + S_Y(t/(2b)) | If both weighted terms are at most t/2, their sum is at most t. The complementary inclusion and union bound give the result. |

The lower envelope max(S_X(t/a), S_Y(t/b)) and the upper sum have exponent min(α,β), by the general analytic rules. The squeeze therefore proves HasFiniteTailExponent for the weighted-sum tail. This does not specialize the older exact two-power formula.

### Measurability and finite measure are handled honestly

Pure event inclusions need no measurability. Lean measures are defined on all sets as outer-measure values, so monotonicity and the union bound still apply. The probability-space assumption ensures finiteness when converting to real-valued measures, avoiding an infinity-to-zero totalization error.

The most general survivalRV theorem permits arbitrary coordinate functions, so its nonmeasurable case should be read as an event outer-measure statement. The separate survivalRV_eq_survival_map lemma requires measurability, and hasFiniteTailExponent_survival_map_weightedSum delivers the ordinary pushforward-law theorem for measurable X and Y. No hidden probability-law construction is assumed.

### Accepted scope and visible limits

**The requested binary, finite-exponent milestone is complete.** No independence assumption is needed, including for dependent coordinates. Pointwise nonnegativity is stronger than an almost-sure formulation but matches the stated theorem. Positive weights and support restrictions prevent cancellation counterexamples.

The source Property 5.1 at printed p.99 / PDF p.113 states a finite-family exponent rule and informally allows an infinite exponent. This release proves the binary finite-real-exponent slice. Finite-family and almost-sure wrappers can follow; an extended-real exponent API is a separate scope decision. These were not retrospectively imposed as acceptance gates for the agreed binary task.

## T029: scope ruling

Credit the completed task without silently deleting the stronger inherited target

The original v0.2.0 T029 target said that a heavier regularly varying tail dominates a sum. The v0.2.6 remaining-obligations field and audit handoff instead specified the nonnegative weighted-sum finite-exponent theorem. Fable implemented that requested milestone correctly. The mismatch is inherited ledger/audit scoping ambiguity, not a new proof gap or failure to follow the previous guidance.

**Recommendation: retain T029 as partial, mark the binary exponent child complete, and separately name the stronger unequal-index regular-variation child.** Do not silently narrow the parent solely to increase the discharged count. A deliberate future ledger revision could split these scopes, preserving the stronger obligation and the history.

### Why the distinction is mathematical

A finite log-tail exponent does not imply regular variation, even for valid survival functions. For 0 < ε < α, set S(t)=1 for t ≤ 1 and S(t)=t^(-α) exp(ε sin(log t)) above 1. It is continuous and decreasing to zero, with finite exponent α. But S(exp(π)t)/S(t)=exp(-πα) exp(-2ε sin(log t)) oscillates. This is an explanatory counterexample, not an additional Lean-verified artifact.

### Precise stronger child

For nonnegative measurable X,Y with eventually positive survival functions regularly varying with indices -α and -β, where 0 ≤ α < β, and a,b > 0, target:

| Normalization | Target asymptotic |
|---|---|
| Relative to the weighted heavier tail | S_(aX+bY)(t) / S_X(t/a) → 1. |
| Relative to the unweighted heavier tail | S_(aX+bY)(t) / S_X(t) → a^α. |

For 0 < δ < 1, the useful upper split is S_Z(t) ≤ S_X((1-δ)t/a) + S_Y(δt/b), with the same lower bound S_X(t/a). After division, the first upper term tends to (1-δ)^(-α) and the strictly lighter term to zero; let δ decrease to zero. No independence is required. A first implementation restricted to α > 0 is a reasonable explicitly recorded slice.

Do not extrapolate a same-index ratio formula from this argument. Dependence can change its coefficient: if Y=X has an exact Pareto tail of index 2, then S_(X+Y)(t)=4t^(-2), whereas S_X(t)+S_Y(t)=2t^(-2), for large t. This example concerns the coefficient; it is not a counterexample to regular variation itself.

The book display itself asserts exponent equality, not the stronger ratio statement. The stronger child is retained because of the established ledger target. The audit does not relabel it as an unproved claim in that display.

## Verification and documentation

The structural repair passes; three small handoff corrections remain

### D026-1/2/3 response accepted

One renderer now serves the generator and verifier. The generator validates before writing either ledger. Independent checks reproduce the v0.2.5 Markdown exactly, detect the prior v0.2.6 difference of 11 removed plus 11 added lines, and reproduce the v0.2.7 files exactly. A real CLI mutation of only T061 Markdown fails the new rendering gate. Existing trust, module, alias and dependency gates are preserved.

The implementation compares decoded, newline-normalized text; the current LF files additionally match byte for byte. This is a content-consistency gate, not a promise to reject harmless CRLF changes. It cannot decide whether synchronized prose accurately describes a theorem.

### D027-1 | low | T029 stale sentence and delivery facet

The authoritative generator and both ledgers still say: "The probabilistic statement about sums of random variables remains open." Replace this with the delivered binary finite-exponent scope and the precise stronger child. The other new scope fields are already more accurate.

Add conditional_law_theorem for the exponent theorem, consistent with the existing vocabulary for assumed tail-property premises. law_theorem may remain if explicitly credited to survivalRV_eq_survival_map, the measurable event/pushforward identity. This classification change does not diminish the proof or demand another existence theorem.

### D027-2 | low | S001 needs an explicit zero-shape branch

The supplemental unified-GEV task writes exp(-(1+ξx)^(-1/ξ)) and requests a valid CDF for every real ξ. Define ξ = 0 separately as gumbelCDF; restrict that power expression to ξ ≠ 0. Otherwise Lean totalized division gives the constant exp(-1) at ξ = 0. For ξ > 0 the off-support left branch is 0; for ξ < 0 the off-support right branch is 1.

Correct its source anchor to printed pp.172-173 / PDF pp.186-187: the unified display is on the first page and the limiting/named families on the next. The endpoint-coordinate warning is correct. This is a future specification repair, not a defect in existing EVT laws or a reason to reopen T061.

### D027-3 | low | supplied probe-count typo

Step 7 of the supplied archive-validation log says 17 probes. There are 18: twelve malformed-schema checks, one valid-schema control, four stale-rendering checks and one valid-rendering control. Correct the next generated summary and visibly annotate the historical count rather than silently rewriting the received record.

No additional expensive Lean fixture is requested for these prose changes. The actual CLI stale-ledger case, existing regression coverage and bounded Python probes address the changed verifier behavior.

## Position in the broader ledger

Parent counts are unchanged; the completed T029 child is substantive progress

| Family | Status | Audited delivery scope |
|---|---|---|
| T001 | Partial | Ratio-only regular/slow variation API; positive measurable convention and its bridge remain. |
| T007 | Partial | Gaussian realization at stable index 2, including zero scale; general stable existence remains. |
| T008 | Partial | Subexponential predicate and conditional self-convolution tail result; concrete-law examples remain. |
| T029 | Partial | Binary weighted-sum finite-exponent theorem and measurable law version; stronger unequal-index regular-variation child remains. |
| T032 | Partial | Analytic power-transform exponent; actual law pushforward remains. |
| T046 | Partial | Actual Gaussian characteristic-function/convolution bridge; Cauchy remains open. |
| T047 | Partial | Prerequisite-only sum/convolution infrastructure; average-law scaling and convergence remain. |
| T060 | Discharged | Generic maximum CDF and minimum survival laws with ordinary probability hypotheses. |
| T061 | Discharged | Three standard EVT measures, exact CDFs, affine families and maximum-law measure equalities; two continuity additions. |
| T118 | Partial | Prerequisite-only tail-kernel convexity; Pareto moments and integrated Jensen remain. |
| T124 | Partial | Rational-expression algebra and positivity; gamma inverse-moment integration remains. |

T029 increases from 2 to 16 credited names; T061 increases from 45 to 47. The total is 123 family/declaration pairs over 122 distinct names, because one Gaussian result is credited to both T007 and T046. All cited declarations occur in the checked project inventory.

There are **140 formal-proof families: 2 discharged and 138 open**, comprising 9 partial, 4 reuse, 91 missing and 34 source-check. Another 15 need models and 3 are empirical. Supplemental S001 and S002 are separately open and excluded from the fixed 158-family denominator.

The companion progress JSON preserves every received row and adds reviewed scopes, all 22 dependency-group tallies, completed and open children, findings and the T029 scope history. Unchanged unsupported rows are tallied, not represented as independently re-proved. The Markdown includes the full family index.

This ledger is a curated working inventory, not an exhaustive atomic census of the book or a measure of remaining effort. These mathematical results also do not establish upstream Mathlib acceptance or readiness of the separate quantum/classical application; those software milestones need their own implementation evidence.

## Next contained milestone

Exact Pareto laws and moments are a sensible next step

Proceed with the exact Pareto slice after the small documentation corrections. The pinned Mathlib already defines paretoMeasure L α using volume.withDensity and proves normalization for L > 0 and α > 0. Its probability result is a lemma that can install a local instance. The inspected pinned file has integral representations of its CDF, but no closed-form CDF or moment theorem to reuse there.

| Stage | Concrete acceptance target |
|---|---|
| 1. Exact law interface | For L > 0 and α > 0: CDF 0 below L and 1-(L/x)^α for x ≥ L. Strict survival is 1 below L and (L/x)^α for x ≥ L, including the endpoint value 1 at L. |
| 2. Finite moments | For real p ≥ 0, prove finiteness exactly when p < α and the value α L^p/(α-p). Include p=0 and the strict boundary p=α. |
| 3. Divergence | At p ≥ α prove that the extended nonnegative moment integral is +∞. A totalized real integral returning 0 is not evidence of finiteness or a valid divergence statement. |
| 4. Follow-on transforms | After the law/moment slice, prove threshold conditioning/excess and positive-power pushforwards with explicit parameter/support hypotheses. |

The first three stages form a useful bounded release. Stage 4 can be a later child milestone. Credit only the exact delivered slices of T005/T021/T028/T032; a Pareto example does not close their broader targets. affineLaw supplies a measurable affine pushforward and a positive-scale CDF rule, not moment integration or conditioning proofs for free.

### Keep the two other workstreams explicit

T029 regular-variation dominance can proceed separately; it need not block Pareto construction. Later Pareto maximum convergence under T011/T062 uses frechetMeasure (1/α), with normalization M_n/(L n^(1/α)). Gaussian Gumbel normalization remains a separate obligation. Densities/withDensity identifications for the EVT laws belong to S002, not to T062.

For S001, standard unified GEV coordinates are: ξ > 0 gives frechetLaw ξ (-1/ξ) (1/ξ); ξ < 0 gives reverseWeibullLaw (-1/ξ) (-1/ξ) (-1/ξ); ξ = 0 gives gumbelLaw 0 1. In the negative case the repeated positive quantity supplies shape, endpoint and scale respectively. These coordinate identities are a future specification, not newly proved Lean results.

For unified location m and scale s > 0, the nonzero-shape endpoint is m-s/ξ, with Fréchet scale s/ξ for ξ > 0 and reverse-Weibull scale -s/ξ for ξ < 0. The shape-to-zero limit belongs to this unified parameterization, not to an unchanged endpoint-coordinate family.

## Independent execution

Actual compiler checks are separated from Python control-flow replays

| Check | Observed outcome |
|---|---|
| Clean build | PASS; exit 0, 114.32 s; 2744 Lake jobs and no compiler warnings/errors. |
| Normal verifier | PASS; exit 0, 231.12 s; 140 theorems, 8 instances and 16 aliases. |
| Trust and ledger | 296 constants, 79 internal; only propext, Classical.choice, Quot.sound. 158 families; 123 citations over 122 names; rendering equality passes. |
| Schema/rendering probes | PASS 18/18: sixteen malformed cases rejected and two valid controls accepted. |
| Shipped regression | PASS 14/14, exactly once; 21.3 min across three concurrent isolated harness invocations. Every restoration check passes. |
| Additional real CLI case | Stale T061 Markdown rejected at rendering gate; exit 1, 233.71 s; source restored. |
| Final source/dependencies | All 213 received files outside generated evidence match byte for byte. All nine dependencies remain pinned and clean. |

Official Lean 4.24.0 and nine exact pinned dependency caches were reused; the project build started without project build outputs. The unchanged harness ran in three disjoint --only shards with separate copies and relative scratch/output arguments. This is full fixture coverage, not one sequential invocation. Both private-sorry cases also exposed sorryAx in standalone scans. No received proof, fixture or axiom policy was changed.

| Fixture | Required behavior |
|---|---|
| valid | Accept the pristine project. |
| namespace_section_theorem | Accept names after section ends inside a namespace. |
| nested_imported_module | Accept and scan the imported nested module. |
| private_sorry_theorem / private_sorry_def | Reject; standalone scan must also expose sorryAx. |
| private_axiom | Reject the added project axiom. |
| structure_namespace_theorem / protected_theorem | Reject public-inventory mismatch. |
| alias_map_mismatch / optimized variant | Reject alias mismatch, including Python -O. |
| orphan_module / nested_orphan_module | Reject unimported project modules. |
| dirty_dependency | Reject a modified dependency checkout. |
| backlog_duplicate_id | Reject the malformed ledger. |

The fourteen shipped names are grouped above for space. The extra real CLI stale-Markdown rejection is separate, as are eighteen shipped Python probes and nine bounded verify.main replays using recorded external-command output. Those replays test Python control flow; they are not additional Lean proof checks.

## Provenance and evidence boundaries

The supplied release remains unchanged

| Item | Independently checked |
|---|---|
| Release ZIP | SHA-256 88ebaa078a18dc0e16bb46057969c5fec186c1fc958df1422b6d434e323d157b; 222 regular files and 251 archive entries. |
| Manifest and paths | 221/221 manifest hashes; exact extraction; no unsafe paths, duplicate regular files, symbolic links or included project build outputs. |
| Bundled snapshot | Commit fe14519deafc0bab2ba6c696932419c7dd55d8d9; project tree 94c53167c02a41c357dc6266c085dd1299cb0898. All project bytes match. |
| Both patch routes | Full v0.2.0 and incremental v0.2.6 patches apply to their stated bases and reproduce the exact project tree and files. |
| Pins and preservation | Lean 4.24.0; Mathlib f897ebcf72cd16f89ab4577d0c826cd14afaafc7. Twenty-five old math modules are byte-identical; the remaining one only adds continuity proofs and documentation. |
| Source correspondence | Locally supplied arXiv:2001.10488v4, 523 pages. Property 5.1: printed99/PDF113. Unified EVT and named forms: printed172-173/PDF186-187. |

### Retained artifacts and history

All 18 retained-artifact manifest entries pass. The prior audit ZIP and progress Markdown match the original outputs. The retained standalone prior PDF differs in binary representation and metadata, but all eight page texts and every 150-dpi rendered RGB pixel buffer match. No substantive page change was identified; the cause of the representation difference is unestablished.

The bundle proves its included history and snapshot. It contains three commits after the prior deliverables commit; the announced current deliverables commit lies outside its explicitly documented scope. This does not establish the author's original working-tree cleanliness or push state, and does not contradict a later fourth commit.

### What this audit establishes

The findings support the specific reviewed Lean propositions, permitted axiom dependencies, bounded source correspondence and the stated family-level progress. The received project has not been patched. The handoff supplies concrete documentation edits and next theorem specifications, not a claim that those future results have already been formalized.

The evidence package contains the PDF, editable report, full progress ledger, Fable handoff, source subreviews, provenance scripts/results and independent execution logs. It excludes compiler binaries, dependency caches, source-book bytes and duplicate submitted archives. SHA256SUMS covers every included evidence file except itself.
