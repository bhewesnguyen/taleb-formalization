"""Package the completed audit without toolchains, source book or duplicate release files."""
from pathlib import Path
import hashlib,json,zipfile
BASE=Path(__file__).resolve().parent;OUT=BASE.parent/'output'
execution=json.loads((BASE/'execution_summary.json').read_text())
assert execution.get('complete') is True, 'Do not package a provisional runtime verdict'
files={}
for name in ['Taleb_Fable_v0.2.7_Independent_Audit.pdf','Taleb_Fable_v0.2.7_Independent_Audit.md','Taleb_Proof_Progress_v0.2.7.json','Taleb_Proof_Progress_v0.2.7.md','Taleb_Fable_v0.2.7_Review_Handoff.md']:
 files[name]=(OUT/name).read_bytes()
for name in ['analytic_review.md','probability_review.md','ledger_review.md','ledger_review.json','verifier_review.md','provenance_review.md','runtime_review.md']:
 files['subreviews/'+name]=(BASE/name).read_bytes()
for folder in ['verifier_probe','provenance','reproduction']:
 for p in sorted((BASE/folder).rglob('*')):
  if p.is_file() and p.suffix in {'.json','.md','.log','.py','.lean','.diff'} and p.stat().st_size<=2_000_000 and '__pycache__' not in p.parts and '.git' not in p.parts and '.lake' not in p.parts:
   if folder=='provenance' and len(p.relative_to(BASE/folder).parts)>1: continue
   files['evidence/'+folder+'/'+str(p.relative_to(BASE/folder))]=p.read_bytes()
files['evidence/execution_summary.json']=(BASE/'execution_summary.json').read_bytes()
for name in ['report_content.py','build_report.py','build_progress.py','package_audit.py','validate_artifacts.py','finalize_report.py']:
 files['audit_scripts/'+name]=(BASE/name).read_bytes()
files['README.md']='''# Taleb Lean v0.2.7 independent audit

Reviewed release ZIP SHA-256:
`88ebaa078a18dc0e16bb46057969c5fec186c1fc958df1422b6d434e323d157b`.

Accept the new mathematics and the preceding audit's binary weighted-sum milestone.
Retain T029 as partial against its inherited stronger regular-variation target, with
the completed exponent child explicitly credited. This is an audit/ledger scope
clarification, not a new defect in the delivered proof. T060 and T061 remain discharged.
The received release is unchanged. No Lean repair was identified.

## Contents and corrections

The PDF and editable Markdown contain the consolidated audit. Progress Markdown has
the full 158-family index; JSON preserves every received row, eleven audited scopes,
22 dependency groups, T029 children/history, completed T061 children and supplemental
S001/S002 tasks. Received rows retain the stale sentence identified by the audit;
read the separate annotations rather than interpreting preservation as endorsement.

The Fable handoff specifies three low-priority corrections and the next contained
Pareto law/moment milestone. It is a specification, not an applied proof-project patch.

- D027-1: T029 stale probabilistic-gap sentence and delivery-facet clarification.
- D027-2: explicit zero-shape branch and corrected source anchor in future S001.
- D027-3: supplied validation log count 17 instead of 18 probes.

Subreview IDs D027-T029 and D027-S001 correspond to D027-1 and D027-2.

## Independent execution

`evidence/reproduction/` contains actual build, verifier, schema/rendering and regression
logs with exact commands/timings. All fourteen shipped fixtures were run exactly once
in three concurrent, disjoint --only invocations of the unchanged harness. Each used
isolated copies and relative scratch/output arguments. This is partitioned full
coverage, not a claim of one sequential suite invocation. Negative fixtures must reject
for the expected reason. Source and build-snapshot restoration markers are checked.

`evidence/reproduction/stale_markdown_cli/` is an additional real CLI check: only T061's
Markdown status was changed, and the unchanged verifier rejected it at the rendering
gate. This is separate from the fourteen fixtures and eighteen shipped Python probes.

`evidence/verifier_probe/` contains actual Python generator, schema and rendering checks.
Nine bounded verify.main cases replay recorded external-command output to isolate
Python control flow. They do not run Lean and are not additional proof evidence.
`evidence/provenance/` records archive, bundle, patch and retained-artifact comparisons.

## Scope and reproducibility

The exact project uses Lean 4.24.0 and unchanged pinned dependencies. Standard gates
are lake build, python3 scripts/verify.py, python3 scripts/backlog_schema_probes.py
and python3 scripts/harness_regression.py. Audit setup/build scripts retain local paths;
they are execution evidence and report sources, not portable installation scripts.

The source review uses the locally supplied arXiv:2001.10488v4 PDF. Property 5.1 is on
printed p.99 / PDF p.113; unified EVT and the named forms are on printed pp.172-173 /
PDF pp.186-187. Book pages and compiler/dependency caches are excluded from this ZIP.

The bundle establishes its included snapshot/history, not the original author's live
worktree or remote push state. The previous standalone audit PDF differs in metadata
and representation from its ZIP member; all eight page texts and all rendered pixels
match. No substantive page difference or cause of the representation change is asserted.

These findings do not certify exhaustive atomic book coverage, upstream Mathlib
integration, empirical claims or deployment of the separate quantum/classical software.
SHA256SUMS covers every included file except itself.
'''.encode()
files['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
target=OUT/'Taleb_Fable_v0.2.7_Audit_and_Progress.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()): z.writestr(name,data)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for name,data in files.items(): assert z.read(name)==data
 assert len(set(z.namelist()))==len(files)
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(OUT/(target.name+'.sha256')).write_text(digest+'  '+target.name+'\n')
print(json.dumps({'archive':str(target),'sha256':digest,'entries':len(files),'bytes':target.stat().st_size},indent=2))
