"""Use actual completed reproduction evidence to finalize the report and ledger."""
from pathlib import Path
import json, subprocess, sys
b=Path(__file__).resolve().parent
s=json.loads((b/'reproduction/execution_summary.json').read_text())
v=s['verification'];r=s['regression'];commands={c['name']:c for c in s['commands']}
assert all(c['exit_code']==0 for c in commands.values())
assert v['status']=='PASS' and v['build_diagnostics_clean']
assert (v['theorem_count'],v['instance_count'],v['alias_count'],v['checked_declarations'])==(140,8,16,164)
inv=v['environment_inventory']
assert (inv['constants_scanned'],inv['internal'],inv['generated'],inv['defs'],inv['imported_project_modules'])==(296,79,98,33,28)
assert all(inv[k] for k in ['all_within_allowlist','no_project_axioms','all_disk_modules_imported','public_inventory_matches_regex','alias_targets_match_replacement_map','backlog_schema_valid','backlog_cited_declarations_exist'])
assert (inv['backlog_families'],inv['backlog_discharged'],inv['backlog_cited_declaration_count'],inv['backlog_cited_distinct_declarations'])==(158,2,123,122)
assert r['fixture_count']==14 and r['all_expected_fixtures_exactly_once'] and r['all_fixtures_behaved_as_expected']
assert s['all_source_restoration_hashes_match'] and s['all_build_snapshots_restored']
assert s['all_received_files_except_generated_evidence_identical']
assert len(s['dependency_revision_and_cleanliness'])==9
assert all(d['revision_matches'] and d['working_tree_clean'] for d in s['dependency_revision_and_cleanliness'])
assert s['schema_probes']['all_probes_behaved_as_expected']
assert len(s['schema_probes']['results'])==18
assert len(s['relative_path_reproduction'])==3
assert all(x['scratch_argument_is_relative'] and x['out_argument_is_relative'] and x['suite_exit_code']==0 for x in s['relative_path_reproduction'])
extra=json.loads((b/'reproduction/stale_markdown_cli/result.json').read_text())
assert extra['behaved_as_expected'] and extra['exit_code']==1 and extra['all_source_files_restored']
seconds=s['regression_wall_time']['seconds'];minutes=round(seconds/60,1);n=s['compared_file_count']
x={'complete':True,
 'verdict':'Independent reproduction passed: clean build, 164 public checks, all 296 project constants within the allowed axioms, 18 schema/rendering probes and all 14 shipped regression fixtures. An additional real stale-Markdown mutation was correctly rejected.',
 'rows':[
  ['Clean build',f"PASS; exit 0, {commands['clean_build']['seconds']:.2f} s; 2744 Lake jobs and no compiler warnings/errors."],
  ['Normal verifier',f"PASS; exit 0, {commands['verify']['seconds']:.2f} s; 140 theorems, 8 instances and 16 aliases."],
  ['Trust and ledger','296 constants, 79 internal; only propext, Classical.choice, Quot.sound. 158 families; 123 citations over 122 names; rendering equality passes.'],
  ['Schema/rendering probes','PASS 18/18: sixteen malformed cases rejected and two valid controls accepted.'],
  ['Shipped regression',f'PASS 14/14, exactly once; {minutes:.1f} min across three concurrent isolated harness invocations. Every restoration check passes.'],
  ['Additional real CLI case',f"Stale T061 Markdown rejected at rendering gate; exit 1, {extra['seconds']:.2f} s; source restored."],
  ['Final source/dependencies',f'All {n} received files outside generated evidence match byte for byte. All nine dependencies remain pinned and clean.']],
 'detail':'Official Lean 4.24.0 and nine exact pinned dependency caches were reused; the project build started without project build outputs. The unchanged harness ran in three disjoint --only shards with separate copies and relative scratch/output arguments. This is full fixture coverage, not one sequential invocation. Both private-sorry cases also exposed sorryAx in standalone scans. No received proof, fixture or axiom policy was changed.',
 'counts':{'public_checks':164,'theorems':140,'instances':8,'aliases':16,'constants':296,'internal_constants':79,'generated_constants':98,'public_definitions':33,'imported_project_modules':28,'families':158,'discharged_families':2,'citation_pairs':123,'distinct_citations':122,'regression_fixtures':14,'schema_rendering_probes':18,'additional_real_cli_mutations':1,'source_files_compared':n},
 'regression_elapsed_seconds':seconds,'regression_mode':r['execution_mode'],
 'fixture_results':r['results'],'all_source_restoration_hashes_match':True,'all_build_snapshots_restored':True,
 'additional_real_cli_mutation':extra,
 'independent_raw_record':'evidence/reproduction/execution_summary.json'}
(b/'execution_summary.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
for script in ['build_report.py','build_progress.py']:
 subprocess.run([sys.executable,str(b/script)],check=True)
print(json.dumps({'complete':True,'regression_seconds':seconds,'compared_files':n},indent=2))
