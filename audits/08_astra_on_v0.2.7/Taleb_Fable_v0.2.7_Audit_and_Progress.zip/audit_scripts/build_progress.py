#!/usr/bin/env python3
"""Build the v0.2.7 audit progress artifacts without changing the received ledger.

Default inputs live beside this script. Execution is explicitly pending unless the
independent execution summary marks itself complete. No compiler or audit is run here.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
VERSION = "v0.2.7"
STATUSES = ["discharged", "partial", "reuse", "missing", "source-check", "model-needed", "empirical"]
FORBIDDEN_DASHES = ("\u2014", "\u2013", "\u2011")


def clean(value: object) -> str:
    text = str(value)
    for char in FORBIDDEN_DASHES:
        text = text.replace(char, "-")
    return text


def cell(value: object) -> str:
    return clean(value).replace("|", "\\|").replace("\n", " ")


def table(headers: list[str], records: list[list[object]]) -> list[str]:
    return [
        "| " + " | ".join(map(cell, headers)) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *["| " + " | ".join(map(cell, row)) + " |" for row in records],
        "",
    ]


def make_markdown(data: dict) -> str:
    execution = data["independent_execution"]
    verified = data["execution_complete"]
    text = [
        f"# Taleb proof progress, {VERSION}", "",
        "Independent assessment, 20 September 2026. The companion JSON preserves all 158 received family rows exactly and adds audited scopes, findings, child obligations and independent-execution evidence.", "",
        "## Current position", "",
        clean(execution["verdict"]), "",
    ]
    if not verified:
        text += ["**Draft execution status:** independent execution is not yet marked complete. Mathematical and ledger assessments below are separate from runtime verification; this draft does not claim a completed build or regression run.", ""]
    text += [
        "**The binary weighted-sum milestone is accepted. T029 remains partial under its inherited broader target.** The new proof gives the minimum finite log-tail exponent of two nonnegative coordinates with positive weights, including the measurable pushforward version, without independence. It delivers the preceding audit's requested milestone. The stronger regular-variation tail equivalence remains separately open.", "",
        "T060 and T061 remain discharged. The previous Markdown/JSON synchronization, continuity prose and EVT routing issues are repaired; the two support-correct EVT continuity statements are now proved too.", "",
    ]
    text += table(["Status", "Received families", "Recommended families"], [[s, data["status_counts"][s], data["recommended_status_counts"][s]] for s in STATUSES])
    text += [
        "Parent-family counts are unchanged from v0.2.6, while the delivered mathematical scope has increased. Eleven families have credited Lean work, with **123 family/declaration pairs over 122 distinct names**, up from 107/106. Of 140 formal-proof families, two are closed and 138 remain open. The other 18 require models or empirical work. These are scope counts, not percentages of effort completed or counts of independent book theorems.", "",
        "Only T029, T060 and T061 changed in the JSON; the other 155 received rows are identical to v0.2.6. The JSON preserves received rows separately from audit recommendations. The sole shared declaration is `AuditGaussian.charFun_gaussianReal_eq_stableS1Expr`, credited to T007 and T046.", "",
        "## T029 scope history and child obligations", "",
        "The original v0.2.0 title was 'Tail of sums with unequal indices'; its target said the heavier regularly varying tail dominates a sum. The corrected source Property 5.1 on printed p. 99 / PDF p. 113 instead displays a finite-n exponent equality. The prior audit specifically requested the binary finite-exponent theorem and allowed the finite-family extension to follow. v0.2.7 meets that milestone. This historical scope ambiguity belongs to the shared audit and ledger history; it is not a new proof defect.", "",
    ]
    text += table(["Child", "State", "Scope and acceptance boundary"], [[x["name"], x["status"], x["scope"] + " " + x.get("acceptance_note", "")] for x in data["T029_children"]])
    text += [
        "For strict unequal regularly varying tail indices `0 < alpha < beta`, the stronger target should explicitly say `P(aX + bY > t) / P(X > t/a) -> 1`. The heavier tail is weighted: relative to `P(X > t)`, the limiting factor is `a^alpha`. Exponent equality alone does not prove this ratio or regular variation. Keep the inherited stronger target open, or preserve it elsewhere through an explicit versioned scope decision before changing the parent status.", "",
        "Finite-family and almost-sure variants are useful extensions, not newly failed release gates. The source's informal infinite-exponent convention is outside the delivered finite-real interface. No existing family explicitly owns an extended-real exponent API, so this is recorded as a scope limitation without invented routing or a retrospective acceptance requirement.", "",
        "## Delivery facets", "",
        "Facets describe scoped components and overlap; their counts must not be added as completed work.", "",
    ]
    facet_names = sorted(set(data["delivery_state_counts_nonexclusive"]) | set(data["recommended_delivery_state_counts_nonexclusive"]))
    text += table(["Facet", "Received count", "Recommended count"], [[name, data["delivery_state_counts_nonexclusive"].get(name, 0), data["recommended_delivery_state_counts_nonexclusive"].get(name, 0)] for name in facet_names])
    text += [
        "Add `conditional_law_theorem` to T029 for the weighted-sum theorem, whose marginal finite exponents are hypotheses. Its `law_theorem` facet may remain if explicitly assigned to the generic `survivalRV_eq_survival_map` identity, which has ordinary measurability hypotheses. This is bookkeeping under the existing glossary, not a reduction in mathematical credit or a demand for new realization proofs.", "",
        "## Completed T061 children", "",
    ]
    text += table(["Child", "State"], [[x, "complete"] for x in data["completed_T061_children"]])
    text += [
        "Global continuity of the guarded Frechet and reverse-Weibull CDFs under positive shapes is separately exported in v0.2.7. The unguarded totalized-power formula's endpoint issue does not apply to those CDFs. The affine law definition and probability instance allow any real scale; the CDF and maximum rules require positive scale.", "",
        "## Supplemental open EVT obligations", "",
        "These are separate from the fixed 158-family count and do not reopen T061.", "",
    ]
    text += table(["ID", "State", "Scope", "Source"], [[x["id"], x["status"], x["scope"], x["source"]] for x in data["supplemental_open_EVT_tasks"]])
    text += [
        "S001 must explicitly define the zero-shape branch as `gumbelCDF`; the power expression is for nonzero shape. Its source anchor is printed pp. 172-173 / PDF pp. 186-187. In unified location/scale coordinates, the support endpoint is `mu - sigma/xi`; the separate-family scale is `sigma/xi` for positive xi and `-sigma/xi` for negative xi. Preserve this reparameterization.", "",
        "Normalized-maxima convergence remains under T011 for the general setup and T062 for the regular-variation/Frechet and Gaussian/Gumbel cases. For exact Pareto tail exponent alpha and lower endpoint L, the proposed limit is `frechetMeasure (1/alpha)` with normalization `M_n/(L*n^(1/alpha))`.", "",
        "## Documentation corrections for the next handoff", "",
    ]
    text += table(["Finding", "Priority", "Correction"], [[x["id"], x["severity"], x["repair"]] for x in data["findings"]])
    text += ["## Audited supported families", ""]
    for family in data["families"]:
        text += [
            f"### {family['id']}: {clean(family['title'])}", "",
            f"**Received status: {family['current_status']}. Recommended status: {family['recommended_status']}.**", "",
            "**Received facets:** " + ", ".join(family["current_states"]) + ".", "",
            "**Recommended facets:** " + ", ".join(family["recommended_states"]) + ".", "",
            "**Delivered scope:** " + clean(family["audited_scope"]), "",
            "**Recommendation:** " + clean(family["recommendation"]), "",
            "**Remaining target:** " + clean(family["remaining_target"]), "",
        ]
    text += [
        "## Dependency-group position", "",
        "Other open formal combines reuse, missing and source-check. The source-check column is a subset of that total, not an additional category. Partial families have remaining work too.", "",
    ]
    group_records = []
    for group, record in data["dependency_group_counts"].items():
        counts = record["status_counts"]
        group_records.append([group, record["total"], counts["discharged"], counts["partial"], counts["source-check"], sum(counts[s] for s in ["reuse", "missing", "source-check"]), counts["model-needed"] + counts["empirical"]])
    text += table(["Group", "Families", "Discharged", "Partial", "Source-check subset", "Other open formal", "Model / empirical"], group_records)
    text += [
        "## Recommended next mathematics", "",
        "Proceed to the exact Pareto slice against the pinned `paretoMeasure`: global CDF and survival, moments finite exactly below the shape threshold, divergence via extended nonnegative integrals, threshold excess and positive-power pushforward. Credit only the delivered portions of T005/T021/T028/T032. The generic affine layer supplies pushforward and positive-scale CDF infrastructure, not integration or conditioning proofs.", "",
        "Finite-family and almost-sure versions of T029 can follow as contained extensions. The stronger unequal-index RV theorem needs an explicit weighted-tail statement. Later EVT work should keep S001/S002 separate from T011/T062 convergence.", "",
        "## Full 158-family index", "",
        "Unsupported rows are tallied without a new full-family mathematical audit. Source locators below are the received release anchors. All original row fields, including the stale T029 sentence, remain unchanged in the JSON's `ledger_rows`; recommendations are stored separately.", "",
    ]
    text += table(["ID", "Unit", "Received status", "Group", "Priority", "Family", "Printed pages"], [[r[k] for k in ["id", "unit", "status", "dependency_group", "priority", "title", "printed_pages"]] for r in data["ledger_rows"]])
    text += [
        "## Interpretation limits", "",
        "This ledger measures recorded formalization scope. It does not establish upstream Mathlib acceptance, an exhaustive census of every source statement, or operational readiness of the separate quantum/classical application. A valid conditional theorem is useful progress; its hypotheses and the parent family's remaining targets still need to be read explicitly.", "",
    ]
    return clean("\n".join(text))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review", type=Path, default=HERE / "ledger_review.json")
    parser.add_argument("--execution", type=Path, default=HERE / "execution_summary.json")
    parser.add_argument("--output-dir", type=Path, default=HERE.parent / "output")
    args = parser.parse_args()

    original = json.loads(args.review.read_text())
    data = copy.deepcopy(original)
    data["artifact_type"] = "independent_audit_progress_ledger"
    data["assessment_date"] = "2026-09-20"
    data["source_review_sha256"] = hashlib.sha256(args.review.read_bytes()).hexdigest()
    if args.execution.exists():
        execution = json.loads(args.execution.read_text())
        execution.setdefault("verdict", "Independent execution summary is available; see the embedded evidence object for its exact state.")
        data["execution_complete"] = execution.get("complete") is True
        data["execution_summary_sha256"] = hashlib.sha256(args.execution.read_bytes()).hexdigest()
    else:
        execution = {"complete": False, "verdict": "Independent execution pending: this draft has no completed independent build, verifier or regression summary attached."}
        data["execution_complete"] = False
        data["execution_summary_sha256"] = None
    data["independent_execution"] = execution
    data["publication_state"] = "final" if data["execution_complete"] else "draft_execution_pending"
    finding_ids = {"D027-T029": "D027-1", "D027-S001": "D027-2"}
    for finding in data["findings"]:
        finding["review_local_id"] = finding["id"]
        finding["id"] = finding_ids.get(finding["id"], finding["id"])
    data["findings"].append({
        "id": "D027-3", "severity": "low", "kind": "supplied_evidence_summary_typo",
        "summary": "The supplied archive validation log says 17 probes, while the packaged source/results and independent Python run record 18 successful checks.",
        "repair": "Correct or visibly annotate the supplied archive-validation summary from 17 to 18 probes. Preserve historical evidence or mark its correction; no extra Lean fixture is required.",
    })

    rows = data["ledger_rows"]
    assert rows == original["ledger_rows"], "Received ledger rows were changed"
    assert [r["id"] for r in rows] == [f"T{i:03}" for i in range(1, 159)]
    assert len(data["families"]) == 11
    assert len(data["dependency_group_counts"]) == 22
    assert sum(g["total"] for g in data["dependency_group_counts"].values()) == 158
    assert Counter(r["status"] for r in rows) == data["status_counts"]
    assert sum(len(r["declarations"]) for r in rows) == data["citation_pair_count"] == 123
    assert len({n for r in rows for n in r["declarations"]}) == data["distinct_cited_declarations"] == 122
    received = HERE / "received/Taleb_Lean_Repairs/docs/FORMALIZATION_BACKLOG.json"
    if received.exists():
        assert rows == json.loads(received.read_text()), "Progress JSON must preserve every received row exactly"
    markdown = make_markdown(data)
    assert all(char not in markdown for char in FORBIDDEN_DASHES)
    assert markdown.endswith("\n")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / f"Taleb_Proof_Progress_{VERSION}.json"
    md_path = args.output_dir / f"Taleb_Proof_Progress_{VERSION}.md"
    json_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    md_path.write_text(markdown)
    print(json.dumps({"json": str(json_path.resolve()), "markdown": str(md_path.resolve()), "publication_state": data["publication_state"], "family_count": len(rows), "supported_count": len(data["families"]), "dependency_groups": len(data["dependency_group_counts"]), "finding_ids": [x["id"] for x in data["findings"]]}, indent=2))


if __name__ == "__main__":
    main()
