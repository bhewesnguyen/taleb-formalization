from pathlib import Path
import collections,hashlib,json,zipfile
import fitz
BASE=Path(__file__).resolve().parent;OUT=BASE.parent/'output'
x=json.loads((OUT/'Taleb_Proof_Progress_v0.2.7.json').read_text())
r=json.loads((BASE/'received/Taleb_Lean_Repairs/docs/FORMALIZATION_BACKLOG.json').read_text())
assert x['ledger_rows']==r
assert [f['id'] for f in r]==[f'T{i:03}' for i in range(1,159)]
assert x['status_counts']==dict(collections.Counter(f['status'] for f in r))
assert [f['id'] for f in r if f['status']=='discharged']==['T060','T061']
assert len(x['completed_T061_children'])==4
assert len(x['families'])==11 and len(x['dependency_group_counts'])==22
assert sum(v['total'] for v in x['dependency_group_counts'].values())==158
pairs={(f['id'],d) for f in r for d in f['declarations']}
assert len(pairs)==123 and len({d for _,d in pairs})==122
assert x['independent_execution']['complete'] is True and x['publication_state']=='final'
assert x['execution_summary_sha256']==hashlib.sha256((BASE/'execution_summary.json').read_bytes()).hexdigest()
for name in ['Taleb_Fable_v0.2.7_Independent_Audit.md','Taleb_Proof_Progress_v0.2.7.md','Taleb_Fable_v0.2.7_Review_Handoff.md']:
 text=(OUT/name).read_text()
 assert not any(ch in text for ch in ['\u2014','\u2013','\u2011']),name
 assert 'pending final' not in text.lower() and 'execution is pending' not in text.lower() and 'draft execution status' not in text.lower(),name
pdf=fitz.open(OUT/'Taleb_Fable_v0.2.7_Independent_Audit.pdf')
assert len(pdf)==9,len(pdf)
for page in pdf:
 assert '\ufffd' not in page.get_text()
 for block in page.get_text('blocks'):
  if 45<block[1]<780 and block[4].strip(): assert block[3]<786,block
zpath=OUT/'Taleb_Fable_v0.2.7_Audit_and_Progress.zip'
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 names=set(z.namelist())
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 for name in ['Taleb_Fable_v0.2.7_Independent_Audit.pdf','Taleb_Fable_v0.2.7_Independent_Audit.md','Taleb_Proof_Progress_v0.2.7.json','Taleb_Proof_Progress_v0.2.7.md','Taleb_Fable_v0.2.7_Review_Handoff.md']:
  assert z.read(name)==(OUT/name).read_bytes()
 assert 'evidence/reproduction/execution_summary.json' in names
 assert 'evidence/reproduction/stale_markdown_cli/result.json' in names
 assert 'evidence/reproduction/stale_markdown_cli/mutation.diff' in names
checksum=(OUT/(zpath.name+'.sha256')).read_text().split()[0]
assert hashlib.sha256(zpath.read_bytes()).hexdigest()==checksum
print(json.dumps({'all_checks_passed':True,'pages':len(pdf),'original_family_rows_preserved':158,'supported_scopes':11,'dependency_groups':22,'zip_sha256':checksum},indent=2))
