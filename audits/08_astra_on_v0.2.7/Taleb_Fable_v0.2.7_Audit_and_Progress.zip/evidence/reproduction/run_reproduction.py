from pathlib import Path
import subprocess,time,json,os,sys,concurrent.futures
base=Path(__file__).resolve().parent
root=Path('/tmp/taleb_v027_audit_project')
env=dict(os.environ)
env['PATH']='/tmp/taleb_v026_runtime/bin'+os.pathsep+env['PATH']
records=[]
def invoke(name,cmd):
 t=time.monotonic()
 print('START',name,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),flush=True)
 with (base/(name+'.log')).open('w') as log:
  proc=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec={'name':name,'command':cmd,'cwd':str(root),'exit_code':proc.returncode,'seconds':round(time.monotonic()-t,2),'log':str(base/(name+'.log'))}
 print(json.dumps(rec),flush=True)
 return rec
commands=[('runtime_version',['lean','--version']),('clean_build',['lake','build']),('verify',['python3','scripts/verify.py']),('schema_probes',['python3','scripts/backlog_schema_probes.py','--out',str(base/'schema_probes')])]
for name,cmd in commands:
 rec=invoke(name,cmd);records.append(rec)
 (base/'reproduction.json').write_text(json.dumps(records,indent=2)+'\n')
 if rec['exit_code']: sys.exit(rec['exit_code'])
shards={
 'A':['valid','private_sorry_theorem','private_axiom','namespace_section_theorem','dirty_dependency'],
 'B':['private_sorry_def','structure_namespace_theorem','alias_map_mismatch','nested_imported_module'],
 'C':['protected_theorem','alias_map_mismatch_optimized','orphan_module','nested_orphan_module','backlog_duplicate_id'],
}
total_start=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 futures=[]
 for key,ids in shards.items():
  name='regression_'+key
  cmd=['python3','scripts/harness_regression.py','--only',','.join(ids),'--scratch','../taleb_v027_regression_'+key,'--out','../../workspace/scratch/c40a0826d9d8/audit_v027/reproduction/regression_'+key]
  futures.append(ex.submit(invoke,name,cmd))
 for f in concurrent.futures.as_completed(futures):
  records.append(f.result());(base/'reproduction.json').write_text(json.dumps(records,indent=2)+'\n')
(base/'regression_wall_time.json').write_text(json.dumps({'seconds':round(time.monotonic()-total_start,2),'invocations':3,'partitioned_full_coverage':True},indent=2)+'\n')
all_results=[];summaries={}
for key,ids in shards.items():
 record=json.loads((base/('regression_'+key)/'harness_regression.json').read_text()); summaries[key]=record
 for result in record['results']:
  result=dict(result); result['shard']=key;all_results.append(result)
import importlib.util
spec=importlib.util.spec_from_file_location('harness_regression',root/'scripts/harness_regression.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
expected=[f[0] for f in mod.FIXTURES]
actual=[r['id'] for r in all_results]
coverage=set(expected)==set(actual) and len(actual)==len(set(actual))==len(expected)
aggregate={'execution_mode':'Three concurrent disjoint --only selections of the unmodified harness; not one sequential invocation','fixture_count':len(all_results),'expected_fixture_ids':expected,'all_expected_fixtures_exactly_once':coverage,'all_fixtures_behaved_as_expected':coverage and all(r['behaved_as_expected'] for r in all_results),'pristine_tree_hashes_by_shard':{k:r['pristine_tree_sha256'] for k,r in summaries.items()},'scratch_copies_by_shard':{k:r['scratch_copy'] for k,r in summaries.items()},'results':sorted(all_results,key=lambda r:expected.index(r['id']))}
(base/'regression_aggregate.json').write_text(json.dumps(aggregate,indent=2)+'\n')
if not aggregate['all_fixtures_behaved_as_expected'] or any(r['exit_code'] for r in records):sys.exit(1)
