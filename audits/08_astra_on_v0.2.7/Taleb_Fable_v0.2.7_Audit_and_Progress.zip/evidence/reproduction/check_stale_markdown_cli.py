from pathlib import Path
import shutil,subprocess,time,os,json,hashlib,difflib
base=Path(__file__).resolve().parent/'stale_markdown_cli'
base.mkdir(exist_ok=True)
pristine=Path('/tmp/taleb_v027_audit_project')
copy=Path('/tmp/taleb_v027_stale_markdown_cli')
assert not copy.exists(), 'Refuse to reuse mutation copy'
shutil.copytree(pristine,copy,ignore=shutil.ignore_patterns('.lake'))
(copy/'.lake').mkdir()
for directory in ['packages','build']:
 subprocess.run(['cp','-a',str(pristine/'.lake'/directory),str(copy/'.lake'/directory)],check=True)
shutil.rmtree(copy/'evidence/current',ignore_errors=True)
p=copy/'docs/FORMALIZATION_BACKLOG.md'; before=p.read_bytes(); text=before.decode()
heading='### T061 - GEV families as probability measures'
assert text.count(heading)==1
head,tail=text.split(heading)
assert tail.startswith('\n\n**P1 / discharged / EVT**')
changed=head+heading+tail.replace('**P1 / discharged / EVT**','**P1 / partial / EVT**',1)
p.write_text(changed)
(base/'mutation.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile='pristine/docs/FORMALIZATION_BACKLOG.md',tofile='mutated/docs/FORMALIZATION_BACKLOG.md')))
env=dict(os.environ);env['PATH']='/tmp/taleb_v026_runtime/bin'+os.pathsep+env['PATH']
cmd=['python3','scripts/verify.py']; start=time.monotonic()
with (base/'verify.log').open('w') as log:
 proc=subprocess.run(cmd,cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT)
seconds=round(time.monotonic()-start,2)
record=json.loads((copy/'evidence/current/verification.json').read_text())
expected='is not the rendering of docs/FORMALIZATION_BACKLOG.json'
ok=proc.returncode==1 and record.get('status')=='FAIL' and expected in record.get('error','')
shutil.copy2(copy/'evidence/current/verification.json',base/'verification.json')
p.write_bytes(before)
paths=sorted(x.relative_to(pristine) for x in pristine.rglob('*') if x.is_file() and '.lake' not in x.relative_to(pristine).parts and not x.relative_to(pristine).as_posix().startswith('evidence/current/'))
restored=all((pristine/x).read_bytes()==(copy/x).read_bytes() for x in paths)
result={'auditor_added_test':True,'part_of_shipped_14_fixtures':False,'part_of_shipped_18_probes':False,'mutation':'Only T061 Markdown status discharged -> partial; JSON and verifier unchanged','command':cmd,'cwd':str(copy),'exit_code':proc.returncode,'seconds':seconds,'verification':record,'expected_error_contains':expected,'behaved_as_expected':ok,'restored_source_files_compared':len(paths),'all_source_files_restored':restored,'original_markdown_sha256':hashlib.sha256(before).hexdigest(),'mutated_markdown_sha256':hashlib.sha256(changed.encode()).hexdigest()}
(base/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
shutil.rmtree(copy)
assert ok and restored
