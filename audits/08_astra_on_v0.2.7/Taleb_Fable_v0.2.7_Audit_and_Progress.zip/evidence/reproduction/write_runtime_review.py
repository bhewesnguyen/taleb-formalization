from pathlib import Path
import json
base=Path(__file__).resolve().parent
s=json.loads((base/'execution_summary.json').read_text());v=s['verification'];i=v['environment_inventory'];r=s['regression'];mut=json.loads((base/'stale_markdown_cli/result.json').read_text());s['auditor_added_stale_markdown_cli']=mut
(base/'execution_summary.json').write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
commands={c['name']:c for c in s['commands']}
lines=['# Independent runtime reproduction: v0.2.7','',
'## Verdict','',
'All independently executed release checks passed. The clean build and normal verifier used the unchanged received sources, pinned Lean 4.24.0, and all nine pinned dependencies. The separately mutated Markdown ledger was rejected by the actual verifier CLI. No mathematical coverage claim follows from compilation alone.','',
'## Setup and integrity','',
f"- Runtime: `{s['runtime_version']}`.",
'- Reused official compiler installation and matching dependency caches from the previous audit; no prior project build outputs were copied.',
'- Tested project: `/tmp/taleb_v027_audit_project`. Immutable received extraction was not modified.',
f"- Initial and final checks: all {len(s['dependency_revision_and_cleanliness'])} dependency revisions match the manifest and all dependency working trees are clean.",
f"- Final byte comparison: {s['compared_file_count']} received files outside generated `evidence/current` match the tested project.",
'- Detailed setup, exact commands, source hashes, and all logs are in `reproduction/`.','',
'## Commands and outcomes','',
'| Check | Exit | Seconds | Result |','|---|---:|---:|---|',
f"| Clean `lake build` | {commands['clean_build']['exit_code']} | {commands['clean_build']['seconds']} | No compiler warnings or errors |",
f"| `python3 scripts/verify.py` | {commands['verify']['exit_code']} | {commands['verify']['seconds']} | PASS |",
f"| Shipped schema/render probes | {commands['schema_probes']['exit_code']} | {commands['schema_probes']['seconds']} | {len(s['schema_probes']['results'])}/{len(s['schema_probes']['results'])} expected outcomes |",
f"| Full shipped harness, three disjoint shards | 0 each | {s['regression_wall_time']['seconds']} elapsed | {r['fixture_count']}/{r['fixture_count']} expected outcomes |",
f"| Auditor-added stale T061 Markdown CLI case | {mut['exit_code']} | {mut['seconds']} | Expected rendering-mismatch rejection |",'',
'## Verification counts','',
f"- {v['theorem_count']} theorems, {v['instance_count']} instances, {v['alias_count']} aliases: {v['checked_declarations']} public checks.",
f"- {i['constants_scanned']} project constants scanned, including {i['internal']} internal constants. Generated constants: {i['generated']} (categories overlap and must not be added).",
f"- {i['defs']} public non-generated definitions; {i['imported_project_modules']} imported project modules.",
'- All scanned project constants use only `propext`, `Classical.choice`, and `Quot.sound`; no project axiom declarations.',
'- Every disk project module is imported, public discovery matches the Lean environment, and all 16 alias targets match the replacement map.',
f"- Backlog: {i['backlog_families']} valid families, {i['backlog_discharged']} discharged; {i['backlog_cited_declaration_count']} family/declaration pairs over {i['backlog_cited_distinct_declarations']} distinct names. Markdown equality with the shared rendering passed through the normal CLI gate.",'',
'## Shipped regression suite','',
'The original harness was not edited. All 14 fixture IDs were covered exactly once through three concurrent, disjoint `--only` invocations. Each invocation had its own dependency copy, scratch directory, output directory, source restoration, and per-fixture project build snapshot. Both scratch and output arguments were genuinely relative. This is partitioned full fixture coverage, not a single sequential all-fixtures execution.','',
'| Fixture | Verifier exit | Status | Expected outcome met |','|---|---:|---|---|']
for x in r['results']:lines.append(f"| `{x['id']}` | {x['verifier_exit_code']} | {x['verification_status']} | {x['behaved_as_expected']} |")
lines+=['',f"All per-fixture source restoration hashes matched their pristine copy: {s['all_source_restoration_hashes_match']}. All project build snapshots were reset: {s['all_build_snapshots_restored']}.",'',
'The two sorry fixtures also independently list their private constants with `sorryAx` when the standalone environment scanner is run. The imported nested-module positive control confirms its module and theorem are scanned.','',
'## Added stale-Markdown check','',
'Only the Markdown T061 status line was changed from `discharged` to `partial`, leaving JSON and verifier byte-identical. The real command `python3 scripts/verify.py` exited 1 with a FAIL record containing:','',
'```text',mut['verification']['error'],'```','',
f"After the test, the Markdown bytes were restored and {mut['restored_source_files_compared']} files were compared with the pristine tested copy; all match. This is one auditor-added end-to-end test, separate from both the 14 shipped fixtures and the 18 shipped Python probes. No external command output was mocked for this case.",'',
'## Boundaries','',
'The official runtime and dependency compilation caches were reused, so this is a fresh project build rather than a rebuild of Lean and Mathlib from source. The test suite checks the shipped adversarial cases and this audit\'s one added rendering case; it is not an exhaustive proof of verifier correctness. The supplied author logs are not substituted for independent execution.']
(base.parent/'runtime_review.md').write_text('\n'.join(lines)+'\n')
print('runtime_review.md written')
