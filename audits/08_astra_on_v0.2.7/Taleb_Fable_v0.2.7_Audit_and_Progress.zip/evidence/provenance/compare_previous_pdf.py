#!/usr/bin/env python3
"""Compare received v0.2.6 audit representations without editing them."""
from pathlib import Path
import hashlib, json, subprocess, tempfile, zipfile
import fitz
from PIL import Image
root=Path(__file__).resolve().parents[2]
work=root/'audit_v027/provenance'
name='Taleb_Fable_v0.2.6_Independent_Audit.pdf'
preserved=work/'repo/audits/07_astra_on_v0.2.6'/name
current=root/'output'/name
sha=lambda b:hashlib.sha256(b).hexdigest()
a=fitz.open(preserved);b=fitz.open(current)
result={'method':'Read-only metadata and extracted-text comparison using PyMuPDF plus Poppler pdftoppm 150-dpi RGB rendering comparison on every page; image pixels and dimensions compared. No edited PDF written.','preserved_sha256':sha(preserved.read_bytes()),'current_sha256':sha(current.read_bytes()),'preserved_metadata':a.metadata,'output_metadata':b.metadata,'pages':[len(a),len(b)],'page_text_equal':[pa.get_text()==pb.get_text() for pa,pb in zip(a,b)],'renders':[]}
with tempfile.TemporaryDirectory(prefix='pdf_compare_',dir=work) as scratch:
 p=Path(scratch)
 for label,path in [('preserved',preserved),('current',current)]:
  subprocess.run(['pdftoppm','-r','150','-png',str(path),str(p/label)],check=True,capture_output=True)
 for i in range(1,len(a)+1):
  old=next(p.glob(f'preserved-{i:0{len(str(len(a)))}d}.png'))
  new=next(p.glob(f'current-{i:0{len(str(len(b)))}d}.png'))
  im1=Image.open(old).convert('RGB');im2=Image.open(new).convert('RGB')
  result['renders'].append({'page':i,'preserved_dimensions':im1.size,'current_dimensions':im2.size,'preserved_pixels_sha256':sha(im1.tobytes()),'current_pixels_sha256':sha(im2.tobytes()),'same_pixels':im1.size==im2.size and im1.tobytes()==im2.tobytes()})
with zipfile.ZipFile(root/'output/Taleb_Fable_v0.2.6_Audit_and_Progress.zip') as z:
 data=z.read(name)
 result['zip_member']={'name':name,'sha256':sha(data),'equals_preserved':data==preserved.read_bytes(),'equals_current':data==current.read_bytes()}
result['conclusion']='All page text and 150-dpi Poppler pixel buffers match. PDF metadata differs and standalone binary representations differ; the cause of that representation change is not established. No substantive difference identified. Previous ZIP is independently byte-identical to the output archive.' if all(result['page_text_equal']) and all(r['same_pixels'] for r in result['renders']) and len(a)==len(b) else 'Differences require review.'
(work/'previous_pdf_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
