#!/usr/bin/env python3
"""Read-only release checks plus patch applications inside this script's own worktrees.
No supplied release/build script is executed. Run from the audit workspace or use
--workspace PATH. A clone of the bundle is made under audit_v027/provenance/repo
if needed. Results are written to audit_v027/provenance/provenance.json.
"""
from pathlib import Path, PurePosixPath
import argparse, collections, hashlib, json, subprocess, zipfile
p=argparse.ArgumentParser();p.add_argument('--workspace',type=Path,default=Path.cwd());args=p.parse_args()
root=args.workspace.resolve();upload=root/'upload';work=root/'audit_v027/provenance';work.mkdir(parents=True,exist_ok=True);repo=work/'repo'
sha=lambda b:hashlib.sha256(b).hexdigest()
def run(argv,cwd=None):
 r=subprocess.run(argv,cwd=cwd,capture_output=True)
 if r.returncode:raise RuntimeError(f'{argv}: {r.stderr.decode(errors="replace")}')
 return r
if not repo.exists():run(['git','clone','--branch','main',str(upload/'taleb-formalization_v0.2.7.bundle'),str(repo)])
def git(*args,cwd=repo):return run(['git',*args],cwd).stdout.decode()
def blob(rev,path):return run(['git','show',f'{rev}:{path}'],repo).stdout
head=git('rev-parse','HEAD').strip();base020=git('rev-parse','f6b1007').strip();base026=git('rev-parse','83ef501').strip()
zpath=upload/'Taleb_Lean_Implementation_Handoff_v0.2.7_fable.zip';checksum=(upload/(zpath.name+'.sha256')).read_text().split()[0]
result={'archive':{'sha256':sha(zpath.read_bytes()),'expected_sha256':checksum},'bundle':{},'patches':{},'inputs':{p.name:sha(p.read_bytes()) for p in sorted(upload.glob('*v0.2.7*')) if p.is_file()}}
with zipfile.ZipFile(zpath) as z:
 infos=z.infolist();files=[f for f in infos if not f.is_dir()];names=[f.filename for f in files];a={n:z.read(n) for n in names}
 result['archive'].update({'entry_count':len(infos),'file_count':len(files),'duplicate_names':[n for n,c in collections.Counter(names).items() if c>1],'unsafe_paths':[i.filename for i in infos if PurePosixPath(i.filename).is_absolute() or '..' in PurePosixPath(i.filename).parts or '\\' in i.filename],'symlinks':[i.filename for i in files if (i.external_attr>>16)&0o170000==0o120000],'unexpected_build_paths':[n for n in names if any(x in PurePosixPath(n).parts for x in ('.lake','__pycache__')) or n.endswith(('.pyc','.olean','.ilean'))]})
 manifestname='Taleb_Lean_Repairs/SHA256SUMS';lines=a[manifestname].decode().splitlines();m={}
 for line in lines:
  digest,name=line.split('  ',1);m['Taleb_Lean_Repairs/'+name]=digest
 result['manifest']={'entry_count':len(m),'line_count':len(lines),'hash_mismatches':[n for n,d in m.items() if n not in a or sha(a[n])!=d],'missing_from_manifest':sorted(set(a)-set(m)-{manifestname}),'manifest_extras':sorted(set(m)-set(a)),'duplicate_manifest_paths':len(lines)!=len(m)}
 result['archive']['hash_ok']=result['archive']['sha256']==checksum
received=root/'audit_v027/received'
received_files={str(p.relative_to(received)):p.read_bytes() for p in (received/'Taleb_Lean_Repairs').rglob('*') if p.is_file()}
result['immutable_extraction']={'file_count':len(received_files),'missing_files':sorted(set(a)-set(received_files)),'extra_files':sorted(set(received_files)-set(a)),'byte_mismatches':[n for n in a if n in received_files and a[n]!=received_files[n]]}
tracked=git('ls-files','-z','--','Taleb_Lean_Repairs').split('\0')[:-1]
bv=run(['git','bundle','verify',str(upload/'taleb-formalization_v0.2.7.bundle')],repo)
result['bundle']={'refs':git('show-ref').splitlines(),'head':head,'clean_clone':not git('status','--porcelain'),'tracked_project_files':len(tracked),'archive_missing_tracked':sorted(set(tracked)-set(a)),'archive_untracked_extras':sorted(set(a)-set(tracked)),'tracked_byte_mismatches':[n for n in tracked if n in a and (repo/n).read_bytes()!=a[n]],'verify':(bv.stdout+bv.stderr).decode(),'log':git('log','--format=%H %s','--all').splitlines(),'head_project_tree':git('rev-parse','HEAD:Taleb_Lean_Repairs').strip(),'fsck':git('fsck','--full'),'commits_after_v026_packaged':git('rev-list','--count',base026+'..HEAD').strip(),'commits_after_v026_deliverables':git('rev-list','--count','ea1286d..HEAD').strip(),'commits_since_v026_deliverables':git('log','--format=%H %s','ea1286d..HEAD').splitlines()}
result['pins']={path:{'head_sha256':sha(a['Taleb_Lean_Repairs/'+path]),'unchanged_from_v020':blob(base020,'Taleb_Lean_Repairs/'+path)==a['Taleb_Lean_Repairs/'+path],'unchanged_from_v026':blob(base026,'Taleb_Lean_Repairs/'+path)==a['Taleb_Lean_Repairs/'+path]}for path in ['lake-manifest.json','lean-toolchain']}
for label,base,patch in [('v020_to_v027',base020,'fable_changes_v0.2.7.patch'),('v026_to_v027',base026,'fable_changes_v0.2.6_to_v0.2.7.patch')]:
 target=work/label
 if target.exists():git('worktree','remove','--force',str(target))
 git('worktree','add','--detach',str(target),base)
 raw=(upload/patch).read_bytes();expected=run(['git','diff',base,head,'--','Taleb_Lean_Repairs'],repo).stdout
 git('apply','--check',str(upload/patch),cwd=target);git('apply','--index',str(upload/patch),cwd=target)
 tree=git('write-tree',cwd=target).strip();project_tree=git('rev-parse',tree+':Taleb_Lean_Repairs',cwd=target).strip()
 tf={str(p.relative_to(target)):p.read_bytes() for p in (target/'Taleb_Lean_Repairs').rglob('*') if p.is_file()}
 result['patches'][label]={'base_full':base,'patch_sha256':sha(raw),'byte_equal_to_git_diff':raw==expected,'changed_file_count':len(git('diff','--name-only',base,head,'--','Taleb_Lean_Repairs').splitlines()),'apply_check_ok':True,'apply_ok':True,'replayed_project_tree':project_tree,'tree_matches_packaged_commit':project_tree==result['bundle']['head_project_tree'],'missing_files':sorted(set(a)-set(tf)),'extra_files':sorted(set(tf)-set(a)),'byte_mismatches':[n for n in a if n in tf and a[n]!=tf[n]]}
man=repo/'audits/RECEIVED_ARTIFACTS.sha256';entries=[]
for line in man.read_text().splitlines():
 if not line.strip() or line.startswith('#'):continue
 digest,name=line.split('  ',1);f=man.parent/name;entries.append({'path':name,'exists':f.exists(),'sha256_ok':f.exists() and sha(f.read_bytes())==digest})
result['received_artifacts_manifest']={'count':len(entries),'all_ok':all(x['sha256_ok'] for x in entries),'entries':entries}
result['historical_archives']={}
for label,revision,path in [('v020',base020,repo/'audits/02_handoff_v0.2.0/Taleb_Lean_Implementation_Handoff.zip'),('v026',base026,repo/'deliverables/v0.2.6/Taleb_Lean_Implementation_Handoff_v0.2.6_fable.zip')]:
 with zipfile.ZipFile(path) as z:archive={i.filename:z.read(i.filename) for i in z.infolist() if not i.is_dir()}
 ht=git('ls-tree','-r','--name-only',revision,'--','Taleb_Lean_Repairs').splitlines()
 result['historical_archives'][label]={'sha256':sha(path.read_bytes()),'file_count':len(archive),'tracked_count':len(ht),'missing_in_archive':sorted(set(ht)-set(archive)),'extra_in_archive':sorted(set(archive)-set(ht)),'byte_mismatches':[n for n in ht if n in archive and archive[n]!=blob(revision,n)]}
result['previous_audit_artifacts']=[]
for name in ['Taleb_Fable_v0.2.6_Independent_Audit.pdf','Taleb_Proof_Progress_v0.2.6.md','Taleb_Fable_v0.2.6_Audit_and_Progress.zip']:
 preserved=repo/'audits/07_astra_on_v0.2.6'/name;local=root/'output'/name
 result['previous_audit_artifacts'].append({'filename':name,'preserved_sha256':sha(preserved.read_bytes()),'actual_audit_output_exists':local.exists(),'actual_audit_output_sha256':sha(local.read_bytes()) if local.exists() else None,'byte_equal':local.exists() and local.read_bytes()==preserved.read_bytes()})
# Prior-round retained binary representations are compared directly with the
# prior release bundle already audited, not presumed equal to separate copies.
prior_retained=sorted(p for p in (repo/'audits').rglob('*') if p.is_file() and not str(p.relative_to(repo/'audits')).startswith('07_astra_on_v0.2.6/') and p.name not in ('RECEIVED_ARTIFACTS.sha256','README.md'))
checks_prior=[]
for p in prior_retained:
 relative=str(p.relative_to(repo))
 old_blob=run(['git','show',base026+':'+relative],repo).stdout
 checks_prior.append({'path':relative,'unchanged_from_v026':p.read_bytes()==old_blob})
result['earlier_retained_artifacts']={'file_count':len(checks_prior),'all_unchanged_from_v026':all(v['unchanged_from_v026'] for v in checks_prior),'entries':checks_prior}
# Lexer-like comment removal, not a Lean AST check. Handles nested block comments
# and double-quoted strings. This checks preserved non-comment text in pre-existing mathematics modules
# after excluding the two new continuity theorems and their axiom-print commands, not a semantic equivalence theorem.
def strip_comments(s):
 out=[];i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2;out.append(' ')
   else:i+=1
  elif string:
   out.append(s[i])
   if s[i]=='\\' and i+1<len(s):i+=1;out.append(s[i])
   elif s[i]=='"':string=False
   i+=1
  elif s.startswith('/-',i):depth=1;i+=2;out.append(' ')
  elif s.startswith('--',i):
   end=s.find('\n',i);i=len(s) if end<0 else end;out.append(' ')
  elif s[i]=='"':string=True;out.append(s[i]);i+=1
  else:out.append(s[i]);i+=1
 if depth:raise ValueError('unclosed Lean comment')
 return ' '.join(''.join(out).split())
oldlean=[n for n in git('ls-tree','-r','--name-only',base026,'--','Taleb_Lean_Repairs/AuditRepairs','Taleb_Lean_Repairs/Proofs').splitlines() if n.endswith('.lean')]
checks=[]
for name in oldlean:
 old=blob(base026,name);new=a[name]
 normalized=new.decode()
 if name.endswith('/ExtremeValueLaws.lean'):
  for theorem,nexttheorem in [('continuous_frechetCDF','frechetCDF_tendsto_atBot'),('continuous_reverseWeibullCDF','reverseWeibullCDF_tendsto_atTop')]:
   start=normalized.index('theorem '+theorem+' ')
   end=normalized.index('theorem '+nexttheorem+' ',start)
   normalized=normalized[:start]+normalized[end:]
   normalized='\n'.join(line for line in normalized.splitlines() if line!='#print axioms AuditEVTLaws.'+theorem)
 checks.append({'path':name,'byte_identical':old==new,'non_comment_text_identical':strip_comments(old.decode())==strip_comments(new.decode()),'preexisting_non_comment_text_preserved':strip_comments(old.decode())==strip_comments(normalized)})
result['preexisting_mathematics']={'method':'Nested-comment-aware textual comparison after removing comments and normalizing whitespace; for ExtremeValueLaws removes the two new continuous_frechetCDF and continuous_reverseWeibullCDF theorem bodies and their two axiom-print commands. Their preceding docstrings are removed by the comment stripper. Not a Lean AST comparison. Excludes root aggregation import and verifier scripts.','module_count':len(checks),'all_preexisting_non_comment_text_preserved':all(x['preexisting_non_comment_text_preserved'] for x in checks),'modules':checks,'new_modules':[n for n in a if (n.startswith('Taleb_Lean_Repairs/AuditRepairs/') or n.startswith('Taleb_Lean_Repairs/Proofs/')) and n.endswith('.lean') and n not in oldlean]}
result['claim_bounds']='The bundle establishes the supplied committed history and packaged snapshot. A clean audit clone does not establish the author worktree state, remote existence, or push state. The bundle contains three commits since the v0.2.6 deliverables commit; the announced subsequent v0.2.7 deliverables commit is necessarily outside this bundle, so four commits since the earlier deliverables cannot all be independently checked here.'
(work/'provenance.json').write_text(json.dumps(result,indent=2)+'\n')
for key in result:
 if key=='bundle':print(key,json.dumps({k:v for k,v in result[key].items() if k!='log'}))
 elif key=='preexisting_mathematics':print(key,json.dumps({k:v for k,v in result[key].items() if k!='modules'}))
 else:print(key,json.dumps(result[key]))
