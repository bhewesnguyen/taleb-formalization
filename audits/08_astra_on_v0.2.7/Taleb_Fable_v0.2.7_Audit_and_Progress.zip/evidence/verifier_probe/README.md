# Bounded Python verifier evidence

Run from the workspace root:

```sh
python3 audit_v027/verifier_probe/check_verifier_python.py \
  --project audit_v027/received/Taleb_Lean_Repairs \
  --v025 audit_v025/received/Taleb_Lean_Repairs \
  --v026 audit_v026/received/Taleb_Lean_Repairs \
  --out audit_v027/verifier_probe/python_probe_results.json
```

The script reads the received trees and performs all writes in a temporary copy or its own output file. It compares the complete received v0.2.7 tree hash map before and after.

It actually executes the shipped schema/rendering probe CLI and generator. For nine `verify.main` integration cases, it deliberately replaces the external-command function with a replay of received Lean, dependency and build evidence. That isolates Python acceptance behavior and must not be reported as independent Lean checking. The separate `reproduction/stale_markdown_cli/` record is a real CLI run with no replay.

`all_probes_matched_expected_observations` means every observed accept/reject behavior matched its intended result, including the two positive verifier controls. It does not mean every input was rejected or that the checker validates mathematical prose.
