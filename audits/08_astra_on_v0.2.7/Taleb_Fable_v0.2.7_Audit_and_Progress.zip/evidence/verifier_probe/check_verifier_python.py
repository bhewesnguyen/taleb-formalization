#!/usr/bin/env python3
"""Independent bounded v0.2.7 Python checks, not Lean execution.

The received project is only read. The actual generator and shipped probe CLI run
in a temporary copy. verify.main is exercised with its external-command function
replaced by a replay of the received Lean logs and environment inventory, so these
integration checks establish Python acceptance behavior only. Independent actual
Lean/CLI execution is recorded by the separate runtime audit.
"""
import argparse
import contextlib
import copy
import difflib
import hashlib
import importlib.util
import io
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def digest(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file() and '.lake' not in p.parts}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', required=True, type=Path)
    ap.add_argument('--v025', required=True, type=Path)
    ap.add_argument('--v026', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    source = args.project.resolve()
    before = digest(source)
    evidence = source / 'evidence/current'
    ledger_bytes = (source / 'docs/FORMALIZATION_BACKLOG.json').read_bytes()
    md_bytes = (source / 'docs/FORMALIZATION_BACKLOG.md').read_bytes()
    ledger = json.loads(ledger_bytes)
    md = md_bytes.decode('utf-8')
    inventory = json.loads((evidence / 'inventory_environment.json').read_text())
    manifest = json.loads((source / 'lake-manifest.json').read_text())
    received = json.loads((evidence / 'verification.json').read_text())
    axioms = (evidence / 'axioms.log').read_text()
    result = dict(scope=__doc__, project=str(source), historical_rendering=[],
                  generator=[], verifier_python_replay=[])
    with tempfile.TemporaryDirectory(prefix='taleb_v027_python_probe_') as tmp:
        temp = Path(tmp)
        staged = temp / 'project'
        shutil.copytree(source, staged, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
        sys.path.insert(0, str(staged / 'scripts'))
        schema = load_module('taleb_schema_probe', staged / 'scripts/backlog_schema.py')
        for label, old_root in [('v0.2.5', args.v025), ('v0.2.6', args.v026), ('v0.2.7', source)]:
            rows = json.loads((old_root / 'docs/FORMALIZATION_BACKLOG.json').read_bytes())
            old_md = (old_root / 'docs/FORMALIZATION_BACKLOG.md').read_bytes()
            rendered = schema.render_markdown(rows).encode('utf-8')
            delta = list(difflib.unified_diff(old_md.decode().splitlines(), rendered.decode().splitlines(),
                                           fromfile=label + '_shipped_md', tofile=label + '_rendered_json'))
            plus = sum(x.startswith('+') and not x.startswith('+++') for x in delta)
            minus = sum(x.startswith('-') and not x.startswith('---') for x in delta)
            result['historical_rendering'].append(dict(version=label, byte_equal=rendered == old_md,
                added_lines=plus, removed_lines=minus, diff=delta,
                matches_expected=(rendered != old_md if label == 'v0.2.6' else rendered == old_md)))

        shipped_out = temp / 'shipped_probes'
        proc = subprocess.run([sys.executable, str(staged / 'scripts/backlog_schema_probes.py'),
            '--out', str(shipped_out)], cwd=staged, text=True, capture_output=True)
        record = json.loads((shipped_out / 'backlog_schema_probes.json').read_text())
        result['shipped_probes'] = dict(exit_code=proc.returncode, stdout=proc.stdout,
            count=len(record['results']), decomposition=dict(schema_negative=12, schema_positive=1,
                rendering_negative=4, rendering_positive=1), result=record,
            matches_expected=proc.returncode == 0 and len(record['results']) == 18
                and record['all_probes_behaved_as_expected'])

        # Actually execute the shipped generator with both output files corrupted.
        gen = staged / 'scripts/rebuild_curated_inventory.py'
        gen_original = gen.read_text()
        output_files = [staged / 'docs/FORMALIZATION_BACKLOG.json', staged / 'docs/FORMALIZATION_BACKLOG.md']
        for f in output_files:
            f.write_text('deliberate stale sentinel\n')
        proc = subprocess.run([sys.executable, str(gen)], cwd=staged, text=True, capture_output=True)
        same_json = output_files[0].read_bytes() == ledger_bytes
        same_md = output_files[1].read_bytes() == md_bytes
        result['generator'].append(dict(case='rebuild_both_corrupted_outputs', exit_code=proc.returncode,
            stdout=proc.stdout, json_matches_shipped_bytes=same_json, markdown_matches_shipped_bytes=same_md,
            matches_expected=proc.returncode == 0 and same_json and same_md))
        needle = '|RV|P1|partial|states='
        if needle not in gen_original:
            raise RuntimeError('Expected invalid-priority insertion point missing')
        gen.write_text(gen_original.replace(needle, '|RV|BAD_PRIORITY|partial|states=', 1))
        for flags in ([], ['-O']):
            before_pair = [f.read_bytes() for f in output_files]
            proc = subprocess.run([sys.executable] + flags + [str(gen)], cwd=staged, text=True, capture_output=True)
            unchanged = [f.read_bytes() for f in output_files] == before_pair
            result['generator'].append(dict(case='invalid_priority' + ('_optimized' if flags else ''),
                exit_code=proc.returncode, stderr=proc.stderr.strip(), both_outputs_unchanged=unchanged,
                matches_expected=proc.returncode != 0 and unchanged and 'unknown priority' in proc.stderr))
        gen.write_text(gen_original)

        # Keep the real verify.main and all Python gates, replay external evidence only.
        verifier = load_module('taleb_verify_probe', staged / 'scripts/verify.py')
        deps = {d['name']: d['rev'] for d in manifest['packages']}
        def replay_run(cmd, log=None):
            if cmd == ['lake', 'env', 'lean', '--version']:
                output = received['lean']
            elif cmd[:2] == ['git', '-C'] and cmd[3:] == ['rev-parse', 'HEAD']:
                output = deps[Path(cmd[2]).name]
            elif cmd[:2] == ['git', '-C'] and cmd[3:] == ['status', '--porcelain']:
                output = ''
            elif cmd == ['lake', 'build']:
                output = 'Python-only replay of a clean build. No Lean process executed.'
            elif cmd == ['lake', 'env', 'lean', 'AuditVerification.lean']:
                output = axioms
            elif cmd == ['lake', 'env', 'lean', 'scripts/FableInventory.lean']:
                output = json.dumps(inventory)
            else:
                raise RuntimeError('Unexpected external command: ' + repr(cmd))
            if log:
                (verifier.OUT / log).write_text(output)
            return output.strip()
        verifier.run = replay_run
        t061_start = md.index('### T061 - ')
        t061_end = md.index('### T062 - ')
        t061 = md[t061_start:t061_end]
        def md_t061_replace(old, new):
            if old not in t061:
                raise RuntimeError('Missing Markdown mutation text: ' + old)
            return md[:t061_start] + t061.replace(old, new, 1) + md[t061_end:]
        mismatch = 'is not the rendering of docs/FORMALIZATION_BACKLOG.json'
        cases = [('valid', copy.deepcopy(ledger), md, True, None),
            ('markdown_T061_stale_status', copy.deepcopy(ledger),
                md_t061_replace('**P1 / discharged / EVT**', '**P1 / partial / EVT**'), False, mismatch),
            ('markdown_T061_stale_scope', copy.deepcopy(ledger),
                md_t061_replace('Delivery scope: All three standardised EVT laws', 'Delivery scope: Only two EVT laws'), False, mismatch),
            ('markdown_T061_dropped_declaration', copy.deepcopy(ledger),
                md_t061_replace('`AuditEVTLaws.continuous_frechetCDF`, ', ''), False, mismatch)]
        for case in ('json_T061_stale_status', 'json_T061_stale_scope', 'json_T061_dropped_declaration'):
            rows = copy.deepcopy(ledger)
            if case.endswith('status'):
                rows[60]['status'] = 'partial'
                rows[60]['discharged'] = False
                rows[60]['states'].remove('discharged')
            elif case.endswith('scope'):
                rows[60]['delivery_scope'] = 'Only two EVT laws'
            else:
                rows[60]['declarations'].pop()
            if schema.validate(rows):
                raise RuntimeError('Rendering mutation unexpectedly invalidates schema')
            cases.append((case, rows, md, False, mismatch))
        rows = copy.deepcopy(ledger)
        rows[60]['declarations'].append('AuditEVTLaws.nonexistent_decl')
        cases.append(('json_and_markdown_synced_dangling_declaration', rows, schema.render_markdown(rows),
                      False, 'cites declarations that do not exist'))
        rows = copy.deepcopy(ledger)
        rows[60]['delivery_scope'] = 'A synchronized but mathematically unaudited scope edit'
        cases.append(('json_and_markdown_synced_scope_control', rows, schema.render_markdown(rows), True, None))
        for name, rows, altered_md, expected_acceptance, expected_error in cases:
            output_files[0].write_text(json.dumps(rows))
            output_files[1].write_text(altered_md)
            accepted, error, error_type = False, None, None
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    verifier.main()
                    accepted = True
                except Exception as exc:
                    error, error_type = str(exc), type(exc).__name__
            result['verifier_python_replay'].append(dict(case=name, accepted=accepted,
                expected_acceptance=expected_acceptance, error=error, error_type=error_type,
                matches_expected=accepted == expected_acceptance
                    and (expected_error is None or expected_error in (error or ''))))

    result['original_tree_unchanged'] = before == digest(source)
    result['all_probes_matched_expected_observations'] = result['original_tree_unchanged'] and (
        result['shipped_probes']['matches_expected'] and
        all(r['matches_expected'] for group in ('historical_rendering', 'generator', 'verifier_python_replay')
            for r in result[group]))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('original_tree_unchanged', 'all_probes_matched_expected_observations')}, indent=2))
    return 0 if result['all_probes_matched_expected_observations'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
