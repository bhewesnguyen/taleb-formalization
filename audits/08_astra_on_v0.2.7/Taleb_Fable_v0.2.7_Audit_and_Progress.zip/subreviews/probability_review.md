# v0.2.7 probability and T029 source-scope review

Review scope: the submitted `AuditRepairs/WeightedSums.lean`, the actual pinned Mathlib measure-real lemmas, the current T029 ledger row and Fable narrative, and the local book PDF. This is source and mathematical review; runtime reproduction is a separate audit strand. No release file was changed.

## Verdict

Accept the new probability result as a correct, nonvacuous, two-variable finite-log-exponent theorem. No mathematical defect was found. Both the raw-event theorem and its measurable pushforward-law corollary prove what their statements say. Nonnegativity, positive weights, finite exponents, and the absence of independence are all handled correctly.

Keep T029 partial in this release. Credit the binary probabilistic exponent slice as complete. The book's Property 5.1 states an exponent conclusion, while the older curated T029 target additionally asks for dominance of unequal regularly varying tails. Those are distinct deliverables. The stronger target is mathematically valid under the recorded nonnegative assumptions and unequal indices, even without independence; it should not silently disappear to obtain a discharged count.

Fairness to the implementation: the previous audit's proposed mathematics milestone was the probabilistic finite-exponent result. That requested binary result has now been delivered. The ambiguity between that milestone and the older family-level regular-variation wording is an audit/ledger scoping issue, not a newly discovered proof defect or a failure to follow the agreed implementation route. Record the older stronger target as its own open child instead of treating it as an unannounced requirement for accepting this milestone.

One low-severity documentation defect remains: T029's `hypotheses_and_gaps` still says that the probabilistic statement about sums remains open, contradicting the delivered binary theorem. This stale sentence originates in the generator and now appears identically in both synchronized ledgers. Rendering consistency cannot detect semantic staleness.

## Probability proof checked

### Events and strict inequalities

Write `Z = a X + b Y` with `a,b > 0`. The lower-left event inclusion is valid because `X > t/a` implies `aX > t`, while `bY >= 0`. The lower-right inclusion is symmetric. Each lower inclusion uses nonnegativity of the other summand, exactly as required.

The upper event inclusion is valid for every real threshold, with no nonnegativity assumption: if neither `X > t/(2a)` nor `Y > t/(2b)` holds, then `aX <= t/2` and `bY <= t/2`, contradicting `Z > t`. The code uses strict upper-tail events throughout, so there is no hidden boundary-mass or `>` versus `>=` mismatch.

The `omit [MeasurableSpace Omega]` blocks are appropriate for these pure set inclusions. The omitted structure is genuinely unnecessary.

### Measure.real without event measurability

Pinned Mathlib's `measureReal_mono` requires an inclusion and finiteness of the larger set's measure. It does not require measurable sets. The probability typeclass supplies `measure_ne_top` for every set, so taking `ENNReal.toReal` introduces no loss of order and no infinity-to-zero problem here.

Pinned Mathlib's `measureReal_union_le` likewise has no measurability assumption. It follows from the underlying outer-measure subadditivity and appropriate finiteness cases. Consequently,

\[
\max(S_X(t/a),S_Y(t/b))\leq S_Z(t)
\leq S_X(t/(2a))+S_Y(t/(2b))
\]

is established correctly even for arbitrary functions `X,Y`. For nonmeasurable functions, `survivalRV` is an outer-measure event function rather than the survival of an already established probability law. The implementation explicitly provides the measurable-law corollary, so this generality is harmless and useful. There is no claim that a nonmeasurable function has an ordinary distribution merely because `survivalRV` is defined.

### Exponents and law identification

The lower bound has exponent `min alpha beta` by positive argument rescaling and the analytic maximum lemma. The upper bound has that same exponent by positive rescaling and the analytic addition lemma. The squeeze then applies to the actual event-tail function. Eventual positivity of the lower bound supplies eventual positivity of the middle tail, so totalized `Real.log 0` cannot make the claim pass spuriously.

The pointwise nonnegativity assumptions are exactly the delivered assumptions. An almost-sure extension is not silently obtained from them. No independence, joint-density, regular-variation, or convolution premise is hidden in the proof.

`survivalRV_eq_survival_map` uses `Measure.map_apply` with a measurable coordinate and the measurable set `Ioi t`. The preimage is definitionally `{omega | t < X omega}`. The weighted sum is measurable by multiplication by constants and addition. Thus `hasFiniteTailExponent_survival_map_weightedSum` is a genuine theorem about pushforward laws under the explicitly stated measurable-coordinate hypotheses.

The real parameters `alpha,beta` are not explicitly assumed positive. This is safe. The general analytic rules support arbitrary finite real limits. Probability-tail hypotheses themselves exclude a negative finite exponent, since the tail is at most one. Zero exponent remains a meaningful allowed case. Bounded tails and tails with an infinite log exponent do not satisfy the current finite-exponent hypotheses.

The proof is direct and reasonably organized. There is no need to replace it for elegance. A later finite-family version can reuse the binary theorem by induction; a new finset maximum API is optional, not necessary for correctness.

## What the source actually states

Source examined: local `audit_v024/source/2001.10488v4(1).pdf`, printed pp. 96-100 (PDF pp. 110-114). Printed p. 99 / PDF p. 113 was rendered and visually checked; the audit render is `audit_v027/source/property_5_1.png`.

Printed p. 96 defines slow variation by the positive-scale tail ratio. Printed p. 97 discusses the log-log slope and defines the power-law class through a slowly varying factor. On printed p. 99, Property 5.1 itself is headed "Tail exponent of a sum" and concludes `alpha_s = min_i alpha_i` for a finite weighted sum. It neither displays nor states the sharper survival-equivalence formula as its conclusion. The adjacent two-power calculation is an exponent calculation and indeed has the known missing-minus-sign error.

The unrestricted source permits signed dependent variables and also uses an informal `+infinity` convention outside the power-law class. The signed cancellation counterexample remains valid. The release responsibly restricts to nonnegative summands and finite exponents. Calling the result the corrected *binary finite-exponent slice* of Property 5.1 is accurate. Calling it the whole finite-family and infinite-exponent source claim would not be accurate.

The finite-exponent/RV distinction is substantive even for genuine probability tails. For example, fix `0 < epsilon < alpha` and define a survival function equal to one for `t <= 1`, and for `t > 1` by

\[
S(t)=t^{-\alpha}\exp(\epsilon\sin(\log t)).
\]

It is continuous and decreases to zero because its logarithmic derivative has numerator `-alpha + epsilon cos(log t) < 0`. Its finite log-tail exponent is `alpha`. But its scaling ratio at `c = exp(pi)` oscillates, so the tail is not regularly varying. This is an explanatory mathematical example, not an added Lean theorem.

## Precise disposition of the stronger T029 target

Recommended bookkeeping:

1. Mark the formula slice and the binary nonnegative finite-exponent probability slice complete.
2. Retain the recorded finite-family extension and almost-sure wrapper as separate named children.
3. Retain the older unequal-index regular-variation dominance target as an explicit stronger child. State its mathematical content precisely, including the weight.
4. Keep any future infinite-exponent extension explicit. Do not quietly claim it from the real-valued interface, and do not introduce it as a new surprise closure gate if it was outside the previously agreed family scope.

For the stronger child, suppose `X,Y` are measurable real-valued coordinates on a probability space, `X,Y >= 0` pointwise (or almost surely after proving the wrapper), `a,b > 0`, and the survival tails are eventually positive and regularly varying with indices `-alpha,-beta`, where `0 <= alpha < beta`. Restricting to `0 < alpha < beta` is also a natural first source-convention statement. Then the correct conclusion is

\[
\Pr(aX+bY>t)\sim\Pr(aX>t)=S_X(t/a),
\]

or, equivalently,

\[
\frac{\Pr(aX+bY>t)}{S_X(t)}\longrightarrow a^\alpha.
\]

It is generally incorrect to write equivalence to the *unweighted* `S_X(t)` with ratio one when `a != 1`.

No independence is needed. For each fixed `0 < delta < 1`, the same event method gives

\[
S_X(t/a)\leq S_Z(t)
\leq S_X((1-\delta)t/a)+S_Y(\delta t/b).
\]

Divide by `S_X(t/a)`. Regular variation gives the first upper term's limit `(1-delta)^(-alpha)`, while the strictly lighter index gives a zero limit for the second upper term. The ratio's lower limit is at least one; its upper limit is at most `(1-delta)^(-alpha)` for every such `delta`. Let `delta` decrease to zero. The ratio tends to one. This also establishes regular variation of the weighted sum's tail with index `-alpha`.

Both tails being regularly varying is a natural sufficient specification matching the recorded target. A more general future lemma could require regular variation of the dominant tail and suitably negligible scaled tails for the other summand. That generalization is optional.

Do not apply this unequal-index conclusion to equal-index tails by continuity in the parameters. For a Pareto tail `S_X(t)=t^(-2)` and `Y=X`, the tail of `X+Y` is `4t^(-2)`, whereas `S_X+S_Y=2t^(-2)`. Dependence changes the leading coefficient. Equal indices can still support a dominance theorem if one tail is negligible relative to the other, but equality of exponents alone does not give that condition. Exact iid convolution equivalence remains a separate subexponential statement.

If the project deliberately wishes to redefine T029 around only the source's exponent conclusion, the defensible process is to record the scope correction visibly, move the stronger dominance target to an explicitly tracked child or supplemental obligation, and preserve its history. Merely replacing the target and incrementing the discharged counter is not a proof completion. Even that bookkeeping decision would not make the present binary theorem a finite-family theorem.

## Actionable documentation correction

Affected source: T029 row in `scripts/rebuild_curated_inventory.py` (line 35 in the submitted release), emitted to `docs/FORMALIZATION_BACKLOG.json` and `docs/FORMALIZATION_BACKLOG.md` (line 269 in the submitted Markdown).

Replace the stale last sentence of `hypotheses_and_gaps` with wording such as:

> The binary probabilistic finite-log-exponent statement is delivered in v0.2.7 for pointwise nonnegative coordinates and positive weights. The finite-family and almost-sure extensions, and the stronger unequal-index regular-variation dominance statement, remain open.

Make the same scope explicit in the remaining-obligations field, using `S_Z(t) ~ S_X(t/a)` for the heavier weighted summand. Regenerate both ledgers from the corrected source and run the existing rendering/schema checks. No new Lean fixture is necessary for this prose correction.

This is low severity and does not block acceptance of the mathematics. It should be repaired before using the ledger as the next implementation handoff.
