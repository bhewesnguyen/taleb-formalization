# v0.2.7 analytic and continuity review

Verdict: accept the new analytic lemmas and the two continuity theorems. No mathematical defect, hidden zero-log dependency, or vacuous hypothesis was found. This is a source-level mathematical review. Compiler execution and the axiom inventory are reported by the separate reproduction workstream.

Reviewed sources are the immutable received `AuditRepairs/WeightedSums.lean`, the definition in `AuditRepairs/Tails.lean`, the changes from v0.2.6 in `AuditRepairs/ExtremeValueLaws.lean`, and the relevant pinned Mathlib continuity and measure-real APIs. The received files were not modified.

## Exact interface

`AuditTails.HasFiniteTailExponent S α` means both:

1. `S(t) > 0` eventually as `t -> +infinity`.
2. `-log(S(t))/log(t) -> α` as `t -> +infinity`.

It does not assert that S is a survival function, monotone, measurable, bounded by 1, or regularly varying. That generality is appropriate for the analytic lemmas. The probability theorem separately supplies actual tail probabilities. Zero finite exponents are included. Negative exponents remain meaningful for arbitrary positive functions, such as powers that grow; they cannot occur for actual probability tails satisfying this interface. No nonnegativity assumption on the analytic exponent is needed by the proofs.

## New analytic declarations

| Declaration in `AuditTails` | Location in `WeightedSums.lean` | Assessment |
|---|---|---|
| `neg_log_div_log_antitone` | line 41 | Correct. The lower positive argument makes both logarithms legitimate, while `1 < x` makes the denominator strictly positive. Negation reverses the log inequality exactly once. |
| `HasFiniteTailExponent.comp_const_mul` | line 47 | Correct for `c > 0`. The map `t -> c*t` tends to infinity, preserves eventual positivity, and gives `log(c*t)/log(t) -> 1`. The cancellation of `log(c*t)` is performed only eventually where `c*t > 1`, explicitly derived from `t > max(1,1/c)`. |
| `log_add_le_log_two_add_max` | line 73 | Correct for two positive arguments, by bounding their sum by twice the larger argument. |
| `log_max_of_pos` | line 84 | Correct. Log is monotone on the positive arguments, and the proof splits which argument is larger. |
| `HasFiniteTailExponent.max` | line 92 | Correct. Eventually for `t > 1`, the log ratio of the maximum is exactly the minimum of the two log ratios. Continuity of minimum gives `min α β`. Eventual positivity follows even from the first input alone. |
| `HasFiniteTailExponent.add` | line 104 | Correct for arbitrary finite real α and β. The lower bound on the resulting log ratio is `min(r1,r2) - log(2)/log(t)` and the upper bound is `min(r1,r2)`. The vanishing additive correction and squeeze yield `min α β`. |
| `HasFiniteTailExponent.of_le_of_le` | line 133 | Correct. Eventual positivity is inherited from the lower tail. The log transform reverses `L <= S <= U`, so the limiting ratio for U bounds the ratio for S below and that for L bounds it above. The implementation uses precisely that order. |

These seven lemmas are reusable analytic results. In particular, the weighted-sum proof uses genuine scale invariance and general max/sum rules, rather than specializing the earlier exact two-power formula. This meets the proposed mathematical route.

### Boundary and totalization checks

- `Real.log 0` does not create a false exponent claim because eventual strict positivity is part of every exponent premise and conclusion.
- The possible zero denominator at `t = 1` and nonpositive denominator below 1 have no role in the limiting proof; all comparisons are restricted to `t > 1`.
- Rescaling does not cancel `log(c*t)` globally. It separately proves the eventual region where this logarithm is nonzero.
- Equal exponents, zero exponents, and negative exponents do not require extra branches in max/sum/squeeze.
- The result is about a finite limit. It does not silently turn a liminf statement into a limit or claim an infinite exponent.
- No regular-variation property, ratio asymptotic, probability normalization, or measurability is smuggled into the analytic interface.

## Two global continuity additions

`AuditEVTLaws.continuous_frechetCDF (hξ : 0 < ξ)` at line 190 correctly proves global continuity of the support-correct Fréchet CDF. Existing right continuity is combined with left continuity. On the nonpositive half-line the function is zero. At a positive point it agrees locally with the smooth positive-base power formula. At zero, the left value is zero and the existing right-hand limit is zero. The proof does not confuse the raw formula's totalized value at zero with the support-correct CDF.

`AuditEVTLaws.continuous_reverseWeibullCDF (hα : 0 < α)` at line 326 is also correct. Right continuity already holds without a shape restriction; the new global theorem uses positivity exactly where needed for the endpoint from the left. On the negative half-line the CDF agrees with `exp(-(-x)^α)`. At zero the same continuous formula has value 1 because `0^α = 0` when α is positive, agreeing with the piecewise CDF. On the positive half-line it is locally constant 1. The pinned `Real.continuousAt_rpow_const` accepts a nonnegative exponent at zero, while strict positivity supplies the required zero-power identity.

The strict positive-shape hypotheses are substantive: at α = 0 the reverse-Weibull negative branch is `exp(-1)` and jumps to 1 at zero, so global continuity would fail. Likewise ξ = 0 makes the Fréchet positive branch constant `exp(-1)` rather than approaching zero. The new claims do not overgeneralize these endpoints.

The prose repairs now accurately distinguish the sufficient Stieltjes requirements from the stronger global continuity that the constructed distributions possess. The mathematical correction is supported by checked statements rather than prose alone.

## Scope of the result

The exponent statement is strictly weaker than regular variation even for valid probability survival functions. An elementary illustrative example is

`S(t) = 1` for `t <= 1`, and `S(t) = t^(-α) * exp(ε*sin(log(t)))` for `t > 1`, where `0 < ε < α`.

It is continuous, decreases to zero, and takes values in [0,1], so it is a valid survival function of a nonnegative law. Its derivative above 1 has the sign of `-α + ε*cos(log(t))`, which is negative. Its finite log-tail exponent is α because the bounded oscillatory log term vanishes after division by `log(t)`. However,

`S(exp(π)*t)/S(t) = exp(-πα) * exp(-2ε*sin(log(t)))`

does not converge. Thus exponent equality cannot be credited as regular variation without another theorem or stronger premises. This example is explanatory mathematics, not a new Lean-verified artifact.

For T029, the analytic review supports full credit for the delivered two-variable, positive-weight, nonnegative-summand finite-log-exponent slice. It does not independently justify relabeling an existing regular-variation target as complete. The source-alignment and family-status decision belongs with the separate probability/ledger review.

## Repair recommendation

No Lean repair is required in these nine declarations. Do not spend the next milestone rewriting the working proofs for stylistic uniformity. Optional later generalizations, including finite nonempty families and almost-everywhere rather than pointwise support assumptions, are API extensions and should not be portrayed as defects in the stated two-variable theorem.
