# v0.2.7 verifier and ledger-rendering review

Verdict: the structural repair for D026-1 is implemented and the bounded independent Python checks pass. No new verifier acceptance defect was found in the changed paths. This is an assessment of source and Python behavior; actual Lean execution and the unchanged 14-fixture regression are recorded separately by the runtime review.

## Scope and source comparison

The verifier change imports `render_markdown` from the already shared `scripts/backlog_schema.py` and requires the shipped Markdown ledger to equal that rendering of the validated JSON rows. The previous schema validation, declaration-existence gate, axiom allowlist, environment inventory, source-module coverage, alias-target and dependency checks are retained. No acceptance condition was weakened.

`scripts/rebuild_curated_inventory.py` now calls the shared validator before writing either ledger and derives both JSON and Markdown from the same `rows`. The renderer has one implementation in `backlog_schema.py`. `harness_regression.py` changes only its description from two to three positive controls; its fixture behavior is unchanged from v0.2.6.

The consistency check compares strings read with `Path.read_text`, so the exact implementation enforces equality of decoded, newline-normalized text. The current files use LF and the independent checks below also establish literal byte equality with generated artifacts. There is no stale-content acceptance observed; a demand for byte-level rejection of harmless line-ending changes would be a separate convention, not a mathematical or ledger-consistency issue.

## Independent bounded checks

The reproducible script is `verifier_probe/check_verifier_python.py`; results are in `verifier_probe/python_probe_results.json`. The received tree's complete file-hash map was unchanged after the checks.

| Check | Observed result |
|---|---|
| Render v0.2.5 JSON with the new renderer | Exact byte match to the shipped v0.2.5 Markdown |
| Render v0.2.6 JSON | Detects the prior T061 discrepancy: 11 removed and 11 added diff lines, including blank separator lines |
| Render v0.2.7 JSON | Exact byte match to shipped Markdown |
| Run actual generator after corrupting both temporary output files | Both restored exactly to the shipped v0.2.7 bytes |
| Insert invalid priority into generator raw rows | Nonzero exit before either output changes |
| Repeat malformed-generator check with Python `-O` | Same rejection and both outputs unchanged |
| Run actual shipped schema/rendering probe CLI | Exit 0; all 18 recorded probes behave as expected |
| Exercise actual `verify.main` with external-command replay | Nine cases behave as expected, as detailed below |

The actual 18 shipped probes consist of 12 malformed-schema rejections, one valid-schema control, four stale-rendering rejections and one valid-rendering control. Thus the five newly added rendering checks include a positive control. They are not five negative tests, and the whole suite is not 18 malformed inputs.

For the nine bounded `verify.main` checks, only external command outputs are replaced by received evidence. The actual Python verifier, schema logic, renderer and existence gate run on a temporary source copy. These checks are not independent Lean compilation or trust-scan evidence.

| Python replay case | Observed |
|---|---|
| Unmodified tree | Accepted |
| T061 status edited only in Markdown | Rejected at rendering gate |
| T061 scope edited only in Markdown | Rejected at rendering gate |
| T061 declaration removed only in Markdown | Rejected at rendering gate |
| T061 status/state/Boolean consistently edited only in JSON | Rejected at rendering gate |
| T061 scope edited only in JSON | Rejected at rendering gate |
| T061 declaration removed only in JSON | Rejected at rendering gate |
| Nonexistent declaration inserted in JSON and Markdown regenerated | Rejected at declaration-existence gate |
| Textually synchronized scope edit in both formats | Accepted, as expected |

The last positive control is a useful limit: the verifier ensures internal consistency and the existence of cited declarations, not that prose scope is mathematically justified. Human review of T029 and the delivery-state vocabulary remains necessary.

A separate actual CLI check completed on an isolated copy, changing only T061's Markdown status from `discharged` to `partial`. The unchanged `python3 scripts/verify.py` exited 1 after 233.71 seconds with the exact expected error: `docs/FORMALIZATION_BACKLOG.md is not the rendering of docs/FORMALIZATION_BACKLOG.json (run scripts/rebuild_curated_inventory.py)`. No external command outputs were mocked for this run. The mutation diff confirms that only the T061 Markdown status changed; all 214 compared files matched after restoration. That count includes 213 release files outside generated evidence plus one generated Python bytecode file; it is not a count of 214 shipped source files. Evidence is in `reproduction/stale_markdown_cli/{mutation.diff,verify.log,verification.json,result.json}`.

This is one auditor-added real CLI rejection, separate from the shipped 14 regression fixtures, the shipped 18 Python probes and the nine bounded verifier replay cases. It must not be counted as an additional shipped regression fixture or conflated with the replay evidence.

## Minor supplied-evidence discrepancy

The standalone supplied `archive_validation_v0.2.7.log`, step 7, says `17 probes ok`. The shipped probe source and JSON record contain 18; independent execution also records 18 successful checks. This is a summary-count typo, not a failed probe or a false mathematical verification. Correct or annotate the count in the next handoff. Do not silently rewrite an archived historical record without marking the correction.

## Ledger prose observations delegated for mathematical review

The T029 `hypotheses_and_gaps` field retains the sentence that the probabilistic statement about sums remains open, despite the newly delivered probabilistic exponent theorem. Its scope and remaining-obligations fields are more precise. The row also adds `law_theorem`, whereas the ledger preamble classifies assumed finite-exponent properties under `conditional_law_theorem`. These are documentation and classification questions, not failures of the consistency gate, and are covered by the ledger and mathematical reviews.

No additional expensive Lean fixture is recommended for this rendering repair. The existing fixtures, the one real stale-Markdown run and bounded Python checks cover the concrete changed behavior.
