# v0.2.7 independent provenance review

The archive, Git bundle and both patches agree exactly. No packaging or history-integrity blocker was found. These checks were performed independently with Python, Git and read-only PDF comparison; no supplied release, build or verification script was run by this provenance review.

## Archive and manifest

- Uploaded ZIP SHA-256: `88ebaa078a18dc0e16bb46057969c5fec186c1fc958df1422b6d434e323d157b`, equal to the uploaded checksum and audit brief.
- 251 ZIP entries comprise 222 regular files plus directory entries. No duplicate regular-file names, unsafe paths, symbolic links, `.lake`, Python bytecode or Lean build outputs were found.
- All 221 `SHA256SUMS` entries match; every regular file other than the manifest itself is covered exactly once.
- All 222 files in the immutable audit extraction match the ZIP bytes.
- All 222 files under the bundled commit's `Taleb_Lean_Repairs/` match the ZIP, with no extra or missing project files.

## Bundle and reproducible patches

`git bundle verify` reports a complete history for `refs/heads/main`; `git fsck --full` returns successfully. The supplied head is `fe14519deafc0bab2ba6c696932419c7dd55d8d9`, whose project tree is `94c53167c02a41c357dc6266c085dd1299cb0898`.

| Route | Base commit | Changed project files | Result |
|---|---|---:|---|
| v0.2.0 to v0.2.7 | `f6b100762540655184b96dd4e0c8f8fd0233da28` | 170 | Exact Git diff; clean apply; identical project tree and all file bytes |
| v0.2.6 to v0.2.7 | `83ef501d87a1c910cc166f880ed44b7094e6f5d3` | 43 | Exact Git diff; clean apply; identical project tree and all file bytes |

Both patch applications were performed inside separate audit-owned worktrees. The immutable extraction was not changed.

The retained v0.2.0 ZIP has 73 files and exactly matches the pristine extraction commit. The retained v0.2.6 ZIP has 205 files and exactly matches its packaged commit; its SHA-256 is `d684d0ef3c3d17f9ceb5cd456969559674c1ac86e21bbd6a27505cf22d4fb3f3`.

`lean-toolchain` and `lake-manifest.json` are byte-identical to both v0.2.0 and v0.2.6. This independently confirms unchanged recorded pins, not the state of dependencies in Fable's original environment.

## Scope of changed mathematics

There are 26 pre-existing `AuditRepairs/` and `Proofs/` Lean modules. Twenty-five are byte-identical to v0.2.6. The remaining file, `ExtremeValueLaws.lean`, changes documentation and adds exactly the two continuity theorem blocks with their two axiom-print commands. After excluding those additions, nested-comment-aware textual comparison preserves all pre-existing non-comment text. `WeightedSums.lean` is the sole new mathematics module.

This comparison is textual and does not replace Lean checking or mathematical review. Root aggregation imports and generated verification declarations are intentionally outside the old-mathematics preservation comparison.

## Retained audit artifacts

All 18 entries in `audits/RECEIVED_ARTIFACTS.sha256` match their retained files. All 15 earlier-round artifacts are unchanged from the v0.2.6 packaged commit. The newly retained v0.2.6 progress Markdown and audit ZIP match the auditor's actual local output bytes.

The newly retained standalone v0.2.6 PDF has SHA-256 `c9b5a23df58b09489d3caf29769abe184864a513d016c8f9d20aca02418e0f57`; the local output and matching member of the unchanged audit ZIP have SHA-256 `e3bef7bcfcf677114a05f0187db1920a83a7b16091106955fefe73594b4ce9e7`. Their PDF metadata differs, but all eight pages have identical extracted text and identical 150-dpi Poppler RGB pixel buffers and dimensions. No substantive difference was identified. The cause of the binary representation change is not established, so this is a bounded provenance note, not an allegation or release blocker.

## Small evidence-text inconsistency

The uploaded `archive_validation_v0.2.7.log`, step 7, says `17 probes ok`; the packaged `evidence/current/backlog_schema_probes.json` contains 18 result records, all marked successful, consistent with the brief and handoff. There are two positive controls and 16 malformed-input checks, so 17 is not the total or the negative-test count. Correct the validation summary count on the next packaging pass, while preserving or visibly annotating the received historical log. This does not invalidate the recorded individual results, and this provenance review does not substitute supplied results for the main audit's independent execution.

## Limits on original-workspace claims

The bundle contains three commits after the v0.2.6 deliverables commit `ea1286d`: the new received audit, the implementation, and the final evidence layer. There are four commits after the prior *packaged-tree* commit `83ef501`. The announced current deliverables commit is outside the supplied bundle, as the brief explicitly acknowledges. Accordingly, the bundle verifies only its supplied committed history and snapshot. The clean audit clone does not prove the author's working tree was clean, whether a remote existed, or whether anything was pushed. No contradiction with a later fourth commit is inferred.

## Reproduction files

- `provenance/check_provenance.py`: independent archive, manifest, bundle, patch, pin and old-source checks.
- `provenance/provenance.json`: machine-readable results, including all uploaded input hashes.
- `provenance/check_provenance.log`: human-readable execution output.
- `provenance/compare_previous_pdf.py`: read-only prior PDF text/render comparison.
- `provenance/previous_pdf_comparison.json`: per-page metadata and pixel-hash results.
- `provenance/compare_previous_pdf.log`: complete PDF comparison output.
