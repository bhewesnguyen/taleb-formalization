# Independent runtime reproduction: v0.2.7

## Verdict

All independently executed release checks passed. The clean build and normal verifier used the unchanged received sources, pinned Lean 4.24.0, and all nine pinned dependencies. The separately mutated Markdown ledger was rejected by the actual verifier CLI. No mathematical coverage claim follows from compilation alone.

## Setup and integrity

- Runtime: `Lean (version 4.24.0, x86_64-unknown-linux-gnu, commit 797c613eb9b6d4ec95db23e3e00af9ac6657f24b, Release)`.
- Reused official compiler installation and matching dependency caches from the previous audit; no prior project build outputs were copied.
- Tested project: `/tmp/taleb_v027_audit_project`. Immutable received extraction was not modified.
- Initial and final checks: all 9 dependency revisions match the manifest and all dependency working trees are clean.
- Final byte comparison: 213 received files outside generated `evidence/current` match the tested project.
- Detailed setup, exact commands, source hashes, and all logs are in `reproduction/`.

## Commands and outcomes

| Check | Exit | Seconds | Result |
|---|---:|---:|---|
| Clean `lake build` | 0 | 114.32 | No compiler warnings or errors |
| `python3 scripts/verify.py` | 0 | 231.12 | PASS |
| Shipped schema/render probes | 0 | 0.06 | 18/18 expected outcomes |
| Full shipped harness, three disjoint shards | 0 each | 1276.28 elapsed | 14/14 expected outcomes |
| Auditor-added stale T061 Markdown CLI case | 1 | 233.71 | Expected rendering-mismatch rejection |

## Verification counts

- 140 theorems, 8 instances, 16 aliases: 164 public checks.
- 296 project constants scanned, including 79 internal constants. Generated constants: 98 (categories overlap and must not be added).
- 33 public non-generated definitions; 28 imported project modules.
- All scanned project constants use only `propext`, `Classical.choice`, and `Quot.sound`; no project axiom declarations.
- Every disk project module is imported, public discovery matches the Lean environment, and all 16 alias targets match the replacement map.
- Backlog: 158 valid families, 2 discharged; 123 family/declaration pairs over 122 distinct names. Markdown equality with the shared rendering passed through the normal CLI gate.

## Shipped regression suite

The original harness was not edited. All 14 fixture IDs were covered exactly once through three concurrent, disjoint `--only` invocations. Each invocation had its own dependency copy, scratch directory, output directory, source restoration, and per-fixture project build snapshot. Both scratch and output arguments were genuinely relative. This is partitioned full fixture coverage, not a single sequential all-fixtures execution.

| Fixture | Verifier exit | Status | Expected outcome met |
|---|---:|---|---|
| `valid` | 0 | PASS | True |
| `private_sorry_theorem` | 1 | FAIL | True |
| `private_sorry_def` | 1 | FAIL | True |
| `private_axiom` | 1 | FAIL | True |
| `structure_namespace_theorem` | 1 | FAIL | True |
| `protected_theorem` | 1 | FAIL | True |
| `alias_map_mismatch` | 1 | FAIL | True |
| `alias_map_mismatch_optimized` | 1 | FAIL | True |
| `orphan_module` | 1 | FAIL | True |
| `nested_orphan_module` | 1 | FAIL | True |
| `nested_imported_module` | 0 | PASS | True |
| `namespace_section_theorem` | 0 | PASS | True |
| `backlog_duplicate_id` | 1 | FAIL | True |
| `dirty_dependency` | 1 | FAIL | True |

All per-fixture source restoration hashes matched their pristine copy: True. All project build snapshots were reset: True.

The two sorry fixtures also independently list their private constants with `sorryAx` when the standalone environment scanner is run. The imported nested-module positive control confirms its module and theorem are scanned.

## Added stale-Markdown check

Only the Markdown T061 status line was changed from `discharged` to `partial`, leaving JSON and verifier byte-identical. The real command `python3 scripts/verify.py` exited 1 with a FAIL record containing:

```text
docs/FORMALIZATION_BACKLOG.md is not the rendering of docs/FORMALIZATION_BACKLOG.json (run scripts/rebuild_curated_inventory.py)
```

After the test, the Markdown bytes were restored and 214 files were compared with the pristine tested copy; all match. This comparison includes 213 release files outside generated evidence plus one generated Python bytecode file. This is one auditor-added end-to-end test, separate from both the 14 shipped fixtures and the 18 shipped Python probes. No external command output was mocked for this case.

## Boundaries

The official runtime and dependency compilation caches were reused, so this is a fresh project build rather than a rebuild of Lean and Mathlib from source. The test suite checks the shipped adversarial cases and this audit's one added rendering case; it is not an exhaustive proof of verifier correctness. The supplied author logs are not substituted for independent execution.
