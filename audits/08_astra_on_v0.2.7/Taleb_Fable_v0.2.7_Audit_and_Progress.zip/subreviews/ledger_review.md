# v0.2.7 ledger and scope review

**Accept the agreed binary weighted-sum milestone. Retain T029 as partial under its inherited broader wording, with the delivered exponent result explicitly marked complete.** The unchanged parent-family counts are conservative, not evidence that the mathematics failed to advance. T060 and T061 remain discharged. Two small documentation groups need repair: T029's stale sentence and delivery-facet attribution, and S001's literal zero-shape definition and source anchor.

This review compares the received v0.2.7 ledger with v0.2.6, the original v0.2.0 T029 target from the bundled Git baseline, the supplied book pages, and the changed Lean declarations. The accompanying JSON preserves all 158 received rows exactly and adds eleven audited family scopes. The 147 unsupported rows are tallied, not represented as newly audited mathematical theorems. Independent build and verifier execution are reported separately by the runtime review.

## Progress and citation tally

| Status | v0.2.6 | v0.2.7 | Recommended |
|---|---:|---:|---:|
| Discharged | 2 | 2 | 2 |
| Partial | 9 | 9 | 9 |
| Reuse available, not instantiated | 4 | 4 | 4 |
| Missing | 91 | 91 | 91 |
| Source check required | 34 | 34 | 34 |
| Model needed | 15 | 15 | 15 |
| Empirical | 3 | 3 | 3 |
| Total | 158 | 158 | 158 |

There are 140 formal-proof families and 18 model or empirical families. Eleven families have credited Lean support; two are closed and nine partial. T047 and T118 remain explicitly prerequisite-only. These counts do not measure effort completion, independent book theorems, upstream Mathlib acceptance, or readiness of the separate quantum/classical software.

The ledger now cites **123 family/declaration pairs over 122 distinct declarations**, up from 107/106. T029 gains fourteen names and T061 gains the two continuity theorems. The sole shared declaration is `AuditGaussian.charFun_gaussianReal_eq_stableS1Expr`, credited to T007 and T046. There are no duplicate pairs and all names occur in the supplied environment inventory. Independent runtime verification must regenerate that evidence rather than relying on its presence in the package.

Only three JSON rows changed: T029's delivery, T060's routing of remaining work, and T061's continuity and routing prose plus the new continuity citations. The other 155 rows are identical. All family statuses, IDs, titles, dependency groups and source locators are unchanged. The companion JSON includes counts for all 22 dependency groups.

The received nonexclusive facets total: `formula_proved` 8, `source_reviewed` 7, `actual_law_constructed` 3, `conditional_law_theorem` 3, `law_theorem` 3, `discharged` 2. Add `conditional_law_theorem` to T029 for the finite-exponent theorem, giving four such families. Its `law_theorem` facet can remain if explicitly assigned to the separate generic `survivalRV_eq_survival_map` identity. Facet totals overlap and are not completed-work totals.

## T029: source, inherited target and the accepted milestone

The original v0.2.0 row at baseline commit `f6b1007` was titled "Tail of sums with unequal indices" and targeted: "Prove the heavier regularly varying tail dominates a sum under appropriate independence and support conditions." The later repair correctly removed unnecessary independence and restricted to nonnegative variables to avoid signed cancellation.

The supplied source, Property 5.1 on printed p. 99 / PDF p. 113, explicitly states a finite weighted sum and equality of its tail exponent with the minimum component exponent. It does not display a survival-ratio equivalence. It also adopts an informal infinite-exponent convention for variables outside the power-law class. The unrestricted signed formulation is false; the already recorded fair-sign Pareto cancellation example remains valid.

The prior v0.2.6 audit asked for two measurable nonnegative coordinates with positive weights and finite log-tail exponents, the general analytic rescaling/squeeze bridge, then the probability statement. It said a finite-family extension could follow. The v0.2.6 ledger's `remaining_obligations` likewise specified the finite log-exponent sum and put exact convolution asymptotics in the subexponential workstream. **v0.2.7 delivers that agreed binary milestone.** The new theorem covers equal as well as unequal finite exponents and requires no independence.

There is nevertheless a real distinction between the original regular-variation wording and the delivered finite-log-exponent conclusion. Finite exponent does not imply regular variation. For example, on t >= 1, the decreasing survival function `t^(-alpha) exp(c sin(log t))`, with `0 < c < alpha`, has finite log-tail exponent alpha but has oscillating scaling ratios. Keeping the stronger, inherited reading visible is appropriate. Calling it a newly discovered defect in this milestone would be unfair.

Recommended recorded scope:

| Component | State | Interpretation |
|---|---|---|
| Two-power-tail formula exponent | Complete since v0.2.3 | Corrected sign and minimum exponent. |
| Binary nonnegative weighted-sum finite exponent | Complete in v0.2.7 | Actual strict-tail events and measurable pushforward version; pointwise nonnegative coordinates, positive weights, assumed finite real exponents. |
| Finite nonempty family exponent extension | Open extension | Closer to the finite-n source statement; prior milestone guidance allowed it to follow the binary theorem. |
| Unequal-index regular-variation tail equivalence | Open inherited stronger target | State it precisely, including the weight on the heavier tail; do not silently substitute exponent equality. |
| Almost-sure nonnegativity | Open API extension | Useful relaxation of the pointwise hypotheses, not a new condition for accepting the delivered result. |

Retain T029 as partial while that inherited stronger target remains within the family. If the project later deliberately scopes T029 solely to the corrected exponent reading, record that versioned decision and preserve the stronger RV target as a separately named obligation. Do not erase it just to gain a third discharged family. Conversely, do not require the stronger theorem as retroactive acceptance work for the already completed v0.2.7 milestone.

For clarity, the stronger binary RV result is valid without independence under strict unequal indices. If X has tail index alpha, Y has tail index beta with `0 < alpha < beta`, and a,b > 0, the appropriate conclusion is

`P(aX + bY > t) / P(X > t/a) -> 1`.

For any epsilon in (0,1), bound the numerator below by `P(X > t/a)` and above by `P(X > (1-epsilon)t/a) + P(Y > epsilon*t/b)`. Regular variation gives an upper ratio limit `(1-epsilon)^(-alpha)`, while the lighter-tail ratio vanishes. Let epsilon decrease to zero. This is future mathematical guidance, not a claim that those Lean lemmas are already present. Writing equivalence to the unweighted tail `P(X > t)` without the factor `a^alpha` would be wrong.

The source's infinite-exponent convention is outside the finite-real interface. No existing family explicitly owns an extended-real exponent API; T024, T025 and T142 discuss related tail phenomena but do not specify that construction. Record this source limitation explicitly without inventing task routing or imposing a new release gate.

## Two documentation repairs

### D027-T029: stale gap sentence and facet attribution

T029's `hypotheses_and_gaps` still ends: "The probabilistic statement about sums of random variables remains open." That contradicts its new target, delivery scope and verified theorem. Because both ledgers are now rendered consistently, the same stale meaning appears in both formats. A consistency check cannot identify a mathematically stale sentence.

Replace it at the generator source with a statement such as: "The binary nonnegative weighted-sum finite log-tail exponent is proved in v0.2.7. Finite-family and almost-sure variants are extensions; the separately recorded unequal-index regular-variation tail equivalence is not yet proved."

The ledger glossary explicitly assigns assumed finite exponents to `conditional_law_theorem`. The weighted-sum theorem assumes both marginal exponents, so add that facet to T029 and attribute it to the main result. The generic `survivalRV_eq_survival_map` identity has only ordinary measurability hypotheses and can justify retaining `law_theorem` for that scoped component. If the project prefers to label only the main mathematical result, replace the latter facet instead. No concrete-tail realization is required to accept this general conditional theorem, and this bookkeeping correction does not change the mathematical credit.

### D027-S001: make the zero-shape branch explicit before implementation

The new supplemental register correctly separates unified GEV work from the closed T061 target, but S001 currently gives `G_xi(x) = exp(-(1 + xi*x)^(-1/xi))` on positive support and asks for a probability CDF for every real xi. That power expression is only the nonzero-shape branch. At xi = 0, Lean's totalized division gives exponent zero, so the literal formula is the constant `exp(-1)`, not a CDF.

Specify `G_0 = gumbelCDF` separately. For xi > 0, use zero below the lower support endpoint and the power formula above it. For xi < 0, use the power formula below the upper endpoint and one at and above it. Then prove the shape-to-zero limit. This is a future specification repair; no delivered Lean theorem defines the erroneous zero case.

Correct S001's source anchor to printed pp. **172-173 / PDF pp. 186-187**: the unified display is on p. 172 and the explicit Gumbel limit and three families on p. 173. The current 173-174 anchor misses the unified display. The endpoint-coordinate warning is correct. In unified location/scale coordinates `(mu, sigma)` with sigma > 0, the endpoint is `mu - sigma/xi`; the separate-family scale is `sigma/xi` for xi > 0 and `-sigma/xi` for xi < 0. The reverse-Weibull exponent is `-1/xi`, while the project's Frechet shape is xi.

## Previous findings and supplemental routing

**D026-1 is structurally addressed:** one renderer generates the Markdown ledger from validated rows, and `verify.py` checks byte equality. The stale v0.2.6 "synced" claim is visibly annotated, and the correction history names the actual error. Renderer behavior and mutation probes are assessed in the separate verifier review. The received Markdown now agrees in substance with the JSON's closed T061 state.

**D026-2 is addressed:** the support-correct Frechet and reverse-Weibull CDFs are globally continuous for positive shapes, and this is now separately proved by `continuous_frechetCDF` and `continuous_reverseWeibullCDF`. Both proofs combine the existing right-continuity with left-continuity; Frechet is zero to the left of its endpoint, and the reverse-Weibull formula approaches one from below zero. The totalized-power caveat remains attached to the unguarded Frechet formula. The affine definition and probability instances allow any real scale; the stated CDF and maximum rules require positive scale.

**D026-3 is addressed subject to the small S001 repair:** densities are now S002, rather than being assigned to T062. T011 describes normalized-maxima convergence, and T062 owns the Frechet RV case and Gaussian/Gumbel normalizers. The proposed Pareto maximum limit correctly uses `frechetMeasure (1/alpha)` and normalization `M_n/(L*n^(1/alpha))`. The correction history properly acknowledges that the earlier density routing came from previous audit guidance as well as implementation documentation.

S002's open-support derivative targets and `withDensity` identifications are appropriate. The endpoint notes are also correct under positive-shape assumptions: the Frechet density extends by zero continuously at its lower endpoint; reverse-Weibull has a density jump at exponent one and divergence from the left when the exponent lies in (0,1). None reopens T061, which constructs the three probability laws with the recorded affine wrappers.

## All eleven supported families

| Family | Recommended status | Audited scope and boundary |
|---|---|---|
| T001 Regular variation API | Partial | Ratio predicates and closure/examples; positive measurable convention remains. |
| T007 Stable-law existence | Partial | Gaussian alpha = 2 realization, including zero scale; other S1 shapes remain. |
| T008 Subexponential law API | Partial | Definition and finite-exponent transport under assumed properties; no concrete law or n-fold characterization. |
| T029 Unequal-index sums | Partial | Binary finite-exponent random-variable milestone complete; stronger inherited RV target separately open. |
| T032 Power transformation | Partial | Analytic exponent formula; probability pushforward and identification remain. |
| T046 Stable specializations | Partial | Gaussian law and convolution instantiated; Cauchy remains expression-level. |
| T047 Stable averages | Partial, prerequisite only | Conditional convolution/sum infrastructure; no average law or convergence. |
| T060 iid extrema | Discharged | Generic maximum CDF and minimum survival with explicit threshold conventions. |
| T061 EVT laws | Discharged | Three laws, global CDFs, maximum laws, positive affine wrappers and measure equalities; now global continuity exported too. |
| T118 Pareto moment convexity | Partial, prerequisite only | Tail-kernel convexity, not the actual moment integral/convexity/Jensen target. |
| T124 Gamma-index mean | Partial | Corrected algebraic excess and positivity; gamma inverse moment and mixture identity remain. |

The next Pareto slice remains a sensible contained milestone. Credit only the portions delivered under T005/T021/T028/T032; establish divergence with extended nonnegative integrals, and avoid using a totalized real integral as evidence of a finite moment. The broader regular-variation and convergence program remains substantial despite the useful reuse this release now enables.
