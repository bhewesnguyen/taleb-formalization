from pathlib import Path
import subprocess,time,json,os,sys
base=Path(__file__).resolve().parent
root=Path('/tmp/taleb_v025_audit_project')
env=dict(os.environ)
env['TAR_OPTIONS']='--no-same-owner'
env['PATH']='/tmp/taleb_v024_runtime/bin'+os.pathsep+env['PATH']
records=[]
commands=[('runtime_version',['lean','--version']),('clean_build',['lake','build']),('verify',['python3','scripts/verify.py']),('regression',['python3','scripts/harness_regression.py','--scratch','../taleb_v025_regression_scratch','--out','../../workspace/scratch/c40a0826d9d8/audit_v025/reproduction/regression'])]
for name,cmd in commands:
 t=time.monotonic()
 print('START',name,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),flush=True)
 with (base/(name+'.log')).open('w') as log:
  proc=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec={'name':name,'command':cmd,'cwd':str(root),'exit_code':proc.returncode,'seconds':round(time.monotonic()-t,2),'log':str(base/(name+'.log'))}
 records.append(rec)
 (base/'reproduction.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(rec),flush=True)
 if proc.returncode: sys.exit(proc.returncode)
