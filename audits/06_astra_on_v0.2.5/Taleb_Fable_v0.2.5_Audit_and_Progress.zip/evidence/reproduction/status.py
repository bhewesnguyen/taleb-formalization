from pathlib import Path
import datetime,json,time,subprocess
base=Path(__file__).resolve().parent
p=base/'regression.log'
print(datetime.datetime.now(datetime.timezone.utc).isoformat())
print((base/'run_progress.log').read_text().splitlines()[-1])
if p.exists():
 print("\n".join(line for line in p.read_text().splitlines() if " exit=" in line or "FIXTURE" in line))
 root=Path('/tmp/taleb_v025_regression_scratch/Taleb_Lean_Repairs/evidence/current')
else:root=Path('/tmp/taleb_v025_audit_project/evidence/current')
if root.exists():
 for f in sorted(root.iterdir(),key=lambda x:x.stat().st_mtime,reverse=True)[:3]:
  print(f.name, f.stat().st_size, 'age_seconds',round(time.time()-f.stat().st_mtime,1))
