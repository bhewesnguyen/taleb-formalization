# v0.2.5 provenance and preservation review

**Assessment: release provenance passes.** The ZIP, main-branch commit, full patch and incremental patch identify exactly the same project tree. No packaging or historical-content discrepancy changes the mathematics assessment. This review did not execute supplied build or release scripts.

## Reproduced identities

| Check | Independent result |
|---|---|
| ZIP SHA-256 | `9e214be3eb53b37721d9bcbc17da5e3aec8ea39dca38760abc4bd20caff56727`, equals the supplied checksum |
| ZIP contents | 186 regular files; no duplicate names, traversal/absolute paths, symlinks, `.lake`, Python bytecode or Lean build outputs |
| `SHA256SUMS` | All 185 entries match; precisely covers the other 185 files |
| Bundled project revision | `579f0d69d77c21e36a4b8bbd288cd57438a688ab` |
| Archive versus bundled revision | All 186 tracked project files match byte for byte; neither extras nor omissions |
| Bundle | `git bundle verify` succeeds and reports complete history |
| Full v0.2.0 to v0.2.5 patch | Exactly the corresponding `git diff`; 134 changed files; applies to `f6b100762540655184b96dd4e0c8f8fd0233da28` and reproduces all 186 packaged files |
| Incremental v0.2.4 to v0.2.5 patch | Exactly the corresponding `git diff`; 43 changed files; applies to `aa484170a40e11a450fbff844f6d5fd4f927f153` and reproduces all 186 packaged files |
| Pins | `lean-toolchain` and `lake-manifest.json` are byte-identical to both v0.2.0 and v0.2.4 |
| Preserved audit manifest | All 12 received-artifact hashes pass |
| Historical baseline archives | v0.2.0: 73 files equal their claimed base commit; v0.2.4: 169 files equal their claimed base commit and known archive hash |

The bundle proves the committed history it supplies and the equality of the packaged snapshot with that history. It does not establish the author's worktree cleanliness or whether a live remote received a push. The updated audit brief states this limitation correctly. A clean audit clone is only evidence about that clone.

## Existing mathematics was preserved

All 24 pre-existing mathematics modules under `AuditRepairs/` and `Proofs/` have identical non-comment text after nested-comment-aware stripping and whitespace normalization. Of those, 23 are also byte-identical. `ExtremeValueBridge.lean` changed docstrings only. `ExtremeValueLaws.lean` is the sole newly added mathematics module, and the root aggregation file adds its import.

This is a bounded lexical comparison, not a Lean AST or semantic equivalence checker. The inspected diff independently confirms that the existing theorem statements, definition bodies and proof bodies were not edited. Runtime verification is assessed separately.

## Prior audit representation note

The preserved v0.2.4 progress Markdown and full audit ZIP match the current audit outputs byte for byte. The preserved standalone v0.2.4 PDF does not byte-match the current standalone PDF or the PDF member of that matching ZIP:

- Preserved standalone: `5407c895a153229f861f8a078831c877c5b73041bbc95963142f9eedca9b31f7`.
- Current standalone and ZIP member: `9c016e079af017a933d88fc0a99fd8bb6381baaef329bb13ba8fcd26beb8af9c`.

The preserved standalone has blank document metadata; the current standalone and ZIP member retain ReportLab metadata. All eight pages have exactly identical extracted text and exactly identical default-resolution rendered pixel buffers. Thus this is a representation discrepancy with no observed content discrepancy. The cause is not established, and this review makes no claim that Fable altered the received audit. The repository manifest correctly hashes the representation it preserves. Evidence: `provenance/previous_pdf_comparison.json`.

## Two minor documentation refinements

1. `docs/AUDIT_HISTORY.md`, row 4 response, still describes only the first T061 child, Gumbel. The current release also contains Fréchet. Update this one summary to mention both constructed laws. The changelog, current review addendum and release brief already describe both correctly.
2. The `minGeEvent` docstring in `ExtremeValueBridge.lean` says the strict and non-strict events differ on `{exists i, X_i = x}` and that probabilities differ by the boundary mass. For exact equality, their difference is `{forall i, x <= X_i} intersect {exists i, X_i = x}`, equivalently `{min_i X_i = x}` when the minimum is defined. The coordinate-equality union contains this boundary but can be larger: at `x = 0`, two constant coordinates `0` and `-1` make that union the whole space while both minimum events are empty. Prefer the boundary of the minimum event itself. This concerns the explanatory docstring, not any theorem statement or proof.

Suggested precise replacement:

> Every coordinate is at least `x`: the minimum is `>= x` (non-strict variant). Its difference from the strict event is the set where all coordinates are at least `x` and at least one equals `x`. For a finite nonempty family, this is `{min_i X_i = x}`. Its probability is zero when each coordinate law assigns zero mass to `{x}`.

These are low-priority wording items and do not justify delaying the next mathematical milestone.

## Evidence

- `provenance/check_provenance.py`: independently clones/checks the bundle and applies both patches in dedicated audit worktrees.
- `provenance/provenance.json`: complete machine-readable identity checks and per-module comparison.
- `provenance/previous_pdf_comparison.json`: prior-PDF metadata, text and pixel comparison.
