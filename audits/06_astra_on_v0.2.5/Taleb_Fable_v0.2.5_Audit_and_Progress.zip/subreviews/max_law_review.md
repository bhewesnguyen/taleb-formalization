# v0.2.5 review: instantiated maximum laws and T061 scope

## Judgment

The two delivered T061 children are mathematically complete within their stated standardized scope. Gumbel and Fréchet are constructed as probability measures, their CDFs equal the intended global formulas, and the maximum laws are instantiated for those actual measures. The product-space theorems also supply a concrete iid realization for every finite nonempty index type. No mathematical repair to these new declarations is indicated by this source review.

This review is a statement and proof-structure audit. Independent compiler, axiom-closure and regression results belong to the runtime audit and are not claimed here.

The remaining T061 obligations, reverse-Weibull and positive location/scale transformations for all three families, are correctly left open. No second whole-family discharge follows from this release.

## Exact delivered statements

Write `n = Fintype.card ι`, with `[Fintype ι] [Nonempty ι]`, so `n > 0`. Write `M = AuditExtremes.maxRV X`.

| Declaration | Delivered content | Important hypotheses |
|---|---|---|
| `AuditEVTLaws.cdf_map_maxRV_gumbel` | `cdf (P.map M) x = gumbelCDF (x - log n)` for every real `x` | Probability measure `P`; mutually independent measurable coordinates; each coordinate has pushforward law `gumbelMeasure` |
| `AuditEVTLaws.cdf_map_maxRV_frechet` | `cdf (P.map M) x = frechetCDF ξ (n^(-ξ) * x)` for every real `x` | The same ordinary hypotheses; `0 < ξ`; common law `frechetMeasure ξ hξ` |
| `AuditEVTLaws.cdf_map_maxRV_pi_gumbel` | The Gumbel maximum identity on the explicit product space `ι → ℝ`, under `Measure.pi (fun _ => gumbelMeasure)` | Only the finite nonempty index type and evaluation point |
| `AuditEVTLaws.cdf_map_maxRV_pi_frechet` | The Fréchet maximum identity on the analogous explicit product space | Finite nonempty index type, `0 < ξ`, and evaluation point |

These statements are global in the evaluation point. In particular, the Fréchet result includes the support boundary and negative arguments. It does not restrict the theorem to `x > 0` or use the raw real-power formula outside its support.

The sign and scaling are correct:

- For `G(x) = exp(-exp(-x))`, `G(x)^n = G(x - log n)`. The maximum therefore has the distribution of a standard Gumbel variable shifted **up** by `log n`.
- For `Fξ(x) = exp(-x^(-1/ξ))` on `x > 0`, with zero elsewhere, `Fξ(x)^n = Fξ(n^(-ξ) x)`. The maximum therefore has the distribution of a standard Fréchet variable multiplied by `n^ξ`.
- The CDF argument scaling and the random-variable scaling are reciprocals. The release uses the correct CDF argument `n^(-ξ) * x`.
- `n = 0` is correctly excluded from real-valued maxima and from the formula identities. For `n = 1` the formulas reduce to the original CDFs.

The new maximum theorems conclude CDF identities for an actual pushforward probability measure. They do not yet state a separately named equality between that measure and an affine pushforward of the standardized law. This is sufficient for these children and accurately described in the current scope. The planned affine CDF rules will make the corresponding measure-equality wrappers straightforward via the pinned `Measure.eq_of_cdf`. Such wrappers are useful for composition but are not a reason to reject the present maximum-CDF theorems.

## Why the instantiation is substantive

The preceding `AuditExtremes.cdf_map_maxRV` does not assume its desired conclusion. It derives the maximum's CDF from mutual independence, coordinate measurability and equality of the coordinate pushforward laws. It establishes the probability instance for the common law from a coordinate, establishes it for the maximum from measurability, unfolds the CDF as the real mass of `Iic x`, identifies the inverse image of this interval as the simultaneous threshold event, and applies the independent product formula. No atomlessness premise is required.

Each new arbitrary-space specialization then rewrites that generic law using the constructed law's exact CDF identity and the earlier analytic max-stability identity. The previously unresolved premise that a probability law with this CDF exists is now discharged. Ordinary independence, common-law and measurability hypotheses remain explicit and appropriate.

The product specializations remove any possible concern that the ordinary hypotheses are unsatisfiable:

1. The probability space is explicitly `ι → ℝ` with the finite product of the constructed measures.
2. The random variables are the coordinate evaluations `ω ↦ ω i`.
3. Measurability is `measurable_pi_apply i`.
4. Mutual independence is the pinned Mathlib `iIndepFun_pi`, applied to measurable identity functions on the component spaces.
5. Each coordinate has exactly the required law by `(measurePreserving_eval _ i).map_eq`.

Pinned API signatures were inspected in `Mathlib/Probability/Independence/Basic.lean` and `Mathlib/MeasureTheory/Constructions/Pi.lean`. Both use probability measures on the component spaces; the new Gumbel and Fréchet probability instances provide those hypotheses. The construction is neither an existential axiom nor an assumption that iid coordinates already exist. Choosing `ι = Fin n` for any positive `n` gives the advertised finite sample size.

The word "constructed" here denotes a mathematical probability measure in Lean. It does not assert an executable numerical sampler, which is outside this milestone.

## CDF construction check

The Stieltjes route is appropriate and economical. It avoids an unnecessary density integral and matches the pinned Mathlib CDF API.

- Gumbel monotonicity, continuity and endpoint limits provide a Stieltjes function with limits zero and one. `gumbelMeasure_isProbabilityMeasure` and `cdf_gumbelMeasure_apply` then follow directly from the established Mathlib construction.
- Fréchet uses the global piecewise CDF, zero on `x ≤ 0`. Monotonicity is proved separately across the support split. The right-continuity proof explicitly handles negative points, zero, and positive points.
- At zero the exponent coefficient `-1 / ξ` is strictly negative. As `x → 0+`, `log x → -∞`, hence `(-1 / ξ) * log x → +∞`; the inner exponential diverges, its negative tends to `-∞`, and the outer exponential tends to zero. This is the correct boundary behavior and avoids Lean's totalized `0 ^ negative` trap.
- At positive infinity the negative real power tends to zero, giving CDF limit one. At negative infinity the function is eventually identically zero.

The maximum-law proofs are short applications of the general law theorem and the established analytic identities. No simplification or abstraction rewrite is needed for correctness or readability at this stage.

## Source and scope

The local book source was checked at PDF pages 186 and 187, printed pages 172 and 173. Equation (9.1), the iid maximum law, is on printed page 172. The three named EVT forms are on page 173. The Gumbel and Fréchet constructions match those forms at location zero and scale one, with `ξ = 1/α > 0` for Fréchet.

The source's reverse-Weibull family has a finite upper endpoint, CDF one at and above that endpoint, and positive shape parameter `α`. The next implementation must retain that support convention. The standardization chosen in v0.2.5 is faithful to the separately displayed family formulas; it is not claiming a full unified GEV parameterization or a classification/domain-of-attraction theorem.

Two low-priority documentation observations remain:

1. **The new `law_theorem` facet also applies to the constructed Gumbel and Fréchet maximum slices.** T061 currently retains `conditional_law_theorem` for its historical results and adds `actual_law_constructed`, but omits `law_theorem`. Because facets are expressly nonexclusive and scoped, adding that facet would accurately credit the new arbitrary-space theorems without changing `partial`. The delivery-scope prose already describes the substance correctly. This is an understatement, not an invalid completion claim.
2. **The repaired threshold-boundary prose is still imprecise.** `ExtremeValueBridge.lean` says the strict and non-strict minimum events differ on `{∃ i, Xᵢ = x}` and that their probabilities differ by that boundary mass. The union event is only a containing event. If interpreted as the exact probability difference, the wording is false. The same issue appears in the review narrative. The Lean event identities are unaffected.

For finite nonempty coordinates the exact differences are

```text
minGeEvent X x \ minGtEvent X x
  = {ω | (∀ i, x ≤ X i ω) ∧ (∃ i, X i ω = x)}
  = {ω | minRV X ω = x}

maxLeEvent X x \ maxLtEvent X x
  = {ω | (∀ i, X i ω ≤ x) ∧ (∃ i, X i ω = x)}
  = {ω | maxRV X ω = x}.
```

Their real probability differences are the masses of these respective extrema-level boundary events. For example, deterministic coordinates `(0, -1)` at threshold zero make `{some coordinate = 0}` have probability one, but both minimum events are false, so their probability difference is zero. The union event is therefore not the exact boundary mass. For finitely many atomless coordinate laws the containing union is null, which does imply equality of the strict and non-strict probabilities. No atomlessness is needed for the generic T060 law theorem itself.

Suggested concise replacement: "The difference is the event that the minimum equals the threshold. This event is contained in the union of the coordinate equality events and has zero mass when the finitely many coordinate laws are atomless."

## Acceptance criteria for the next T061 milestone

The proposed next order is sound. Keep the gate within the recorded family scope:

1. Define the standard reverse-Weibull CDF for `α > 0` as `exp(-(-x)^α)` when `x < 0`, and `1` when `x ≥ 0`. Prove monotonicity, right-continuity, endpoint limits zero and one, a probability measure, and its exact global CDF identity. The value and continuity limit at the upper endpoint zero are **one**.
2. Prove or instantiate `Rα(x)^n = Rα(n^(1/α) * x)` for positive `n`, including both support branches, and connect it to the general maximum theorem. The corresponding random-variable scaling is `n^(-1/α)`, not `n^(1/α)`.
3. For each of the three laws, construct the pushforward by `z ↦ μ + σ * z`, for arbitrary real location and strictly positive scale. Establish probability and the global rule `cdf (ν.map affine) x = cdf ν ((x - μ) / σ)`. A reusable affine-CDF lemma can serve all three laws.
4. State the support consequences correctly: Fréchet CDF zero at and below `μ`; reverse-Weibull CDF one at and above `μ`; Gumbel on all of `ℝ`. Include the correct parameter assumptions in each theorem.
5. Confirm the source correspondence, clean build and allowed axiom closure, and update T061's declaration list, scope and remaining obligations before discharging the family.

Optional compositional corollaries can identify maximum measures with affine transforms of the standardized laws. For iid input laws with location `μ` and scale `σ`, the maximum has location and scale `(μ + σ * log n, σ)` for Gumbel, `(μ, σ * n^ξ)` for Fréchet, and `(μ, σ * n^(-1/α))` for reverse-Weibull. These formulas provide useful sign checks and follow from the CDF transformations and the appropriate max-stability identity.

Do not add density formulas, asymptotic maximum-domain-of-attraction results, the Fisher-Tippett-Gnedenko classification, or a unified GEV shape-limit theorem as new closure conditions for this scoped T061 family. They are distinct work. The planned later T029 nonnegative-sum squeeze and exact Pareto slice remain sensible and independent next stages.
