# v0.2.5 verifier and regression harness review

Scope: static review of the received `scripts/verify.py`, `scripts/FableInventory.lean`, `scripts/harness_regression.py`, the ledger generator, and verifier-related audit responses. Independent bounded Python probes ran against immutable source and temporary copies. This review does not claim a Lean run; the separate runtime reproduction owns the clean build, full verifier and sequential regression results.

## Assessment

The H1 and H2 repairs are correctly implemented. The all-constant trust scan, alias-target comparison, recursive module coverage, public inventory reconciliation, dependency cleanliness and sequential fixture restoration remain intact. No new Lean trust-check defect was established.

The new ledger gate is a useful improvement. It validates enumerated statuses and states, consistency between the discharged status and state, joint presence of delivery metadata, the 158-row count, and declaration-name existence. It is not yet a complete structural schema validator: a duplicated family ID, a contradictory redundant `discharged` Boolean and a wrongly typed scope field can pass. This is a low-priority ledger-integrity limitation. The delivered ledger does not contain these defects, and none bypasses Lean's proof or axiom checks.

## H1: closed

At `harness_regression.py:144-151`, the requested comma-separated fixture IDs are stripped, empty elements are rejected, and unknown IDs are checked against the fixture registry before output or scratch directories are created. Explicit `--only ''` is distinguished from the omitted option. The summary at line 213 also requires `bool(results)`, so an empty result list cannot be successful.

Independent subprocess probes used the unchanged received runner with unknown, mixed known/unknown, empty and empty-element selections. All four exited 2, and neither the requested scratch directory nor output directory existed afterward. Evidence is in `verifier_probe/python_probe_results.json`. No Lean command was reached by these probes.

## H2: closed in implementation; full runtime coverage recorded separately

`harness_regression.py:152,155` resolves both the output path and an explicitly supplied scratch path to absolute paths. All derived snapshot and copied-project paths therefore remain stable when the runner changes subprocess working directories. The default temporary directory behavior is unchanged.

The independent runtime reviewer is running the full unchanged suite with genuinely relative `--scratch` and `--out` arguments, covering this behavior through real build restoration. Consult that reproduction's final result rather than treating a Python stub as an independent Lean execution. The received Fable evidence also contains a successful relative-path valid-only fixture; that is author-supplied evidence, not a new auditor run.

## Prior trust gates and isolation remain intact

`FableInventory.lean` is byte-identical to v0.2.4. Every project-attributed constant has its axiom closure collected before internal/generated filtering. `verify.py:110-119` continues to reject extra axioms, project axiom declarations, unimported project modules, public inventory differences and mismatched alias targets. All acceptance gates use ordinary `check(...)` calls, so Python optimization does not remove them.

Recursive discovery still traverses `AuditRepairs` and module coverage still traverses `AuditRepairs` and `Proofs`. These are explicitly scoped project roots, not an assertion about arbitrary Lean files elsewhere in an archive. The runner's source snapshot restoration, deletion/restoration of `.lake/build`, and pristine source hash check before each mutation are unchanged. Its 12 fixtures, including nested coverage, private/internal axioms and optimized alias rejection, are unchanged.

## V025-L1: low-priority ledger identity and field-consistency gap

Location: `verify.py:123-138`, especially the row-count-only identity check at line 135 and truthiness checks at lines 128-133.

The following mutations were independently exercised through the unchanged `verify.main` control flow in a temporary project copy. All external command outputs were deliberately replayed from the received clean records; these tests isolate Python validation behavior and do not rerun or establish Lean correctness.

| Mutation | Actual validator behavior | Consequence |
|---|---|---|
| Replace the T003 row with a copy of T002, leaving 158 rows | PASS, `backlog_schema_valid: true`, `backlog_families: 158` | Only 157 distinct family IDs remain and one obligation family is silently omitted. |
| Change T060's redundant `discharged` field to `false`, keeping its status and state discharged | PASS, schema reported valid | Two machine-readable representations of completion disagree. |
| Change T001's `delivery_scope` from a string to `123` | PASS, schema reported valid | Truthiness does not enforce the intended field type. |

The valid baseline passed. Unknown status, unknown state, missing scope, disagreement between discharged status and state, and a nonexistent cited declaration were each rejected for the expected reason. Thus the defect is limited to missing mechanical integrity checks, not a failure of the checks actually implemented.

Suggested small follow-up: share a single `validate_backlog(rows)` function between the generator and verifier. Require unique IDs and the expected ID set for this ledger revision, correctly typed status/state/declaration/scope fields, and equality of the `discharged` Boolean with the status/state representation. Preserve semantic target fulfillment as a human review responsibility. The existing `completion` prose should not be treated as a mechanically certified theorem claim. Use lightweight Python tests for these conditions; no additional Lean mutation run is needed to establish a JSON validation rule.

This does not invalidate the current 158-family tally. The received ledger has 158 unique IDs and the expected fields agree. There is no need to block T061 work on this hardening.

## Documentation response assessment

- The verifier header now accurately describes recursive public discovery without a stale fixed declaration count.
- `docs/AUDIT_HISTORY.md` correctly distinguishes reproduced findings from the preventive R1 repair. The still-present sentence that all findings were reproduced in FABLE_REVIEW section 12 refers specifically to the earlier v0.2.1 audit; it is not a renewed claim that R1 was reproduced.
- The bundle wording correctly limits the evidence to committed history and archive correspondence, without claiming proof of original worktree cleanliness or remote push state.
- The schema report now distinguishes family/declaration citation pairs from distinct declaration names. The received records and ledger give 83 pairs over 82 distinct names; the shared Gaussian identification accounts for the difference.
- Small residual wording correction in `FABLE_REVIEW.md:524-526`: the strict/non-strict maximum probability difference is the mass of `{maxRV X = x}`, and the minimum counterpart is the mass of `{minRV X = x}`. Each event is contained in `{there exists i, X_i = x}`; the latter union need not be the exact difference. For two independent fair Bernoulli coordinates at x = 0, the maximum probability difference is 1/4 but the union of coordinate equality events has probability 3/4. Suggested wording: "The differences are the boundary events `{maxRV X = x}` and `{minRV X = x}`. Each is contained in `{there exists i, X_i = x}`, so the differences vanish for atomless coordinate laws." The Lean statements already use the correct threshold events and need no repair.

## Reproducible Python evidence

Run from any directory:

```bash
python3 check_verifier_python.py --project /absolute/path/to/Taleb_Lean_Repairs --out /absolute/path/to/python_probe_results.json
```

The helper stages temporary copies, hashes the original tree before and after, and never invokes Lean. Four early CLI rejection probes and nine validator replay cases matched the stated observations. The original tree was unchanged. An overall successful probe exit means the observed behaviors were reproduced, including the documented low-priority acceptance gaps; it does not mean every malformed ledger was rejected.
