# Independent static ledger review of v0.2.5

Static semantic review of the shipped ledger and Lean source, comparison with v0.2.4, recomputed counts and cross-check of supplied environment inventory. Compilation and independent source-page checks are separate root-audit tasks.

## Verdict

Keep all eleven supported family statuses. T060 remains correctly discharged; the other ten remain partial. The new work completes the standard Gumbel and Frechet measure children of T061, including exact CDF identifications and genuine iid maximum models. This is substantial mathematical progress with no new parent-family closure.

The previous scope ambiguities are repaired: T060 now has a law_theorem facet; every supported row has a delivery_scope and remaining_obligations; T047 and T118 explicitly receive prerequisite-only credit. No original target, hypothesis, priority, source locator or status changed in any of the 158 rows. The clarification does not shrink the agreed completion scope.

## Exact counts

| Status | Families |
|---|---:|
| discharged | 1 |
| partial | 10 |
| reuse | 4 |
| missing | 91 |
| source-check | 34 |
| model-needed | 15 |
| empirical | 3 |
| Total | 158 |

There are 140 formal-proof families and 18 model/empirical families. The status distribution is unchanged from v0.2.4. This curated family register is not an exhaustive census of atomic book theorems, and unequal family sizes make a percentage-of-effort estimate misleading.

The eleven supported rows cite 83 distinct (family, declaration) pairs and 82 distinct declarations, up from 71/70. The shared declaration is AuditGaussian.charFun_gaussianReal_eq_stableS1Expr, legitimately credited to both T007 and T046. All 82 names occur in the supplied environment inventory; the root execution audit separately verifies the current Lean environment.

Nonexclusive facets: formula_proved 8; conditional_law_theorem 3; law_theorem 1; actual_law_constructed 3; source_reviewed 7; discharged 1. These are scoped descriptive facets, not stages or independent completed items. A constructed-law count of 3 means three ledger families contain realization credit, not only three concrete measures or three fully completed families.

## Supported families

### T001: Regular variation API

Recorded and audited status: **partial**. Assessment: accurate.

Ratio-only regular/slow variation API, examples and closure rules. The negative-constant diagnostic explicitly separates this from the positive measurable convention.

Retain partial. Positivity/measurability remain; Karamata, uniform convergence and Potter bounds belong to other recorded families.

Remaining recorded obligations: Positive measurable convention and its relationship to the ratio predicates. Uniform convergence, Potter bounds and Karamata are T026, T027 and T002.

### T007: Stable law existence

Recorded and audited status: **partial**. Assessment: accurate.

Gaussian realization of the S1 expression at alpha = 2, including zero scale, by reusing Mathlib's actual Gaussian law.

Retain partial. No alpha < 2 existence theorem is delivered; reuse is correctly disclosed.

Remaining recorded obligations: Existence of a probability law with the S1 characteristic function for every 0 < alpha < 2, including alpha = 1 with beta != 0, and the zero-scale Dirac case for those alpha.

### T008: Subexponential law API

Recorded and audited status: **partial**. Assessment: accurate.

A probability-level subexponential predicate and preservation of an assumed finite log-tail exponent under self-convolution.

Retain partial. Concrete examples, the n-fold characterization and standard-definition equivalences remain. The revised conditional-law legend now covers these property premises.

Remaining recorded obligations: Any concrete subexponential law, the equivalent n-fold tail characterizations, equivalence with the standard definition, and whether subexponential laws must have a finite exponent.

### T029: Tail of sums with unequal indices

Recorded and audited status: **partial**. Assessment: accurate.

Finite log-tail exponent of a sum of two positive power-tail formulas, with exponent equal to the minimum of the two exponents.

Retain partial. The random-variable nonnegative weighted-sum squeeze remains. Keep exact convolution asymptotics distinct.

Remaining recorded obligations: Finite log tail exponent of nonnegative weighted sums via event inclusions and a squeeze lemma (no independence needed). Exact convolution asymptotics belong to the subexponential workstream.

### T032: Power transformation of a law

Recorded and audited status: **partial**. Assessment: accurate.

Analytic power-composition tail exponent alpha/p, without a pushforward-law identification.

Retain partial. Measurability, the inverse event and actual transformed law remain.

Remaining recorded obligations: Measurable pushforward under x -> x^p for nonnegative x and p > 0, the inverse-event identity and identification of the transformed law.

### T046: Stable characteristic function specializations

Recorded and audited status: **partial**. Assessment: accurate.

Gaussian law and instantiated stable convolution bridge; Cauchy expression specialization remains formula-level.

Retain partial. A Cauchy law/characteristic-function identification is still required.

Remaining recorded obligations: A Cauchy probability law with its characteristic function (none in the pinned Mathlib), nonnegative scale including Dirac, and its instantiation of the bridge.

### T047: Stable sample averages

Recorded and audited status: **partial**. Assessment: accurate prerequisite only.

Conditional stable sum/convolution infrastructure only, now explicitly labeled prerequisite only.

Retain partial. Sample-average pushforwards, the n^(1/alpha-1) scale, alpha = 1 skew-location correction and finite-mean convergence remain.

Remaining recorded obligations: Pushforward under division by n, the average scale n^(1/alpha - 1), the alpha = 1 skew-location correction under rescaling, and finite-mean convergence.

### T060: Distribution of iid maxima

Recorded and audited status: **discharged**. Assessment: discharge accepted.

Actual measurable maximum/minimum laws for independent coordinates with a common law on a finite nonempty index type, plus all four event threshold conventions.

Retain discharged. The new law_theorem facet correctly records the probability-law level. No named EVT construction is required for this family's unchanged target.

Remaining recorded obligations: None within the family. Named EVT laws are T061, the density derivative and domains of attraction are T062/T011.

### T061: GEV families as probability measures

Recorded and audited status: **partial**. Assessment: accurate partial with two completed children.

Standard Gumbel and positive-shape Frechet probability measures constructed via Stieltjes functions, exact global CDF identities, maximum-CDF theorems for these laws and explicit finite-product iid realizations.

Retain partial. Reverse-Weibull and positive-scale affine pushforwards for all three families remain. Optionally add law_theorem for the new realized-law maximum results; omission is conservative.

Remaining recorded obligations: Reverse-Weibull measure with the correct upper endpoint and shape convention, location/scale pushforwards x -> mu + sigma x with sigma > 0 for all three families and their cdf transformation rules. Do not close before all three named families and the location/scale scope are done.

### T118: Moment convexity in Pareto exponent

Recorded and audited status: **partial**. Assessment: accurate prerequisite only.

Convexity of alpha -> c^(-alpha) only, now explicitly separated from the Pareto moment formula, its convexity and Jensen.

Retain partial under the ledger's prerequisite-credit convention. The actual moment-convexity target is still open; p > 0 and positive scale are already recorded in the hypotheses.

Remaining recorded obligations: Identify E[X^p] = scale^p alpha/(alpha - p) for alpha > p, prove its convexity in alpha, and justify Jensen with the mixing support and integrability assumptions.

### T124: Shifted-gamma index mean

Recorded and audited status: **partial**. Assessment: accurate.

Corrected rational gamma-mixture excess expression and positivity, purely algebraic.

Retain partial. The gamma inverse moment, finiteness threshold and mixture expectation identity remain.

Remaining recorded obligations: The inverse moment of the gamma law, its finiteness threshold, and the mixture expectation identity that produces the formula.

## T061 scope and next acceptance boundaries

The two new standard laws are genuine measures with probability instances. Gumbel uses the continuous global CDF exp(-exp(-x)); Frechet uses zero on x <= 0 and exp(-x^(-1/xi)) for x > 0, xi > 0. The right-continuity proof explicitly treats the support boundary, and the CDF identities hold at every real threshold. The maximum statements assume actual common laws, not unresolved all-x CDF-existence hypotheses. The product-space theorems exhibit those models for every finite nonempty index type. No remaining existence premise makes these children vacuous.

The current result is explicitly a CDF identity. Equality with the affine image of the named measure can be added naturally with the planned pushforward CDF rules and measure uniqueness. This is a useful completion of the recorded location/scale work, not a reason to deny the current standardized measure children or reopen T060.

The next order in section 15.5 is sound: reverse-Weibull, then the positive-scale affine families, then T029's nonnegative-sum exponent squeeze, then exact Pareto work. For reverse-Weibull, record alpha > 0 and use G(x) = exp(-(-x)^alpha) on x < 0 and G(x) = 1 on x >= 0. Establish monotonicity, right continuity, endpoint limits, a probability measure and its global CDF identity. The stated maximum identity G(x)^n = G(n^(1/alpha) x) has the correct sign and direction for n > 0, including the endpoint branch.

For each named family, define the law under x -> mu + sigma*x with sigma > 0 and prove its probability instance and all-real CDF rule F((x-mu)/sigma). The existing Gumbel/Frechet maximum identities and the new reverse-Weibull identity then connect to the transformed laws. Keep shape conventions and support thresholds explicit. No density formula, domain-of-attraction theorem or asymptotic limit theorem should silently become an extra T061 gate; those are separate backlog families.

Do not close T061 after only the first two laws, or after reverse-Weibull without the recorded affine scope. Stable child identifiers would make later progress easier to track, but their absence does not invalidate this milestone. This audit records two completed named-law children and the remaining children explicitly without inventing a percentage of T061 effort.

## Verification schema and documentation

The runtime verifier now enforces the stated status/state vocabularies, discharged status versus facet, co-presence of states/declarations/scope/remaining fields and 158 rows; it also checks cited declaration names in the environment. This is the requested structural improvement. It still cannot infer semantic fulfillment of a mathematical target from a name or tag, and its scope disclaimer correctly reserves book coverage for review. This assessment does not treat verifier PASS as automatic certification of family completion.

The current README, FABLE_REVIEW section 15, CHANGELOG and ledger distinguish constructed laws from open reverse-Weibull/affine scope and avoid the former assumption-free reading of 'unconditional'. T047 and T118 now state the actual prerequisite slice. The T008 definition of conditional_law_theorem now explicitly allows unresolved property premises such as subexponentiality and a finite exponent.

Low-priority finding L1: REPLACEMENT_MAP rows 10 and 11, in both Markdown and JSON, append the correct v0.2.5 results but leave earlier present-tense phrases that CDF realization or measure construction remains open. Mark those older clauses as historical or replace them. This is local documentation drift; the current authoritative delivery scopes are accurate and the mathematical milestone is unaffected.

Optional conservative understatement: T061 also qualifies for law_theorem through cdf_map_maxRV_gumbel and cdf_map_maxRV_frechet, whose premises concern existing laws under ordinary independence/measurability/common-law assumptions. Adding that facet would be justified. Retaining conditional_law_theorem is also correct because its older conditional results remain part of the cited scoped delivery.

## Dependency-group totals

| Group | Total | Discharged | Partial | Reuse | Missing | Source-check | Model | Empirical |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| APP | 8 | 0 | 0 | 0 | 0 | 0 | 5 | 3 |
| CALC | 4 | 0 | 1 | 0 | 3 | 0 | 0 | 0 |
| CDF | 5 | 1 | 0 | 0 | 3 | 1 | 0 | 0 |
| CF | 5 | 0 | 3 | 0 | 1 | 1 | 0 | 0 |
| CLT | 8 | 0 | 0 | 0 | 6 | 2 | 0 | 0 |
| DENS | 8 | 0 | 0 | 0 | 7 | 1 | 0 | 0 |
| ENT | 10 | 0 | 0 | 0 | 8 | 2 | 0 | 0 |
| EST | 13 | 0 | 0 | 0 | 6 | 3 | 4 | 0 |
| EVT | 4 | 0 | 1 | 0 | 2 | 1 | 0 | 0 |
| FIN | 14 | 0 | 0 | 0 | 5 | 4 | 5 | 0 |
| GAMMA | 2 | 0 | 1 | 0 | 0 | 1 | 0 | 0 |
| GINI | 10 | 0 | 0 | 0 | 6 | 4 | 0 | 0 |
| KAPPA | 8 | 0 | 0 | 0 | 6 | 2 | 0 | 0 |
| LLN | 3 | 0 | 0 | 2 | 1 | 0 | 0 | 0 |
| MOM | 19 | 0 | 0 | 2 | 14 | 3 | 0 | 0 |
| MULTI | 4 | 0 | 0 | 0 | 3 | 0 | 1 | 0 |
| QUANT | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| RUIN | 3 | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| RV | 8 | 0 | 1 | 0 | 5 | 2 | 0 | 0 |
| SDE | 5 | 0 | 0 | 0 | 4 | 1 | 0 | 0 |
| SUBEXP | 5 | 0 | 2 | 0 | 2 | 1 | 0 | 0 |
| TAIL | 11 | 0 | 1 | 0 | 5 | 5 | 0 | 0 |

Review limitation: all 158 rows were tallied and compared for scope changes. Semantic review concentrated on the eleven Lean-supported families and the announced next tasks. This is not a new page-by-page audit of every unimplemented family, an upstream Mathlib novelty/merge assessment, or a review of the separate quantum/classical executable software.
