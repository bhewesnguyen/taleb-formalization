# Mathematical review of v0.2.5: Gumbel and Frechet laws

## Verdict and review bounds

Accept the mathematical content of the two delivered T061 children. I found no false statement, missing necessary hypothesis, circular construction, or scope substitution in `AuditRepairs/ExtremeValueLaws.lean`. Its 20 theorems, two probability instances and four definitions genuinely promote the previously verified formulas to probability measures with the claimed global distribution functions. The four maximum-law corollaries then use those measures.

This is a source-level mathematical review. Independent Lean execution and trust verification are handled separately by the runtime reviewer. The review used the received v0.2.5 source, the pre-existing `Tails.lean` and `ExtremeValueBridge.lean` dependency statements, and the exact pinned Mathlib APIs available in the previous runtime. It does not assert novelty against current upstream Mathlib.

The source anchor was checked directly against the locally recovered book PDF: printed page 173, PDF page 187. Its Gumbel form is `exp(-exp(-(x-b_n)/a_n))`; its Frechet form is zero for `x <= b_n` and `exp(-((x-b_n)/a_n)^(-alpha))` above that boundary, with `alpha > 0` and `xi = 1/alpha`. Setting `b_n = 0` and `a_n = 1` gives the implemented forms exactly.

## Construction and theorem review

Line references below identify `AuditRepairs/ExtremeValueLaws.lean` in the unmodified received archive.

| Declaration or group | Lines | Assessment |
|---|---:|---|
| `gumbelCDF_monotone` | 40-43 | Correct. Negation reverses order twice around the inner increasing exponential, and the outer exponential preserves it. |
| `continuous_gumbelCDF` | 45-47 | Correct global continuity, discharged by the compositional continuity tactic. |
| `gumbelCDF_tendsto_atBot` | 49-53 | Correct successive limits: `-x` tends to positive infinity, `exp(-x)` tends to positive infinity, its negative tends to negative infinity, and the final exponential tends to zero. |
| `gumbelCDF_tendsto_atTop` | 55-61 | Correct: the inner exponential tends to zero, and continuity of the outer exponential gives one. |
| `gumbelStieltjes`, `gumbelMeasure` | 64-70 | A genuine monotone right-continuous bundled function, followed by the existing Lebesgue-Stieltjes measure construction. No probability assumption is smuggled into the definition. |
| `gumbelMeasure_isProbabilityMeasure` | 72-73 | The endpoint limits supply total mass one via Mathlib's Stieltjes theorem. This is a proved instance, not an assumption or a declaration of a new axiom. |
| `cdf_gumbelMeasure`, `cdf_gumbelMeasure_apply` | 75-81 | Exact bundled and pointwise CDF identities, respectively. The normalization and zero lower endpoint are precisely the hypotheses of `cdf_measure_stieltjesFunction`. |
| `cdf_map_maxRV_gumbel` | 86-93 | Correct probability-law theorem under ordinary measurability, mutual independence and common-law hypotheses. The sign `x - log n` is correct: the maximum shifts to the right by `log n`. |
| `cdf_map_maxRV_pi_gumbel` | 98-103 | Supplies a concrete product probability space, coordinate maps, independence and common laws. The resulting maximum CDF no longer assumes the existence of suitable coordinates. |
| `frechetCDF_of_pos`, `frechetCDF_of_nonpos` | 111-116 | Correct support split. The nonpositive branch is zero, including the exact endpoint zero. |
| `frechetCDF_nonneg` | 118-122 | Correct for every real shape argument; only positivity of the exponential is required. It does not improperly claim a probability measure for invalid shapes. |
| `neg_one_div_nonpos` | 124-126 | Correct helper under the strictly positive shape assumption. |
| `frechetCDF_monotone` | 128-136 | Correct. On positive arguments, the negative real exponent reverses the base order, negation reverses it back, and the exponential preserves order. When the first argument is nonpositive, nonnegativity suffices. |
| `frechetCDF_continuousWithinAt_Ici` | 140-173 | Correct right-continuity proof at every point, with a substantive, nonvacuous proof at the support endpoint; detailed below. |
| `frechetCDF_tendsto_atBot` | 175-179 | Correct eventual-zero proof. This needs no positivity restriction on the shape because the support branch is independent of it. |
| `frechetCDF_tendsto_atTop` | 181-191 | Correct for positive shape. The exponent is strictly negative, so the power tends to zero and the CDF tends to one. |
| `frechetStieltjes`, `frechetMeasure` | 194-200 | Genuine Stieltjes construction under `0 < xi`. The proof argument does not create distinct laws depending on which positivity proof is supplied, because Lean proof irrelevance identifies those arguments. |
| `frechetMeasure_isProbabilityMeasure` | 202-204 | Correct normalization from the two endpoint limits. |
| `cdf_frechetMeasure`, `cdf_frechetMeasure_apply` | 206-214 | Exact global CDF identities, including zero and all negative thresholds. These refer to the support-correct CDF, not the analytically convenient but invalid-at-zero raw formula. |
| `cdf_map_maxRV_frechet` | 219-226 | Correct: `F(x)^n = F(n^(-xi) * x)`, so the maximum has the same law as a base variable scaled by `n^xi`. The result is global in the threshold, not limited to positive thresholds. |
| `cdf_map_maxRV_pi_frechet` | 229-234 | A concrete product-space realization with the constructed Frechet measure. It supplies all independence, measurability and common-law premises through established Mathlib results. |

## The Frechet support boundary is handled correctly

The delicate point is zero, where Lean's total real power convention would make the unguarded analytic expression have the wrong value. The received source avoids that mistake in both the definition and proof.

At negative points, the function is locally constant zero. At positive points, it is locally the smooth real-power expression. At zero, lines 148-165 split the `Ici 0` neighborhood into the endpoint itself and the right-hand neighborhood `Ioi 0`. The endpoint branch establishes the actual value zero. The right-hand branch uses positive arguments only, where the identity `x^(-1/xi) = exp((-1/xi) * log x)` is valid. Since `xi > 0`, multiplying the logarithm's negative-infinity limit by the strictly negative coefficient gives positive infinity. Negating the resulting exponential gives negative infinity; the outer exponential therefore tends to zero.

This proves exactly the right-continuity required by `StieltjesFunction`. A separate theorem of full continuity or atomlessness would be useful to some future applications, but is not needed for this milestone and should not be added as a new acceptance condition.

## Measures, probability semantics, and nonvacuity

The local pinned API checks matter here. `StieltjesFunction` consists of a real function, monotonicity and right-continuity on `Ici x`. Its `isProbabilityMeasure` result requires the limits zero at negative infinity and one at positive infinity. `cdf_measure_stieltjesFunction` uses those same endpoint conditions to identify the measure's CDF with the original function. The supplied proofs match these requirements exactly.

The generic maximum theorem inherited from v0.2.4 proves measurability of the finite maximum and gives its pushforward the probability-measure instance before using `cdf_eq_real`. Thus these CDF conclusions have their ordinary measure-theoretic meaning, rather than relying on the CDF operation's behavior on a non-probability input.

Both product-space results are for finite **nonempty** index types. For every integer `n > 0`, instantiate the index type by `Fin n`. The zero-sample case is deliberately excluded because an empty maximum is not a real-valued maximum. Fable's abbreviated phrase "every finite n" should be read with this positive-size restriction, already stated in the source and review.

`Measure.pi`, `iIndepFun_pi` applied to the identity functions, `measurable_pi_apply`, and `measurePreserving_eval` provide an explicit mathematical realization. No hypothesis asserts the desired CDF of the maximum, and no contradictory existence premise remains. An additional existential wrapper would change only the presentation, not the established existence content.

These are noncomputable mathematical measures and theorem-level realizations. They do not supply numerical random samplers or an executable statistics package; no such software claim is made by the Lean results.

## Scope and next milestone

T061 should remain **partial**. The newly delivered scope is standard Gumbel, standard Frechet with positive extreme-value index, exact CDF identities, instantiated maximum laws, and finite nonempty iid product realizations. The source and current addendum correctly leave reverse-Weibull and positive location/scale transformations open. There is no new domain-of-attraction theorem, density formula, moment formula, or generalized extreme-value limit theorem in this increment.

The proposed next reverse-Weibull target is correct: for `alpha > 0`, use `exp(-(-x)^alpha)` for `x < 0` and one for `x >= 0`. Its standard maximum identity has the factor `n^(1/alpha)` **inside** the CDF. After constructing that measure, a reusable affine pushforward theorem for an arbitrary real probability measure,

`cdf (nu.map (fun y => mu + sigma * y)) x = cdf nu ((x - mu) / sigma)` for `sigma > 0`,

can support all three location/scale wrappers. This avoids three copies of the same measure-preimage argument and preserves the correct Frechet lower and reverse-Weibull upper endpoints.

The new source's scoped wording is good: the CDF-realization premise is discharged, while ordinary hypotheses on arbitrary collections of random variables remain. The product-space corollaries supply the corresponding explicit models. No mathematical repair is required before proceeding with the remaining T061 children.

## Minor presentation observations

- The old `ExtremeValueBridge.lean` introductory note says the measures are not constructed "here". That remains literally true of that module. An optional pointer to `ExtremeValueLaws.lean` would help readers discover the now-completed constructions; it is not a correctness issue.
- The historical section 14.5 of `FABLE_REVIEW.md` still uses "unconditional statements" for the formerly planned milestone. Current section 15.2 and the new module state the scope precisely. Marking 14.5 as historical or superseded would avoid a stale roadmap sentence, but no new proof obligation follows from it.
- No simplification is needed for correctness. The proof organization already keeps the analytic prerequisites separate from construction, CDF identification and law-level corollaries. The short reuse of established Mathlib Stieltjes and product APIs is an appropriate design choice.
