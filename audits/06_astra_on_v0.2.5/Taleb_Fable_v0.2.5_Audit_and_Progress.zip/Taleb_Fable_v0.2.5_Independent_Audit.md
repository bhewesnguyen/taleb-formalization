# Taleb Lean v0.2.5

Independent audit | 19 September 2026 | Mathematics, verification and progress

### Assessment

**Accept the Gumbel and Fréchet construction milestone.** Both standard distribution functions now define actual probability measures, with exact global CDF identities, maximum-law theorems and explicit finite product-space iid realizations. No mathematical repair was identified in the new Lean proofs. T061 correctly remains partial.

Independent clean build and verifier passed. The unchanged sequential regression suite passed all 12 fixtures with the intended outcomes, using relative scratch and output paths. All 216 scanned project constants satisfy the standard three-axiom allowlist.

| Area | Independent assessment |
|---|---|
| New mathematics | 20 theorems, 2 instances and 4 definitions. Fréchet support and the right-hand limit at zero are handled correctly. |
| Earlier findings | H1 argument validation is repaired. H2 path normalization is repaired, with full runtime coverage recorded on page 7. Source and ledger corrections are substantially implemented. |
| Remaining findings | One low-priority ledger-validation gap; residual boundary-event prose; stale historical scope descriptions. No mathematical or release-identity blocker. |
| Release identity | ZIP, manifest, bundled commit and both patch routes agree. Existing mathematical executable text and dependency pins are unchanged. |

### Progress within the broader ledger

**1 discharged / 10 partial / 4 reuse / 91 missing / 34 source-check / 15 model-needed / 3 empirical = 158 families.** These counts are unchanged from v0.2.4. The substantive gain is two completed standard-law construction children inside T061, which a parent-status count alone cannot show.

There are 83 family/declaration citation pairs over 82 distinct declarations. The 122 public checks and 216 scanned constants are implementation counts, not counts of independent book propositions. The families are unequal and the inventory is not an exhaustive atomic theorem census; no effort-completion percentage is justified.

Proceed with reverse-Weibull and the recorded positive location/scale scope. The small validator and documentation changes can be made alongside that mathematics.

## The two distribution constructions

Global CDFs, normalization and the Fréchet support boundary

Source anchor: §9.1, printed p.173 / PDF p.187. The code uses the book's standardized Gumbel and Fréchet forms. For Fréchet, ξ > 0 is the reciprocal of the positive power exponent α: ξ = 1/α.

| Obligation | Delivered evidence |
|---|---|
| Gumbel formula | G(x) = exp(-exp(-x)) on all real x. Monotonicity is proved by composing exponential inequalities; continuity is ordinary global continuity. |
| Gumbel endpoints | As x tends to -∞, -x tends to +∞ and G tends to 0. As x tends to +∞, exp(-x) tends to 0 and G tends to 1. |
| Fréchet support | Fξ(x) = 0 for x ≤ 0; Fξ(x) = exp(-x^(-1/ξ)) for x > 0. The raw positive-branch formula is never substituted at zero. |
| Fréchet monotonicity | On positive inputs, the negative power is decreasing, so its negation and exponential are increasing. Nonpositive inputs use the explicit zero branch. |
| Fréchet right continuity | Negative points are locally constant; positive points use continuity of real powers away from zero. At zero, the endpoint is separated from the right-hand approach and the positive branch tends to 0. |
| Measures and exact CDFs | Each formula is bundled as a StieltjesFunction. Endpoint limits give IsProbabilityMeasure. The pinned cdf_measure_stieltjesFunction theorem identifies its measure's CDF everywhere. |

### The delicate zero-boundary argument is sound

For y > 0, y^(-1/ξ) = exp((-1/ξ) log y). As y approaches 0 from the right, log y tends to -∞; the coefficient -1/ξ is strictly negative, so the product tends to +∞. Thus -y^(-1/ξ) tends to -∞, and the final exponential tends to 0. The proof separately includes the value Fξ(0) = 0 when passing to the closed right neighborhood.

The positivity hypothesis is used exactly where needed. ξ = 0 and negative ξ are not silently accepted as Fréchet parameters. Supplying hξ : 0 < ξ to the measure constructor creates no ambiguity between different proofs of the same proposition; Lean proof irrelevance handles that.

The implementation uses short reductions to established Stieltjes, continuity and limit APIs. There is no assumed normalization, missing support branch, density-integral shortcut, or circular CDF-realization premise. The subreview lists all 26 new user declarations and their roles.

## Maximum laws and iid realizations

The new results apply to actual measures

Let P be a probability measure and Xᵢ measurable, mutually independent coordinates sharing the constructed law. The index type is finite and nonempty; n is its cardinality. The new theorems establish these identities for every real threshold x:

| Law | CDF of the actual maximum | Normalization interpretation |
|---|---|---|
| Gumbel | G(x - log n) | The maximum has the shifted standard Gumbel distribution. Subtract log n to normalize. |
| Fréchet, ξ > 0 | Fξ(n^(-ξ) x) | The maximum has the n^ξ-scaled standard Fréchet distribution. Multiply by n^(-ξ) to normalize. |

`cdf_map_maxRV_gumbel` and `cdf_map_maxRV_frechet` directly combine T060's law theorem, the newly proved CDF identities and the existing analytic max-stability identities. The shifts and scale exponents have the correct signs. The Fréchet statement remains valid on x ≤ 0 because the scale is positive and the CDF is support-correct.

### Explicit iid models

`cdf_map_maxRV_pi_gumbel` and `cdf_map_maxRV_pi_frechet` use the sample space ι → ℝ with `Measure.pi` of the constructed common law. Coordinate projections are measurable, independent by `iIndepFun_pi`, and have the required pushforward law by `measurePreserving_eval`. This gives a concrete model for every finite nonempty index type, hence every positive integer sample size.

- n = 1 is allowed and gives the original law. n = 0 is correctly excluded because a real maximum of an empty sample is undefined.
- Measurability, independence and common law remain ordinary hypotheses in the general random-variable theorems. The product-space specializations discharge them for the exhibited models.
- No domain-of-attraction or asymptotic convergence theorem follows merely from exact max-stability of these named laws.
- The displayed conclusions are global CDF identities for pushforward maximum measures. Separately named equalities to affine pushforward measures are natural corollaries for the location/scale milestone; their absence does not reopen the present construction children.

### Scope judgment

Both planned construction children are complete. T061 remains partial because the reverse-Weibull law and the positive location/scale wrappers are still absent. A `law_theorem` facet could now be added for T061's constructed-law maximum results. Keeping the older conditional-law facet is also accurate because those older bridge declarations remain available.

## Repairs and remaining findings

All findings below are nonblocking for this mathematics milestone

| Prior item | Current assessment |
|---|---|
| H1: --only selection | Closed. Unknown, mixed, empty and empty-element selections independently exited 2 before either output or scratch directories were created. Empty results cannot count as success. |
| H2: relative paths | Both --scratch and --out resolve to absolute paths. The independent full-suite invocation uses relative paths and tests real source/build restoration. Final outcome appears on page 7. |
| Source and scope | Maximum identity corrected to Eq. (9.1), p.172 / PDF186. Minimum survival is a proved companion. T047 and T118 explicitly receive prerequisite-only credit; T060 carries law_theorem. |
| Earlier trust repairs | The all-constant scanner and recursive coverage remain intact. Fixture source/build restoration is retained. No new Lean trust-check defect was found. |

### V025-L1 | low | ledger identity and field consistency

The new schema gate checks enums, joint field presence, status/state consistency, 158 rows and declaration existence. It still accepts: replacing T003 with a second T002; setting T060's redundant `discharged` Boolean to false; or setting `delivery_scope` to the number 123. Python-only replay through unchanged `verify.main` reproduced these gaps. External command outputs were explicitly replayed; these probes are not additional Lean proof evidence.

The delivered ledger contains none of those defects. Share a small validator between the generator and verifier: check unique IDs and the expected ID set, field types and nonblank scope text, and agreement of the Boolean with status/state. Keep mathematical target fulfillment as a review task.

### D025-1 | low | exact boundary-event wording

In `ExtremeValueBridge.lean` and FABLE_REVIEW §14, replace the unrestricted event “some coordinate equals x” with `{minRV X = x}` or `{maxRV X = x}` as appropriate. The former union merely contains the exact difference. For constant coordinates 0 and -1 at x = 0, the union is certain but both minimum threshold events are false, so their probability difference is zero. The Lean statements are correct. Finite atomless coordinate laws are sufficient to make these differences null.

### D025-2 | low | stale progress descriptions

`docs/REPLACEMENT_MAP.md` and its JSON still contain unqualified statements that Fréchet/Gumbel construction is open, immediately before the correct v0.2.5 realization notes. Mark the old clauses as historical or remove them. The v0.2.5 response in `docs/AUDIT_HISTORY.md` mentions only Gumbel and should also record Fréchet. These are documentation repairs, not reasons to change family statuses.

## The eleven supported families

Retain all recorded parent statuses; T061 has advanced within partial

| Family | Status | Audited delivery scope |
|---|---|---|
| T001 | Partial | Ratio-limit regular/slow variation API. Positive measurable conventions and their connection remain open. |
| T007 | Partial | Actual Gaussian realization at α = 2, including zero scale. General stable-law existence remains open. |
| T008 | Partial | Subexponential predicate and preservation of an assumed finite exponent under self-convolution. Concrete-law examples remain open. |
| T029 | Partial | Two-power-tail formula exponent. The random-variable nonnegative weighted-sum squeeze remains open. |
| T032 | Partial | Power-composition exponent formula. Probability-law pushforward identification remains open. |
| T046 | Partial | Actual Gaussian bridge and convolution law. Cauchy remains at formula level. |
| T047 | Partial | Explicit prerequisite-only convolution/sum infrastructure. No average-law scaling, location rule or convergence yet. |
| T060 | Discharged | Generic maximum CDF and minimum survival laws under ordinary iid/common-law hypotheses. Scope unchanged. |
| T061 | Partial | New Gumbel and Fréchet probability measures, exact CDFs, maximum laws and product-space realizations. Reverse-Weibull and location/scale remain. |
| T118 | Partial | Explicit prerequisite-only tail-kernel convexity. Pareto moment identification, moment convexity and integrated Jensen remain open. |
| T124 | Partial | Rational-expression algebra and positivity. Gamma inverse-moment and mixture integration remain open. |

All eleven now have `delivery_scope` and `remaining_obligations`. Core targets, hypotheses and parent statuses were not weakened from v0.2.4. The added T061 actual-law and source-review credit is warranted. Optionally adding its `law_theorem` facet would acknowledge the new probability-law slice more precisely.

The working set contains 140 formal-proof families and 18 model/empirical families. The companion ledger preserves all 158 original rows, an audit of the eleven supported scopes, dependency-group counts and a child-level view of T061. Rows outside the supported set are tallied, not represented as a new full mathematical audit.

## Next milestone: finish T061

Acceptance boundaries that preserve the recorded family target

### 1. Reverse-Weibull, with the upper endpoint at zero

For α > 0, use Wα(x) = exp(-(-x)^α) for x < 0 and Wα(x) = 1 for x ≥ 0. Prove global monotonicity, right continuity and limits 0/1, construct its Stieltjes probability measure, and prove its CDF identity everywhere. The book's extreme-value index is ξ = -1/α. This is the upper-endpoint EVT family, distinct from a right-supported Weibull lifetime law.

The correct formula is Wα(x)^n = Wα(n^(1/α) x), for n > 0. Consequently the maximum has scale n^(-1/α), approaching the endpoint from below. Instantiate the generic maximum theorem with the constructed law and, where an iid realization is claimed, provide the same finite-product construction used here.

### 2. One reusable positive affine pushforward API

For a probability measure ν, μ in ℝ and σ > 0, define the transformed law as ν.map (fun z => μ + σ*z). Prove it is a probability measure and that its CDF at x equals cdf ν ((x - μ)/σ). Apply this to all three standardized laws. Positive scale is essential: negative scale reverses inequalities and requires different endpoint conventions.

The table uses affine coordinates of the book's displayed standardized families. In particular, μ is the lower endpoint for Fréchet and the upper endpoint for reverse-Weibull; keep this convention explicit when relating them to a unified GEV parameterization.

| Family | Maximum parameters from a location/scale law |
|---|---|
| Gumbel | Location μ + σ log n; scale σ. |
| Fréchet, ξ > 0 | Location μ; scale σ n^ξ. |
| Reverse-Weibull, α > 0 | Upper-endpoint location μ; scale σ n^(-1/α). |

These parameter rules are mathematical guidance for the next implementation, not claims that v0.2.5 already exports these affine-law theorems. CDF uniqueness supplies equality of probability measures once both CDFs are identified. Reuse the generic affine lemma rather than repeating three independent event arguments.

### 3. Close only the agreed family scope

T061 may be proposed for discharge when all three globally valid probability laws and the recorded location/scale CDF rules are delivered and checked. Keep max-stability consequences explicit. Do not add domains of attraction, Fisher-Tippett-Gnedenko, densities, moments, or a ξ → 0 continuity theorem as surprise requirements for this family; those belong to separate obligations.

Then proceed to T029's finite log-tail exponent for nonnegative weighted sums by event inclusions, followed by the exact Pareto slice against `paretoMeasure`. Exact convolution asymptotics and broad parent-family closure remain separate judgments.

## Independent execution

Auditor runs distinguished from the release's supplied logs

| Check | Independent outcome |
|---|---|
| Clean lake build | PASS; exit 0; 115.59 s; no compiler diagnostics. |
| Verifier | PASS; 103 theorems + 3 instances + 16 aliases = 122 checks; 216 constants, including 49 internal; 273.78 s. |
| Sequential regression | PASS; 12/12 expected outcomes; exit 0; 3,251.90 s (54 min 12 s) in this environment. |

All 178 received files outside regenerated evidence match byte-for-byte. All nine dependencies match their pins and have clean worktrees. Every fixture restored the pristine source hash and reset the project build snapshot. The allowlist is propext, Classical.choice and Quot.sound; no project axioms were found.

### Sequential regression suite

| Fixture | Verifier result | Expected behavior |
|---|---|---|
| valid | PASS | Positive control |
| private_sorry_theorem | FAIL | Diagnostics; sorryAx also scanned |
| private_sorry_def | FAIL | Diagnostics; sorryAx also scanned |
| private_axiom | FAIL | Forbidden project axiom |
| structure_namespace_theorem | FAIL | Public inventory mismatch |
| protected_theorem | FAIL | Public inventory mismatch |
| alias_map_mismatch | FAIL | Wrong alias target |
| alias_map_mismatch_optimized | FAIL | Wrong alias target under -O |
| orphan_module | FAIL | Unimported module |
| nested_orphan_module | FAIL | Nested unimported module |
| nested_imported_module | PASS | Imported nested theorem scanned |
| dirty_dependency | FAIL | Modified dependency |

A FAIL inside a negative fixture is the expected regression outcome when it rejects the intended defect. The suite itself must exit 0 only when every selected fixture behaves as expected.

The full suite uses relative --scratch and --out arguments to exercise H2 through actual build restoration. Separate portable Python probes cover H1 and the ledger-validation findings. The schema cases replay external verifier outputs; none of these Python probes claims another Lean execution.

## Release identity and evidence

Reproducibility, source correspondence and limits

| Check | Independent result |
|---|---|
| Archive | 186 regular files. All 185 SHA256SUMS entries correct, with exact coverage excluding the manifest itself. No unsafe paths, duplicate names or packaged build outputs. |
| Committed snapshot | All 186 files equal commit 579f0d69d77c21e36a4b8bbd288cd57438a688ab. The supplied bundle verifies and contains the stated history. |
| Both patch routes | Full v0.2.0 route: 134 changed files. Incremental v0.2.4 route: 43. Both patches equal the relevant Git diffs, apply to their bases and reproduce the complete release tree. |
| Existing mathematics | All 24 pre-existing mathematical modules retain identical non-comment text; 23 are byte-identical and the extrema bridge has documentation edits. The root import and generated verification inventory add the new module. |
| Pins / retained evidence | Toolchain and manifest unchanged. All 12 retained-artifact manifest entries pass. Historical release snapshots match their claimed bases. |

### Identity anchors

Release ZIP SHA-256: `9e214be3eb53b37721d9bcbc17da5e3aec8ea39dca38760abc4bd20caff56727`. Lean 4.24.0; Mathlib `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.

Source: Taleb, Statistical Consequences of Fat Tails, arXiv:2001.10488v4, 523-page PDF, SHA-256 `758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567`. Pages inspected: Eq. (9.1), printed172/PDF186; named EVT forms, printed173/PDF187.

### One bounded representation note

The preserved standalone v0.2.4 audit PDF has different bytes and metadata from the PDF inside the exact-matching prior audit ZIP. All eight pages have identical extracted text and rendered pixels. No substantive content difference was found; the cause of the representation change was not established.

A bundle certifies committed history and archive correspondence, not the author's original worktree or live remote state. This audit makes no upstream Mathlib novelty/merge claim and does not certify the separate quantum/classical application. No additional files are needed for this mathematics audit.
