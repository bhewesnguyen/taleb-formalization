#!/usr/bin/env python3
"""Bounded Python-only v0.2.5 probes. No Lean executable is invoked.

CLI probes run the unchanged received harness and stop at argument validation.
Schema probes run unchanged verify.main in a temporary source copy, substituting
recorded command outputs for all subprocess results. These test Python control
flow, not mathematical correctness or a fresh build. The original tree is read-only.
"""
import argparse
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def digest_tree(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file() and '.lake' not in p.parts}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    a = ap.parse_args()
    source = a.project.resolve()
    before = digest_tree(source)
    evidence = source / 'evidence/current'
    inventory = json.loads((evidence / 'inventory_environment.json').read_text())
    original_ledger = json.loads((source / 'docs/FORMALIZATION_BACKLOG.json').read_text())
    manifest = json.loads((source / 'lake-manifest.json').read_text())
    received_report = json.loads((evidence / 'verification.json').read_text())
    axioms = (evidence / 'axioms.log').read_text()
    results = {'scope': __doc__, 'project': str(source), 'cli': [], 'schema_replay': []}

    with tempfile.TemporaryDirectory(prefix='taleb_v025_python_probe_') as td:
        temp = Path(td)
        for name, selection in [('unknown', 'unknown_fixture'), ('mixed', 'valid,unknown_fixture'),
                                ('empty', ''), ('empty_element', 'valid,,')]:
            scratch = temp / (name + '_scratch')
            out = temp / (name + '_out')
            cmd = [sys.executable, str(source / 'scripts/harness_regression.py'),
                   '--only', selection, '--scratch', str(scratch), '--out', str(out)]
            proc = subprocess.run(cmd, cwd=temp, text=True, capture_output=True)
            results['cli'].append(dict(case=name, selection=selection, exit_code=proc.returncode,
                scratch_created=scratch.exists(), out_created=out.exists(),
                stderr=proc.stderr.strip(),
                matches_expected=proc.returncode == 2 and not scratch.exists() and not out.exists()))

        staged = temp / 'project'
        shutil.copytree(source, staged, ignore=shutil.ignore_patterns('.lake', '__pycache__'))
        spec = importlib.util.spec_from_file_location('taleb_verify_probe', staged / 'scripts/verify.py')
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        deps = {d['name']: d['rev'] for d in manifest['packages']}

        def replay_run(args, log=None):
            if args == ['lake', 'env', 'lean', '--version']:
                output = received_report['lean']
            elif args[:2] == ['git', '-C'] and args[3:] == ['rev-parse', 'HEAD']:
                output = deps[Path(args[2]).name]
            elif args[:2] == ['git', '-C'] and args[3:] == ['status', '--porcelain']:
                output = ''
            elif args == ['lake', 'build']:
                output = 'Python-only replay: clean build result substituted; no Lean run.'
            elif args == ['lake', 'env', 'lean', 'AuditVerification.lean']:
                output = axioms
            elif args == ['lake', 'env', 'lean', 'scripts/FableInventory.lean']:
                output = json.dumps(inventory)
            else:
                raise RuntimeError('Unexpected subprocess requested: ' + repr(args))
            if log:
                (mod.OUT / log).write_text(output)
            return output.strip()

        mod.run = replay_run
        cases = []
        cases.append(('valid', copy.deepcopy(original_ledger), True))
        bad = copy.deepcopy(original_ledger); bad[0]['status'] = 'unknown'
        cases.append(('unknown_status', bad, False))
        bad = copy.deepcopy(original_ledger); bad[0]['states'].append('unknown')
        cases.append(('unknown_state', bad, False))
        bad = copy.deepcopy(original_ledger); bad[0]['delivery_scope'] = ''
        cases.append(('missing_delivery_scope', bad, False))
        bad = copy.deepcopy(original_ledger); bad[59]['states'].remove('discharged')
        cases.append(('discharge_state_mismatch', bad, False))
        bad = copy.deepcopy(original_ledger); bad[0]['declarations'][0] = 'AuditRV.does_not_exist'
        cases.append(('dangling_declaration', bad, False))
        bad = copy.deepcopy(original_ledger); bad[2] = copy.deepcopy(bad[1])
        cases.append(('duplicate_T002_omits_T003', bad, True))
        bad = copy.deepcopy(original_ledger); bad[59]['discharged'] = False
        cases.append(('contradictory_discharged_boolean', bad, True))
        bad = copy.deepcopy(original_ledger); bad[0]['delivery_scope'] = 123
        cases.append(('numeric_delivery_scope', bad, True))
        for name, ledger, expected_acceptance in cases:
            (staged / 'docs/FORMALIZATION_BACKLOG.json').write_text(json.dumps(ledger))
            err = None
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    mod.main()
                    accepted = True
                except mod.VerificationError as exc:
                    accepted = False
                    err = str(exc)
            report = json.loads((mod.OUT / 'verification.json').read_text()) if accepted else None
            results['schema_replay'].append(dict(case=name, accepted=accepted,
                expected_observed_acceptance=expected_acceptance, error=err,
                schema_valid_reported=report['environment_inventory']['backlog_schema_valid'] if report else None,
                family_count=report['environment_inventory']['backlog_families'] if report else None,
                unique_family_ids=len({row['id'] for row in ledger}),
                matches_expected=accepted == expected_acceptance))

    results['original_tree_unchanged'] = before == digest_tree(source)
    results['all_probes_matched_expected_observations'] = (
        results['original_tree_unchanged'] and
        all(r['matches_expected'] for key in ('cli', 'schema_replay') for r in results[key]))
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({k: results[k] for k in ('original_tree_unchanged',
        'all_probes_matched_expected_observations')}, indent=2))
    return 0 if results['all_probes_matched_expected_observations'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
