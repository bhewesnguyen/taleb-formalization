# v0.2.5 Python-only verifier probes

`check_verifier_python.py` accepts `--project` pointing to a pristine v0.2.5 extracted project and `--out` for a JSON result file. It leaves the project unchanged.

The four CLI cases invoke the unchanged runner but stop at argument validation. The nine schema cases invoke unchanged `verify.main` in a temporary source copy while replaying all subprocess outputs from the received evidence. No Lean command is invoked. These cases verify the Python validator's control flow, not a build or mathematical proof.

`python_probe_results.json` records the independent audit observations. Its successful overall result includes reproduction of three intentionally exposed validation gaps. Read `verifier_review.md` for their scope and severity. Real build, verifier and sequential-suite results are recorded separately in the main reproduction evidence.
