from pathlib import Path
import hashlib, json, zipfile

BASE=Path(__file__).resolve().parent
OUT=BASE.parent/'output'
assert (BASE/'execution_summary.json').exists(), 'Final execution assessment required'
files={}
for name in ['Taleb_Fable_v0.2.5_Independent_Audit.pdf','Taleb_Fable_v0.2.5_Independent_Audit.md','Taleb_Proof_Progress_v0.2.5.json','Taleb_Proof_Progress_v0.2.5.md']:
    files[name]=(OUT/name).read_bytes()
for name in ['evt_math_review.md','max_law_review.md','ledger_review.md','ledger_review.json','verifier_review.md','provenance_review.md']:
    files['subreviews/'+name]=(BASE/name).read_bytes()
for name in ['check_verifier_python.py','python_probe_results.json','README.md']:
    files['python_probes/'+name]=(BASE/'verifier_probe'/name).read_bytes()
for name in ['provenance.json','check_provenance.py','previous_pdf_comparison.json']:
    files['evidence/provenance/'+name]=(BASE/'provenance'/name).read_bytes()
files['evidence/execution_summary.json']=(BASE/'execution_summary.json').read_bytes()
for p in sorted((BASE/'reproduction').rglob('*')):
    if p.is_file() and p.suffix in {'.json','.md','.log','.py','.lean'} and p.stat().st_size<=2_000_000 and '__pycache__' not in p.parts:
        files['evidence/reproduction/'+str(p.relative_to(BASE/'reproduction'))]=p.read_bytes()
for name in ['report_content.py','build_report.py','package_audit.py']:
    files['audit_scripts/'+name]=(BASE/name).read_bytes()
files['README.md']='''# Taleb Lean v0.2.5 independent audit

Reviewed release ZIP SHA-256:
`9e214be3eb53b37721d9bcbc17da5e3aec8ea39dca38760abc4bd20caff56727`.

The PDF and Markdown give the consolidated assessment. The progress Markdown is a readable
158-family index; the JSON preserves every original row and adds the eleven audited scopes,
dependency-group counts and T061 child progress. Child labels are audit planning labels, not
extra parent rows or an effort-completion percentage.

The Gumbel and Frechet construction children are accepted. T061 remains partial pending
reverse-Weibull and positive location/scale wrappers. Findings concern mechanical ledger
validation and documentation, not a defect in the new Lean mathematics. The uploaded
release was preserved unchanged. No correction patch is applied or supplied in this audit.

## Evidence

Independent real execution records are under `evidence/reproduction/`. The human-facing
summary is `evidence/execution_summary.json`. Read actual fixture outcomes and expected
rejection reasons; a negative fixture's FAIL is a successful regression result only when
it rejects the intended defect. The unchanged full suite uses relative scratch/output
arguments to cover H2 through actual build restoration.

The separate `python_probes/` folder contains a portable bounded probe for H1 and the
new ledger gate. It does not run Lean. Schema cases deliberately replay external outputs
from the release evidence to isolate Python control flow. The successful probe exit
means the documented behaviors were reproduced, including three intentionally exposed
acceptance gaps; it does not mean all malformed ledgers were rejected.

```sh
python3 python_probes/check_verifier_python.py --project /path/to/pristine/v0.2.5/Taleb_Lean_Repairs --out ./python_probe_results.json
```

The normal project gate remains:

```sh
lake exe cache get
lake build
python3 scripts/verify.py
python3 scripts/harness_regression.py
```

Use the supplied Lean 4.24.0 toolchain and unchanged dependency manifest. Audit setup and
provenance scripts retain relevant workspace paths and are records, not a portable installer.

## Boundaries

The bundle establishes committed history and archive equality, not the author's original
worktree cleanliness or live remote push state. The preserved previous audit PDF differs
in binary representation from the prior ZIP's member, but every page's text and rendered
pixels match; the metadata difference has no established cause.

This package does not certify an upstream Mathlib merge, exhaustive atomic coverage of
the book, domains of attraction, numerical computation or the separate quantum/classical
application. Compiler binaries, dependency caches, source-book bytes and duplicate release
archives are excluded. SHA256SUMS covers every included file except itself.
'''.encode()
files['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
target=OUT/'Taleb_Fable_v0.2.5_Audit_and_Progress.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,data in files.items():assert z.read(name)==data
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(OUT/(target.name+'.sha256')).write_text(digest+'  '+target.name+'\n')
print(json.dumps({'archive':str(target),'sha256':digest,'entries':len(files),'bytes':target.stat().st_size},indent=2))
