from pathlib import Path
import collections, hashlib, json, re, html, sys
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from report_content import make_pages
OUT=BASE.parent/'output'
OUT.mkdir(exist_ok=True)
ROOT=BASE/'received/Taleb_Lean_Repairs'
execution_path=BASE/'execution_summary.json'
execution=json.loads(execution_path.read_text()) if execution_path.exists() else {
 'verdict':'Independent execution is pending. Mathematical and release-identity reviews support acceptance; this draft does not assert a final runtime pass.',
 'rows':[['Clean build','Pending final record'],['Verifier','Pending final record'],['Sequential regression','Pending']],
 'detail':'The received release is unchanged. Final independent results will be inserted after the full sequential run.'}
pages=make_pages(execution)
def md_inline(s): return s
md = []
for i,p in enumerate(pages):
    md += [('# ' if i == 0 else '## ') + p['title'], '', p['subtitle'], '']
    for typ, val in p['blocks']:
        if typ == 'p': md += [val, '']
        elif typ == 'h': md += ['### ' + val, '']
        elif typ == 'b': md += ['- ' + x for x in val] + ['']
        else:
            headers, rows, widths = val
            esc = lambda x: x.replace('|', '/')
            md += ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---']*len(headers)) + '|']
            md += ['| ' + ' | '.join(esc(x) for x in row) + ' |' for row in rows]
            md += ['']
md_text = '\n'.join(md)
assert '\u2014' not in md_text
(OUT/'Taleb_Fable_v0.2.5_Independent_Audit.md').write_text(md_text)

for n, f in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(n, '/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
styles = {
    'p': ParagraphStyle('p',fontName='Body',fontSize=9.1,leading=13.3,spaceAfter=8,textColor=colors.HexColor('#263445')),
    'h': ParagraphStyle('h',fontName='Bold',fontSize=11,leading=14,spaceBefore=6,spaceAfter=6,textColor=colors.HexColor('#0B5269')),
    'cell': ParagraphStyle('cell',fontName='Body',fontSize=8.2,leading=11.7,textColor=colors.HexColor('#263445')),
    'th': ParagraphStyle('th',fontName='Bold',fontSize=8.2,leading=11.7,textColor=colors.white),
    'title': ParagraphStyle('title',fontName='Bold',fontSize=24,leading=28,spaceAfter=9,textColor=colors.HexColor('#12283C')),
    'subtitle': ParagraphStyle('subtitle',fontName='Body',fontSize=9.2,leading=13,spaceAfter=18,textColor=colors.HexColor('#526878')),
}
def fmt(s):
    s=html.escape(s)
    s=re.sub(r'\[([^]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#0B5269">\1</link>',s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`(.+?)`',lambda m:'<font name="Mono" size="7.6">'+m.group(1)+'</font>',s)
    return s
def P(s,sty='p'): return Paragraph(fmt(s),styles[sty])
story=[]
for i,p in enumerate(pages):
    if i: story.append(PageBreak())
    story += [P(p['title'],'title'),P(p['subtitle'],'subtitle')]
    for typ,val in p['blocks']:
        if typ in ('p','h'): story.append(P(val,typ))
        elif typ=='b':
            for item in val:
                story.append(Paragraph('• '+fmt(item),styles['p']))
        else:
            headers,rows,widths=val
            data=[[P(x,'th') for x in headers]]+[[P(x,'cell') for x in row]for row in rows]
            t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
            row_padding=4 if headers[0]=='Fixture' else 8
            t.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#16445B')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F0F5F8'),colors.white]),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),
                ('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),row_padding),
                ('BOTTOMPADDING',(0,0),(-1,-1),row_padding),
                ('LINEBELOW',(0,-1),(-1,-1),0.4,colors.HexColor('#C9D5DF'))]))
            story += [t,Spacer(1,10)]
def decor(c,doc):
    c.saveState()
    c.setFillColor(colors.HexColor('#16445B')); c.rect(0,813.89,595.28,28,fill=1,stroke=0)
    c.setFillColor(colors.white);c.setFont('Bold',8)
    c.drawString(48,823,'INDEPENDENT AUDIT  /  TALEB LEAN v0.2.5')
    c.setStrokeColor(colors.HexColor('#C9D5DF'));c.line(48,42,547,42)
    c.setFont('Body',8);c.setFillColor(colors.HexColor('#526878'))
    c.drawString(48,28,'19 September 2026  |  Scope and evidence reviewed independently')
    c.drawRightString(547,28,str(doc.page));c.restoreState()
doc=SimpleDocTemplate(str(OUT/'Taleb_Fable_v0.2.5_Independent_Audit.pdf'),pagesize=(595.28,841.89),leftMargin=48,rightMargin=48,topMargin=49,bottomMargin=54,title='Taleb Lean v0.2.5 Independent Audit',author='Independent audit')
doc.build(story,onFirstPage=decor,onLaterPages=decor)

ledger=json.loads((ROOT/'docs/FORMALIZATION_BACKLOG.json').read_text())
review=json.loads((BASE/'ledger_review.json').read_text())
by_id={r['id']:r for r in review['families']}
groups=collections.defaultdict(collections.Counter)
for r in ledger: groups[r['dependency_group']][r['status']]+=1
child_rows=[
 {'child':'Standard Gumbel','audit_state':'complete','delivered':'Concrete probability measure, exact global CDF, actual maximum law and finite product iid model.','remaining':'No remaining obligation within this standard-law construction child.'},
 {'child':'Standard Frechet, xi > 0','audit_state':'complete','delivered':'Support-correct probability measure, exact global CDF, actual maximum law and finite product iid model.','remaining':'No remaining obligation within this standard-law construction child.'},
 {'child':'Standard reverse-Weibull','audit_state':'open','delivered':'Not constructed in this release.','remaining':'Global upper-endpoint CDF, probability measure, exact CDF and max-stability instantiation.'},
 {'child':'Positive location/scale, all three laws','audit_state':'open','delivered':'Not exported in this release.','remaining':'Affine pushforward probability laws and global CDF transformation rules, with the intended parameter conventions.'}]
progress={
 'release':'v0.2.5','audit_date':'2026-09-19',
 'source_archive_sha256':'9e214be3eb53b37721d9bcbc17da5e3aec8ea39dca38760abc4bd20caff56727',
 'family_count':len(ledger),'status_counts':dict(collections.Counter(r['status'] for r in ledger)),
 'supported_families':11,'discharged_families':['T060'],'citation_pairs':83,'distinct_cited_declarations':82,
 'caution':'Unequal curated families, not an exhaustive atomic theorem census or an effort-completion percentage. The T061 child labels are audit planning labels, not additional parent rows.',
 'execution':execution,'t061_children':child_rows,
 'dependency_group_counts':{g:dict(c) for g,c in sorted(groups.items())},
 'families':[{'original':r,'audit':by_id.get(r['id'],{'audited_status':r['status'],'scope':'Status tallied; no new full-family correctness audit or proof credit.'})} for r in ledger]}
(OUT/'Taleb_Proof_Progress_v0.2.5.json').write_text(json.dumps(progress,indent=2,ensure_ascii=False)+'\n')
clean=lambda s:str(s).replace('\u2014','-').replace('\u2013','-').replace('|','/')
lines=['# Taleb proof progress, v0.2.5','','Independent assessment, 19 September 2026. The companion JSON preserves every original family row and the audited scopes for all eleven supported families.','','## Current position','',execution['verdict'],'',
 '| Status | Families |','|---|---:|']
for status in ['discharged','partial','reuse','missing','source-check','model-needed','empirical']:
 lines.append(f'| {status} | {progress["status_counts"][status]} |')
lines += ['','The parent counts have not changed from v0.2.4. The substantive gain is completion of two standard-law construction children within T061. T060 remains the only discharged parent family. There are 140 formal-proof families plus 15 model-needed and 3 empirical families. These counts do not measure implementation effort.','','## T061 child progress','',
 'These labels expose the reviewed subparts of T061; they are not new rows in the 158-family ledger.','','| Child | Audit state | Delivered | Remaining |','|---|---|---|---|']
for r in child_rows:lines.append('| '+' | '.join(clean(r[k]) for k in ['child','audit_state','delivered','remaining'])+' |')
lines += ['','The remaining location/scale work applies to all three laws. No additional density, moment, domain-of-attraction or general GEV-limit requirement is being added to this family.','','## Audited supported families','']
for r in review['families']:
 lines += [f'### {r["id"]}: {r["title"]}','',f'**Status: {r["audited_status"]}.** Recorded states: '+', '.join(r['states'])+'.','',
  '**Assessment:** '+clean(r['audit_verdict']).replace('_',' '),'','**Delivered scope:** '+clean(r['audited_scope']),'',
  '**Recommended clarification:** '+clean(r['recommendation']),'','**Remaining target:** '+clean(r['remaining_target']),'']
lines += ['## Dependency-group position','','The groups are the original ledger categories. Remaining formal combines reuse, missing and source-check; the source-check column is a subset, not an additional category.','','| Group | Families | Discharged | Partial | Source-check subset | Remaining formal | Model / empirical |','|---|---:|---:|---:|---:|---:|---:|']
for g,c in sorted(groups.items()):
 values=[g,sum(c.values()),c['discharged'],c['partial'],c['source-check'],sum(c[s] for s in ['reuse','missing','source-check']),c['model-needed']+c['empirical']]
 lines.append('| '+' | '.join(str(v) for v in values)+' |')
lines += ['','## Full 158-family index','','Unsupported rows are tallied here without a new full-family mathematical audit. Source locators are the recorded release anchors.','','| ID | Unit | Status | Group | Priority | Family | Printed pages |','|---|---|---|---|---|---|---|']
for r in ledger:lines.append('| '+' | '.join(clean(r[k]) for k in ['id','unit','status','dependency_group','priority','title','printed_pages'])+' |')
lines += ['','## Next acceptance sequence','',
 '1. Construct the upper-endpoint reverse-Weibull probability measure with global CDF identity and max-stability instantiation.',
 '2. Prove one positive affine pushforward CDF rule and instantiate it for all three EVT laws. Propose T061 discharge when its recorded scope is complete.',
 '3. Prove T029 finite log-tail exponents for nonnegative weighted sums by event inclusions. Keep exact convolution asymptotics separate.',
 '4. Develop the exact Pareto survival, moments, divergence, excess and power-pushforward slice, without automatically closing broader parent families.','',
 'Alongside the mathematics, tighten ledger identity/type/Boolean validation and remove the residual boundary-event and stale construction prose. The main audit gives precise findings and separates real Lean execution from Python-only replay probes.','']
(OUT/'Taleb_Proof_Progress_v0.2.5.md').write_text('\n'.join(lines))
print(json.dumps({'draft':not execution_path.exists(),'pages_planned':len(pages),'family_count':len(ledger)},indent=2))
