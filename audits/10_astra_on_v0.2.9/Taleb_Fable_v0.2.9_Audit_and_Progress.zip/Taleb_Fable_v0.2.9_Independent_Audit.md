# Taleb Lean v0.2.9

Independent audit | 21 September 2026 | Pareto Stage B and proof progress

### Assessment

**Accept the mathematics of Pareto Stage B as stated.** The threshold-conditioned law, excess distribution and positive-power pushforward have the right parameters, support and boundary conventions. No proof defect was identified in the twenty-one new theorems or the excess-law definition. One low-priority wording correction is recommended; it does not require a new Lean theorem.

Independent reproduction passed: clean project build, 205 public checks, all 361 project constants within the allowed axioms, 18 schema/rendering probes and all 14 shipped regression fixtures.

| Area | Independent assessment |
|---|---|
| Threshold law | For L > 0, alpha > 0 and K >= L, conditioning Pareto(L, alpha) on X > K gives Pareto(K, alpha). K=L is included. |
| Excess law | The conditional law is pushed forward by x -> x-K through the existing affineLaw. Global CDF and strict survival include y<0 and the endpoint y=0. |
| Means and divergence | Finite conditional mean and finite mean excess are separate, valid formulas for alpha>1. The exported infinite extended-integral theorem concerns the conditional first moment. |
| Power law | For q>0, the actual image measure is Pareto(L^q, alpha/q). The inverse-event argument is restricted to positive support, avoiding real-power behavior on negative inputs. |
| Audit responses | T118 receives the available moment-law credit, T028 has the corrected source locator, and the historical count annotation is now inspectable and verified. |

### Broader progress

**2 discharged / 12 partial / 4 reuse / 89 missing / 33 source-check / 15 model-needed / 3 empirical = 158 families.** T005 joins the supported set, which rises from 13 to 14. T032 gains an actual-law slice. T060 and T061 remain the only discharged parents.

The received ledger has **169 family/declaration pairs over 164 distinct declarations**, up from 146/142. Public checks rise from 184 to 205. These unequal counts describe coverage and reuse; none measures the fraction of the total research effort completed.

## Conditioning and the excess law

Actual probability measures, strict thresholds and correctly separated means

### Threshold conditioning is well-defined

Write nu = paretoMeasure L alpha, with L>0, alpha>0 and K>=L. paretoMeasure_Ioi identifies nu(Ioi K) with ofReal((L/K)^alpha). The base L/K is strictly positive, so this mass is nonzero; probability supplies finiteness. The proof reuses ProbabilityTheory.cond and its probability theorem instead of introducing a competing conditioning definition.

cdf_cond_paretoMeasure computes the conditional lower-tail event as (K,x]. If x<K the interval is empty. If x>=K, subtracting the two original CDFs and dividing by the positive tail mass gives 1-(K/x)^alpha. Measure.eq_of_cdf then identifies the entire measure with Pareto(K,alpha), with probability instances on both sides. At x=K the CDF is zero; at K=L the conditional law is the original law.

### The excess is a pushforward of that conditional law

excessLaw L alpha K is exactly affineLaw (nu[|Ioi K]) (-K) 1. After the threshold identity, it becomes the translate of Pareto(K,alpha). The affine CDF theorem applies because the slope is 1>0.

| Argument | CDF of the excess | Strict survival |
|---|---|---|
| y < 0 | 0 | 1 |
| y >= 0 | 1 - (K/(K+y))^alpha | (K/(K+y))^alpha |
| y = 0 | 0 | 1 |

This includes the complete support convention, rather than applying the power expression to arbitrary negative denominators. The strict survival at zero reflects absence of endpoint mass. The theorem does not condition the unshifted law after applying the translation.

### Finite means and the precise divergence claim

| Result | Domain | Delivered value |
|---|---|---|
| Conditional p-th moment | p < alpha | alpha K^p/(alpha-p) |
| Conditional first moment | alpha > 1 | alpha K/(alpha-1) |
| Mean excess | alpha > 1 | K/(alpha-1) |
| Extended conditional first moment | 0 < alpha <= 1 | +infinity |

The finite mean-excess proof establishes integrability before splitting the affine integral into a constant and the identity. Divergence is proved using Stage A as an extended nonnegative integral, including alpha=1. No totalized real integral is used as evidence of finiteness or infinity. An extended divergence theorem for excessLaw itself is not exported and is not required for the accepted Stage B core.

## The positive-power pushforward

The four helper lemmas expose the support and inverse-event argument

For L>0, alpha>0 and q>0, map_rpow_paretoMeasure proves (paretoMeasure L alpha).map (x -> x^q) = paretoMeasure (L^q) (alpha/q). This is equality of measures, extending the earlier analytic exponent formula to the actual pinned Pareto law.

| Helper | What was checked |
|---|---|
| paretoMeasure_apply_inter_Ici | For every set A, nu A = nu (A intersect [L,infinity)). The discarded set lies below L and has zero mass. No measurability of arbitrary A is silently required. |
| preimage_rpow_Iic_inter_Ici_eq_empty | If x<L^q, no support point y>=L can satisfy y^q<=x. Monotonicity is applied only with positive lower base and q>0. This branch includes negative x. |
| preimage_rpow_Iic_inter_Ici | If x>=L^q, then x>0 and the support part of {y:y^q<=x} is [L,x^(1/q)]. Both directions use the inverse-power equivalence with nonnegative bases. |
| pareto_power_algebra | The ratio (L/x^(1/q))^alpha equals (L^q/x)^(alpha/q). The generic helper permits x>=0; the CDF branch supplies x>0. Nonzero q is established before cancelling exponents. |

### From the event computation to equality of laws

The power map is measurable. The source law, its image, and the target law each carry probability instances before CDF uniqueness is invoked. In the upper branch, the null region below L is dropped, Stage A supplies the source CDF, and the exponent identity produces the target CDF. The lower branch is zero on both sides. Equality at x=L^q is covered by the upper branch.

The proof never asserts that x -> x^q has the needed order inverse on all real inputs. This matters because Lean real powers are totalized outside the positive domain. The support restriction is substantive and correctly used, not merely an explanatory comment.

### Moment threshold and implementation quality

integrable_rpow_map_rpow_paretoMeasure_iff gives integrability of an order-p moment of the image law exactly when p<alpha/q, for every real p. Since q>0, this is equivalent to p*q<alpha. Negative moment orders remain legitimate because L^q>0 keeps the image support away from zero.

The split into four helpers is a useful proof organization. Each helper isolates a mathematical step that can be inspected independently. The reported earlier heartbeat timeout does not change the statement or trusted basis of the final proof. The implementation claims no law identity for q<=0 and does not close the general arbitrary-law reading of Property 5.2.

## Audit responses and one correction

The previous ledger repairs are accepted; one summary should name its divergence theorem

| Previous item | Current assessment |
|---|---|
| D028-1: T118 moment credit | Repaired. integral_rpow_paretoMeasure is cross-cited at Eq. (21.7), printed382/PDF396. Law and realization facets are scoped to moment identification; convexity and integrated Jensen remain open. |
| D028-2: T028 source locator | Repaired. Printed95/PDF109 locates the constant-factor tail; printed96 introduces the slowly varying factor; printed97 contains Definition5.1. |
| D027-3: historical count annotation | Resolved. The new in-package index snapshot reproduces the historical repository index, including the old validation-count annotation. The shipped old log remains unchanged. |
| Scope remarks | Accepted: T029 realizes marginal laws while keeping its joint-space and pointwise-nonnegativity premises; T021 negative orders rely on L>0; raw absolute moments remain distinct from centered MAD. |

### D029-1 | low | name which first moment has proved divergence

The brief and changelog group the conditional mean and mean excess with an unqualified infinity statement, and T005 delivery_scope abbreviates this as extended first-moment divergence. The exported theorem is specifically lintegral_id_cond_paretoMeasure_eq_top. There is no corresponding excessLaw divergence declaration. The module docstring and detailed review already state the narrower result correctly.

**Repair:** say "extended conditional first-moment divergence" in the grouped summaries and T005 delivered scope. Keep both finite mean formulas. Change the generator and regenerate both ledgers together. If a later pass claims excess-mean divergence, give it its own extended-integral theorem. Do not require that optional theorem to accept Stage B, and do not alter counts or status for this wording correction.

### G20: the corrected derivative is right

For m_p(alpha)=L^p alpha/(alpha-p), the corrected second derivative is 2 p L^p/(alpha-p)^3. The book omits p and substitutes (alpha-1)^3 in the denominator. T118 correctly requires p>0 for the convexity claim. The all-real-order Stage A moment theorem does not extend this convexity to negative p.

Optional wording refinement: "agrees only at p=1" is safest as "for positive moment orders" or "as an identity in alpha". Negative orders can give accidental equality at a single alpha; L=1, p=-1/8, alpha=1/4 gives -128/27 for both expressions. This is an ambiguity in prose, not a defect in the corrected derivative or a new Stage B obligation.

The repository-only scope memo is explicitly a historical v0.2.8 planning note. Its release-count forecasts and broad infrastructure-absence claims are not adopted as established facts here. The authoritative progress artifact retains the full 158-family denominator and the current scoped obligations.

## Position in the broader ledger

Fourteen supported families; one new supported parent and no new parent closure

| Family | Status | Delivered scope and remaining work |
|---|---|---|
| T001 | Partial | Ratio-only regular variation API; positive measurable convention and bridge remain. |
| T005 | Partial | NEW: exact Pareto threshold/excess laws and means. General tail-integral identity (2.10) remains. |
| T007 | Partial | Gaussian realization of the stable expression at index2; general stable existence remains. |
| T008 | Partial | Conditional subexponential tail theorem; concrete-law examples remain. |
| T021 | Partial | Exact Pareto raw/absolute moments. Centered MAD/STD and other distributions remain. |
| T028 | Partial | Exact Pareto tail, CDF, moments and threshold. General regular-variation boundary remains. |
| T029 | Partial | Binary exponent child plus concrete Pareto marginal specialization. Stronger ratio child remains. |
| T032 | Partial | NEW: exact Pareto positive-power image law and moment threshold. Arbitrary-law target remains. |
| T046 | Partial | Gaussian characteristic-function/convolution bridge; Cauchy identification remains. |
| T047 | Partial | Prerequisite sum/convolution infrastructure; sample-average scaling/convergence remains. |
| T060 | Discharged | Generic maximum CDF and minimum survival laws under ordinary probability hypotheses. |
| T061 | Discharged | Three EVT measures, exact CDFs, affine families and iid maximum-law measure equalities. |
| T118 | Partial | Tail-kernel convexity and exact moment identification. Moment convexity/Jensen remain. |
| T124 | Partial | Repaired rational algebra and positivity; shifted-gamma inverse-moment integration remains. |

Of **140 formal-proof families, 2 are discharged and 138 remain open**. Eighteen further families require models or empirical work. Six ledger rows changed in this release: T005, T021, T028, T029, T032 and T118. The other 152 rows are identical to their v0.2.8 versions.

The companion JSON preserves every received field of all 158 rows and adds separate audit annotations, completed/open child scopes and all 22 dependency-group tallies. The 169 citation pairs cover 164 distinct names. A reused declaration may support several families; citation counts must not be added to theorem counts.

S001 and S002 remain open outside the fixed family count. This is a curated inventory, not an exhaustive atomic theorem census, an effort-completion percentage, evidence of an upstream Mathlib merge or evidence that the separate quantum/classical application is operational.

## Next milestone: centered Pareto ratios

Reuse the new conditional law to prove the centered absolute deviation

For X with law Pareto(L,alpha), L>0, define m=E[X] in the integrable range. The next contained T021 slice should identify the actual centered moments and reproduce Eq. (4.14), printed86/PDF100.

| Quantity | Domain | Target value |
|---|---|---|
| Mean m | alpha > 1 | alpha L/(alpha-1) |
| Variance | alpha > 2 | alpha L^2 / ((alpha-1)^2 (alpha-2)) |
| Centered MAD: E/X-m/ | alpha > 1 | 2 L (alpha-1)^(alpha-2) / alpha^(alpha-1) |
| STD / MAD | alpha > 2 | alpha^(alpha-1/2) / (2 sqrt(alpha-2) (alpha-1)^(alpha-1)) |

### A short route through delivered law facts

First obtain the first two raw moments and the required integrability from Stage A. Show E|X-m| = 2 E[(X-m)+] using the integrable centered variable and E[X-m]=0. This still requires a checked absolute-deviation argument; the first two raw moments alone do not prove MAD.

Because m>L when alpha>1, Stage B applies at K=m. Its conditional mean-excess formula gives E[X-m | X>m] = m/(alpha-1). Multiply by P(X>m)=(L/m)^alpha to recover the positive-part expectation, then simplify to the displayed MAD. This can avoid a new direct density integral and need not wait for the general layer-cake milestone.

For variance and the ratio, prove square integrability, use the pinned variance API or an explicit central second moment, and establish positive denominators before cancellation. Keep alpha>2 on the real STD/MAD ratio. Do not infer divergent variance from a totalized real variance value outside that domain. T021 remains partial until its other distribution and ratio obligations are proved.

### Separate follow-up: the general tail-integral identity

For a probability measure P, measurable X>=0 almost everywhere and K>=0, let A={X>K}. Prove first as extended nonnegative integrals: integral_A X = K P(A) + integral_(K,infinity) P(X>t) dt, and E[(X-K)+] = integral_(K,infinity) P(X>t) dt. Here nonnegative quantities are embedded into ENNReal. Atoms at K are allowed; keep the strict event convention.

Reuse the pinned layer-cake API. Under Integrable X, derive the finite real version, then the conditional mean and excess formulas when P(A)>0. This can lift T005 beyond the Pareto slice. Assess closure against its stated family target once those general obligations are actually delivered; do not close it in advance.

## Independent execution

Actual runtime outcomes are distinct from supplied logs and source consistency checks

| Check | Observed outcome |
|---|---|
| Runtime and dependencies | Fresh official Lean 4.24.0 archive matches its expected SHA-256. All nine dependency revisions match the pinned manifest; official cached artifacts fetched. |
| Clean project build | PASS; exit 0, 204.01 s; 2747 Lake jobs, no compiler warnings/errors. |
| Normal verifier | PASS; exit 0, 398.51 s; 181 theorems, 8 instances, 16 aliases (205 checks). |
| Trust and ledger | 361 constants, including 101 internal; only propext, Classical.choice and Quot.sound. 158 valid families; 169 citation pairs over 164 names; raw-byte rendering gate passes. |
| Schema/render probes | PASS 18/18: sixteen malformed cases rejected and two valid controls accepted. |
| Shipped regression | PASS 14/14 exactly once; 37.5 min across three isolated, disjoint --only invocations. All source and build restoration checks pass. |
| Final integrity | All 246 received files outside generated current evidence match the tested project exactly. Received extraction unchanged; all nine dependencies pinned and clean. |

Earlier temporary compiler/dependency caches were absent and the retained old archive was truncated, so a fresh official runtime and exact pinned dependencies were obtained. Setup records are distinct from project outcomes. The project began without project build outputs; dependency build artifacts came from the official Mathlib cache. This is not a rebuild of all Mathlib from source. Regression used real relative scratch/output arguments and separate dependency copies.

### Verifier and ledger checks

verify.py, backlog_schema.py, backlog_schema_probes.py, harness_regression.py and FableInventory.lean are byte-identical to v0.2.8. Generator executable logic is unchanged; only the raw ledger data differs. Independent normal and optimized Python runs regenerate deliberately corrupted disposable ledger files to the exact shipped bytes.

The public source inventory has 181 theorems, 8 instances and 16 aliases. The new module adds 21 theorems and one definition. The 158-row ledger validates, cites 169 family/declaration pairs over 164 names, and matches its Markdown renderer byte for byte. Consistency of a supplied environment JSON is not itself an independent Lean execution.

### Coverage and evidence boundaries

The unchanged regression suite contains positive controls for the pristine project, imported nested modules and namespace/section handling; negative cases cover private sorry declarations, added axioms, public-inventory mismatch, alias mismatch including optimized Python, unimported modules, duplicate ledger IDs and modified dependencies. Outcomes and restoration records belong to the runtime evidence.

No new CRLF campaign or replayed-command suite was added to this release: the byte-rendering gate and its tests are unchanged and were independently exercised in v0.2.8. Current generator round trips are real Python executions. The review does not count them as additional Lean proofs.

## Provenance and audit boundaries

Archive, patches and committed project agree; the received release is unchanged

| Item | Independently checked |
|---|---|
| Release ZIP | SHA-256 abbea690e34bfde5799b8384b727e834d6a319f25cdda52c851c61eca602b77e; 255 regular files, 288 entries, 254 manifest checks. |
| Bundled snapshot | Commit 382faa0cfb13ccc8f5586ef89b903c2874aeddd6; project tree 2931c3c6a54e6259d225f690b2a272d90dc08aef. |
| Both patch routes | Full patch from v0.2.0 changes 203 files; incremental v0.2.8 patch changes 38. Both reproduce the exact tree and every packaged file byte. |
| Preserved mathematics | All 28 pre-existing mathematical modules are byte-identical. ParetoConditional.lean is new. Lean4.24.0 and Mathlib f897ebcf72cd16f89ab4577d0c826cd14afaafc7 remain pinned. |
| Source edition | arXiv:2001.10488v4, 523 pages; SHA-256 758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567. Relevant source pages were visually reviewed. |
| Historical annotation | The in-package index snapshot has one provenance preamble followed by an exact copy of the historical repository index. The earlier evidence boundary is resolved. |

All 26 retained-artifact hashes pass. The prior v0.2.8 audit ZIP matches the independently recorded checksum and all 93 internal manifest checks. Its standalone PDF and ZIP member differ in binary representation, but all eight page texts and all 150-dpi rendered RGB buffers match. No substantive page change was found; no cause of the byte difference is asserted.

### What the bundle establishes

The bundle contains the committed project and history through its advertised snapshot, including the repository-only historical scope memo. The fourth commit adding current deliverables is outside the bundle. Original worktree cleanliness and remote push state are not established by an auditor checkout. No finding depends on assuming those unobserved states.

### Scope of acceptance

This audit accepts the reviewed Stage B propositions and scoped ledger credit, with D029-1 as a low wording correction. It does not certify general arbitrary-law power transformation, the general tail-integral identity, centered-moment ratios or all claims in the book. The received release was not modified.

The evidence ZIP contains the PDF and editable report, full progress ledger, Fable handoff, mathematical and verifier subreviews, provenance comparisons and actual execution records. It excludes the source book, compiler/dependency caches, temporary Git worktrees and duplicate input archives. SHA256SUMS covers every included file except itself.
