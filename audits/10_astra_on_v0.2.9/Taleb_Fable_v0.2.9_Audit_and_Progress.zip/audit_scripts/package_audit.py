"""Package completed audit evidence without caches, book or duplicate release files."""
from pathlib import Path
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parent
OUT = BASE.parent / 'output'
execution = json.loads((BASE / 'execution_summary.json').read_text())
assert execution.get('complete') is True, 'Cannot package a provisional verdict'
files = {}
deliverables = [
    'Taleb_Fable_v0.2.9_Independent_Audit.pdf',
    'Taleb_Fable_v0.2.9_Independent_Audit.md',
    'Taleb_Proof_Progress_v0.2.9.json',
    'Taleb_Proof_Progress_v0.2.9.md',
    'Taleb_Fable_v0.2.9_Review_Handoff.md',
]
for name in deliverables:
    files[name] = (OUT / name).read_bytes()
for name in ['conditional_review.md', 'power_review.md', 'ledger_review.md',
             'ledger_review.json', 'verifier_review.md', 'provenance_review.md',
             'runtime_review.md', 'general_tail_integral_spec.md', 'conditional_api_evidence.json']:
    files['subreviews/' + name] = (BASE / name).read_bytes()
for folder in ['verifier_probe', 'provenance', 'reproduction']:
    for p in sorted((BASE / folder).rglob('*')):
        if not p.is_file() or any(x in p.parts for x in ['__pycache__', '.git', '.lake']):
            continue
        rel = p.relative_to(BASE / folder)
        if folder == 'provenance' and len(rel.parts) > 1:
            continue
        if p.suffix not in {'.json', '.md', '.log', '.py', '.lean', '.diff', '.sha256'}:
            continue
        assert p.stat().st_size <= 2_000_000, f'Review unexpectedly large evidence: {p}'
        files['evidence/' + folder + '/' + str(rel)] = p.read_bytes()
files['evidence/execution_summary.json'] = (BASE / 'execution_summary.json').read_bytes()
for name in ['report_content.py', 'build_report.py', 'build_progress.py',
             'build_ledger_review.py', 'package_audit.py', 'validate_artifacts.py',
             'finalize_report.py']:
    files['audit_scripts/' + name] = (BASE / name).read_bytes()
files['README.md'] = (BASE / 'PACKAGE_README.md').read_bytes()
files['SHA256SUMS'] = ''.join(
    hashlib.sha256(data).hexdigest() + '  ' + name + '\n'
    for name, data in sorted(files.items())
).encode()
target = OUT / 'Taleb_Fable_v0.2.9_Audit_and_Progress.zip'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name, data in files.items():
        assert z.read(name) == data
    assert len(set(z.namelist())) == len(files)
digest = hashlib.sha256(target.read_bytes()).hexdigest()
(OUT / (target.name + '.sha256')).write_text(digest + '  ' + target.name + '\n')
print(json.dumps({'archive': str(target), 'sha256': digest,
                  'entries': len(files), 'bytes': target.stat().st_size}, indent=2))
