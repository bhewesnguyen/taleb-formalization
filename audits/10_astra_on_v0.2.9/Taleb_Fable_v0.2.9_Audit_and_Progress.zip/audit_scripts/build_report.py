from pathlib import Path
import collections, hashlib, json, re, html, sys
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from report_content import make_pages
OUT=BASE.parent/'output'
OUT.mkdir(exist_ok=True)
ROOT=BASE/'received/Taleb_Lean_Repairs'
execution_path=BASE/'execution_summary.json'
execution=json.loads(execution_path.read_text()) if execution_path.exists() else {
 'verdict':'Independent execution is pending. Mathematical and release-identity reviews support acceptance; this draft does not assert a final runtime pass.',
 'rows':[['Clean build','Pending final record'],['Verifier','Pending final record'],['Regression coverage','Pending']],
 'detail':'The received release is unchanged. Final independent results will be inserted after the full regression coverage.'}
pages=make_pages(execution)
def md_inline(s): return s
md = []
for i,p in enumerate(pages):
    md += [('# ' if i == 0 else '## ') + p['title'], '', p['subtitle'], '']
    for typ, val in p['blocks']:
        if typ == 'p': md += [val, '']
        elif typ == 'h': md += ['### ' + val, '']
        elif typ == 'b': md += ['- ' + x for x in val] + ['']
        else:
            headers, rows, widths = val
            esc = lambda x: x.replace('|', '/')
            md += ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---']*len(headers)) + '|']
            md += ['| ' + ' | '.join(esc(x) for x in row) + ' |' for row in rows]
            md += ['']
md_text = '\n'.join(md)
assert '\u2014' not in md_text
(OUT/'Taleb_Fable_v0.2.9_Independent_Audit.md').write_text(md_text)

for n, f in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(n, '/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
styles = {
    'p': ParagraphStyle('p',fontName='Body',fontSize=9.1,leading=13.3,spaceAfter=8,textColor=colors.HexColor('#263445')),
    'h': ParagraphStyle('h',fontName='Bold',fontSize=11,leading=14,spaceBefore=6,spaceAfter=6,textColor=colors.HexColor('#0B5269')),
    'cell': ParagraphStyle('cell',fontName='Body',fontSize=8.2,leading=11.7,textColor=colors.HexColor('#263445')),
    'th': ParagraphStyle('th',fontName='Bold',fontSize=8.2,leading=11.7,textColor=colors.white),
    'title': ParagraphStyle('title',fontName='Bold',fontSize=24,leading=28,spaceAfter=9,textColor=colors.HexColor('#12283C')),
    'subtitle': ParagraphStyle('subtitle',fontName='Body',fontSize=9.2,leading=13,spaceAfter=18,textColor=colors.HexColor('#526878')),
}
def fmt(s):
    s=html.escape(s)
    s=re.sub(r'\[([^]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#0B5269">\1</link>',s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`(.+?)`',lambda m:'<font name="Mono" size="7.6">'+m.group(1)+'</font>',s)
    return s
def P(s,sty='p'): return Paragraph(fmt(s),styles[sty])
story=[]
for i,p in enumerate(pages):
    if i: story.append(PageBreak())
    story += [P(p['title'],'title'),P(p['subtitle'],'subtitle')]
    for typ,val in p['blocks']:
        if typ in ('p','h'): story.append(P(val,typ))
        elif typ=='b':
            for item in val:
                story.append(Paragraph('• '+fmt(item),styles['p']))
        else:
            headers,rows,widths=val
            data=[[P(x,'th') for x in headers]]+[[P(x,'cell') for x in row]for row in rows]
            t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
            row_padding=4 if headers[0]=='Fixture' else (6 if headers[0]=='Family' else 8)
            t.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#16445B')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F0F5F8'),colors.white]),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),
                ('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),row_padding),
                ('BOTTOMPADDING',(0,0),(-1,-1),row_padding),
                ('LINEBELOW',(0,-1),(-1,-1),0.4,colors.HexColor('#C9D5DF'))]))
            story += [t,Spacer(1,10)]
def decor(c,doc):
    c.saveState()
    c.setFillColor(colors.HexColor('#16445B')); c.rect(0,813.89,595.28,28,fill=1,stroke=0)
    c.setFillColor(colors.white);c.setFont('Bold',8)
    c.drawString(48,823,'INDEPENDENT AUDIT  /  TALEB LEAN v0.2.9')
    c.setStrokeColor(colors.HexColor('#C9D5DF'));c.line(48,42,547,42)
    c.setFont('Body',8);c.setFillColor(colors.HexColor('#526878'))
    c.drawString(48,28,'21 September 2026  |  Scope and evidence reviewed independently')
    c.drawRightString(547,28,str(doc.page));c.restoreState()
doc=SimpleDocTemplate(str(OUT/'Taleb_Fable_v0.2.9_Independent_Audit.pdf'),pagesize=(595.28,841.89),leftMargin=48,rightMargin=48,topMargin=49,bottomMargin=54,title='Taleb Lean v0.2.9 Independent Audit',author='Independent audit')
doc.build(story,onFirstPage=decor,onLaterPages=decor)

print('Built v0.2.9 report: '+str(len(pages))+' planned pages')
