#!/usr/bin/env python3
"""Review v0.2.9 scope and counts, preserving all received rows exactly.

This is a ledger/source audit. Independent execution is attached by build_progress.py.
"""
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE / 'received/Taleb_Lean_Repairs'
SOURCE = HERE.parent / 'audit_v024/source/2001.10488v4(1).pdf'
rows = json.loads((ROOT / 'docs/FORMALIZATION_BACKLOG.json').read_text())
prev = json.loads((HERE / 'prior_audit/Taleb_Proof_Progress_v0.2.8.json').read_text())
old = {r['id']: r for r in prev['ledger_rows']}
prior_family = {r['id']: r for r in prev['families']}
statuses = ['discharged', 'partial', 'reuse', 'missing', 'source-check', 'model-needed', 'empirical']
status_counts = {s: sum(r['status'] == s for r in rows) for s in statuses}
citations = Counter(n for r in rows for n in r['declarations'])
inventory = json.loads((ROOT / 'evidence/current/inventory_environment.json').read_text())
inventory_names = {c['name'] for c in inventory['constants']}
groups = {}
for name in sorted({r['dependency_group'] for r in rows}):
    members = [r for r in rows if r['dependency_group'] == name]
    groups[name] = {'total': len(members), 'status_counts': {s: sum(r['status'] == s for r in members) for s in statuses}}

findings = [{
    'id': 'D029-1',
    'severity': 'low',
    'kind': 'documentation_divergence_scope',
    'summary': 'Grouped conditional/excess descriptions can read as if both divergent first moments were formalized. The exported divergence theorem is for the raw conditional first moment only.',
    'locations': ['T005 delivery_scope in the generator and both renderings', 'current brief and changelog descriptions that group both means with the divergence clause'],
    'repair': 'Name the delivered divergence result explicitly: for 0 < alpha <= 1 the raw conditional first moment has extended nonnegative integral top. Both finite means are proved for alpha > 1. The analogous excess-law divergence is mathematically valid but is not exported in this release. Either clarify the text only or add it later as an optional corollary.',
    'effect': 'Wording precision only. No theorem, facet, family-status or Stage B acceptance change. A new excess-divergence theorem is not required to accept the agreed milestone.'
}]

families = []
for row in rows:
    if not row['declarations']:
        continue
    r = copy.deepcopy(row)
    inherited = prior_family.get(row['id'], {})
    r.update(
        audited_scope=inherited.get('audited_scope', r['delivery_scope']),
        recommendation='Retain the received status and scoped delivery facets.',
        remaining_target=r['remaining_obligations'],
        audited_status=r['status'], audit_verdict='accurate',
        current_status=r['status'], recommended_status=r['status'],
        current_states=copy.deepcopy(r['states']), recommended_states=copy.deepcopy(r['states']),
        recommended_additional_declarations=[])
    if r['id'] == 'T005':
        r.update(
            audit_verdict='partial_transition_accepted_with_divergence_wording_clarification',
            audited_scope='Exact Pareto conditional law above K equals Pareto(K,alpha) for K >= L > 0 and alpha > 0, endpoint included. The excess law is its affine pushforward by x-K, with global CDF and strict survival. Finite raw conditional mean alpha*K/(alpha-1), finite excess mean K/(alpha-1), and all-real conditional moment formula for p < alpha. The raw conditional first moment has infinite extended nonnegative integral for 0 < alpha <= 1. Excess-law divergence is not separately exported.',
            recommendation='Accept missing to partial and law_theorem/actual_law_constructed/source_reviewed for this exact-Pareto slice. Apply D029-1 wording precision. Keep the general tail-integral identity and derived general conditional/excess means open.')
    if r['id'] == 'T021':
        r.update(
            audited_scope='Stage A exact pinned Pareto raw and absolute moments: extended integral finite with the closed formula for every real p < alpha, infinite for p >= alpha, integrability iff p < alpha, and zeroth moment one. L > 0 and alpha > 0. Negative orders are valid because the support stays away from zero. The new conditional-moment corollaries are credited to T005, not a new centered-dispersion result.',
            recommendation='Retain partial. The explicit distinction between raw absolute moments and centered mean absolute deviation is correct. Next compute centered MAD, not only mean/variance and ratio algebra.',
            remaining_target='Gaussian and Student absolute moments; Pareto mean, variance, and the centered mean absolute deviation E[|X-E X|], then the STD/MD ratio (4.14); correct scale conventions. Raw E[|X|^p] does not itself compute centered MD.')
    if r['id'] == 'T028':
        r.update(
            audit_verdict='accurate_source_anchor_repaired',
            recommendation='Accept D028-2. The exact tail locator is now printed p. 95 / PDF 109; p. 96 introduces L(x), p. 97 contains Definition 5.1. Retain partial and the general regularly varying boundary statement-review gate.')
    if r['id'] == 'T029':
        r.update(
            audit_verdict='accurate_explicit_marginal_scope',
            recommendation='Accept the clarified actual-law facet as scoped to concrete Pareto marginal laws. A common joint space, measurable coordinates and pointwise nonnegativity remain stated hypotheses. No explicit joint realization was required for the accepted exponent child. Keep partial and the stronger unequal-index RV child open.')
    if r['id'] == 'T032':
        r.update(
            audit_verdict='accurate_exact_law_slice_added',
            audited_scope='The earlier analytic exponent formula remains. Stage B now identifies the actual positive-power pushforward of the pinned Pareto law: Pareto(L,alpha).map(x -> x^q) = Pareto(L^q,alpha/q) for L > 0, alpha > 0 and q > 0. The proof computes inverse events on the positive support, and the moment corollary is integrability iff p < alpha/q.',
            recommendation='Retain partial. Accept law_theorem and actual_law_constructed for the exact-Pareto law identity. Property 5.2 for arbitrary laws and the general density transformation remain open; do not treat the exact slice as closing those targets.')
    if r['id'] == 'T118':
        r.update(
            audit_verdict='accurate_prior_undercredit_repaired',
            audited_scope='The earlier tail-kernel convexity plus the now cross-credited exact Pareto moment identification AuditPareto.integral_rpow_paretoMeasure. The new law/actual-law facets describe only the moment identification. Convexity of the moment function in alpha and integrated Jensen are not delivered.',
            recommendation='Accept D028-1 and G20. The moment theorem is correctly cross-credited without being counted as a new declaration. Retain partial. On the stated p > 0, alpha > p domain the two derivative expressions agree only at p=1; do not generalize that pointwise wording to negative orders.',
            remaining_target='For fixed p > 0 and L > 0, convexity of alpha -> L^p alpha/(alpha-p) on alpha > p, then justified Jensen with random-index support and integrability or extended-expectation assumptions. Use the corrected second derivative 2*p*L^p/(alpha-p)^3.')
    families.append(r)

stages = copy.deepcopy(prev['Pareto_children'])
for item in stages:
    if item['id'] == 'Pareto.B1':
        item.update(status='complete', introduced='v0.2.9', scope='For K >= L > 0 and alpha > 0, the normalized restricted law above K equals Pareto(K,alpha), and its affine excess law has global CDF/survival. Conditional moment formulas and the two distinct finite first means are proved; the raw conditional first moment diverges as an extended integral for 0 < alpha <= 1. This is the exact-Pareto T005 slice only.')
    if item['id'] == 'Pareto.B2':
        item.update(status='complete', introduced='v0.2.9', scope='For q > 0, the pinned Pareto(L,alpha) law pushed through x^q equals Pareto(L^q,alpha/q). Measurability, positive-support inverse events and exponent algebra are proved. Integrability of order p under the image law is equivalent to p < alpha/q. This is the exact-Pareto T032 slice only.')
stages.extend([
    {'id': 'Pareto.C1', 'name': 'Centered Pareto dispersion and STD/MD', 'status': 'open', 'families': ['T021'], 'scope': 'Compute mean, variance and E[|X-E X|] for the actual law. For alpha > 2 derive the scale-free ratio in Eq. (4.14). The centered absolute-deviation integration is a genuine step beyond the raw moments.'},
    {'id': 'T005.general', 'name': 'General tail-integral identity and conditional means', 'status': 'open', 'families': ['T005'], 'scope': 'For measurable nonnegative X and K >= 0, prove the atom-safe strict-tail identity by Tonelli/layer-cake in extended integrals, then finite real-valued conditional and excess formulas under the appropriate integrability and positive-tail hypotheses.'},
    {'id': 'T032.general', 'name': 'General power transformation', 'status': 'open', 'families': ['T032'], 'scope': 'For a nonnegative law with a finite tail exponent or regularly varying survival and q > 0, prove exponent alpha/q by inverse events; separately state and prove the density change of variables with appropriate support and regularity.'}
])
facet = Counter(s for r in rows for s in r['states'])
d = {
    'version': 'v0.2.9',
    'method': 'Independent ledger/source/signature comparison with the preserved v0.2.8 audit, supplied v0.2.9 ledger and inventory, and arXiv v4 source pages. Independent runtime checks are attached separately. Unchanged unsupported families are tallied, not represented as newly audited or proved.',
    'family_count': len(rows), 'supported_count': len(families),
    'discharged_count': 2, 'formal_proof_working_set': 140, 'no_credited_declaration_count': 144,
    'status_counts': status_counts, 'recommended_status_counts': status_counts.copy(),
    'delivery_state_counts_nonexclusive': dict(sorted(facet.items())),
    'recommended_delivery_state_counts_nonexclusive': dict(sorted(facet.items())),
    'citation_pair_count': sum(citations.values()), 'distinct_cited_declarations': len(citations),
    'recommended_citation_pair_count': 169, 'recommended_distinct_cited_declarations': 164,
    'duplicate_pair_count': sum(len(r['declarations']) - len(set(r['declarations'])) for r in rows),
    'missing_from_supplied_environment_inventory': sorted(set(citations) - inventory_names),
    'shared_declaration_credit': {n: [r['id'] for r in rows if n in r['declarations']] for n, c in citations.items() if c > 1},
    'changed_rows_since_v028': [{'id': r['id'], 'fields': sorted(k for k in set(r) | set(old[r['id']]) if r.get(k) != old[r['id']].get(k))} for r in rows if r != old[r['id']]],
    'unchanged_rows_since_v028': sum(r == old[r['id']] for r in rows),
    'new_family_closures': [],
    'status_transitions': [{'id': 'T005', 'from': 'missing', 'to': 'partial', 'decision': 'accepted_exact_Pareto_slice_general_identity_open'}],
    'T028_scope_decision': copy.deepcopy(prev['T028_scope_decision']),
    'T029_scope_decision': copy.deepcopy(prev['T029_scope_decision']),
    'T029_children': copy.deepcopy(prev['T029_children']), 'Pareto_children': stages,
    'completed_T061_children': copy.deepcopy(prev['completed_T061_children']), 'open_T061_children': [],
    'supplemental_open_EVT_tasks': copy.deepcopy(prev['supplemental_open_EVT_tasks']),
    'dependency_group_counts': groups, 'findings': findings, 'families': families, 'ledger_rows': rows,
    'prior_audit_responses': [
        {'id': 'D028-1', 'state': 'accepted', 'scope': 'T118 cross-credits the existing exact Pareto moment law, uses scoped law/actual-law facets, retains partial and the convexity/Jensen obligations, and cites Eq. (21.7). G20 records the corrected derivative with the positive-order convexity domain.'},
        {'id': 'D028-2', 'state': 'accepted', 'scope': 'T028 exact constant-factor tail locator is printed p.95/PDF109, slow variation p.96/PDF110, and Definition5.1 p.97/PDF111.'},
        {'id': 'D027-3', 'state': 'previous_evidence_boundary_closed', 'scope': 'The package now includes the historical deliverables index at packaging time. Its v0.2.7 row explicitly annotates the old 17-versus-18 count while preserving the shipped historical log. Its v0.2.8 current label is historical, not an unlabelled stale v0.2.9 claim.'}
    ],
    'T118_derivative_scope_note': 'The two derivative formulas agree only at p=1 on the positive-order target domain p>0, alpha>p. As an all-real pointwise assertion this would be too broad: p=-1/8 and alpha=1/4 give an isolated equality. No negative-order convexity is claimed by the repaired T118 specification.',
    'ledger_json_sha256': hashlib.sha256((ROOT / 'docs/FORMALIZATION_BACKLOG.json').read_bytes()).hexdigest(),
    'source_pdf_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'source_pages_reviewed': {'T005': 'Eq.(2.10) printed18/PDF32; proof Eq.(13.4)-(13.7) printed260/PDF274', 'T021': 'Pareto density and centered STD/MD Eq.(4.14) printed86/PDF100', 'T028': 'exact tail printed95/PDF109; slow variation printed96/PDF110; Definition5.1 printed97/PDF111', 'T032': 'Property5.2 and Eq.(5.8) printed100/PDF114', 'T118': 'Proposition21.1 printed381/PDF395; Eq.(21.7) and derivative display printed382/PDF396'},
    'source_gate_count': 20,
    'source_gate_interpretation': 'G01-G20 are targeted checks, not a full source audit. Some diagnose false unrestricted statements, some prescribe repaired domains, and some remain review gates. They do not establish that every gated family is unprovable.',
    'execution_complete': False
}
assert [r['id'] for r in rows] == [f'T{i:03}' for i in range(1, 159)]
assert len(families) == 14 and len(groups) == 22
assert sum(citations.values()) == 169 and len(citations) == 164
assert not d['missing_from_supplied_environment_inventory']
assert d['unchanged_rows_since_v028'] == 152
assert status_counts == {'discharged': 2, 'partial': 12, 'reuse': 4, 'missing': 89, 'source-check': 33, 'model-needed': 15, 'empirical': 3}
(HERE / 'ledger_review.json').write_text(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: d[k] for k in ['status_counts', 'supported_count', 'citation_pair_count', 'distinct_cited_declarations', 'changed_rows_since_v028']}, indent=2))
