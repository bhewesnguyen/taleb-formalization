#!/usr/bin/env python3
"""Build the v0.2.9 progress artifacts without asserting uncompleted execution."""
import argparse
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = 'v0.2.9'
STATUSES = ['discharged', 'partial', 'reuse', 'missing', 'source-check', 'model-needed', 'empirical']
FORBIDDEN_DASHES = ('\u2014', '\u2013', '\u2011')


def clean(value):
    text = str(value)
    for char in FORBIDDEN_DASHES:
        text = text.replace(char, '-')
    return text


def cell(value):
    return clean(value).replace('|', '\\|').replace('\n', ' ')


def table(headers, records):
    return ['| ' + ' | '.join(map(cell, headers)) + ' |', '| ' + ' | '.join('---' for _ in headers) + ' |', *['| ' + ' | '.join(map(cell, row)) + ' |' for row in records], '']


def markdown(d):
    t = [f'# Taleb proof progress, {VERSION}', '',
         'Independent assessment, 21 September 2026. The companion JSON preserves all received fields of all 158 families and adds audited scopes, child obligations, source decisions and independent-execution evidence.', '',
         '## Current position', '', clean(d['independent_execution']['verdict']), '']
    if not d['execution_complete']:
        t += ['**Draft execution status:** independent reproduction is not yet marked complete. The scope assessment below does not assert a completed clean build, verifier or regression run.', '']
    t += ['**Pareto Stage B is accepted.** The actual conditional threshold law, excess law and positive-power pushforward are now identified against the pinned Mathlib Pareto law. T005 moves from missing to partial; T032 gains its exact-law slice. T060 and T061 remain the two discharged families.', '']
    t += table(['Status', 'Received families', 'Recommended families'], [[s, d['status_counts'][s], d['recommended_status_counts'][s]] for s in STATUSES])
    t += ['**Fourteen families have credited Lean work, up from thirteen.** The received ledger contains **169 family/declaration pairs over 164 distinct declarations**, up from 146/142. Of the 23 additional pairs, one is T118 cross-crediting an existing moment theorem; 22 cite the new Stage B declarations. These are not 23 newly independent proofs.', '',
          'The 140 formal-proof families contain two closed and 138 open families. The other 18 families need models or empirical work. There are 144 families without credited declarations, including those model/data families. These are scope counts, not effort-completion percentages or an exhaustive census of the book\'s theorems.', '',
          'Six JSON rows changed since v0.2.8: T005, T021, T028, T029, T032 and T118. The other 152 rows are identical. The exact received rows remain unchanged in `ledger_rows`; the independent assessment is stored separately.', '',
          '## Completed Pareto milestones and remaining children', '']
    t += table(['Child', 'State', 'Scope'], [[x['name'], x['status'], x['scope']] for x in d['Pareto_children']])
    t += ['The threshold theorem includes K=L, because the exact law has no atom at its positive lower endpoint. Its excess law is the conditional law pushed through x-K, with survival one for y<0 and (K/(K+y))^alpha for y>=0, including value one at zero. The two finite first means are distinct: alpha*K/(alpha-1) for the conditional raw variable and K/(alpha-1) for the excess, when alpha>1.', '',
          'For 0<alpha<=1, the exported divergence theorem is the extended nonnegative integral of the **raw conditional first moment**. Excess-law divergence is mathematically valid but has no separate exported theorem in this release. D029-1 asks for this wording precision only; it does not add a new Stage B acceptance gate.', '',
          'The positive-power theorem identifies probability measures for q>0, with shape alpha/q and lower endpoint L^q. Its inverse-event proof is restricted to the positive support. No property of a totalized real power on negative bases is used to claim global monotonicity. Integrability of order p under the image law is equivalent to p<alpha/q.', '',
          'Stage A remains accepted for all real p<alpha, including negative orders. L>0 keeps the support away from zero. For p>=alpha the extended moment is infinite. Raw absolute moments E[|X|^p] do not supply the centered mean absolute deviation E[|X-E X|].', '',
          '## Prior audit responses', '']
    t += table(['Item', 'State', 'Scope'], [[x['id'], x['state'], x['scope']] for x in d['prior_audit_responses']])
    t += ['T118 now correctly credits the actual-law moment formula from Eq. (21.7), printed p.382 / PDF396, while leaving moment-function convexity and integrated Jensen open. Its source correction is m_p\'\'(alpha)=2*p*L^p/(alpha-p)^3 for positive p and alpha>p. The printed expression omits p and uses alpha-1 instead of alpha-p. The phrase "agrees only at p=1" should be understood on that positive-order domain, or as equality of formulas in alpha. Adding either qualification would remove an ambiguity about isolated negative-order coincidences, without changing the proof target.', '',
          'T028 retains the general regularly varying critical-moment statement-review gate. For positive alpha, the critical moment for a tail t^(-alpha)*L(t) is controlled by the integral of L(t)/t; exact Pareto has constant L and diverges, while a sufficiently far-tail factor (log t)^(-2) can give convergence. This explanatory distinction is not a new Lean result.', '',
          '## T029 scope and child obligations', '',
          'The completed binary finite-log-exponent result assumes pointwise nonnegative coordinates, positive weights and finite real exponents, and needs no independence. Its Pareto corollary specializes the exponent premises to concrete Pareto marginal laws. A common joint space and measurable pointwise nonnegative coordinates remain hypotheses. The ledger now says this explicitly; an additional joint realization theorem is not a retrospective acceptance requirement.', '']
    t += table(['Child', 'State', 'Scope and acceptance boundary'], [[x['name'], x['status'], x['scope'] + ' ' + x.get('acceptance_note', '')] for x in d['T029_children']])
    t += ['The stronger unequal-index target remains S_(aX+bY)(t)/S_X(t/a) -> 1, equivalently S_(aX+bY)(t)/S_X(t) -> a^alpha. Exponent equality alone does not imply this ratio or regular variation. Equal-index dependent tails require another statement.', '',
          '## Delivery facets', '',
          'Facets describe scoped components and overlap; their counts cannot be added as completed work. No facet or status change is recommended by this audit.', '']
    names = sorted(d['delivery_state_counts_nonexclusive'])
    t += table(['Facet', 'Received count', 'Recommended count'], [[n, d['delivery_state_counts_nonexclusive'][n], d['recommended_delivery_state_counts_nonexclusive'][n]] for n in names])
    t += ['T005 and T032 have actual-law credit because the conditional and pushforward laws are identified using real probability measures. T118\'s law and realization facets are confined to moment identification, with formula_proved retained for the earlier tail-kernel convexity. These facets do not assert moment-function convexity.', '',
          '## Completed EVT work and supplemental obligations', '']
    t += table(['T061 child', 'State'], [[x, 'complete'] for x in d['completed_T061_children']])
    t += ['T060 covers independent maximum/minimum law identities. T061 covers the three separate EVT families and their positive location/scale maximum laws, not convergence to those laws. The affine definition accepts any real scale; its CDF and maximum rules require positive scale.', '']
    t += table(['ID', 'State', 'Scope', 'Source'], [[x['id'], x['status'], x['scope'], x['source']] for x in d['supplemental_open_EVT_tasks']])
    t += ['S001 and S002 remain open outside the fixed 158-family ledger and do not reopen T061. S001 includes the explicit zero-shape Gumbel branch and the endpoint-coordinate reparameterization. Normalized-maxima convergence remains T011/T062. For exact Pareto shape alpha, the proposed Frechet limit is frechetMeasure(1/alpha), with normalization M_n/(L*n^(1/alpha)).', '',
          '## Documentation finding', '']
    t += table(['Finding', 'Priority', 'Correction'], [[x['id'], x['severity'], x['repair']] for x in d['findings']])
    t += ['## Audited supported families', '']
    for f in d['families']:
        t += [f"### {f['id']}: {clean(f['title'])}", '',
              f"**Received status: {f['current_status']}. Recommended status: {f['recommended_status']}.**", '',
              '**Received facets:** ' + ', '.join(f['current_states']) + '.', '',
              '**Recommended facets:** ' + ', '.join(f['recommended_states']) + '.', '',
              '**Delivered scope:** ' + clean(f['audited_scope']), '',
              '**Recommendation:** ' + clean(f['recommendation']), '',
              '**Remaining target:** ' + clean(f['remaining_target']), '']
    t += ['## Dependency-group position', '',
          'Other open formal combines reuse, missing and source-check. Source-check is a subset of that column. Partial families retain additional work.', '']
    group_rows = []
    for name, group in d['dependency_group_counts'].items():
        c = group['status_counts']
        group_rows.append([name, group['total'], c['discharged'], c['partial'], c['source-check'], sum(c[s] for s in ['reuse', 'missing', 'source-check']), c['model-needed'] + c['empirical']])
    t += table(['Group', 'Families', 'Discharged', 'Partial', 'Source-check subset', 'Other open formal', 'Model / empirical'], group_rows)
    t += ['## Recommended next mathematics', '',
          'T021 centered Pareto dispersion is a coherent next contained milestone. Prove the mean for alpha>1; the variance and standard deviation for alpha>2; the centered absolute deviation; and then Eq. (4.14). The mean absolute deviation is 2*L*(alpha-1)^(alpha-2)*alpha^(1-alpha). For alpha>2 the STD/MD ratio is alpha^(alpha-1/2)/(2*sqrt(alpha-2)*(alpha-1)^(alpha-1)), matching printed p.86 / PDF100. These are target specifications, not delivered Lean theorems. Gaussian and Student work remains in the parent family.', '',
          'The general T005 identity is a useful next reusable theorem: for measurable nonnegative X and K>=0, the extended truncated moment equals K*P(X>K) plus the integral from K to infinity of P(X>t). Prove it with Tonelli/layer-cake, then derive finite conditional and excess means when the first moment is integrable and the conditioning event has positive mass. Strict-tail events handle atoms correctly. The source density identity is Eq.(2.10), printed p.18 / PDF32, proved on printed p.260 / PDF274.', '',
          'T118 convexity/Jensen, the stronger T029 RV child, general T032 power transformation, stable-law realization below alpha=2, concrete subexponential laws and later EVT convergence remain separately scoped. G01-G20 are targeted source checks, not a proof that every gated target is false or an exhaustive source audit. No calendar completion estimate follows from these counts.', '',
          '## Full 158-family index', '',
          'Unsupported rows are tallied without a new full-family mathematical audit. Source locators in this table are the received release anchors. Every original row field is preserved in the companion JSON; the documentation finding and recommendations are separate.', '']
    t += table(['ID', 'Unit', 'Received status', 'Group', 'Priority', 'Family', 'Printed pages'], [[r[k] for k in ['id', 'unit', 'status', 'dependency_group', 'priority', 'title', 'printed_pages']] for r in d['ledger_rows']])
    t += ['## Interpretation limits', '',
          'This tracks formalization scope. It does not establish upstream Mathlib acceptance, exhaustive coverage of every book statement, or operational readiness of the separate quantum/classical software. A family without credited declarations may have reusable dependencies; a partial family may contain substantial completed children.', '']
    return clean('\n'.join(t))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review', type=Path, default=HERE / 'ledger_review.json')
    parser.add_argument('--execution', type=Path, default=HERE / 'execution_summary.json')
    parser.add_argument('--output-dir', type=Path, default=HERE.parent / 'output')
    args = parser.parse_args()
    original = json.loads(args.review.read_text())
    d = copy.deepcopy(original)
    d.update(artifact_type='independent_audit_progress_ledger', assessment_date='2026-09-21', source_review_sha256=hashlib.sha256(args.review.read_bytes()).hexdigest())
    if args.execution.exists():
        execution = json.loads(args.execution.read_text())
        execution.setdefault('verdict', 'Independent execution summary is attached; see its exact state and evidence.')
        d['execution_summary_sha256'] = hashlib.sha256(args.execution.read_bytes()).hexdigest()
    else:
        execution = {'complete': False, 'verdict': 'Independent execution pending: no completed runtime summary is attached to this draft.'}
        d['execution_summary_sha256'] = None
    d['execution_complete'] = execution.get('complete') is True
    d['independent_execution'] = execution
    d['publication_state'] = 'final' if d['execution_complete'] else 'draft_execution_pending'
    rows = d['ledger_rows']
    assert rows == original['ledger_rows']
    assert [r['id'] for r in rows] == [f'T{i:03}' for i in range(1, 159)]
    assert Counter(r['status'] for r in rows) == d['status_counts']
    assert len(d['families']) == 14 and len(d['dependency_group_counts']) == 22
    assert sum(g['total'] for g in d['dependency_group_counts'].values()) == 158
    assert sum(len(r['declarations']) for r in rows) == d['citation_pair_count'] == 169
    assert len({n for r in rows for n in r['declarations']}) == d['distinct_cited_declarations'] == 164
    assert rows == json.loads((HERE / 'received/Taleb_Lean_Repairs/docs/FORMALIZATION_BACKLOG.json').read_text())
    md = markdown(d)
    assert all(c not in md for c in FORBIDDEN_DASHES) and md.endswith('\n')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    jp = args.output_dir / f'Taleb_Proof_Progress_{VERSION}.json'
    mp = args.output_dir / f'Taleb_Proof_Progress_{VERSION}.md'
    jp.write_text(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
    mp.write_text(md)
    print(json.dumps({'json': str(jp.resolve()), 'markdown': str(mp.resolve()), 'publication_state': d['publication_state'], 'family_count': len(rows), 'supported_count': len(d['families']), 'dependency_groups': len(d['dependency_group_counts']), 'findings': [x['id'] for x in d['findings']]}, indent=2))


if __name__ == '__main__':
    main()
