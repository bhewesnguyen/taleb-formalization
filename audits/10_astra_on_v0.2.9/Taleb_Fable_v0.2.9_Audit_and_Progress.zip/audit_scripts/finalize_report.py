"""Finalize the audit only after completed independent runtime evidence."""
from pathlib import Path
import json, re, subprocess, sys, hashlib
BASE=Path(__file__).resolve().parent
s=json.loads((BASE/'reproduction/execution_summary.json').read_text())
assert s['complete'] is True
assert s['fresh_project_build_absent'] and not s['clean_build_diagnostics']
assert s['received_unchanged'] and s['project_source_unchanged']
commands={r['name']:r for r in s['commands']}
assert all(r['exit_code']==0 for r in commands.values())
for name in ['initial_dependencies','final_dependencies']:
    assert len(s[name])==9
    assert all(r['expected']==r['actual'] and r['status_porcelain']=='' for r in s[name])
v=s['normal_verification']; inv=v['environment_inventory']
assert v['status']=='PASS' and v['build_diagnostics_clean']
assert (v['theorem_count'],v['instance_count'],v['alias_count'],v['checked_declarations'])==(181,8,16,205)
assert (inv['constants_scanned'],inv['internal'])==(361,101)
assert all(inv[k] for k in ['all_within_allowlist','no_project_axioms','all_disk_modules_imported',
    'public_inventory_matches_regex','alias_targets_match_replacement_map','backlog_schema_valid',
    'backlog_cited_declarations_exist'])
assert (inv['backlog_families'],inv['backlog_discharged'],inv['backlog_cited_declaration_count'],
        inv['backlog_cited_distinct_declarations'])==(158,2,169,164)
expected={'valid','private_sorry_theorem','private_sorry_def','private_axiom',
    'structure_namespace_theorem','protected_theorem','alias_map_mismatch',
    'alias_map_mismatch_optimized','orphan_module','nested_orphan_module',
    'nested_imported_module','namespace_section_theorem','backlog_duplicate_id','dirty_dependency'}
fixtures=s['regression_results']
assert len(fixtures)==14 and {r['id'] for r in fixtures}==expected
assert all(r['behaved_as_expected'] for r in fixtures)
for i in range(1,4):
    shard=json.loads((BASE/f'reproduction/regression_shard_{i}/harness_regression.json').read_text())
    assert all(r['restored_tree_matches_pristine'] and r['restored_tree_sha256']==shard['pristine_tree_sha256']
               and r['build_dir_reset_from_snapshot'] for r in shard['results'])
    args=commands[f'regression_shard_{i}']['argv']
    assert not Path(args[args.index('--scratch')+1]).is_absolute()
    assert not Path(args[args.index('--out')+1]).is_absolute()
probes=json.loads((BASE/'reproduction/schema_probes/backlog_schema_probes.json').read_text())
assert probes['all_probes_behaved_as_expected'] and len(probes['results'])==18
n=s['received_non_current_file_count']; seconds=s['regression_parallel_elapsed_seconds']
build_text=(BASE/'reproduction/clean_build.log').read_text()
m=re.search(r'Build completed successfully \((\d+) jobs\)',build_text)
jobs=m.group(1) if m else 'recorded'
x={
    'complete':True,
    'verdict':'Independent reproduction passed: clean project build, 205 public checks, all 361 project constants within the allowed axioms, 18 schema/rendering probes and all 14 shipped regression fixtures.',
    'rows':[
        ['Runtime and dependencies','Fresh official Lean 4.24.0 archive matches its expected SHA-256. All nine dependency revisions match the pinned manifest; official cached artifacts fetched.'],
        ['Clean project build',f"PASS; exit 0, {commands['clean_build']['elapsed_seconds']:.2f} s; {jobs} Lake jobs, no compiler warnings/errors."],
        ['Normal verifier',f"PASS; exit 0, {commands['verify']['elapsed_seconds']:.2f} s; 181 theorems, 8 instances, 16 aliases (205 checks)."],
        ['Trust and ledger','361 constants, including 101 internal; only propext, Classical.choice and Quot.sound. 158 valid families; 169 citation pairs over 164 names; raw-byte rendering gate passes.'],
        ['Schema/render probes','PASS 18/18: sixteen malformed cases rejected and two valid controls accepted.'],
        ['Shipped regression',f'PASS 14/14 exactly once; {seconds/60:.1f} min across three isolated, disjoint --only invocations. All source and build restoration checks pass.'],
        ['Final integrity',f'All {n} received files outside generated current evidence match the tested project exactly. Received extraction unchanged; all nine dependencies pinned and clean.'],
    ],
    'detail':'Earlier temporary compiler/dependency caches were absent and the retained old archive was truncated, so a fresh official runtime and exact pinned dependencies were obtained. Setup records are distinct from project outcomes. The project began without project build outputs; dependency build artifacts came from the official Mathlib cache. This is not a rebuild of all Mathlib from source. Regression used real relative scratch/output arguments and separate dependency copies.',
    'counts':{'public_checks':205,'theorems':181,'instances':8,'aliases':16,'constants':361,
        'internal_constants':101,'generated_constants':inv['generated'],'public_definitions':inv['defs'],
        'imported_project_modules':inv['imported_project_modules'],'families':158,'supported_families':14,
        'discharged_families':2,'citation_pairs':169,'distinct_citations':164,'regression_fixtures':14,
        'schema_rendering_probes':18,'additional_real_cli_mutations':0,
        'received_file_count':len(s['source_sha256_received']),'source_files_compared':n},
    'regression_elapsed_seconds':seconds,
    'regression_mode':'Three isolated disjoint --only invocations of the unchanged harness; all shipped fixtures exactly once.',
    'fixture_results':fixtures,'all_source_restoration_hashes_match':True,'all_build_snapshots_restored':True,
    'independent_raw_record':'evidence/reproduction/execution_summary.json',
    'independent_raw_sha256':hashlib.sha256((BASE/'reproduction/execution_summary.json').read_bytes()).hexdigest(),
}
(BASE/'execution_summary.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
for script in ['build_report.py','build_progress.py']:
    subprocess.run([sys.executable,str(BASE/script)],check=True)
print(json.dumps({'complete':True,'regression_seconds':seconds,'compared_files':n,'jobs':jobs},indent=2))
