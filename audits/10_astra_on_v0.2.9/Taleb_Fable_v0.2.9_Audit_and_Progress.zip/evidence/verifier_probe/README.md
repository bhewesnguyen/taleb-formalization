# v0.2.9 verifier evidence

`check_verifier_python.py` compares verification source to the exact prior packaged commit, independently computes the current public inventory and ledger shape, and runs the changed ledger generator on disposable copies under normal and optimized Python. It makes no Lean calls and does not replay external command output.

`results/python_probe_results.json` reports the actual Python and source checks. Its supplied-environment consistency subsection is explicitly distinguished from independent Lean execution. Runtime reproduction belongs to the separate reproduction evidence directory.

The original generator diff is retained as evidence; its prose is authored by the release producer. All received files were unchanged after these checks.
