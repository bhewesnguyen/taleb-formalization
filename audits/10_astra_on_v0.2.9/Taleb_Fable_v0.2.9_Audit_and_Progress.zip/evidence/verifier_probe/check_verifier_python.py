#!/usr/bin/env python3
"""Bounded source and Python checks for v0.2.9. Does not execute Lean."""
import argparse
import ast
import collections
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def sha(b):
    return hashlib.sha256(b).hexdigest()


def snapshot(root):
    return {str(p.relative_to(root)): sha(p.read_bytes())
            for p in sorted(root.rglob('*')) if p.is_file()}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def remove_raw(tree):
    found = 0
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'raw' for t in node.targets):
            node.value = ast.Constant(value='<ledger data removed>')
            found += 1
    require(found == 1, 'Expected one raw ledger assignment')
    return ast.dump(tree, include_attributes=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--base', default='d086ce0cc9ac978e332df4d25bd92994e5f09230')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    received = args.project.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    before = snapshot(received)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    sys.dont_write_bytecode = True
    rows = []
    unchanged = ['scripts/verify.py', 'scripts/backlog_schema.py',
                 'scripts/backlog_schema_probes.py', 'scripts/harness_regression.py',
                 'scripts/FableInventory.lean']

    def prior(path):
        return subprocess.check_output(['git', '-C', str(args.repo.resolve()), 'show',
                                        f'{args.base}:Taleb_Lean_Repairs/{path}'])

    for path in unchanged:
        old, current = prior(path), (received/path).read_bytes()
        require(old == current, f'Unexpected verification code change: {path}')
        rows.append({'file': path, 'unchanged_from_v028': True, 'sha256': sha(current)})
    generator = 'scripts/rebuild_curated_inventory.py'
    old_gen, new_gen = prior(generator), (received/generator).read_bytes()
    require(remove_raw(ast.parse(old_gen)) == remove_raw(ast.parse(new_gen)),
            'Generator code differs outside its raw ledger data')
    (out/'generator.diff').write_bytes(subprocess.check_output([
        'git', '-C', str(args.repo.resolve()), 'diff', args.base, 'HEAD', '--',
        f'Taleb_Lean_Repairs/{generator}']))

    with tempfile.TemporaryDirectory(prefix='taleb_v029_python_probe_') as tmp:
        project = Path(tmp)/'project'
        shutil.copytree(received, project)
        schema = load('backlog_schema', project/'scripts/backlog_schema.py')
        sys.modules['backlog_schema'] = schema
        verifier = load('auditor_verify_v029', project/'scripts/verify.py')
        declarations = verifier.declarations()
        counts = collections.Counter(d['kind'] for d in declarations)
        expected = '\n'.join(['import AuditRepairs', ''] + [
            '#print axioms '+d['name'] for d in declarations])+'\n'
        require((project/'AuditVerification.lean').read_text() == expected,
                'AuditVerification inventory is stale')
        new = [d for d in declarations if d['file'] == 'AuditRepairs/ParetoConditional.lean']
        require(len(new) == 21 and all(d['kind'] == 'theorem' for d in new),
                'New module public theorem count differs from 21')
        require(counts == {'theorem': 181, 'instance': 8, 'alias': 16},
                f'Unexpected public inventory: {dict(counts)}')
        source = (project/'AuditRepairs/ParetoConditional.lean').read_text()
        defs = [line.strip() for line in source.splitlines()
                if line.startswith(('def ', 'noncomputable def '))]
        require(len(defs) == 1 and 'excessLaw' in defs[0], 'Expected exactly one new definition')
        old_prints = [line for line in prior('AuditVerification.lean').decode().splitlines()
                      if line.startswith('#print axioms ')]
        new_prints = [line for line in expected.splitlines() if line.startswith('#print axioms ')]
        old_names = set(old_prints)
        require([line for line in new_prints if line in old_names] == old_prints,
                'Pre-existing public inventory altered or reordered')
        require('import AuditRepairs.ParetoConditional\n' in (project/'AuditRepairs.lean').read_text(),
                'New module missing umbrella import')
        backlog = json.loads((project/'docs/FORMALIZATION_BACKLOG.json').read_text())
        errors = schema.validate(backlog)
        require(not errors, f'Invalid backlog schema: {errors}')
        rendered = schema.render_markdown(backlog).encode('utf-8')
        require((project/'docs/FORMALIZATION_BACKLOG.md').read_bytes() == rendered,
                'Shipped Markdown differs in bytes from shared renderer')
        citations = {(row['id'], name) for row in backlog for name in row['declarations']}

        # Source-level and supplied-record consistency only. These records are not
        # an independent Lean execution and are identified as such in the result.
        inventory = json.loads((project/'evidence/current/inventory_environment.json').read_text())
        supplied_names = {r['name'] for r in inventory['constants']}
        require(all(name in supplied_names for _, name in citations), 'Dangling shipped citation')
        supplied_new = [r for r in inventory['constants']
                        if r['module'] == 'AuditRepairs.ParetoConditional']
        public_new = [r for r in supplied_new if not r['isInternal'] and not r['generated']]
        require(len(public_new) == 22, 'Expected 22 supplied public constants from new module')
        require(len(inventory['constants']) == 361, 'Supplied trust count differs from 361')
        require(all(set(r['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
                    for r in supplied_new), 'Supplied new axiom list outside allowlist')
        generator_results = []
        targets = ['docs/FORMALIZATION_BACKLOG.json', 'docs/FORMALIZATION_BACKLOG.md']
        for optimized in (False, True):
            for target in targets:
                (project/target).write_text('Auditor disposable-output corruption\n')
            cmd = [sys.executable] + (['-O'] if optimized else []) + [generator]
            process = subprocess.run(cmd, cwd=project, env=env, text=True,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            log = f'generator_{"optimized" if optimized else "normal"}.log'
            (out/log).write_text(process.stdout)
            equal = all((project/target).read_bytes() == (received/target).read_bytes()
                        for target in targets)
            require(process.returncode == 0 and equal, 'Generator did not restore exact shipped ledgers')
            generator_results.append({'command': cmd, 'optimized': optimized,
                                      'exit_code': process.returncode,
                                      'both_outputs_equal_received_bytes': equal, 'log': log})

    after = snapshot(received)
    require(before == after, 'Received tree changed during audit')
    result = {
        'status': 'PASS', 'scope': 'Independent Python and source checks; no Lean executed by this driver',
        'base_commit': args.base, 'unchanged_verification_files': rows,
        'generator_code_unchanged_outside_raw_ledger': True,
        'public_inventory': dict(counts), 'checked_public_total': len(declarations),
        'new_module_theorems': new, 'new_module_definitions': defs,
        'preexisting_public_inventory_preserved': True, 'new_module_imported': True,
        'schema_valid': True, 'ledger_rows': len(backlog),
        'markdown_literal_bytes_match': True, 'markdown_bytes': len(rendered),
        'family_declaration_pairs': len(citations),
        'distinct_credited_declarations': len({name for _, name in citations}),
        'supplied_environment_record_consistency_only': {
            'constants': len(inventory['constants']), 'new_module_all_constants': len(supplied_new),
            'new_module_public_constants': len(public_new), 'new_module_axiom_lists_allowed': True,
            'all_credited_names_present': True, 'not_independent_Lean_execution': True},
        'generator_roundtrips': generator_results,
        'received_tree_unchanged': before == after, 'received_file_count': len(before)}
    (out/'python_probe_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: result[k] for k in [
        'status', 'public_inventory', 'ledger_rows', 'family_declaration_pairs',
        'distinct_credited_declarations', 'received_tree_unchanged', 'received_file_count']}, indent=2))


if __name__ == '__main__':
    main()
