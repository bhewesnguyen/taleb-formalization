from pathlib import Path
import concurrent.futures, subprocess, os, json, time, shutil, hashlib, tarfile
BASE=Path('/workspace/scratch/c40a0826d9d8/audit_v029/reproduction')
RECEIVED=BASE.parent/'received/Taleb_Lean_Repairs'
PROJECT=Path('/tmp/taleb_v029_audit_project')
RUNTIME=Path('/tmp/taleb_v029_runtime')
BASE.mkdir(exist_ok=True)
if not PROJECT.exists(): shutil.copytree(RECEIVED,PROJECT)
records=[]
def cmd(name,args,cwd=PROJECT,timeout=None):
    t=time.monotonic()
    with (BASE/(name+'.log')).open('w') as log:
        try: p=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=timeout); rc=p.returncode
        except subprocess.TimeoutExpired: rc=124
    row=dict(name=name,argv=args,cwd=str(cwd),exit_code=rc,elapsed_seconds=round(time.monotonic()-t,2),log=str(BASE/(name+'.log')))
    records.append(row); print(json.dumps(row),flush=True)
    (BASE/'setup_commands.json').write_text(json.dumps(records,indent=2)+'\n')
    return rc
manifest=json.loads((PROJECT/'lake-manifest.json').read_text())
def dep(pkg):
    d=PROJECT/'.lake/packages'/pkg['name']; d.mkdir(parents=True,exist_ok=True)
    if cmd('dep_'+pkg['name']+'_init',['git','init','-q'],d): return False
    if cmd('dep_'+pkg['name']+'_remote',['git','remote','add','origin',pkg['url']],d): return False
    if cmd('dep_'+pkg['name']+'_fetch',['git','fetch','--depth=1','origin',pkg['rev']],d,180): return False
    if cmd('dep_'+pkg['name']+'_checkout',['git','checkout','--detach',pkg['rev']],d): return False
    if pkg['name']=='proofwidgets':
        if cmd('dep_proofwidgets_tag',['git','fetch','--depth=1','origin','tag','v0.0.74'],d,120): return False
    return True

def runtime():
    archive=Path('/tmp/taleb_v029_runtime.tar.zst')
    if cmd('runtime_download',['curl','-fL','--retry','2','--connect-timeout','35','--max-time','240','-o',str(archive),'https://github.com/leanprover/lean4/releases/download/v4.24.0/lean-4.24.0-linux.tar.zst'],timeout=800): return False
    sha=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
    ok=sha=='b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec'
    (BASE/'runtime_archive.json').write_text(json.dumps(dict(path=str(archive),sha256=sha,expected_sha256='b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec',expected_hash_matches=ok),indent=2)+'\n')
    if not ok: return False
    RUNTIME.mkdir(exist_ok=True)
    if cmd('runtime_extract',['tar','--zstd','--no-same-owner','-xf',str(archive),'--strip-components=1','-C',str(RUNTIME)],timeout=120): return False
    return cmd('runtime_version',[str(RUNTIME/'bin/lean'),'--version'])==0
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
    fut={ex.submit(runtime):'runtime'}
    fut.update({ex.submit(dep,p):p['name'] for p in manifest['packages']})
    outcomes={fut[f]:f.result() for f in concurrent.futures.as_completed(fut)}
(BASE/'setup_outcome.json').write_text(json.dumps(outcomes,indent=2)+'\n')
print(json.dumps(outcomes),flush=True)
