from pathlib import Path
import subprocess, json, os, time, shutil, hashlib, re, concurrent.futures, threading
BASE=Path(__file__).resolve().parent
RECEIVED=BASE.parent/'received/Taleb_Lean_Repairs'
PROJECT=Path('/tmp/taleb_v029_audit_project')
RUNTIME=Path('/tmp/taleb_v029_runtime')
ENV=dict(os.environ, PATH=str(RUNTIME/'bin')+os.pathsep+os.environ['PATH'], TAR_OPTIONS='--no-same-owner', PYTHONDONTWRITEBYTECODE='1')
summary={'complete':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'tested_project':str(PROJECT),'received_project':str(RECEIVED),'runtime':str(RUNTIME),'commands':[],'environment_overrides':{'PATH_prepend':str(RUNTIME/'bin'),'TAR_OPTIONS':'--no-same-owner','PYTHONDONTWRITEBYTECODE':'1'}}
lock=threading.Lock()
def dump():
    (BASE/'execution_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
def filehash(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def hashes(root):
    return {str(p.relative_to(root)):filehash(p) for p in sorted(root.rglob('*')) if p.is_file() and '.lake' not in p.relative_to(root).parts}
def cmd(name,args,cwd=PROJECT,timeout=None):
    t=time.monotonic()
    print('START '+name,flush=True)
    with (BASE/(name+'.log')).open('w') as log:
        try: p=subprocess.run(args,cwd=cwd,env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=timeout); rc=p.returncode
        except subprocess.TimeoutExpired: rc=124
    row=dict(name=name,argv=args,cwd=str(cwd),exit_code=rc,elapsed_seconds=round(time.monotonic()-t,2),log=str(BASE/(name+'.log')))
    with lock: summary['commands'].append(row); dump()
    print(json.dumps(row),flush=True)
    return rc

def dependencies():
    rows=[]
    for p in json.loads((PROJECT/'lake-manifest.json').read_text())['packages']:
        d=PROJECT/'.lake/packages'/p['name']
        def git(*args): return subprocess.check_output(['git',*args],cwd=d,text=True).strip()
        rows.append(dict(name=p['name'],expected=p['rev'],actual=git('rev-parse','HEAD'),status_porcelain=git('status','--porcelain','--untracked-files=no')))
    return rows

summary['source_sha256_received']=hashes(RECEIVED)
summary['fresh_project_build_absent']=not (PROJECT/'.lake/build').exists()
shutil.rmtree(PROJECT/'evidence/current',ignore_errors=True)
summary['initial_dependencies']=dependencies()
assert all(x['expected']==x['actual'] and x['status_porcelain']=='' for x in summary['initial_dependencies'])
dump()
if cmd('runtime_version',['lean','--version']): raise SystemExit('runtime unavailable')
summary['runtime_binary_sha256']={str(p.relative_to(RUNTIME)):filehash(p) for p in [RUNTIME/'bin/lean',RUNTIME/'bin/lake']}; dump()
imports=sorted({s for p in RECEIVED.rglob('*.lean') for s in re.findall(r'^import (Mathlib\.[\w.]+)',p.read_text(),re.M)})
summary['cache_direct_imports']=imports; dump()
if cmd('cache',['lake','exe','cache','get',*imports]): raise SystemExit('cache setup failed')
if cmd('clean_build',['lake','build']): raise SystemExit('clean build failed')
summary['clean_build_diagnostics']=[x for x in (BASE/'clean_build.log').read_text().splitlines() if re.search(r'warning:|error:|\bsorry\b',x)]
dump()
if cmd('verify',['python3','scripts/verify.py']): raise SystemExit('normal verification failed')
current=PROJECT/'evidence/current'
summary['normal_verification']=json.loads((current/'verification.json').read_text())
shutil.copytree(current,BASE/'normal_verification')
dump()
if cmd('schema_probes',['python3','scripts/backlog_schema_probes.py','--out',str(BASE/'schema_probes')]): raise SystemExit('schema probes failed')
summary['schema_probes']=json.loads((BASE/'schema_probes/backlog_schema_probes.json').read_text()); dump()
shards=[['valid','private_axiom','structure_namespace_theorem','orphan_module','dirty_dependency'],['private_sorry_theorem','protected_theorem','alias_map_mismatch','nested_imported_module'],['private_sorry_def','alias_map_mismatch_optimized','nested_orphan_module','namespace_section_theorem','backlog_duplicate_id']]
flat=sum(shards,[]); assert len(flat)==len(set(flat))==14
summary['regression_shards']=shards; dump()
t=time.monotonic()
def shard(i,ids):
    args=['python3','scripts/harness_regression.py','--only',','.join(ids),'--scratch',f'../taleb_v029_regression_scratch_{i}','--out',os.path.relpath(BASE/f'regression_shard_{i}',PROJECT)]
    return cmd(f'regression_shard_{i}',args)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
    codes=list(ex.map(lambda item:shard(*item),enumerate(shards,1)))
summary['regression_parallel_elapsed_seconds']=round(time.monotonic()-t,2)
summary['regression_results']=[r for i in range(1,4) for r in json.loads((BASE/f'regression_shard_{i}/harness_regression.json').read_text())['results']]
summary['final_dependencies']=dependencies()
summary['received_unchanged']=summary['source_sha256_received']==hashes(RECEIVED)
baseline={p:h for p,h in summary['source_sha256_received'].items() if not p.startswith('evidence/current/')}
tested={p:h for p,h in hashes(PROJECT).items() if not p.startswith('evidence/current/')}
summary['project_source_unchanged']=baseline==tested
summary['received_non_current_file_count']=len(baseline)
summary['regression_all_pass']=not any(codes) and len(summary['regression_results'])==14 and all(r['behaved_as_expected'] and r['restored_tree_matches_pristine'] and r['build_dir_reset_from_snapshot'] for r in summary['regression_results'])
summary['complete']=summary['regression_all_pass'] and summary['received_unchanged'] and summary['project_source_unchanged'] and all(x['expected']==x['actual'] and x['status_porcelain']=='' for x in summary['final_dependencies'])
summary['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()); dump()
print('COMPLETE '+str(summary['complete']),flush=True)
