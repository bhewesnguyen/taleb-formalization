# Independent v0.2.9 runtime reproduction

These are independent audit commands and observations. Fable's received evidence remains in the immutable received tree and is not substituted for a fresh result here.

The tested project is `/tmp/taleb_v029_audit_project`. The received project is `audit_v029/received/Taleb_Lean_Repairs`. The tested copy starts without project build output. No prior dependency cache survived, so all nine dependency repositories were fetched at the shipped revisions and the official Mathlib cache is downloaded for the 20 directly imported Mathlib modules and their dependency closure. The ProofWidgets v0.0.74 tag was fetched to let Lake locate its pinned release.

The previous local runtime archive was truncated and was not used. A fresh official Lean 4.24.0 Linux archive was downloaded and checked against SHA-256 `b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec` before extraction under `/tmp/taleb_v029_runtime`. Initial short connectivity probes timed out, but normal official upstream requests with longer connection timeouts succeeded. No dependency, compiler pin, project theorem, verification gate, or regression fixture was changed.

`setup_commands.json` records setup commands and timings. `runtime_archive.json` records the archive hash. `reproduce_runtime.py` runs the checks and writes `execution_summary.json`, which is now final with `complete: true` after the requested checks and restoration comparisons succeeded. Normal verification output is copied to `normal_verification/` before regression starts.

The 14 shipped regression fixtures are partitioned into three disjoint concurrent shards. Each shard uses the unmodified harness, its own copied dependencies and pristine project build snapshot, and real relative `--scratch` and `--out` arguments. The source and build restoration checks are performed by the unchanged harness for every fixture. No optional additional expensive fixture is included.

The runtime and dependency binaries are not included in the audit ZIP. The setup and reproduction scripts, exact commands, logs, hashes, counts and per-fixture records are sufficient to distinguish completed independent checks from received claims.

During the concurrent regression run, observed cgroup memory approached its limit, primarily as file cache, with reclaim events and no OOM kill. The auditor issued `POSIX_FADV_DONTNEED` only on the unused original dependency-copy files and downloaded archives. This was an advisory file-cache operation with no content writes and no process interruption. Its exact targets, before/after counters and outcome are in `release_unused_file_cache.py` and `.json`. This observation is not presented as an established explanation of runtime differences.

Final outcome: the clean build and normal verifier passed, all 18 probes and all 14 fixtures behaved as expected, all source restoration checks passed, the received tree was unchanged, and all nine dependency revisions remained pinned and clean. See `../runtime_review.md` for the verified counts and timing table.
