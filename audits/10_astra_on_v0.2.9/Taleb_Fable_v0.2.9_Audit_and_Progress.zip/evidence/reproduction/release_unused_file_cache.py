from pathlib import Path
import os,json,time
BASE=Path(__file__).resolve().parent
paths=[Path('/tmp/taleb_v029_audit_project/.lake/packages'),Path('/tmp/taleb_v029_runtime.tar.zst'),Path('/root/.cache/mathlib')]
def memory():
 return {'current':Path('/sys/fs/cgroup/memory.current').read_text().strip(),'events':Path('/sys/fs/cgroup/memory.events').read_text(),'stat':Path('/sys/fs/cgroup/memory.stat').read_text()}
r={'operation':'POSIX_FADV_DONTNEED on original dependency and downloaded-archive file cache only; contents unchanged','targets':[str(p) for p in paths],'before':memory(),'file_count':0,'errors':[]}
t=time.monotonic()
for root in paths:
 for p in ([root] if root.is_file() else root.rglob('*')):
  if not p.is_file(): continue
  try:
   with p.open('rb') as f: os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
   r['file_count']+=1
  except OSError as e: r['errors'].append({'path':str(p),'error':str(e)})
r['after']=memory();r['elapsed_seconds']=round(time.monotonic()-t,2)
(BASE/'release_unused_file_cache.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('file_count','errors','elapsed_seconds')}))
print('memory_before',r['before']['current'],'memory_after',r['after']['current'])
