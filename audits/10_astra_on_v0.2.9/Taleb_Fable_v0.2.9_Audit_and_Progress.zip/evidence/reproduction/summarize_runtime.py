from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
j=json.loads((BASE/'execution_summary.json').read_text())
if not j.get('complete'): raise SystemExit('Actual independent execution is not complete; no final report written.')
v=j['normal_verification']; inv=v['environment_inventory']; commands={x['name']:x for x in j['commands']}
rows=j['regression_results']; probes=j['schema_probes']['results']
assert len(rows)==14 and len({r['id'] for r in rows})==14
assert all(r['behaved_as_expected'] and r['restored_tree_matches_pristine'] and r['build_dir_reset_from_snapshot'] for r in rows)
assert len(probes)==18 and all(r['behaved_as_expected'] for r in probes)
assert v['status']=='PASS' and j['received_unchanged'] and j['project_source_unchanged']
assert not j['clean_build_diagnostics']
lines=[
'# v0.2.9 independent runtime review','',
'All requested independent runtime gates completed successfully. The received project and all compared source files remained unchanged.','',
'## Environment and scope','',
'The audited copy was `/tmp/taleb_v029_audit_project`. It started without project build output. All nine dependency repositories were freshly fetched at the exact manifest revisions, including the ProofWidgets v0.0.74 release tag. The official Mathlib cache supplied the dependency closure of the 20 directly imported Mathlib modules. No prior project build or dependency cache was reused.','',
'The official Lean 4.24.0 Linux archive was freshly downloaded, verified against SHA-256 `b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec`, and extracted under `/tmp/taleb_v029_runtime`. The compiler identified commit `797c613eb9b6d4ec95db23e3e00af9ac6657f24b`. Mathlib was pinned to `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. All nine initial and final dependency revisions matched their manifest pins, with clean tracked Git working trees; the normal verifier separately accepted dependency cleanliness.','',
'## Results','',
'| Check | Independent result | Wall time |','|---|---|---|',
f"| Official cache fetch | Completed for dependency imports | {commands['cache']['elapsed_seconds']:.2f} s |",
f"| Fresh project `lake build` | Exit 0, no warning/error/sorry diagnostics | {commands['clean_build']['elapsed_seconds']:.2f} s |",
f"| Normal `verify.py` | PASS | {commands['verify']['elapsed_seconds']:.2f} s |",
f"| Schema/rendering probes | {len(probes)}/{len(probes)} behaved as expected | {commands['schema_probes']['elapsed_seconds']:.2f} s |",
f"| Three isolated regression shards | {len(rows)}/{len(rows)} behaved as expected | {j['regression_parallel_elapsed_seconds']:.2f} s elapsed in parallel |",'',
f"The normal verifier checked {v['theorem_count']} theorem declarations, {v['instance_count']} instances and {v['alias_count']} aliases, totaling {v['checked_declarations']} public checks. Its environment inventory scanned {inv['constants_scanned']} constants, including {inv['internal']} internal and {inv['generated']} generated declarations; these categories overlap. It identified {inv['defs']} public non-generated definitions and {inv['imported_project_modules']} imported project modules. All axiom closures stayed within `propext`, `Classical.choice`, and `Quot.sound`; no project axiom was accepted.",'',
f"The same run validated all {inv['backlog_families']} ledger families, their literal Markdown rendering, and {inv['backlog_cited_declaration_count']} family/declaration citations over {inv['backlog_cited_distinct_declarations']} distinct declarations. Exactly {inv['backlog_discharged']} ledger families are marked discharged.",'',
'## Regression isolation','',
'All 14 shipped fixtures ran once each, using the unchanged harness in three disjoint shards. Every shard used its own dependency copy and pristine project build snapshot. The commands passed actual relative `--scratch` and `--out` arguments. Every fixture record confirms restored-source equality and a build reset before mutation. Each shard finished by restoring its disposable project and deleting its scratch directory.','',
'| Fixture | Verifier exit | Verification record | Expected behavior |','|---|---:|---|---|']
for r in sorted(rows,key=lambda x:x['id']): lines.append(f"| {r['id']} | {r['verifier_exit_code']} | {r['verification_status']} | Confirmed |")
lines += ['',f"The received tree contained {len(j['source_sha256_received'])} files. Its entire content hash map was unchanged after execution. The tested project's {j['received_non_current_file_count']} files outside generated `evidence/current/` matched the received copy. All normal verification evidence was saved before fixtures ran; received Fable logs were not substituted for actual execution.",'',
'## Reproduction evidence','',
'During the parallel run, cgroup memory approached its limit, primarily as file cache, without an OOM kill. The auditor advised the OS to discard unused file-cache pages belonging to the original dependency copy and downloaded archives, leaving active shard copies untouched. This changed no file content or test and interrupted no process. Exact targets, timing and before/after counters are recorded in `release_unused_file_cache.py` and `.json`. Resource pressure was observed; it is not asserted to explain the timing differences.','',
'`execution_summary.json` contains exact commands, exit codes, timings, original source hashes, dependency states, the complete normal verifier record and per-fixture outcomes. `normal_verification/` contains the actual build, axiom and environment-inventory logs. `schema_probes/` and `regression_shard_1/` through `regression_shard_3/` contain fresh probe and fixture evidence. Setup commands, archive identity, host details and the driver are retained separately.','',
'These checks establish compilation, trust-scan behavior and the claimed formal declarations in the supplied project. They do not establish complete book coverage, Mathlib upstream acceptance, mathematical novelty, numerical software correctness or deployment readiness.','']
(BASE.parent/'runtime_review.md').write_text('\n'.join(lines))
print('Final runtime review written.')
