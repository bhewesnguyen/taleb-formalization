#!/usr/bin/env python3
"""Compare retained standalone prior PDF with byte-preserved prior audit ZIP member."""
from pathlib import Path
import hashlib,json,subprocess
from PIL import Image
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'audit_v029/provenance'
a=OUT/'prior_zip_report.pdf'
b=OUT/'repo/audits/09_astra_on_v0.2.8/Taleb_Fable_v0.2.8_Independent_Audit.pdf'
sha=lambda b:hashlib.sha256(b).hexdigest()
def run(args): return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
info={}
for label,path in [('zip_member',a),('standalone',b)]:
    info[label]={'sha256':sha(path.read_bytes()),'pdfinfo':run(['pdfinfo',str(path)]).decode()}
    run(['pdftotext','-layout',str(path),str(OUT/(label+'.txt'))])
    prefix=OUT/('render_'+label)
    run(['pdftoppm','-r','150','-png',str(path),str(prefix)])
text_a=(OUT/'zip_member.txt').read_bytes();text_b=(OUT/'standalone.txt').read_bytes()
pa=sorted(OUT.glob('render_zip_member-*.png'));pb=sorted(OUT.glob('render_standalone-*.png'))
assert len(pa)==len(pb)
checks=[]
for x,y in zip(pa,pb):
    with Image.open(x) as xx,Image.open(y) as yy:
        aa=xx.convert('RGB');bb=yy.convert('RGB')
        checks.append({'page':len(checks)+1,'size_a':aa.size,'size_b':bb.size,'pixel_sha_a':sha(aa.tobytes()),'pixel_sha_b':sha(bb.tobytes()),'equal':aa.size==bb.size and aa.tobytes()==bb.tobytes()})
assert text_a==text_b and all(c['equal'] for c in checks)
result={'inputs':info,'literal_pdf_bytes_equal':a.read_bytes()==b.read_bytes(),'pdftotext_layout_equal':text_a==text_b,'page_count':len(pa),'renderer':'Poppler pdftoppm, 150 dpi, RGB pixel buffers via Pillow','pages':checks,'all_page_pixels_equal':all(c['equal'] for c in checks),'interpretation':'Binary representations differ; extracted text and every rendered page are identical. No substantive page change found. Cause of representation change not established.'}
(OUT/'previous_pdf_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
