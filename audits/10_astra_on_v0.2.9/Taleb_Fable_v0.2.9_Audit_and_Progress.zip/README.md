# Taleb Lean v0.2.9 independent audit

Reviewed release ZIP SHA-256:
`abbea690e34bfde5799b8384b727e834d6a319f25cdda52c851c61eca602b77e`.

Accept Pareto Stage B. No Lean proof defect was identified. The actual threshold
conditional law, global excess CDF/survival, finite means, conditional raw
first-moment divergence and positive-power pushforward have the correct scope.
T005 moves to partial; T032 receives a law slice. T060 and T061 remain the only
discharged parent families. The received project is unchanged.

## Contents and one correction

The PDF and editable Markdown contain the consolidated audit. The progress files
preserve all 158 received family rows and add separate annotations, fourteen
supported scopes, 22 dependency-group tallies, completed/open children and the
supplemental S001/S002 tasks. Their counts are coverage counts, not an estimate
of effort completed.

D029-1 is a low wording correction: grouped means summaries and T005's delivered
scope should explicitly say conditional raw first-moment divergence. No separate
extended first moment of excessLaw is exported. Such a theorem is optional, not
a new acceptance condition. The preserved received rows still contain the
ambiguous wording; read the separate recommendations.

The prior T118 cross-credit and T028 source-locator repairs are accepted. The
historical count annotation is now inside the release and matches the repository
index, resolving the earlier evidence boundary. G20's corrected derivative is
right; its optional prose qualification is not a second numbered finding.

The Fable handoff specifies the next exact-Pareto centered MAD/STD milestone,
reusing Stage B at the mean, and a separate later general layer-cake milestone
for T005. These are specifications, not implemented new Lean proofs. The detailed
general tail-integral specification and exact pinned API evidence are included
with the subreviews.

## Independent execution

`evidence/reproduction/` contains actual setup, build, verifier, schema and
regression logs, commands and timings. Runtime setup recovered after finding the
old retained archive truncated: a fresh official Lean4.24.0 archive matched its
expected hash. All nine dependency checkouts match the manifest pins. Mathlib's
official cached build artifacts were fetched; the project began without its own
build outputs. This is not a full Mathlib source rebuild.

All fourteen shipped regression fixtures ran exactly once in three concurrent
disjoint --only invocations of the unchanged harness. Each used isolated copies,
real relative scratch/output arguments, and the original source/build snapshot
restoration checks. This is full partitioned fixture coverage, not one sequential
suite invocation. Negative verifier exits are expected for deliberate defects;
the three harness commands themselves must pass.

The current eighteen schema/rendering probes are separate from fixture coverage.
The verifier, schema, probe suite, harness and Lean inventory scanner are unchanged
since v0.2.8. `evidence/verifier_probe/` contains bounded actual Python source and
generator checks, including normal and optimized generator round trips. No new
CRLF mutation or replayed-command campaign was run in this release. These Python
checks are not extra Lean proof evidence.

## Provenance and scope

`evidence/provenance/` records archive, manifest, bundle, both patch routes,
retained-artifact hashes and the now-inspectable index snapshot. All 28 old
mathematical modules remain unchanged. The bundle proves its committed snapshot
and history, not the author's live worktree cleanliness or remote state. The
fourth current-deliverables commit is outside the bundle.

The prior standalone audit PDF and its ZIP member differ in representation, but
all eight page texts and rendered RGB buffers match. No substantive change or
cause of the byte difference is asserted. The repository-only scope memo is
historical; its forecasts and broad infrastructure claims are not endorsed here.

The source book is arXiv:2001.10488v4, 523 pages, SHA-256
`758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567`.
Source pages, compiler archives, dependency caches, temporary worktrees and
duplicate input packages are excluded from this ZIP. Audit scripts retain local
paths as execution/report evidence; they are not portable installation scripts.

This audit does not certify exhaustive atomic book coverage, upstream Mathlib
integration, empirical claims or operation of the separate quantum/classical app.
SHA256SUMS covers every included file except itself.
