# v0.2.9 independent runtime review

All requested independent runtime gates completed successfully. The received project and all compared source files remained unchanged.

## Environment and scope

The audited copy was `/tmp/taleb_v029_audit_project`. It started without project build output. All nine dependency repositories were freshly fetched at the exact manifest revisions, including the ProofWidgets v0.0.74 release tag. The official Mathlib cache supplied the dependency closure of the 20 directly imported Mathlib modules. No prior project build or dependency cache was reused.

The official Lean 4.24.0 Linux archive was freshly downloaded, verified against SHA-256 `b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec`, and extracted under `/tmp/taleb_v029_runtime`. The compiler identified commit `797c613eb9b6d4ec95db23e3e00af9ac6657f24b`. Mathlib was pinned to `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. All nine initial and final dependency revisions matched their manifest pins, with clean tracked Git working trees; the normal verifier separately accepted dependency cleanliness.

## Results

| Check | Independent result | Wall time |
|---|---|---|
| Official cache fetch | Completed for dependency imports | 454.70 s |
| Fresh project `lake build` | Exit 0, no warning/error/sorry diagnostics | 204.01 s |
| Normal `verify.py` | PASS | 398.51 s |
| Schema/rendering probes | 18/18 behaved as expected | 0.07 s |
| Three isolated regression shards | 14/14 behaved as expected | 2248.05 s elapsed in parallel |

The normal verifier checked 181 theorem declarations, 8 instances and 16 aliases, totaling 205 public checks. Its environment inventory scanned 361 constants, including 101 internal and 120 generated declarations; these categories overlap. It identified 35 public non-generated definitions and 30 imported project modules. All axiom closures stayed within `propext`, `Classical.choice`, and `Quot.sound`; no project axiom was accepted.

The same run validated all 158 ledger families, their literal Markdown rendering, and 169 family/declaration citations over 164 distinct declarations. Exactly 2 ledger families are marked discharged.

## Regression isolation

All 14 shipped fixtures ran once each, using the unchanged harness in three disjoint shards. Every shard used its own dependency copy and pristine project build snapshot. The commands passed actual relative `--scratch` and `--out` arguments. Every fixture record confirms restored-source equality and a build reset before mutation. Each shard finished by restoring its disposable project and deleting its scratch directory.

| Fixture | Verifier exit | Verification record | Expected behavior |
|---|---:|---|---|
| alias_map_mismatch | 1 | FAIL | Confirmed |
| alias_map_mismatch_optimized | 1 | FAIL | Confirmed |
| backlog_duplicate_id | 1 | FAIL | Confirmed |
| dirty_dependency | 1 | FAIL | Confirmed |
| namespace_section_theorem | 0 | PASS | Confirmed |
| nested_imported_module | 0 | PASS | Confirmed |
| nested_orphan_module | 1 | FAIL | Confirmed |
| orphan_module | 1 | FAIL | Confirmed |
| private_axiom | 1 | FAIL | Confirmed |
| private_sorry_def | 1 | FAIL | Confirmed |
| private_sorry_theorem | 1 | FAIL | Confirmed |
| protected_theorem | 1 | FAIL | Confirmed |
| structure_namespace_theorem | 1 | FAIL | Confirmed |
| valid | 0 | PASS | Confirmed |

The received tree contained 255 files. Its entire content hash map was unchanged after execution. The tested project's 246 files outside generated `evidence/current/` matched the received copy. All normal verification evidence was saved before fixtures ran; received Fable logs were not substituted for actual execution.

## Reproduction evidence

During the parallel run, cgroup memory approached its limit, primarily as file cache, without an OOM kill. The auditor advised the OS to discard unused file-cache pages belonging to the original dependency copy and downloaded archives, leaving active shard copies untouched. This changed no file content or test and interrupted no process. Exact targets, timing and before/after counters are recorded in `release_unused_file_cache.py` and `.json`. Resource pressure was observed; it is not asserted to explain the timing differences.

`execution_summary.json` contains exact commands, exit codes, timings, original source hashes, dependency states, the complete normal verifier record and per-fixture outcomes. `normal_verification/` contains the actual build, axiom and environment-inventory logs. `schema_probes/` and `regression_shard_1/` through `regression_shard_3/` contain fresh probe and fixture evidence. Setup commands, archive identity, host details and the driver are retained separately.

These checks establish compilation, trust-scan behavior and the claimed formal declarations in the supplied project. They do not establish complete book coverage, Mathlib upstream acceptance, mathematical novelty, numerical software correctness or deployment readiness.
