# v0.2.9 provenance review

Date: 21 September 2026.

## Verdict

The supplied v0.2.9 archive, both patch routes, and the committed project tree agree. No provenance defect was found. The newly included deliverables-index snapshot resolves the D027-3 inspectability limit noted in the v0.2.8 audit. The archived snapshot is historical and correctly retains the index's then-current v0.2.8 label.

This report checks supplied bytes and committed history. It does not infer the original working tree's cleanliness or remote push state, and it does not substitute the supplied execution logs for the separate independent runtime reproduction.

## Archive and exact tree

| Check | Independently established result |
|---|---|
| Archive SHA-256 | `abbea690e34bfde5799b8384b727e834d6a319f25cdda52c851c61eca602b77e` |
| Contents | 288 ZIP entries, 255 files |
| Manifest | 254 unique file entries, all match, covering every file except `SHA256SUMS` itself |
| Paths and contents | No duplicate names, path traversal, symlinks, `.lake`, `.git`, bytecode or compiled project outputs |
| Local extraction | Exact file set and file bytes agree with the archive |
| Bundle commit | `382faa0cfb13ccc8f5586ef89b903c2874aeddd6` |
| Project subtree | `2931c3c6a54e6259d225f690b2a272d90dc08aef` |
| Bundle verification | Complete history, `refs/heads/main` at the stated commit |
| Archive versus commit | Exact equality of all 255 project files |

The project subtree is `Taleb_Lean_Repairs/`. An equality of this subtree does not mean the archive includes the entire repository, which also holds audit receipts, release deliverables and the scope memo.

The clone initially had no checkout because the bundle's remote HEAD did not name its main ref. Explicitly checking out the supplied `main` ref succeeded. This is a routine bundle-clone detail, not an integrity failure.

## Patch routes and preserved code

Both patches were applied with `git apply --cached --check` followed by `git apply --cached` to distinct temporary Git indexes initialized at the stated bases. Each resulting project subtree was compared by tree ID, full path set and every file's bytes. The audit checkout and immutable received extraction were not changed by these patch applications.

| Route | Base commit | Changed project files | Result |
|---|---|---:|---|
| v0.2.0 to v0.2.9 | `f6b100762540655184b96dd4e0c8f8fd0233da28` | 203 | Exact packaged subtree |
| v0.2.8 to v0.2.9 | `d086ce0cc9ac978e332df4d25bd92994e5f09230` | 38 | Exact packaged subtree |

All 28 pre-existing `.lean` modules under `AuditRepairs/` and `Proofs/` are byte-identical to v0.2.8. The new mathematical module is `AuditRepairs/ParetoConditional.lean`; the project root adds its import and the generated verification file adds inventory checks. This substantiates the claim that pre-existing mathematical modules were not modified.

Both `lean-toolchain` and `lake-manifest.json` are byte-identical to the pristine v0.2.0 base and the v0.2.8 packaged tree. The independently reproduced runtime checks, reported separately, establish that the pinned environment was actually used.

## Prior release and audit preservation

All 26 entries in `audits/RECEIVED_ARTIFACTS.sha256` match their retained files. The retained v0.2.8 release ZIP hashes to `696c5187ed87bb0ad428bbbdd78185758de5b437fb14a9e2411c07b32a8ccbb0`.

The prior independent audit ZIP hashes to `3cbb8ee00e86828af538134403a78fe850b9bba05eb4775e58b81eff63500954`, matching the prior delivered checksum supplied in the audit context. Its 93 internal manifest entries all pass. The retained standalone progress Markdown and Fable handoff Markdown are byte-identical to their members of that ZIP.

The prior standalone PDF differs at the binary level:

| Representation | SHA-256 |
|---|---|
| PDF inside prior audit ZIP | `83fa788a4ba7e9a6cebdd5986c6cc3eeb4dd91fa50f1e4b95f55dbb5da89c142` |
| Retained standalone PDF | `0d71cf28204885e768e9e4ba6f2c10cc617a8d2bb90ac3dc18b7dc09712d0945` |

Comparison with `pdftotext -layout` found identical extracted text. Rendering each PDF with Poppler at 150 dpi and comparing the RGB pixel buffers found every one of the eight pages identical, including dimensions. No substantive page change was found. The cause of the binary representation difference was not established.

## D027-3 annotation is now inspectable

`evidence/fable/v0.2.9/deliverables_index_at_packaging.md` consists of a provenance preamble followed by the repository's `deliverables/README.md`. Removing only that preamble and its separating blank line leaves byte-identical content, SHA-256 `595a6dee15c15a69b07c300a1b0d0d62edd40db62845ff154496a2da6f226e05`.

The repository index has those exact bytes at the v0.2.8 deliverables commit `287bbd8`, the current audit-receipt commit `886f2e3`, and the v0.2.9 packaged commit `382faa0`. Its v0.2.7 row visibly annotates the old validation log's incorrect "17 probes ok" count, identifies 18 actual results and explains the missed clean-ledger control. The original v0.2.7 log remains byte-identical to its copy at `499e9e0`.

Therefore the historical correction is now established from the supplied package and history. The snapshot's "current v0.2.8" wording is appropriate for this pre-v0.2.9-deliverables index; it is not presented as the current release ledger. The later index after the announced fourth commit remains outside this bundle, but is unnecessary to establish the historical annotation.

The supplied v0.2.9 fresh-extraction log says the count is derived from JSON and reports 18/18. The shipped `backlog_schema_probes.json` contains 18 successful expected outcomes. This is a consistency check on supplied evidence; the separate runtime review reports its own probe execution.

## History and scope boundaries

Three commits after the v0.2.8 deliverables commit are present in the bundle:

1. `886f2e3`: receipt of the v0.2.8 audit and repository-only scope memo.
2. `f5e90e8`: D028 ledger corrections, G20 and Pareto Stage B.
3. `382faa0`: final evidence and manifest for the packaged project.

The brief explicitly says that the fourth, current deliverables commit is later than this bundle. Its existence, the final original worktree status, and remote push state are not independently established here. The attached current audit brief and fresh-extraction log are hashed as inputs, but their exact bytes are outside the project subtree and this pre-deliverables bundle.

`SCOPE_MEMO_v0.2.8.md` is present in the repository at commit `886f2e39836d939b05423d8fcd2b043cbdfd74c1`, SHA-256 `54acd015e02303ecea255f47fdcc9e44161f98deef9c2ff7bc26cad622fbe9de`. It is absent from the handoff archive and explicitly calls itself a historical personal working reference. This provenance review does not validate its effort forecasts or broad claims about absent Mathlib infrastructure. Current progress should come from the audited v0.2.9 ledger.

## Reproduction records

- `provenance/check_provenance.py`, `check_provenance.log`, `provenance.json`.
- `provenance/bundle_verify.log`, `recent_history.log`.
- `provenance/compare_previous_pdf.py`, `compare_previous_pdf.log`, `previous_pdf_comparison.json`.

The review package can preserve these small scripts and results while excluding the audit checkout, duplicated prior archives, temporary PDF copies, rendered page images and extracted PDF text.
