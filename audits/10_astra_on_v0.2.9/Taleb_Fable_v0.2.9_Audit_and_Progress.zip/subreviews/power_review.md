# v0.2.9 source review: positive Pareto powers and the next centered-moment slice

Date: 21 September 2026.

## Verdict and limits of this review

The positive-power law is mathematically correct as stated. Its four helper lemmas make the support and real-power requirements explicit. I found no false theorem, hidden realization premise, or misuse of totalized real powers in this part of `AuditRepairs/ParetoConditional.lean`.

This is a source and mathematical review. It does not independently claim a local Lean compilation or trust-scan result. The root audit records execution evidence separately. I did not change the received project or run additional Lean tests.

The reviewed sources are the received `ParetoConditional.lean`, the Stage A `ParetoLaw.lean`, the current ledger and source gates, and the exact pinned Mathlib real-power and variance source files. The Mathlib API signatures were checked again against the local pinned checkout at `/tmp/taleb_v029_audit_project/.lake/packages/mathlib` after it became available; that check also covered `L2Space.lean` and the conditional-probability and Bochner integration APIs used by the suggested next route. The book's printed pages 86 and 100, PDF pages 100 and 114, were inspected visually as well as extracted to text. Source-page images are `audit_v029/source/power_pdf100.png` and `audit_v029/source/power_pdf114.png`.

## The four helper lemmas

1. `paretoMeasure_apply_inter_Ici` removes only the null part below the lower endpoint. For any set `A`, the difference `A \\ Ici L` lies in `Iio L`, which Stage A proves null. Decomposing a measure across the measurable set `Ici L` proves the claimed equality. The absence of positivity assumptions here is sound: the density vanishes below its cutoff for all parameter values. The main probability-law theorem supplies positive parameters separately. No measurability assumption on `A` is needed for this decomposition.

2. `preimage_rpow_Iic_inter_Ici_eq_empty` treats every CDF argument below `L^q`, including negative arguments and zero. If `y >= L > 0` and `q > 0`, monotonicity gives `y^q >= L^q`, contradicting `y^q <= x < L^q`. No inverse-power identity is applied in this branch.

3. `preimage_rpow_Iic_inter_Ici` handles `x >= L^q`. This branch implies `x > 0`, although the imported inverse comparison lemma only needs `x >= 0`. Membership in `Ici L` gives `y >= L > 0`. The exact pinned signature of `Real.le_rpow_inv_iff_of_pos` requires two nonnegative bases and a strictly positive exponent; all three arguments are supplied. The resulting set is `Iic (x ^ q⁻¹) \\ Iio L`, retaining the lower endpoint. Both directions of the equivalence use the correct orientation of the inverse comparison.

4. `pareto_power_algebra` converts `(L / x^(1/q))^α` to `(L^q / x)^(α/q)` using `Real.div_rpow`, `Real.rpow_rpow_inv`, and `Real.rpow_mul`. Their nonnegative-base and nonzero-exponent conditions are supplied. The helper legitimately allows arbitrary real `α` and nonnegative `x`; in its probability-law use, `α > 0` and `x >= L^q > 0` hold. Its slightly broader algebraic statement is not a probability claim about the totalized zero-denominator boundary.

The argument never asserts that `y^q <= x` is equivalent to `y <= x^(1/q)` on all real `y`. That unrestricted assertion would fail for some totalized powers on negative bases. The proof intersects with the positive support before using inverse powers.

## Equality of laws and moment threshold

`map_rpow_paretoMeasure` assumes exactly `L > 0`, `α > 0`, and `q > 0`. It proves positivity of the output parameters `L^q` and `α/q`, establishes probability-measure instances for the input and output, and uses measurability of the globally defined real power to establish the mapped probability instance.

The CDF argument then applies `Measure.map_apply`, restricts the preimage to `Ici L`, and splits at the output lower endpoint. Below it, the support preimage is empty. At and above it, dropping the null set `Iio L` gives the original Pareto CDF at `x^(1/q)`; the algebra helper gives the target CDF. Equality of CDFs for probability measures yields the equality of measures. The endpoint `x = L^q` is in the second branch and has CDF zero. Negative CDF arguments are covered by the first branch. There is no lost boundary mass and no assumed CDF-realization premise.

The final theorem is therefore the concrete identity

`(paretoMeasure L α).map (fun x => x ^ q) = paretoMeasure (L ^ q) (α / q)`.

The corollary `integrable_rpow_map_rpow_paretoMeasure_iff` reuses this equality and Stage A's integrability theorem. It holds for every real moment order `p`, with condition `p < α/q`, equivalent to `p*q < α` because `q > 0`. Negative moment orders are valid because the output law has strictly positive lower endpoint `L^q`.

The book's Property 5.2 on printed page 100, PDF page 114, states the exponent transformation `α/p`; the delivered exact-Pareto law is a valid slice of this content. It also supplies the transformed support, which the source's informal change-of-density discussion does not handle carefully. No result for `q = 0`, `q < 0`, or a general regularly varying law is claimed. T032 should remain partial under its broader target.

Splitting the original proof into these helper lemmas is a useful improvement in auditability. I cannot independently attribute the reported heartbeat improvement without the original failed run, and no such performance attribution is needed for mathematical acceptance.

## Small precision issue in the new G20 prose

The corrected derivative and the proposed positive-order convexity target are right. One phrase deserves a qualification: the printed derivative and corrected derivative agree "only at p = 1" on the intended domain of positive moment orders. Interpreted as a pointwise claim for all real `p < α`, it is false.

For example, set `L = 1`, `p = -1/8`, and `α = 1/4`. Then both `2 L^p/(α - 1)^3` and `2 p L^p/(α - p)^3` equal `-128/27`. These parameters satisfy the actual Pareto moment domain. This does not challenge the corrected derivative or any delivered Lean theorem. A sufficient wording repair is "for positive moment orders, it agrees only at p = 1" or simply "it agrees at p = 1." The latter also avoids confusion between equality at one parameter pair and identity as a function of `α`.

## Precise next T021 Pareto target

Write `ν = paretoMeasure L α`, with `L > 0`. All formulas below are future targets, not claims of new formalization by this review.

For `α > 1`, define and identify the mean

`m = ∫ x, x dν = α L / (α - 1)`.

The centered mean absolute deviation is

`MAD = ∫ x, |x - m| dν`

`    = 2 L^α m^(1 - α) / (α - 1)`

`    = 2 L (α - 1)^(α - 2) / α^(α - 1)`.

This is deviation about the mean. It is neither the already delivered raw absolute moment `∫ |x| dν` nor median absolute deviation. It requires a new centered-integral argument, even though the raw mean and second moment are already available.

For `α > 2`, the second moment and variance are

`E[X²] = α L² / (α - 2)`,

`Var(X) = α L² / ((α - 1)² (α - 2))`.

Hence

`STD = L / (α - 1) * sqrt(α / (α - 2))`,

`STD / MAD = α^(α - 1/2) / (2 sqrt(α - 2) (α - 1)^(α - 1))`.

The ratio is exactly the book's Eq. (4.14), printed page 86 / PDF page 100, which writes its equivalent reciprocal form

`1 / (2 sqrt(α - 2) (α - 1)^(α - 1) α^(1/2 - α))`.

## Suggested implementation route

First derive the mean and its integrability from the Stage A theorem at order 1. Prove `m > L`, then derive integrability of `x - m`, `|x - m|`, and the positive part. The MAD theorem can reuse Stage B instead of introducing another density integration or waiting for a general layer-cake theorem:

1. At threshold `K = m`, the new excess-mean result gives conditional mean excess `m/(α - 1)`.
2. Convert its normalized conditional integral back to the restricted original integral, with the positive finite conditioning mass explicitly justified. Stage A gives `ν.real (Ioi m) = (L/m)^α`.
3. Therefore `∫_(Ioi m) (x - m) dν = (L/m)^α * m/(α - 1)`.
4. Since `∫ (x - m) dν = 0`, the identity `|x - m| = 2 max(x - m, 0) - (x - m)` gives the MAD formula. All terms are integrable, so the decomposition is legitimate.

For variance, derive `MemLp (fun x => x) 2 ν` from the delivered second-moment integrability using the pinned `MeasureTheory.memLp_two_iff_integrable_sq`, then use `ProbabilityTheory.variance_eq_sub`. The latter API requires `MemLp X 2 μ`; merely rewriting two raw moments without supplying finiteness is insufficient. Prove positivity of the variance and MAD before cancellation and square-root algebra in the ratio theorem.

Keep the ratio theorem restricted to `α > 2` and the mean/MAD theorems to `α > 1`. The pinned real-valued variance is `evariance.toReal`, so its value outside the finite range cannot be used as evidence of finiteness or divergence. An optional divergence result should use `evariance` or an extended nonnegative integral. No such extra result is necessary for this bounded next milestone.

As a small mathematical check, at `L = 1`, `α = 3`, the formulas give mean `3/2`, variance `3/4`, MAD `4/9`, and ratio `9 sqrt(3)/8`. This is an optional corollary, not a new regression requirement.

Completing this slice should leave T021 partial because its Gaussian and Student targets remain separate. The general tail-integral identity of T005 can proceed independently as a later or parallel milestone.

## Exact pinned sources consulted

- [Mathlib real powers at f897ebcf72cd16f89ab4577d0c826cd14afaafc7](https://raw.githubusercontent.com/leanprover-community/mathlib4/f897ebcf72cd16f89ab4577d0c826cd14afaafc7/Mathlib/Analysis/SpecialFunctions/Pow/Real.lean): the inverse comparison and power-algebra hypotheses used by the received code.
- [Mathlib variance at the same pin](https://raw.githubusercontent.com/leanprover-community/mathlib4/f897ebcf72cd16f89ab4577d0c826cd14afaafc7/Mathlib/Probability/Moments/Variance.lean): `variance`, `evariance`, and the `MemLp` premise of `variance_eq_sub` for the future implementation route.
- Taleb, *Statistical Consequences of Fat Tails*, supplied version `2001.10488v4(1).pdf`: Eq. (4.14), printed page 86 / PDF page 100; Property 5.2 and Eq. (5.8), printed page 100 / PDF page 114.
