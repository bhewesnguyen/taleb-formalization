# Later T005 milestone: general upper-tail and excess identities

This is a proposed implementation target, not a theorem delivered in v0.2.9. Keep it separate from the next contained T021 centered-Pareto-moment milestone.

## Scope and hypotheses

Use a probability space with measure P, a measurable real random variable X that is nonnegative P-almost everywhere, and K>=0. Write

`A_K = {omega | K < X omega}`,

`S(t) = P {omega | t < X omega}` in the extended nonnegative reals.

The initial targets use extended nonnegative integrals and require no finite first moment. They require no density or no-atoms premise. In particular, an atom at X=K is excluded from the strict-threshold event and does not invalidate the formulas. The current ledger already records nonnegative X and K as its baseline domain.

## First targets: extended identities

Prove

`integral_plus over A_K of ofReal(X) dP = ofReal(K) * P(A_K) + integral_plus over t>K of S(t) dt`.

Here `integral_plus` means Lean's `lintegral`, so both sides take values in `ENNReal` and may be infinite.

Also prove the positive-part/excess payoff identity

`integral_plus of ofReal(X-K) dP = integral_plus over t>K of S(t) dt`.

The second integrand already represents the positive part because `ofReal` clips negative values. Equivalently, one can state it as the extended integral over A_K of `ofReal(X-K)`.

A direct route for the first target is to apply the existing layer-cake theorem to `Y = A_K.indicator X`. For 0<t<=K, the event Y>t is A_K. For t>K, it is X>t. Splitting the layer-cake integral over `(0,K]` and `(K,infinity)` gives the boundary term exactly. This also includes K=0, where the first interval is empty. For the excess identity, apply layer-cake to `max (X-K) 0` and translate the threshold parameter. Do not subtract extended integrals to manufacture the excess formula, since infinity minus infinity would lose the intended statement.

The truncated and positive-part identities in fact admit stronger hypotheses than the book requires: when K>=0, global nonnegativity of X is unnecessary because only X>K contributes. Dropping that hypothesis is optional and is not a requirement for the next milestone.

## Real and conditional consequences

Add `Integrable X P` for the ordinary real-valued versions. Establish integrability of the truncated variable and positive part, and finiteness of the nonnegative tail integral, before applying `toReal` or linearity. Prove

`integral over A_K of X dP = K * P.real(A_K) + J_K`,

where `J_K = integral over t>K of P.real{X>t} dt`.

For `P(A_K) != 0`, the pinned `ProbabilityTheory.cond P A_K` is a probability measure. Write `s_K = P.real(A_K) > 0`. Derive, as integrals under that conditional measure,

`conditional raw mean = K + J_K / s_K`,

`conditional mean excess = J_K / s_K`.

These should remain distinct theorem statements. Confirm the formula against Pareto with L>0, alpha>1 and K>=L: the existing Stage B formulas give raw mean `alpha*K/(alpha-1)` and mean excess `K/(alpha-1)`.

For a measure-law interface, the same formulas may first be proved with X equal to the identity under a probability measure on the reals, then transferred to arbitrary measurable X. Either organization is acceptable if the exported claims match the general ledger target.

## Pinned API confirmed by source reading

The exact pinned source file `Mathlib/MeasureTheory/Integral/Layercake.lean` was read directly from the recovered Mathlib checkout at commit `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. Its main extended strict-tail theorem is `MeasureTheory.lintegral_eq_lintegral_meas_lt` at lines 493-495. It accepts almost-everywhere nonnegativity and `AEMeasurable`; there is no sigma-finiteness premise in that exported version. `MeasureTheory.Integrable.integral_eq_integral_meas_lt` at lines 515-517 supplies the corresponding real formula for integrable almost-everywhere nonnegative functions. Reuse this API rather than duplicating its Tonelli proof.

This confirms source availability and signatures. The proposed new implementation remains for Fable to write and check in its pinned build environment.

## Delivery accounting

T005 remains partial until its stated general identity and the claimed conditional/excess consequences are implemented and audited. Do not close it based solely on a Pareto check or a real-integral equation stated without integrability. Extra excess-law divergence is optional; if claimed, provide an actual extended-integral theorem and cite it explicitly.
