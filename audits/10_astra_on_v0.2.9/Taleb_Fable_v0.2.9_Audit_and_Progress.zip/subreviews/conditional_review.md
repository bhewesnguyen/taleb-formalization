# v0.2.9 Pareto conditioning, excess and moment source review

Reviewed 21 September 2026. Scope: `AuditRepairs/ParetoConditional.lean`, principally lines 45-194, and the existing `ParetoLaw.lean` and `ExtremeValueAffine.lean` dependencies. The supplied tree was read without modification. This is a mathematical and source review, not an independent Lean execution report.

## Verdict

Accept the delivered conditioning, excess and finite-mean mathematics. No proof defect found. The new results identify actual probability measures using the pinned Mathlib Pareto law and conditioning definition. They correctly preserve the strict threshold, include `K = L`, and keep the conditional raw mean distinct from the mean excess.

One low documentation precision correction is advisable. Only the conditional raw first-moment divergence is exported; there is no separate theorem for the extended first moment of `excessLaw`. The module introduction, `FABLE_REVIEW.md` section 19.2 and the main T005 target state the narrower delivered result accurately. Some grouped summaries abbreviate it ambiguously. This does not introduce a missing Stage B acceptance requirement.

## Exact delivered content

Assume `L > 0`, `alpha > 0` and `L <= K`. Therefore `K > 0` follows without a separate premise.

| Location in ParetoConditional.lean | Result | Audit assessment |
|---|---|---|
| 45-55 | `paretoMeasure_Ioi` and positivity of the conditioning event | The Stage A real survival formula is converted back to an extended measure using finite measure mass. Its value is strictly positive since both scale and threshold are positive. |
| 59-62 | The conditioned measure is a probability measure | The original probability instance supplies finite mass; the event positivity discharges the pinned conditioning API premise. |
| 65-90 | Global conditional cdf | Below K the intersection is empty; at and above K it is `(K,x]`. The event probability normalizes the cdf difference to `1 - (K/x)^alpha`. |
| 94-105 | Threshold law and endpoint law | Equality of cdfs between probability measures gives `(Pareto(L,alpha))[X>K] = Pareto(K,alpha)`. The specialization `K=L` is an actual theorem. |
| 111-121 | `excessLaw`, equality to the shifted threshold Pareto law and probability property | The definition is exactly the old `affineLaw` applied to the conditional law, with shift `-K` and scale 1. It is not an independently invented excess measure. |
| 124-148 | Global excess cdf and strict survival | Cdf is 0 for y<0 and `1-(K/(K+y))^alpha` for y>=0. Survival is 1 for y<0 and `(K/(K+y))^alpha` for y>=0. The survival value 1 at y=0 is proved separately. |
| 153-163 | Conditional moments and conditional mean | All real p<alpha are supported by the Stage A theorem after replacing the conditioned law by Pareto(K,alpha). The first moment is `alpha*K/(alpha-1)` for alpha>1. |
| 166-185 | Mean excess | The first moment of the shifted law is `K/(alpha-1)` for alpha>1. The proof establishes integrability before distributing the real integral over the constant plus identity. |
| 188-194 | Divergent conditional raw first moment | For 0<alpha<=1, the extended nonnegative integral of x under the conditional law equals infinity, by the Stage A p=1 result. No totalized real integral is used to witness divergence. |

The block contains 15 theorems and one definition. The whole module has 21 theorems and one definition; the positive-power section is reviewed separately.

## Conditioning and endpoint checks

The conditioning event is `Ioi K`, while a cdf evaluates `Iic x`. Their intersection is `Ioc K x`. For x<K it is empty. For x>=K the proof uses `Iic x` minus `Iic K`; this correctly excludes the boundary X=K from the numerator. At x=K the cdf is zero, since `(K/K)^alpha=1` with K>0. No hidden division by zero occurs.

For x>=K, the original law gives the normalized numerator

`((L/K)^alpha - (L/x)^alpha) / (L/K)^alpha`.

Positive L, K and x justify the real-power division rule and cancellation. The result is `1-(K/x)^alpha`. At K=L, the conditioning mass is 1 from the Stage A endpoint survival theorem; the endpoint specialization is valid. No independence hypothesis is needed anywhere in this block.

The theorem conditions the actual marginal measure on a measurable event. It does not export a separate arbitrary-random-variable transport lemma equating conditioning before and after a pushforward. Such a bridge is not required by the stated equality-of-laws milestone.

## Excess and integrability checks

The affine definition maps x to `-K + 1*x`, exactly x-K. Its cdf evaluates the threshold Pareto cdf at K+y. The below-support branch corresponds precisely to y<0, and the formula branch forces K+y>=K>0. Thus the real-power denominator is positive wherever the rational expression is used.

Survival is computed from the complement of `Iic y` under a probability measure. The boundary statement at zero concerns strict survival, not the cdf: survival(0)=1 and cdf(0)=0. The absence of an excess atom at zero follows from the identified law, although a separate singleton lemma is not exported.

In the mean-excess proof, `Integrable id (paretoMeasure K alpha)` is established from the Stage A iff at p=1. Constants are integrable because the law is finite. Only then is the integral of the affine function split. The algebra uses alpha-1>0. Therefore the result is an ordinary expectation within its integrable domain, rather than an artifact of Lean's totalized real integral.

Negative conditional moment orders remain valid because K>0. This is a raw moment result. It says nothing by itself about a centered absolute moment or about arbitrary laws that charge values near zero.

## D029-1: specify which divergent moment was delivered

Severity: low, wording only.

Affected shorthand:

- `AUDIT_BRIEF_v0.2.9.md`, grouped moment row at line 48.
- `CHANGELOG_FABLE.md`, grouped moment row at line 23.
- T005 `delivery_scope` in the generator and both ledger renderings.
- The supplied Fable summary, where both finite means are followed by an unqualified infinity statement.

The accurate replacement is: "For 0<alpha<=1, the conditional raw first moment diverges as an extended nonnegative integral."

Do not describe a separate excess-law divergence theorem as delivered. That statement is mathematically true, but an explicit proof of it is not exported in this release. It can be an optional future corollary if a later release chooses to claim it. Do not block Stage B acceptance or require a new Lean theorem solely to repair the wording. The main T005 target, module introduction and detailed Fable review already use the precise scope.

## Source anchors and dependency source boundary

The retained book PDF `audit_v024/source/2001.10488v4(1).pdf` was inspected by text extraction and rendered-page review:

- Printed p.18 / PDF 32 displays Eq. (2.10), the upper-tail first-moment identity for a nonnegative random variable written with a density.
- Printed p.260 / PDF 274 displays the same identity as Eq. (13.4), with the indicator/Fubini proof in (13.5)-(13.7).

These support the general T005 target. The current Pareto conditional and excess laws prove exact-law consequences, not that general identity. Keeping T005 partial is correct.

The pinned Mathlib checkout was recovered during this audit. The following dependencies were then read directly from `/tmp/taleb_v029_audit_project/.lake/packages/mathlib`, with git HEAD independently read as `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. Earlier web text reads were preliminary source checks; the line numbers below refer to the recovered local files:

- `Mathlib/Probability/ConditionalProbability.lean`: conditioning definition at lines 70-71, finite-measure probability theorem at 158-159, measurable-event application rules at 210-215.
- `Mathlib/MeasureTheory/Integral/Bochner/Basic.lean`: the integral over a map transfers under almost-everywhere measurability hypotheses at lines 1080-1082; addition of integrals requires both integrability premises at 230-231.

No source change or compiled-proof claim is made by this review.
