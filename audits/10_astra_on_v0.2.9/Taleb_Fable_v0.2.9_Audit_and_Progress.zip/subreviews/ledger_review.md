# Independent ledger and scope review: v0.2.9

Assessment date: 21 September 2026. Compared the immutable release ledger and generator with the retained v0.2.8 audit, the supplied environment inventory, new Lean signatures and the arXiv v4 source. Runtime reproduction is reported separately.

## Verdict and counts

Accept Pareto Stage B, T005's move from missing to partial, and T032's added actual-law slice. Accept the D028-1 and D028-2 repairs. The scope of all fourteen supported families is defensible. One low documentation clarification remains: grouped descriptions should identify which first moment has an exported divergence theorem.

| Status | Families |
|---|---:|
| Discharged | 2 |
| Partial | 12 |
| Reuse | 4 |
| Missing | 89 |
| Source-check | 33 |
| Model-needed | 15 |
| Empirical | 3 |
| Total | 158 |

Fourteen families carry 169 family/declaration citations over 164 distinct names. All names occur in the supplied inventory; that static check is separate from independent Lean execution. Compared with v0.2.8, there is one new supported family and 23 additional citations: one cross-credit of the pre-existing moment theorem to T118, plus 22 new Stage B declarations. This does not mean 23 new independent mathematical results.

Six JSON rows changed: T005, T021, T028, T029, T032 and T118. The other 152 are identical. No parent family closes. The formal-proof working set still has 140 families: two discharged and 138 open. The other 18 families concern models or empirical work. There are 144 rows with no credited declaration. These are coverage counts, not percentages of effort completed.

The companion ledger_review.json preserves every field of all 158 received rows, records fourteen supported-family assessments, all twenty-two dependency-group counts, completed and open child tasks, source decisions and the documentation finding. Recommendations are separate from received rows.

## D029-1: state exactly which divergent moment is formalized

The new theorem `AuditPareto.lintegral_id_cond_paretoMeasure_eq_top` proves that the raw conditional first moment is infinite as an extended nonnegative integral when `0 < alpha <= 1`. The release also proves the finite conditional mean and finite excess mean separately for `alpha > 1`.

It does not export a theorem that the excess law itself has infinite extended first moment. The main T005 target and FABLE_REVIEW's statement list are precise, but T005's delivery scope and grouped brief/changelog descriptions can read as if both divergent means are formalized.

Clarify these summaries to say "conditional first-moment extended-integral divergence for 0 < alpha <= 1." This requires no new Lean theorem, status change, facet change or reopening of Stage B. Excess-law divergence is mathematically true and may be added as a later optional corollary; it was not a required acceptance gate in the preceding handoff.

## T005 and T032: new exact-law slices are correctly partial

T005 now has the exact threshold law, including `K = L`, as an equality between the normalized restriction using `ProbabilityTheory.cond` and `paretoMeasure K alpha`. The excess law is the affine pushforward of that conditional probability law. Its global CDF and strict survival are specified with the support boundary correct. For `y < 0` survival is one; for `y >= 0` it is `(K/(K+y))^alpha`, also one at zero. The two finite means are kept distinct.

This earns the law, actual-law and source-reviewed facets for the exact-Pareto child. The general identity (2.10), and its derived conditional and excess mean formulas for arbitrary nonnegative laws, remain explicitly open. The source equation is on printed p.18 / PDF32; its displayed proof is on printed p.260 / PDF274. The older umbrella locator includes p.259 because the relevant section starts there; the new delivery locator is precise.

T032 now identifies the positive-power pushforward law, rather than only a tail formula: for `L > 0`, `alpha > 0`, `q > 0`, the image of `paretoMeasure L alpha` under `x^q` is `paretoMeasure (L^q) (alpha/q)`. The support restriction and inverse-event statements address totalized real powers correctly. Its integrability corollary uses the resulting law's order threshold. The law and actual-law facets are earned. Property 5.2 for arbitrary laws and the general density change of variables in (5.8) remain open, so partial is accurate.

## Prior audit repairs

D028-1 is repaired. T118 cross-credits `AuditPareto.integral_rpow_paretoMeasure` and Eq. (21.7), printed p.382 / PDF396. The law and actual-law facets explicitly cover moment identification; the older formula facet covers tail-kernel convexity. Neither claims the moment function is already proved convex in the index. T118 remains partial with convexity and integrated Jensen open.

G20 records the correct derivative `2*p*L^p/(alpha-p)^3`; the source display omits `p` and uses `(alpha-1)^3`. T118 states `p > 0`, common positive scale and `alpha > p`, the right domain for strict positivity of that derivative. The phrase "agrees only at p=1" is correct on that positive-order domain, or as an identity of formulas in alpha. As optional wording precision, add one of those qualifications in G20. Without it, an all-real pointwise reading admits isolated negative-order coincidences: `p=-1/8`, `alpha=1/4` gives the same two numerical values. This is not a new proof defect or a numbered finding.

D028-2 is repaired. T028 now cites printed p.95 / PDF109 for the constant-factor Pareto tail, p.96 / PDF110 for the slowly varying factor and p.97 / PDF111 for Definition 5.1. The density anchor p.86 / PDF100 remains correct. T028's general regularly varying boundary gate stays explicit despite its partial status.

T021 correctly says that negative-order moments rely on `L > 0`, and distinguishes raw absolute moments from centered mean absolute deviation. T029 now explicitly confines realization credit to the Pareto marginal laws: a joint probability space, coordinates with those marginal laws, measurability and pointwise nonnegativity remain hypotheses. An additional product realization is not imposed retrospectively.

The previous D027-3 evidence boundary is closed by the new packaged `deliverables_index_at_packaging.md`. It contains the annotation of the historical v0.2.7 count, saying that 17 was a text-counting mistake and the machine-readable record has 18. Its "current v0.2.8" label is part of the clearly labelled historical snapshot, not an unlabelled v0.2.9 status claim.

## Other supported-family scopes

T001 remains the ratio-only RV API, with a positive measurable convention and deeper regular-variation infrastructure open. T007 and T046 retain the actual Gaussian stable slice only. T008 still assumes subexponentiality and does not yet instantiate a concrete subexponential law. T047 remains convolution/prerequisite work rather than a complete sample-average law. T124 remains formula-level mixture algebra. New exact-Pareto work does not automatically discharge these broad targets.

T060 and T061 stay discharged within the already reviewed targets. The completed T061 children are the three separately constructed EVT measures, exact CDFs and instantiated/product-space maximum laws, followed by positive affine pushforwards and location/scale maximum laws as equalities of measures. S001 unified GEV and its zero-shape limit, and S002 density identifications, remain open outside the 158-family ledger. These do not reopen T061. Normalized-maxima convergence remains a separate T011/T062 target.

## Next mathematics and source boundaries

T021 centered Pareto dispersion is a coherent next contained milestone. The raw moments supply the mean and variance route, but computing `E[|X-E X|]` requires a centered absolute-deviation integral. For `alpha > 1`, the target mean deviation is `2*L*(alpha-1)^(alpha-2)*alpha^(1-alpha)`. For `alpha > 2`, divide the standard deviation by that value to obtain `alpha^(alpha-1/2)/(2*sqrt(alpha-2)*(alpha-1)^(alpha-1))`, matching the source's (4.14), printed p.86 / PDF100. These formulas are next-target mathematics, not newly delivered Lean theorems. The Gaussian/Student portions keep T021 partial.

The general T005 identity via Tonelli/layer-cake is another reusable next theorem. Use measurable nonnegative coordinates, a nonnegative threshold, strict tails and extended integrals first; derive real conditional and excess formulas after integrability and positive conditioning mass are known. Atom-free hypotheses are unnecessary for this strict-tail identity when the truncated event is also strict.

Do not convert source-check into "unprovable." G01-G20 mix diagnosed false unrestricted statements, repaired parameter domains, and genuine remaining review questions. They are targeted checks rather than a complete audit of all source theorems. The broader ledger also does not establish that a library has no CLT in any form, measure upstream Mathlib acceptance, or establish the separate quantum/classical software's operational readiness.
