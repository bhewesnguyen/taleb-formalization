# v0.2.9 verifier and rendering review

Verdict: no verifier defect or weakening was found in this release. All five verification components are byte-identical to v0.2.8. The changed generator contains ledger-data edits only. Independently executed Python checks confirm that the current inventory and both ledger renderings match their sources.

This subreview establishes source and Python behavior only. It does not represent the received Fable logs as independent Lean execution. The clean build, normal verifier, shipped 18-probe suite and 14-fixture regression reproduction are recorded separately by the runtime reviewer, with any execution limitation stated there.

## Exact source comparison

The baseline is packaged v0.2.8 commit `d086ce0cc9ac978e332df4d25bd92994e5f09230`, read from the supplied Git bundle. These files match the current received files byte for byte:

| File | SHA-256 |
|---|---|
| `scripts/verify.py` | `d749e6d3e9ba5f4c95a08cc842e0bd3b462108d44bdd6d360632ed0e5466ba0d` |
| `scripts/backlog_schema.py` | `7155c49d904afb2743bd5cca551f955e20f685908e6b7cc576b2992a491e41bc` |
| `scripts/backlog_schema_probes.py` | `86ef5582c78fcedc5d99280f003ee2d8a5152a0e71c9040ef58b022e18129af7` |
| `scripts/harness_regression.py` | `dd63330848ad0bc00fce2545a18e0da3ffa8aa4b7a2e78982c1f5232874a27d3` |
| `scripts/FableInventory.lean` | `2b4be85a8d667b26a773066de6a7f286a92d543e3513b77545fce9accfc87349` |

The generator's parsed Python syntax tree is unchanged after removing the single `raw` ledger string. Its parsing, shared schema validation and writing logic are therefore unchanged. The preserved source diff contains only the intended ledger rows. The Lake configuration changes the project version from 0.2.8 to 0.2.9, with the same build targets. The umbrella module gains the new ParetoConditional import.

The normal verification path still requires literal UTF-8 byte equality between the Markdown ledger and `render_markdown(JSON)`. It retains full-environment axiom checking before visibility filtering; rejection of any project axiom; recursive project-module coverage; equality of public theorem/instance inventories; replacement-alias target checks; dependency revisions and clean dependency worktrees; warning-free builds; schema validation; and existence of all cited declarations. Explicit verification checks remain active under optimized Python.

The shared schema validates form, not mathematical sufficiency of a family citation. A synchronized, well-typed ledger can still under-credit or over-credit a valid declaration, so the separate ledger review remains necessary.

## Current inventory and independent Python checks

All executions below used a disposable copy. Hashing all 255 received files before and after confirmed that this review left the received extraction unchanged.

| Check | Independently observed result |
|---|---|
| Public source discovery | 181 theorems, 8 instances, 16 aliases; 205 total |
| Generated `AuditVerification.lean` | Exact match with the source-discovered list |
| Added public theorem inventory | Exactly 21 theorems from ParetoConditional |
| Added definition | Exactly one, `AuditPareto.excessLaw` |
| Previous public inventory | Every pre-existing entry retained in its previous relative order |
| New module reachability | ParetoConditional imported by the umbrella module |
| Current ledger schema | Valid, all 158 rows |
| Markdown rendering | Literal byte equality, 82,850 bytes |
| Credited names | 169 family/declaration pairs over 164 distinct declarations |
| Generator after corrupting both disposable outputs | Exit 0; JSON and Markdown restored to the exact received bytes |
| Same reconstruction under Python `-O` | Exit 0; both outputs restored to the exact received bytes |

The definition correctly does not add an entry to the public theorem/instance count. It belongs in the independent environment trust scan. The source-level definition check above is distinct from actually executing that scan.

## Supplied evidence consistency, explicitly limited

The received environment JSON reports 361 constants, including 40 from ParetoConditional. Of the latter, 22 are public and non-generated: the 21 theorems and one definition. Its recorded new axiom lists contain only `propext`, `Classical.choice` and `Quot.sound`, and all credited ledger names occur in that received environment record.

Those comparisons establish that the supplied records agree with the current source inventory. They are not an independent kernel run. The Python result JSON labels this part `supplied_environment_record_consistency_only` and `not_independent_Lean_execution`.

No replay of Lean command output was used for this release's Python checks. No extra CRLF CLI case or expanded adversarial campaign was added: the relevant verifier, renderer and existing fixtures are unchanged from the previously audited code. The current source and generator round trips address the actual change surface.

## Evidence and reproduction

- `verifier_probe/check_verifier_python.py`: independent source and bounded Python check driver.
- `verifier_probe/results/python_probe_results.json`: exact source hashes, inventory, ledger counts, reconstruction results and received-tree check.
- `verifier_probe/results/generator.diff`: original generator diff preserved as evidence.
- `verifier_probe/results/generator_normal.log` and `generator_optimized.log`: actual generator executions.

Run from the workspace root:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 audit_v029/verifier_probe/check_verifier_python.py --project audit_v029/received/Taleb_Lean_Repairs --repo audit_v029/provenance/repo --out audit_v029/verifier_probe/results
```

No verifier code change or additional heavyweight fixture is requested for v0.2.9.
