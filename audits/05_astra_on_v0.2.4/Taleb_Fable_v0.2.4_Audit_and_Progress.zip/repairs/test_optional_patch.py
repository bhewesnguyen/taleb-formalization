"""Python-only harness CLI tests. The valid fixture uses a labelled verifier stub,
not Lean; these results assess argument handling and restoration only."""
from pathlib import Path
import ast,json,shutil,subprocess,tempfile
BASE=Path('/workspace/scratch/c40a0826d9d8/audit_v024/verifier_probe')
RECEIVED=BASE.parent/'received/Taleb_Lean_Repairs'
work=Path(tempfile.mkdtemp(prefix='cli_patch_tests_',dir=BASE))
results=[]
def run_case(label,root,options):
    args=['python3','scripts/harness_regression.py',*options]
    p=subprocess.run(args,cwd=root,capture_output=True,text=True)
    result=dict(case=label,command=args,cwd=str(root),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
    results.append(result)
    return result
nod=work/'no_dependencies'; (nod/'scripts').mkdir(parents=True)
shutil.copyfile(BASE/'patched/scripts/harness_regression.py',nod/'scripts/harness_regression.py')
for label,selection in [('unknown','does_not_exist'),('empty',''),('mixed_unknown','valid,typo'),('empty_element','valid,')]:
    scratch=work/(label+'_scratch');out=work/(label+'_out')
    r=run_case(label,nod,['--only',selection,'--scratch',str(scratch),'--out',str(out)])
    r.update(scratch_created=scratch.exists(),out_created=out.exists(),dependencies_present=(nod/'.lake').exists())
    if r['exit_code']!=2 or scratch.exists() or out.exists():
        raise RuntimeError('invalid selector not rejected before filesystem work: '+label)
STUB="""# Synthetic CLI-test verifier stub: does not invoke or certify Lean.
from pathlib import Path
import json
out=Path('evidence/current');out.mkdir(parents=True,exist_ok=True)
(out/'verification.json').write_text(json.dumps({'status':'PASS','synthetic_cli_stub':True}))
"""
for variant in ['original','patched']:
    root=work/variant
    (root/'scripts').mkdir(parents=True)
    (root/'.lake/packages/Cli').mkdir(parents=True)
    (root/'.lake/build').mkdir(parents=True)
    (root/'.lake/build/pristine_marker').write_text('baseline\n')
    src=RECEIVED/'scripts/harness_regression.py' if variant=='original' else BASE/'patched/scripts/harness_regression.py'
    shutil.copyfile(src,root/'scripts/harness_regression.py')
    (root/'scripts/verify.py').write_text(STUB)
    out=work/(variant+'_result')
    # Also check harmless whitespace normalization in the corrected selector.
    selector='valid' if variant=='original' else ' valid '
    r=run_case(variant+'_relative_valid',root,['--only',selector,'--scratch','../'+variant+'_relative','--out',str(out)])
    rec=out/'harness_regression.json';r['report']=json.loads(rec.read_text()) if rec.exists() else None
    if variant=='original':
        if r['exit_code']!=1 or 'could not restore .lake/build' not in r['stderr']:
            raise RuntimeError('original relative-path reproduction failed')
    else:
        if r['exit_code']!=0 or r['report']['fixture_count']!=1 or not r['report']['all_fixtures_behaved_as_expected']:
            raise RuntimeError('corrected relative-path positive control failed')
# Verify the verify.py change is documentation only.
def semantic_ast(path):
    t=ast.parse(path.read_text())
    if t.body and isinstance(t.body[0],ast.Expr) and isinstance(t.body[0].value,ast.Constant) and isinstance(t.body[0].value.value,str):
        t.body.pop(0)
    return ast.dump(t,include_attributes=False)
if semantic_ast(RECEIVED/'scripts/verify.py')!=semantic_ast(BASE/'patched/scripts/verify.py'):
    raise RuntimeError('verify.py change exceeds module documentation')
summary=dict(all_python_cli_checks_passed=True,scope='Synthetic Python-only CLI and restoration checks; valid fixture uses a verifier stub and does not execute Lean.',verify_runtime_ast_unchanged=True,results=results)
(BASE/'optional_patch_probe_results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'all_python_cli_checks_passed':True,'cases':[(r['case'],r['exit_code']) for r in results],'verify_runtime_ast_unchanged':True},indent=2))
