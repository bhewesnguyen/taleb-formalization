# Optional v0.2.4 harness CLI repair

This small patch addresses two low-priority harness invocation defects found during the audit. The default full regression invocation is unchanged. It does not alter Lean mathematics or verifier acceptance logic.

Changes:

- Reject unknown fixture names, explicitly empty `--only`, and empty comma-separated elements before creating output/scratch directories or copying dependencies.
- Normalize a supplied `--scratch` path to an absolute path, so build restoration works when invoked with a relative directory.
- Require at least one result before reporting overall regression success.
- Remove the stale `67/69` count and shallow-path wording from the `verify.py` module documentation.

From the v0.2.4 project root, with the patch saved locally:

```sh
git apply --check /path/to/optional_harness_cli.patch
git apply /path/to/optional_harness_cli.patch
```

The audit checked that the patch applies cleanly to the delivered v0.2.4 files. `optional_patch_probe_results.json` records six Python-only checks: four invalid selectors reject with exit 2 before filesystem setup, the original relative-path invocation fails during build restoration, and the patched relative-path invocation completes its single selected positive fixture. That positive fixture uses an explicitly labelled synthetic verifier stub, so it demonstrates CLI dispatch and fixture restoration only. It is not evidence of an additional Lean build or proof verification. AST comparison confirms that the edit to `verify.py` changes only its module docstring.

After applying in the real project, the existing full regression command remains:

```sh
python3 scripts/harness_regression.py
```

A valid partial invocation can use a fresh relative directory:

```sh
python3 scripts/harness_regression.py --only valid --scratch ../taleb_cli_check
```

No rerun of Lean is necessary to understand or reproduce the Python-only findings. Apply the normal release verification procedure before packaging any follow-up release.

To reproduce the six Python-only checks before applying the patch, place `check_cli_patch.py` beside `optional_harness_cli.patch` and run:

```sh
python3 check_cli_patch.py --project /path/to/pristine/v0.2.4/Taleb_Lean_Repairs --out ./portable_cli_probe_results.json
```

The helper requires Python 3.9+, `git`, and `cp`. It copies only the two scripts into a fresh temporary directory, applies the patch there, runs the synthetic checks, and writes the JSON result. It leaves the input project unchanged and requires no Lean installation or downloaded dependencies. Use `--patch /path/to/optional_harness_cli.patch` if the patch is elsewhere. `portable_cli_probe_results.json` contains the successful audit run of this portable helper.
