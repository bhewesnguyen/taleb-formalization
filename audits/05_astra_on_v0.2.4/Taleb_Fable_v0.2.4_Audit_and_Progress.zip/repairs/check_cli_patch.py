#!/usr/bin/env python3
"""Portable, Python-only checks for the optional v0.2.4 harness CLI patch.

Requires Python 3.9+, git, and cp. No Lean, Lake, or dependency checkout is needed.
Only the two audit scripts are copied from --project. All mutations occur in a
fresh temporary directory. The positive fixture uses a labelled verifier stub.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

SCRIPT_NAMES = ('scripts/harness_regression.py', 'scripts/verify.py')
STUB = """# Synthetic CLI-test verifier stub: does not invoke or certify Lean.
from pathlib import Path
import json
out=Path('evidence/current');out.mkdir(parents=True,exist_ok=True)
(out/'verification.json').write_text(json.dumps({'status':'PASS','synthetic_cli_stub':True}))
"""


def semantic_ast(path):
    tree = ast.parse(path.read_text())
    if (tree.body and isinstance(tree.body[0], ast.Expr)
            and isinstance(tree.body[0].value, ast.Constant)
            and isinstance(tree.body[0].value.value, str)):
        tree.body.pop(0)
    return ast.dump(tree, include_attributes=False)


def script_hashes(project):
    return {name: hashlib.sha256((project / name).read_bytes()).hexdigest()
            for name in SCRIPT_NAMES}


def copy_scripts(source, dest):
    for name in SCRIPT_NAMES:
        path = dest / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, path)


def run_case(results, label, root, options):
    args = [sys.executable, 'scripts/harness_regression.py', *options]
    process = subprocess.run(args, cwd=root, capture_output=True, text=True)
    result = dict(case=label, command=args, cwd=str(root),
                  exit_code=process.returncode, stdout=process.stdout,
                  stderr=process.stderr)
    results.append(result)
    return result


def checks(project, patch, summary):
    before = script_hashes(project)
    summary['project_script_sha256'] = before
    summary['patch_sha256'] = hashlib.sha256(patch.read_bytes()).hexdigest()
    with tempfile.TemporaryDirectory(prefix='taleb_cli_patch_check_') as tmp:
        work = Path(tmp)
        pristine = work / 'pristine'
        staged = work / 'patched_scripts'
        copy_scripts(project, pristine)
        copy_scripts(pristine, staged)
        for extra in (['--check'], []):
            command = ['git', 'apply', *extra, str(patch)]
            p = subprocess.run(command, cwd=staged, capture_output=True, text=True)
            if p.returncode:
                raise RuntimeError('Patch did not apply to pristine v0.2.4 scripts: '
                                   + p.stdout + p.stderr)
        summary['patch_applied_to_temporary_copy'] = True
        if semantic_ast(pristine / 'scripts/verify.py') != semantic_ast(staged / 'scripts/verify.py'):
            raise RuntimeError('verify.py patch changes more than its module documentation')
        summary['verify_runtime_ast_unchanged'] = True
        nod = work / 'no_dependencies'
        (nod / 'scripts').mkdir(parents=True)
        shutil.copyfile(staged / 'scripts/harness_regression.py', nod / 'scripts/harness_regression.py')
        for label, selection in [('unknown', 'does_not_exist'), ('empty', ''),
                                 ('mixed_unknown', 'valid,typo'), ('empty_element', 'valid,')]:
            scratch = work / (label + '_scratch')
            out = work / (label + '_out')
            row = run_case(summary['results'], label, nod,
                           ['--only', selection, '--scratch', str(scratch), '--out', str(out)])
            row.update(scratch_created=scratch.exists(), out_created=out.exists(),
                       dependencies_present=(nod / '.lake').exists())
            row['behaved_as_expected'] = (row['exit_code'] == 2
                and not scratch.exists() and not out.exists() and not (nod / '.lake').exists())
            if not row['behaved_as_expected']:
                raise RuntimeError('Invalid selector was not rejected before setup: ' + label)
        for variant, source in [('original', pristine), ('patched', staged)]:
            root = work / variant
            copy_scripts(source, root)
            (root / '.lake/packages/Cli').mkdir(parents=True)
            (root / '.lake/build').mkdir(parents=True)
            (root / '.lake/build/pristine_marker').write_text('baseline\n')
            (root / 'scripts/verify.py').write_text(STUB)
            out = work / (variant + '_result')
            selection = 'valid' if variant == 'original' else ' valid '
            row = run_case(summary['results'], variant + '_relative_valid', root,
                ['--only', selection, '--scratch', '../' + variant + '_relative', '--out', str(out)])
            rec = out / 'harness_regression.json'
            row['report'] = json.loads(rec.read_text()) if rec.exists() else None
            if variant == 'original':
                row['behaved_as_expected'] = (row['exit_code'] == 1
                    and 'could not restore .lake/build' in row['stderr'])
            else:
                report = row['report'] or {}
                row['behaved_as_expected'] = (row['exit_code'] == 0
                    and report.get('fixture_count') == 1
                    and report.get('all_fixtures_behaved_as_expected') is True)
            if not row['behaved_as_expected']:
                raise RuntimeError('Relative-path probe behaved unexpectedly: ' + variant)
    summary['project_scripts_unchanged'] = before == script_hashes(project)
    if not summary['project_scripts_unchanged']:
        raise RuntimeError('Input project scripts changed during the checks')
    summary['all_python_cli_checks_passed'] = (len(summary['results']) == 6
        and all(row['behaved_as_expected'] for row in summary['results']))
    if not summary['all_python_cli_checks_passed']:
        raise RuntimeError('The required six CLI probes did not all pass')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True, type=Path,
                        help='path to pristine, unpatched v0.2.4 project')
    parser.add_argument('--patch', type=Path,
                        default=Path(__file__).resolve().with_name('optional_harness_cli.patch'),
                        help='patch path (default: optional_harness_cli.patch beside this script)')
    parser.add_argument('--out', required=True, type=Path, help='output JSON evidence file')
    args = parser.parse_args()
    project, patch, out = args.project.resolve(), args.patch.resolve(), args.out.resolve()
    for name in SCRIPT_NAMES:
        if not (project / name).is_file():
            parser.error('missing project script: ' + str(project / name))
    if not patch.is_file():
        parser.error('patch file does not exist: ' + str(patch))
    for executable in ('git', 'cp', 'python3'):
        if shutil.which(executable) is None:
            parser.error('required executable is unavailable: ' + executable)
    summary = dict(all_python_cli_checks_passed=False,
        scope='Synthetic Python-only CLI and restoration checks; valid fixture uses a verifier stub and does not execute Lean.',
        project=str(project), patch=str(patch), results=[])
    try:
        checks(project, patch, summary)
    except Exception as exc:
        summary['error'] = str(exc)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(dict(all_python_cli_checks_passed=summary['all_python_cli_checks_passed'],
        cases=[(row['case'], row['exit_code']) for row in summary['results']],
        evidence=str(out), **({'error': summary['error']} if 'error' in summary else {})), indent=2))
    return 0 if summary['all_python_cli_checks_passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
