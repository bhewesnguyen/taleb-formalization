# Independent static ledger review of v0.2.4

Scope: all eleven rows with delivery states in `docs/FORMALIZATION_BACKLOG.json`, corresponding Markdown, the generator, `FABLE_REVIEW.md` section 14, `scripts/verify.py`, and the cited Lean source. This review did not run Lean or independently re-open book pages; the root audit handles reproduction/source checks. Statements below concern semantic correspondence of source declarations to recorded target/status.

## Verdict

The ledger's aggregate status counts are correct. T060 merits discharge against its longstanding stated target. The remaining ten supported rows should stay partial. No additional family merits discharge. T007's Gaussian existence credit fixes the previous understatement.

Most states are fair if interpreted existentially: some scoped component of the family has that kind of evidence. They are not stages completed for the entire family. Two rows particularly need explicit scope: T118 credits only a convex tail-kernel prerequisite, and T047 credits a conditional sum/convolution prerequisite, not a sample-average theorem. T060 is understated by its formula-only delivery tag; it now has genuine generic probability-law theorems. These are ledger precision issues, not discovered false Lean statements.

## Exact counts

| Status | Families |
|---|---:|
| discharged | 1 |
| partial | 10 |
| reuse | 4 |
| missing | 91 |
| source-check | 34 |
| model-needed | 15 |
| empirical | 3 |
| total | 158 |

The supported set is T001, T007, T008, T029, T032, T046, T047, T060, T061, T118, T124. T060 is the only discharged row.

Delivery tags are nonexclusive: formula_proved 8; conditional_law_theorem 3; actual_law_constructed 2; source_reviewed 6; discharged 1. The eleven rows cite 71 `(family, declaration)` pairs but 70 distinct Lean constants. `AuditGaussian.charFun_gaussianReal_eq_stableS1Expr` receives appropriate cross-family credit in T007 and T046; this is one theorem, not two implementations.

Relative to the shipped v0.2.3 ledger, T007 moves missing to partial, and T060 moves partial to discharged. Thus partial stays 10 while missing drops from 92 to 91 and discharged rises from 0 to 1. T007 is retrospective recognition of work delivered in v0.2.3. The new mathematical completion is T060.

A defensible numerical report is one fully closed family and ten more supported families. Neither 1/158 nor 11/158 estimates the fraction of implementation effort completed. Families are very unequal; the ledger is a curated family register, not an exhaustive atomic theorem census. The formal-proof working set is 140 families, separate from 15 model and 3 empirical families.

## Family-by-family assessment

### T001: Regular variation API

Recorded: partial; formula_proved, source_reviewed. Verdict: accurate.

`AuditRV.IsSlowlyVarying` and `IsRegularlyVarying` are ratio-limit predicates. Checked lemmas cover logarithms, nonzero constants, convergence to a nonzero constant, multiplication, powers under explicit eventual positivity, regular/slow equivalence, zero-index equivalence, eventual equality and nonzero constant scaling. This is meaningful analytic infrastructure.

The negative-one diagnostic explicitly proves that the ratio-only predicate admits a negative constant. It therefore does not silently constitute the book's positive measurable regular-variation class. No positive-measurable wrapper or equivalence carrying those assumptions is present. No Karamata/Potter result is implied. Maintain partial. Formula credit is justified, and page-level source scope is documented in the source docstring.

### T007: Stable law existence

Recorded: partial; actual_law_constructed, source_reviewed. Verdict: accurate only for the explicitly named Gaussian slice, which is already clearly recorded.

`AuditGaussian.charFun_gaussianReal_eq_stableS1Expr` supplies a genuine Mathlib probability law `gaussianReal mu v` whose characteristic function is the desired S1 expression when `v = 2 sigma^2`. Arbitrary location and all nonnegative scales are realized at alpha=2; zero variance is included. `gaussianParameters` packages an admissible alpha=2 parameter tuple. The skew parameter is irrelevant at alpha=2, and the charFun theorem accepts arbitrary beta.

Using an existing Mathlib measure counts as a realization; it need not reimplement the Gaussian construction. However, the label should be read as 'Gaussian law realized', not existence for every stable parameter. No alpha<2 stable measure/CF identification is delivered. The generic all-alpha zero-scale Dirac identification has not been exported either, although it should be elementary. Maintain partial.

### T008: Subexponential law API

Recorded: partial; conditional_law_theorem. Verdict: appropriate scoped credit, but the definition of the tag should include substantive property hypotheses.

`AuditProbability.IsSubexponential` is genuinely a property of one probability measure and its self-convolution. It includes support on nonnegative reals, eventual positive survival and the tail-ratio limit 2. `IsSubexponential.finiteTailExponent` proves preservation of an already assumed finite log-tail exponent under self-convolution, deriving eventual positive convolution survival. This is no longer a theorem about two unrelated formulas.

It does not prove that any concrete law is subexponential, derive the n-fold tail characterization, establish equivalence with other standard definitions, or show subexponential laws must have a finite exponent. Its hypotheses include subexponentiality and finite exponent. Maintain partial. The current tag definition mentions existence/CDF/CF premises but not these property premises; broadening that definition or using a law_theorem tag would make this row fit cleanly.

### T029: Tail of sums with unequal indices

Recorded: partial; formula_proved, source_reviewed. Verdict: accurate and appropriately cautious.

`two_power_tail` and `two_power_tail_min` prove the finite log-exponent of an analytic sum of two positive power tails. The weights are formula coefficients, not the random-variable scaling constants in an already established sum survival identity. General real exponents are allowed analytically; no claim that every such formula is a survival function is made.

No theorem connects this expression to the survival function of a weighted sum of random variables. The nonnegative-sum event-inclusion squeeze remains open. The correction of the sign in the source display and the signed-dependent cancellation counterexample are recorded. Maintain partial. The eventual target should explicitly say finite log-tail exponent unless exact asymptotic tail dominance is independently proved; exact tail equivalence is a stronger obligation.

### T032: Power transformation of a law

Recorded: partial; formula_proved. Verdict: accurate.

`pareto_power_tail` checks the exponent alpha/p for the analytic composition `C * (y^(1/p))^(-alpha)`. The theorem's positive-p assumption matches the intended monotone-transform interpretation even though it is unused in this formula proof. This is not yet a theorem about `P.map (fun x => x^p)`, nor a Pareto law identification. Measurability, monotone inverse/event identity and survival law remain. Maintain partial.

### T046: Stable characteristic-function specializations

Recorded: partial; formula_proved, actual_law_constructed, source_reviewed. Verdict: accurate with the stated Gaussian-only realization.

`stableS1Expr_gaussian` and `_cauchy` check the formulas; `_at_zero` checks normalization. The Gaussian bridge identifies the real Gaussian law with the S1 expression at variance `2 sigma^2`. The Gaussian convolution-power result explicitly invokes the conditional stable bridge; it therefore demonstrates nonvacuity of both CF premises at alpha=2, including zero scale and zero convolution count.

The centered Cauchy expression is still only a formula. No Cauchy probability measure/characteristic-function identification is supplied. The 'when' documentation repair is correct: the implemented theorem is one-directional, and an arbitrary pointwise converse would fail at t=0. Maintain partial. Do not describe the combined family as wholly realized.

### T047: Stable sample averages

Recorded: partial; conditional_law_theorem. Verdict: acceptable prerequisite credit, but it needs a direct scope sentence.

The declarations establish convolution powers, their probability instance and characteristic function, a conditional stable convolution-power equality, and a binary independent-sum pushforward identity. `stableS1Expr_power` is formula-level algebra. Together they form useful scaffolding for average laws.

There is no theorem for the law of an n-sample average, no affine pushforward scaling theorem, no proved average scale `n^(1/alpha - 1)`, no alpha=1 skew-location correction for rescaling, and no finite-mean convergence. The Gaussian case realizes the sum bridge elsewhere; it still does not turn this row into a completed average theorem. Add delivery_scope: 'Conditional stable sum/convolution bridge only; average pushforward, location rules and convergence remain open.' Maintain partial.

### T060: Distribution of iid maxima and minima survival

Recorded: discharged; formula_proved, source_reviewed, discharged. Verdict: discharge accepted; law-level tag is missing/underspecified.

`cdf_map_maxRV` literally proves the CDF of the pushforward law of the finite real-valued maximum equals `(cdf nu x)^card iota`. `measureReal_map_minRV_Ioi` proves the survival of the minimum is the common survival to that power, and `_eq_one_sub_cdf` proves `(1 - cdf nu x)^card iota`. Coordinates are measurable, independent and share the pushforward law nu; the base measure is a probability measure; the index is finite and nonempty. The needed probability instances are derived, not assumed through an unproved CDF-existence axiom.

The random variables maxRV/minRV are explicit finite supremum/infimum functions with measurability proved. Threshold conventions are atom-safe: max uses Iic and min uses Ioi, whose complement is Iic. No continuity or atomlessness assumption is smuggled in. Event-level product and power laws are also available.

The core target sentence is unchanged from v0.2.3. Specific Gumbel/Frechet constructions were already assigned to T061. Rewriting the delivered detail and separating the scope is clarification, not goalpost-moving. Empty samples are excluded in the real-valued extrema theorem, as is appropriate without extended-real sentinel values. Explicit IID model existence is not part of this generic theorem family's stated target.

The tag formula_proved understates this achievement. Add a general law_theorem/generic_law_theorem facet, or explicitly broaden conditional_law_theorem to include common-law assumptions and add it. Prefer the general facet so routine hypotheses are not confused with an unresolved special-law existence gap. No named EVT-law construction should be credited here.

### T061: GEV families as probability measures

Recorded: partial; formula_proved, conditional_law_theorem. Verdict: accurate.

There are raw and support-correct piecewise Frechet formulas, the Gumbel formula, formula max-stability identities, and maximum-event theorems for coordinates whose CDFs satisfy those formulas. The Frechet boundary diagnostic explains why the raw formula at zero is invalid as a global CDF.

No Gumbel or Frechet measure with these CDFs is constructed. No Stieltjes validity proof, endpoint-limit proof, right-continuity proof, reverse-Weibull formula/measure, or full location-scale family is delivered. Conditional-law credit is deserved but does not establish any concrete instance. Maintain partial.

The absence of source_reviewed is conservatively incomplete: source correspondence of the formula subpieces is already discussed at page level in FABLE_REVIEW, while reverse-Weibull and the whole-family construction have not been checked here. Do not infer an overall stage count from these optional facets.

### T118: Moment convexity in Pareto exponent

Recorded: partial; formula_proved. Verdict: the weakest semantic mapping; retain prerequisite-only partial credit but make the limitation explicit.

The only credited declaration is `AuditTails.convexOn_rpow_neg_right`. It proves that alpha -> c^(-alpha) is convex for c>0. It does not prove that `m_p(alpha) = scale^p * alpha/(alpha-p)` is convex on alpha>p. It does not express or evaluate a Pareto moment, and it does not integrate a Jensen inequality against a random alpha. FABLE_REVIEW's existing per-proof table correctly calls it an analogue and leaves Jensen/integration open.

This tail-kernel convexity can support the target after a tail-integral/moment representation, so partial is reasonable under the ledger's explicitly broad 'some supplied lemmas exist' rule. A bare formula_proved label can nevertheless be read as completion of the displayed target formula. Add delivery_scope: 'Only alpha -> c^(-alpha) convexity is proved as a prerequisite. Convexity of scale^p alpha/(alpha-p), its identification with a Pareto moment, and integrated Jensen remain open.' Alternatively add prerequisite_proved as a separate facet. Do not promote or imply the moment-convexity target itself has been checked.

### T124: Shifted-gamma index mean

Recorded: partial; formula_proved, source_reviewed. Verdict: accurate.

`gamma_mixture_excess` proves the corrected rational-expression difference. `_pos` proves positivity under scale>0, m>0, nonzero spread and m^2>s^2. These are algebraic statements, and the source/gap text already says the gamma inverse-moment integral remains open.

No inverse-gamma-moment expectation evaluation, mixture law, finite-mean proof or divergence theorem is supplied. The source's missing scale and denominator regime are treated correctly at formula level. Maintain partial.

## Delivery-schema assessment

1. The five states are useful nonexclusive facets, not a monotone completion ladder. `source_reviewed` is a human evidence state; `formula_proved`, `conditional_law_theorem`, `actual_law_constructed` describe different slices; only `discharged` is a whole-family judgment.
2. Add per-state scope and evidence, or at least `delivery_scope` and `remaining_obligations`. Unscoped whole-family flags are particularly ambiguous for Gaussian-only realization and for T118's prerequisite.
3. Distinguish a generic law theorem from a theorem conditional on as-yet unrealized special CDF/CF hypotheses. T060 is the concrete example demonstrating this missing distinction.
4. `actual_law_constructed` is defensible because its definition says realization, not novel implementation. `actual_law_realized` would better communicate reuse of Mathlib Gaussian measures.
5. Declaration existence is necessary but not semantic validation. `scripts/verify.py:120-125` checks each cited name exists in the scanned environment; it does not inspect whether its proposition entails the row target or validates state/status/source review. This is acceptable because the verifier's scope disclaimer says so. Do not describe PASS as certifying the ledger's completion claims.
6. The generator validates allowed status/state names and agreement between discharged status and discharged tag. The runtime verifier does not validate those ledger schema constraints. Adding a lightweight schema check is a sensible durability improvement; it does not solve semantic review. Stable child IDs and explicit acceptance criteria should be introduced as T061 is decomposed.
7. `FORMALIZATION_BACKLOG.md:5` still says 'No row is a claim that its book statement is already verified'. This is now too broad with an explicit discharged T060 row. Replace with 'Only rows marked discharged claim completion of their stated, reviewed scope.'

## Next milestone acceptance boundaries

The order Gumbel, Frechet, reverse-Weibull is sensible and all three must remain explicit child tasks of T061. For each child, require a support-correct global formula, appropriate shape/scale assumptions, monotonicity, right continuity, limits zero/one, a concrete probability measure and a theorem identifying its CDF with that formula at every real threshold. Location/scale wrappers are part of the announced parent scope and should not disappear after the standardized cases.

To call the ensuing max-stability 'unconditional', eliminate the unresolved distribution-existence premise by supplying these actual laws. Ordinary iid/measurability/shape hypotheses necessarily remain. For a fully realized distribution statement, exhibit the canonical finite product iid model or equivalent sampling-law construction and prove equality of the maximum's law with the transformed named law via CDF uniqueness. Merely restating the current conditional theorem with another unproved all-x CDF premise would not meet the milestone.

T029 should next be specified as a finite log-tail exponent theorem for nonnegative weighted sums, using event inclusions and no independence assumption. Keep any exact regularly-varying/convolution asymptotics distinct. The exact Pareto work then advances moment, excess and power-pushforward families, but a narrow exact-Pareto slice should not automatically discharge their full general targets.
