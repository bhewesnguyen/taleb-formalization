# Independent mathematical review of T060 in v0.2.4

Review scope: direct inspection of `AuditRepairs/ExtremeValueBridge.lean`, the T060/T061 backlog entries, FABLE_REVIEW section 14, and the supplied v0.2.3-to-v0.2.4 patch. This note does not claim an independent Lean build; the runtime audit covers that. The source-book PDF was subsequently recovered at `audit_v024/source/2001.10488v4(1).pdf`; extracted PDF pages 185-187 were inspected against the relevant statements.

## Verdict

**Accept T060 as discharged, subject to the independent build/trust checks.** Its previously stated targets are a finite iid maximum CDF identity and the minimum survival analogue. Both now exist as genuine statements about pushforward probability laws of measurable real random variables. Constructing particular extreme-value laws belongs to T061 and is not needed to prove this distribution-free family.

The core target was not weakened to obtain closure. The supplied incremental patch preserves the sentence `Prove CDF(max_i X_i)(x)=F(x)^n and minima survival analog.` The previous gap text already assigned Fréchet/Gumbel measure construction to T061. The new scope note makes this boundary clearer.

## What the checked statements actually say

For a finite nonempty index type, a probability space `(Omega,P)`, measurable coordinates `X_i`, mutual independence `iIndepFun X P`, and common pushforward law `P.map (X_i) = nu`, the new code proves:

1. `cdf (P.map (maxRV X)) x = (cdf nu x)^n`, where `n = Fintype.card iota` (`ExtremeValueBridge.lean:220-230`).
2. `(P.map (minRV X)).real (Ioi x) = (nu.real (Ioi x))^n` (`:233-237`).
3. The same minimum survival probability equals `(1 - cdf nu x)^n` (`:240-252`).

These are the required book-level distribution identities. A separate equality of measures with a newly named maximum-distribution constructor is not an unfulfilled obligation: the required CDF identity is already stated directly for the actual pushforward law. An explicit minimum CDF corollary `1 - (1-F)^n` would be convenient, but the existing target specifically asks for the survival analogue, which is present.

## Mathematical and implementation checks

| Concern | Inspection result |
|---|---|
| Actual extrema rather than unnamed events | `maxRV` and `minRV` are finite `sup'`/`inf'` of functions, hence pointwise extrema (`:70-76`). Their threshold preimage equalities connect them to the events (`:78-86`). |
| Measurability | Both extrema are proved measurable from measurable coordinates (`:207-215`). The map-law results require these coordinate hypotheses; there is no use of `Measure.map` on an arbitrary nonmeasurable function to sidestep its semantics. |
| Common distribution | `hnu : forall i, P.map (X i) = nu` is enough to transfer every measurable-set probability (`:188-205`). It is a legitimate formulation of common law. Full law equality is stronger than the single-threshold equality sufficient for one numerical power identity, but entirely appropriate for the distribution theorem. |
| Probability normalization | The CDF theorem requires `IsProbabilityMeasure P`, proves the corresponding instance for `nu` using an index witness, and proves it for the maximum pushforward (`:220-230`). Complement arithmetic uses the real probability-measure identity (`:244-252`). |
| ENNReal versus real | The finite-measure real power lemma first obtains nonnegativity and uses `measure_ne_top` to justify `ofReal/toReal` conversion (`:174-182`). The law-level statements use `ENNReal.toReal_pow`; the complement statement is over a genuine probability measure. No hidden conversion of infinite mass is used to derive the required probability result. |
| Mutual independence | The product identity uses Mathlib's `iIndepFun.meas_iInter` (`:146-148`), then specializes measurable threshold sets. Pairwise independence has not been substituted for mutual independence. |
| Empty index | Actual real-valued maximum/minimum definitions and the law-level theorems require `Nonempty iota`. This correctly excludes an undefined empty real extremum. The finite-intersection event theorems are more general and should not be interpreted as laws of an empty real extremum. |
| One coordinate | The definitions reduce to the coordinate, and both powers reduce to first powers. No unnecessary `n >= 2` assumption occurs. |
| Atom handling | Maximum CDF uses `Iic x`; minimum survival uses `Ioi x`, exactly its complement. Product statements also cover `Iio x` and `Ici x` separately (`:150-163`). No continuity or atomlessness assumption is made. |
| Degenerate laws | Allowed. For common law `delta_0` and threshold `0`, the required maximum CDF is 1 and strict minimum survival is 0, whereas the non-strict minimum event has probability 1. The code keeps these events separate. |
| Existence assumptions | The generic iid theorem takes an existing measurable family and common measure; this is the normal scope of an iid distribution theorem. It does not assume its conclusion. Construction of independent copies for arbitrary laws is useful library infrastructure but was not a stated T060 target. |
| Size and proof style | The addition is 19 theorems and 5 definitions. Proofs are short reductions to existing independence, finite-extremum measurability, map, CDF, and complement lemmas. There is no algebraically suspicious detour. |

The lower-level `measure_*Event` statements do not explicitly require coordinate measurability or an ambient probability-measure instance; they inherit the exact stronger/general behavior supported by Mathlib's independence API. The actual CDF and survival law statements do impose measurable coordinates and a probability space, so this generality is not a gap in the book-level result.

## Source correspondence

Book section 9.1 begins on printed page 171 (PDF page 185) with independent Pareto variables sharing a CDF F. Equation (9.1), the exact maximum CDF identity, is on printed page 172 (PDF page 186). The code generalizes this correctly to arbitrary common laws, including atomic laws. The minimum survival result is a proved companion extension of the source's "max (or minimum)" sentence, rather than a verbatim survival equation printed there. The three EVT distribution forms appear on printed page 173 (PDF page 187).

No derivative-of-CDF/density result is required for T060's original stated target; the book's next sentence about a PDF is additional source material whose assumptions differ for atomic laws. It should not be inferred from T060 discharge that the whole of section 9.1, its density formula, or its asymptotic claims have been formalized.

## Nonblocking documentation and classification changes

0. **Correct the maximum-law source anchor (low).** `ExtremeValueBridge.lean:138` and `FABLE_REVIEW.md:511` cite printed page 173 / PDF 187 for the new generic extrema work. Equation (9.1) is actually printed page 172 / PDF 186. Cite that equation for T060, and reserve page 173 / PDF 187 for the named EVT formulas. The broad backlog range 171-173 is fine. This is a traceability correction, not a target mismatch or mathematical failure.
1. **The module's first heading is stale.** `ExtremeValueBridge.lean:7` still labels the file `backlog family T060, part`, although the generic family is now discharged. A more accurate title is `Independent extrema and conditional EVT max-stability (T060 complete; T061 partial)`.
2. **T060's delivery states understate the probability-level result.** `docs/FORMALIZATION_BACKLOG.md:527` and JSON states list only `formula_proved`, `source_reviewed`, `discharged`. This omits the chief new achievement: a generic probability-law theorem. A `law_theorem` or `generic_law_theorem` state would express this well. Reusing `conditional_law_theorem` according to its current definition is possible, but should not imply a missing existence premise for the generic iid theorem. The absence of `actual_law_constructed` for a specifically named EVT law is correct.
3. **Strict/non-strict wording can be made exact.** `ExtremeValueBridge.lean:48-49` and FABLE_REVIEW section 14 say the strict and non-strict variants differ exactly on atoms. At the set level they differ on the boundary event, even when it has measure zero. Suggested wording: `The probabilities differ by the mass of the boundary event; this distinction matters for atomic laws.` This is a prose precision issue, not a proof error.
4. **Keep the next milestone's use of “unconditional” bounded.** FABLE_REVIEW section 14.5 says EVT measure construction will turn the conditional results into unconditional statements. It will discharge the unverified CDF-realization assumptions; iid and common-law hypotheses remain for random-variable versions. Prefer `instantiate max-stability for the constructed laws` or `discharge the CDF-realization premises`.

The backlog delivery sentence says the four threshold events have product and power forms. Explicit named power lemmas are provided for `max <= x` and `min > x`, while `max < x` and `min >= x` have product lemmas whose common-probability power consequences follow immediately. This is slightly broad prose but neither a mathematical error nor a reason to reopen T060.

## T061 next-milestone acceptance boundaries

The proposed order is sensible: Gumbel, Fréchet, reverse-Weibull, then location/scale families. Define child tasks with acceptance declarations, rather than counting a new distribution formula as measure construction.

For each standardized family require a globally defined support-correct CDF; monotonicity, right continuity, endpoint limits; a concrete measure; `IsProbabilityMeasure`; and an everywhere CDF identity. For each max-stability application, instantiate the generic `cdf_map_maxRV` with that measure and prove the intended normalized-law consequence. If the desired theorem explicitly claims an iid realization exists for every `n`, construct a finite product law and coordinate maps as well.

For Fréchet verify the `x <= 0` branch and right continuity at zero with `xi > 0`; for reverse-Weibull use the upper endpoint and correct shape/sign convention. Location/scale pushforwards need strictly positive scale. All three named families and their recorded scope must be complete before closing T061. Merely constructing the first two, or proving their analytic max-stability identities again, does not close it.

## Evidence boundary

No mathematical defect requiring a Lean-source repair was found in the new T060 material. This conclusion is a source-level assessment and should be combined with independent build, axiom closure, and packaging checks performed elsewhere in the audit. Existing Fréchet/Gumbel bridge statements still carry their explicit CDF hypotheses, and this review does not claim those distribution measures already exist in the project.
