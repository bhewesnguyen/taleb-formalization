# v0.2.4 verifier and regression harness review

Scope: static adversarial review of the received `scripts/verify.py`, `scripts/FableInventory.lean`, and `scripts/harness_regression.py`; targeted Python-only CLI probes of an unchanged harness copied into a minimal synthetic project. No edits to the received package. Runtime Lean reproduction is owned by the parent auditor and is not asserted here.

## Verdict

The prior V1 repair is correctly implemented for the declared project roots, and the R1 isolation change addresses the identified contamination route. No new trust-scan defect or mathematical blocker was established. The new backlog gate does exactly the narrow job it advertises: rejecting credited project declaration names absent from the scanned environment. It cannot certify whether a declaration proves a family's target or whether a delivery state is appropriate; those remain review tasks.

## Prior findings

- **V1, recursive project coverage:** `verify.py:58` recursively discovers public API declarations under `AuditRepairs`; `verify.py:69-75` recursively enumerates both `AuditRepairs` and `Proofs`. The module list is compared against actual imported modules at `verify.py:113-114`. An unimported nested module is therefore rejected even if it contains only private declarations. The harness has both the exact nested-orphan negative case (`harness_regression.py:75-78,108-109`) and an imported nested theorem positive control (`:79-85,110-111,186-189`). This correctly repairs the scoped omission, rather than merely adding another string scan for `sorry`.
- **R1, sequential fixture isolation:** `harness_regression.py:122-136` removes all non-`.lake` entries, reextracts the source snapshot, removes the current evidence, deletes `.lake/build`, restores a pristine build snapshot, and refuses to continue if the restored source hash differs. The sequence is executed before every mutation (`:169`) and once after the last case (`:203`). The compiled artifact from a previous fixture cannot persist through an ordinary project-build restore. The stored per-fixture reset/hash assertions are calculated from actual operations. This does not retrospectively establish the exact cause of the earlier auditor's contamination, which remains correctly described as unresolved in the review history.

## Trusted environment checks

`FableInventory.lean:104-124` collects axioms for every constant attributed to the fixed project module roots before any visibility or generated-provenance filtering. `verify.py:110-112` checks all rows and rejects any project axiom. Private/internal constants cannot avoid the axiom allowlist by escaping the public API regex. Public provenance filtering is only used for the independent public inventory comparison (`verify.py:115-116`). Alias targets are compared directly to the replacement map (`:117-119`). Compiler warnings and errors are rejected after a successful build (`:94-104`). Acceptance checks are ordinary conditionals and remain active under Python optimization.

The scanner roots are explicitly `AuditRepairs`, `Proofs`, and `AuditVerification` (`FableInventory.lean:42-46`). It is a verifier for these project libraries, not an arbitrary Lean file anywhere in the archive. `AuditVerification.lean` is itself constrained to the exact generated import/print inventory (`verify.py:92-93`).

## Backlog gate

At `verify.py:120-125`, each `(family ID, declaration name)` pair must belong to the scanned project constants. The received backlog contains **71 such pairs, representing 70 distinct declaration names across 11 families**. All names occur in the delivered environment inventory. This is useful protection against typos or deleted declarations. It intentionally does not validate correspondence between theorem type and family target, source review, status/state consistency, or atomic completion. The report's `backlog_cited_declaration_count` is the pair count, so it should not be read as 71 distinct declarations.

There is no regression fixture targeting this new gate. A small future negative fixture that changes one credited name to a nonexistent declaration would preserve its intended behavior as the script evolves. This is a coverage improvement, not an observed failure of the present gate.

## Low-priority harness CLI issues, independently reproduced

### H1: unknown selected fixture names can produce a zero-test success

- Location: `harness_regression.py:151,168,204-212`.
- Reproduction: invoke the unchanged script with `--only nonexistent_fixture` and an absolute fresh scratch directory on a minimal synthetic project containing `.lake/packages` and `.lake/build`.
- Observed: process exit 0, output `ALL FIXTURES BEHAVED AS EXPECTED`, JSON `all_fixtures_behaved_as_expected: true`, `fixture_count: 0`, and `results: []`.
- Cause: the requested set is never compared to the fixture registry, and `all([])` is true. A mixed known/unknown selection silently skips the unknown IDs as well.
- Repair: validate requested IDs against the registry before copying any files; reject unknown IDs and any empty effective selection. Keep partial-suite counts explicit in reports.
- Scope: the default invocation selects all 12 cases, so this does not invalidate the shipped 12/12 record or affect mathematical verification.

### H2: a relative `--scratch` directory fails build restoration

- Location: `harness_regression.py:146,153,132`.
- Reproduction: `--scratch ../relative_work` with a project build snapshot present.
- Observed: process exit 1 with `could not restore .lake/build: cp: cannot stat '../relative_work/pristine_build': No such file or directory`.
- Cause: paths derived from the caller-relative scratch path are later supplied to `cp` with the fixture directory as its working directory.
- Repair: normalize a supplied scratch path with `.resolve()` before using it.
- Scope: the default temporary path and absolute `--scratch` paths are unaffected. This is a usability failure, not a false acceptance.

Probe evidence is in `audit_v024/verifier_probe/python_probe_results.json`. The probe is deliberately Python-only and does not claim a new Lean execution. Python 3.13 also emitted tar extraction deprecation warnings, which did not affect either result and are not recorded as a substantive finding.

## Optional corrective patch

`audit_v024/verifier_probe/optional_harness_cli.patch` repairs H1 and H2, rejects empty selected lists, makes empty-result success impossible, and updates the stale verifier header counts. `git apply --check` succeeds against the received v0.2.4 tree. Six Python-only probe cases in `optional_patch_probe_results.json` confirm early rejection and the corrected relative-path restoration; the positive control uses an explicitly labelled verifier stub, not Lean. An AST comparison confirms the `verify.py` change is module documentation only. Application notes are in `OPTIONAL_PATCH_README.md`.

For a portable reproduction, `verifier_probe/check_cli_patch.py` accepts an unpatched v0.2.4 `--project`, an optional `--patch`, and an output JSON `--out`. It stages only the two scripts, applies the patch in a temporary directory, and leaves the project unchanged. Its independent successful six-case run is saved in `portable_cli_probe_results.json`; this includes the verifier AST comparison and source-script hash checks. The earlier probe script and evidence remain unchanged.
