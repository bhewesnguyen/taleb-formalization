# T061: pinned Mathlib API feasibility note

Inspected the local Mathlib source at commit `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. This is a read-only API review, not a compiled implementation or a claim about current upstream coverage.

**The proposed Gumbel-first construction has a direct supported route.** Its measure-theory infrastructure is already present; the new work is chiefly the analytic properties of the existing `AuditTails.gumbelCDF` and connecting them to the extrema bridge.

| Purpose | Exact pinned declaration and source |
|---|---|
| Bundle a candidate CDF | `StieltjesFunction`, `Mathlib/MeasureTheory/Measure/Stieltjes.lean:38`: fields `toFun`, `mono' : Monotone toFun`, `right_continuous' : forall x, ContinuousWithinAt toFun (Set.Ici x) x`. |
| Construct its measure | `StieltjesFunction.measure`, same file, line 361. |
| Prove total mass one | `StieltjesFunction.isProbabilityMeasure`, same file, lines 506-507: endpoint limits `Tendsto f atBot (nhds 0)` and `Tendsto f atTop (nhds 1)` imply `IsProbabilityMeasure f.measure`. |
| Recover exactly the supplied CDF | `ProbabilityTheory.cdf_measure_stieltjesFunction`, `Mathlib/Probability/CDF.lean:93-99`, from the same two endpoint limits. The result is equality of bundled Stieltjes functions. |
| Relate the CDF to probabilities | `ProbabilityTheory.cdf_eq_real`, same file, line 76; requires `IsProbabilityMeasure`. Also `StieltjesFunction.measure_Iic` (Stieltjes line 434) and `measure_Ioi` (line 457) give direct lower-ray and strict-survival measures in `ENNReal.ofReal` form. |
| Promote pointwise CDF equality to measure equality | `StieltjesFunction.ext` (Stieltjes line 55), then `MeasureTheory.Measure.eq_of_cdf` or `MeasureTheory.Measure.cdf_eq_iff` (CDF lines 113-120), both measures probability measures. |
| Apply the project result | Existing `AuditExtremes.cdf_map_maxRV`; combine the concrete CDF theorem with `AuditTails.gumbel_maxstable`. This discharges the assumed Gumbel CDF realization. |

For `gumbelCDF x = Real.exp (-Real.exp (-x))`, monotonicity follows by the two order reversals and `Real.exp_monotone` / `Real.exp_strictMono` (`Mathlib/Analysis/Complex/Exponential.lean:292-302`). Global continuity follows from `Real.continuous_exp` and composition with negation, so it supplies the bundled right-continuity field. Endpoint limits use `Real.tendsto_exp_atTop` and `Real.tendsto_exp_atBot` (`Mathlib/Analysis/SpecialFunctions/Exp.lean:212-228`) plus negation and ordinary continuous composition. At positive infinity the inner exponential tends to zero, giving outer limit one; at negative infinity the inner exponential diverges to positive infinity, giving outer limit zero. No density integral or change-of-variables theorem is needed for this route.

Searches of the pinned `Probability` and `MeasureTheory` source found no named Gumbel, Fréchet-distribution, reverse-Weibull, or EVT distribution construction to instantiate directly. Fréchet-derivative hits were unrelated. Existing `expMeasure` and its CDF are in `Probability/Distributions/Exponential.lean`, but defining Gumbel through a transformed exponential would add map/log-support work that is unnecessary for the planned Stieltjes route. This search result is bounded to the inspected snapshot and directories.

Easy pitfalls for the Fable pass:

- `cdf` is totalized for arbitrary measures, and its own documentation warns that its ordinary interpretation is for probability measures. Prove/register `IsProbabilityMeasure` for the constructed measure before treating `cdf_eq_real` or measure uniqueness as probability evidence.
- Strict monotonicity and a density are not extra acceptance requirements. Monotonicity, right continuity, and endpoint limits already suffice for this construction; strict monotonicity is available for Gumbel if useful.
- The Stieltjes right-continuity field is over `Ici x`, not an unrestricted continuity requirement. Gumbel is globally continuous; Fréchet needs the separate support-boundary argument at zero.
- Preserve the existing support-correct `frechetCDF`, not `frechetFormula`. The latter evaluates to 1 at zero under Lean's totalized real power, already documented by `frechetFormula_zero`.
- Keep extrema sample size positive and location/scale wrappers' scale positive. Concrete-law instantiation removes the abstract CDF-realization premise, not the independence/common-law assumptions for arbitrary input coordinates.

This supplies the existing APIs for the recorded T061 child tasks. It adds no new scope to the milestone.
