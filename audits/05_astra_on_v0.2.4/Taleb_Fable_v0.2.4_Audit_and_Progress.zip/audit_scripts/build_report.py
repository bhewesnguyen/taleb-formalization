from pathlib import Path
import collections, hashlib, json, re, html
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

BASE = Path(__file__).resolve().parent
OUT = BASE.parent / 'output'
OUT.mkdir(exist_ok=True)
ROOT = BASE / 'received/Taleb_Lean_Repairs'
execution_path = BASE / 'execution_summary.json'
execution = json.loads(execution_path.read_text()) if execution_path.exists() else {
    'verdict': 'Independent execution pending. Source, ledger and release-identity reviews are complete.',
    'rows': [['Independent clean build', 'Pending'], ['Independent verifier', 'Pending'], ['Sequential regression suite', 'Pending']],
    'detail': 'The compiler environment is being restored. No fresh execution claim is made in this draft.'
}

pages = []
def page(title, subtitle=''):
    p = {'title': title, 'subtitle': subtitle, 'blocks': []}
    pages.append(p)
    return p['blocks']
def para(b, text): b.append(('p', text))
def head(b, text): b.append(('h', text))
def table(b, headers, rows, widths=None): b.append(('t', (headers, rows, widths)))
def bullets(b, items): b.append(('b', items))

b = page('Taleb Lean v0.2.4', 'Independent audit | 19 September 2026 | Release, mathematics and progress ledger')
head(b, 'Assessment')
para(b, '**Accept T060 as the first discharged obligation family.** The new maximum-CDF and minimum-survival theorems meet the original stated targets. Specific EVT measure construction already belonged to T061; the target was not narrowed to obtain closure. No mathematical repair was identified in the new extrema proofs.')
para(b, execution['verdict'])
table(b, ['Audit area', 'Assessment'], [
    ['New mathematics', '19 theorem declarations and 5 definitions added. Existing mathematical statements and proof bodies are unchanged.'],
    ['Eleven supported families', 'Keep all recorded statuses. Clarify prerequisite-only credit for T118 and T047; give T060 a probability-law delivery label.'],
    ['Prior verifier findings', 'Recursive source coverage and source/build restoration are implemented. Runtime evidence is detailed below.'],
    ['New findings', 'Two low-priority regression-runner CLI defects, plus ledger and source-reference wording corrections.'],
    ['Release identity', 'ZIP, manifest, Git snapshot and both patch routes match exactly.']
], [112, 386])
head(b, 'Progress that this release actually records')
para(b, '**1 discharged / 10 partial / 4 reuse / 91 missing / 34 source-check / 15 model-needed / 3 empirical = 158 families.** T060 is the new mathematical completion. T007\'s move to partial recognizes Gaussian work already delivered in v0.2.3.')
para(b, 'The 100 public checks and 189 scanned constants are implementation counts, not independent book theorems. The 158 ledger families differ greatly in size and are not an exhaustive atomic theorem census. Neither the closed-family fraction nor the supported-family fraction measures work completed across the book.')
para(b, 'Proceed with the proposed T061 child tasks, with the small runner and documentation cleanup alongside them. This audit does not establish an upstream Mathlib contribution or operational readiness of the separate quantum/classical application.')

b = page('What T060 now proves', 'The closure claim is justified within its unchanged scope')
para(b, 'Let the index type be finite and nonempty, let P be a probability measure, and let the real-valued coordinates Xᵢ be measurable, mutually independent, and share law ν. Write n for the number of coordinates. The code proves:')
table(b, ['Target', 'Delivered declaration and content'], [
    ['Maximum CDF', '`AuditExtremes.cdf_map_maxRV`: cdf(P.map(maxRV X))(x) = cdf(ν)(x)^n.'],
    ['Minimum survival', '`AuditExtremes.measureReal_map_minRV_Ioi`: P(min Xᵢ > x) = ν((x, ∞))^n.'],
    ['CDF complement form', '`AuditExtremes.measureReal_map_minRV_Ioi_eq_one_sub_cdf`: P(min Xᵢ > x) = (1 - cdf(ν)(x))^n.']
], [105, 393])
para(b, '`maxRV` and `minRV` are actual finite extrema of functions, with measurability proved. Their threshold preimages are connected to the events used by the independence lemmas. Equality of coordinate pushforward laws transfers probabilities of measurable sets to ν. The CDF theorem derives the needed probability-measure instances.')
head(b, 'Boundary and assumption checks')
bullets(b, [
    'Atoms are permitted. The maximum CDF uses ≤; minimum survival uses >, the exact complement convention. Separate product laws also cover < and ≥.',
    'Real-valued extrema require a nonempty finite index type. Empty-sample extrema are not assigned artificial real values. The one-coordinate and degenerate-law cases are allowed.',
    'Mutual independence is used through Mathlib\'s finite-intersection result. Pairwise independence is not substituted for it.',
    'Real/extended-real conversions are justified by the finite/probability hypotheses where needed. No infinite mass is silently treated as a real probability.',
    'The statements do not assume their desired maximum/minimum law as a premise. Ordinary independence, measurability and common-law hypotheses are appropriate for this generic theorem.'
])
head(b, 'Source correspondence and limits')
para(b, 'The exact maximum identity is Eq. (9.1), **printed p.172 / PDF p.186**, in the supplied v4 book. The section starts with Pareto variables; the code validly generalizes to arbitrary common laws, including atomic ones. The minimum survival identity is a proved companion extension of the source discussion, not a verbatim displayed survival equation.')
para(b, 'Correct the new theorem commentary that points to p.173 / PDF p.187: those pages contain the three EVT formulas. T060 does not close the density derivative, domains of attraction, or all of §9.1. Constructing named EVT measures and location/scale families remains T061.')

family_rows_a = [
    ['T001 | partial', 'Formula; source review', 'Accurate. Ratio-limit RV closure/example lemmas are proved. Positive measurable RV and its connection to these weaker predicates remain open. The negative-constant diagnostic makes the distinction explicit.'],
    ['T007 | partial', 'Actual law; source review', 'Accurate for the Gaussian slice α = 2, using Mathlib\'s Gaussian measure, including zero scale. No general stable-law existence or α < 2 realization is established. Reuse counts as realization, not novelty.'],
    ['T008 | partial', 'Conditional law', 'Accurate scoped credit. A genuine self-convolution predicate and finite-exponent preservation theorem exist. Concrete subexponential examples and equivalent n-fold characterizations remain open. A finite exponent is assumed.'],
    ['T029 | partial', 'Formula; source review', 'Accurate. The two-power-tail minimum exponent is an analytic formula theorem. The survival law of a nonnegative weighted random-variable sum still needs event-inclusion squeezing. Exact tail equivalence is a stronger task.'],
    ['T032 | partial', 'Formula', 'Accurate. Exponent α/p is proved for the analytic power composition. The measurable random-variable power pushforward, inverse-event argument and law identification remain open.']
]
family_rows_b = [
    ['T046 | partial', 'Formula; actual law; source review', 'Accurate with Gaussian-only realization. The stable bridge is instantiated with actual Gaussian laws. Cauchy remains a formula without a measure/characteristic-function identification.'],
    ['T047 | partial', 'Conditional law', 'Keep partial, but say prerequisite-only: conditional stable sum/convolution infrastructure. No sample-average law, affine scaling/location rule, or convergence theorem is delivered.'],
    ['T060 | discharged', 'Formula; source review; discharged', 'Closure accepted. The formula label underdescribes genuine generic probability-law theorems. Add a law_theorem facet; do not imply that a special-law existence premise is unresolved here.'],
    ['T061 | partial', 'Formula; conditional law', 'Accurate. Fréchet/Gumbel identities and conditional maxima results exist. No Gumbel, Fréchet or reverse-Weibull measure or full location/scale family has been constructed.'],
    ['T118 | partial', 'Formula', 'Keep prerequisite-only partial credit. Convexity of α ↦ c^(−α) is proved, not convexity of scale^p α/(α-p), its Pareto-moment identification, or integrated Jensen. This is the most important scope clarification.'],
    ['T124 | partial', 'Formula; source review', 'Accurate. A corrected rational-expression difference and positivity regime are proved. The gamma inverse-moment expectation, mixture law and integrability/divergence results remain open.']
]
b = page('Delivery-state audit, part 1', 'All eleven supported families reviewed against their credited declarations')
para(b, 'The delivery states are defensible as **nonexclusive evidence for named subparts**, not stages completed for an entire family. Only discharged is a whole-family completion judgment. The following assessments retain the recorded family statuses.')
table(b, ['Family / status', 'Recorded evidence', 'Audited scope and remaining work'], family_rows_a, [76, 98, 324])
head(b, 'How to make the ledger durable')
para(b, 'Add a short `delivery_scope` and explicit remaining obligations, ideally per child task. For Gaussian credit, say which parameter slice is realized. For T118 and T047, say which prerequisite is proved. A declaration name existing in the environment is necessary evidence, but it does not establish that the declaration meets the family target.')
para(b, 'The current labels are not a completion ladder: a generic law theorem need not construct a newly named distribution, and a source review is a human traceability judgment. A general `law_theorem` facet would distinguish ordinary theorem hypotheses from unresolved realization premises in a special CDF/CF bridge.')

b = page('Delivery-state audit, part 2', 'No additional family should be promoted to discharged')
table(b, ['Family / status', 'Recorded evidence', 'Audited scope and remaining work'], family_rows_b, [76, 98, 324])
para(b, 'There are **71 family/declaration citation pairs but 70 distinct declarations**: the Gaussian characteristic-function identification correctly receives credit in both T007 and T046. It is still one implementation. State counts overlap and should not be added together as completed work.')
para(b, 'Replace the stale backlog introduction saying that no row claims verification with: “Only rows marked discharged claim completion of their stated, reviewed scope.” T061\'s missing source-review tag may conservatively understate the reviewed formula slices; it does not change its partial status.')

b = page('Verifier and runner findings', 'Prior defects addressed; two small CLI repairs supplied separately')
head(b, 'Previous findings')
para(b, '**V1:** Recursive discovery now covers nested source modules under AuditRepairs and Proofs. Coverage is compared to actual imported modules, and private/internal constants remain in the axiom scan. The suite includes a nested orphan negative fixture and an imported nested theorem positive control.')
para(b, '**R1:** Each fixture restores source files and the project build directory from pristine snapshots, then checks the restored source hash before mutation. This removes the ordinary route by which a previous fixture\'s compiled proof could survive. It does not retrospectively prove the precise cause of the previous environment\'s interference.')
para(b, 'The new backlog gate correctly checks whether each credited declaration exists. It does not certify state labels, mathematical entailment, source correspondence or family discharge. The generator validates some schema constraints; preserving that validation in the normal verification path would be useful.')
head(b, 'H1 | low | unknown test selector can produce zero-test success')
para(b, '`scripts/harness_regression.py` accepts an unknown `--only` ID, executes no fixtures, and returns exit 0 with `fixture_count: 0` and “ALL FIXTURES BEHAVED AS EXPECTED”. A mixed known/unknown selection silently omits the unknown ID. Validate requested IDs and reject empty effective selections before creating scratch directories.')
head(b, 'H2 | low | relative scratch path fails restoration')
para(b, 'A relative `--scratch` path is later interpreted from the fixture directory by `cp`, so the pristine build snapshot cannot be found. Resolve a caller-supplied scratch path to an absolute path before use. The default temporary-directory path is unaffected.')
para(b, 'Neither issue invalidates the documented full 12-fixture invocation. Both were reproduced on the unchanged runner in a small synthetic Python project. The optional patch applies cleanly; targeted probes confirm early rejection of malformed selections and successful relative-path restoration. The positive probe uses an explicit verifier stub, not Lean. No mathematical source is changed.')
head(b, 'Minor documentation cleanup')
bullets(b, [
    'Correct the T060 equation/page reference and stale “T060, part” module heading.',
    'At event level, strict/non-strict inequalities differ on boundary events; their probabilities differ by boundary mass. Avoid saying sets differ only “on atoms”.',
    'Replace “every finding is reproduced before repair” with wording that distinguishes reproduced failures from preventive repairs based on audit evidence.',
    'A Git bundle proves committed history and archive equality, not the author\'s original worktree cleanliness or live remote push state.'
])

b = page('Next milestone: construct the EVT laws', 'T061 child tasks with explicit acceptance boundaries')
para(b, 'The proposed order is sound. Track the following as children of T061, preserving the parent\'s full scope. The suggested child labels below are planning labels, not new discharged ledger entries.')
table(b, ['Child', 'Required acceptance evidence'], [
    ['Gumbel', 'Global G(x) = exp(-exp(-x)); monotonicity, right continuity and endpoint limits; concrete measure; IsProbabilityMeasure; cdf equals G at every real x.'],
    ['Fréchet', 'For ξ > 0, F(x) = 0 when x ≤ 0 and exp(-x^(−1/ξ)) when x > 0. Prove the boundary behavior at zero, measure construction, probability normalization and global CDF identity.'],
    ['Reverse-Weibull', 'Support-correct upper-endpoint CDF with the declared positive shape parameter; endpoint behavior, probability measure and global CDF identity. A right-supported Weibull is not this EVT family.'],
    ['Location / scale', 'Pushforwards under x ↦ μ + σx with σ > 0; CDF transformation and parameter correspondence for all three named families.']
], [108, 390])
para(b, 'The pinned Mathlib already supplies the construction route: `StieltjesFunction.measure`, its probability-normalization theorem, `cdf_measure_stieltjesFunction`, and `Measure.eq_of_cdf`. The included T061 API note gives exact source references. Gumbel can use this route without a density integral.')
head(b, 'Connect Gumbel and Fréchet to the existing bridge')
para(b, 'Instantiate `cdf_map_maxRV` for measurable independent coordinates of the constructed common law. Combine the existing analytic max-stability identities with the new CDF identities to identify the maximum law with the correctly shifted/scaled named law. For a theorem claiming existence of iid realizations for every positive n, supply a finite product model and its coordinate maps.')
para(b, 'Prefer “max-stability instantiated for the constructed laws” to “unconditional”. Construction discharges the unresolved CDF-realization premise; independence, measurability, common-law, shape and positive sample-size assumptions remain in the appropriate RV statements.')
para(b, '**Do not close T061 after Gumbel and Fréchet alone.** Reverse-Weibull and the recorded location/scale scope remain part of the family. Child-level completion provides useful progress without weakening the parent target.')
head(b, 'Following this milestone')
para(b, 'T029: prove the finite log-tail exponent of nonnegative weighted sums using event inclusions. Independence is unnecessary for that squeeze argument. Keep exact convolution asymptotics separate. Then develop survival, moments, divergence and excess for the existing `paretoMeasure`, followed by power pushforwards. These slices advance broader families without automatically closing all their targets.')

b = page('Independent execution', 'Fresh build and verifier evidence, separated from supplied release logs')
table(b, ['Check', 'Independent outcome'], execution['rows'], [136, 362])
para(b, execution['detail'])
if execution.get('fixture_rows'):
    head(b, 'Sequential regression suite')
    table(b, ['Fixture', 'Verifier result', 'Expected behavior'], execution['fixture_rows'], [210, 102, 186])
    para(b, 'The result column is the verifier outcome inside each fixture. Negative fixtures are successful regression checks when they reject the intended defect. The suite itself must exit 0 only when every selected fixture behaves as expected.')
else:
    para(b, 'No independent sequential fixture result is asserted in this draft.')
para(b, 'Reproduction uses the pinned compiler and dependency revisions. The initial setup failures and later command results are preserved in the audit evidence. No uploaded mathematical source or verifier gate was changed to obtain a pass.')

b = page('Release identity and evidence', 'Archive, committed history, source anchors and audit boundaries')
table(b, ['Release check', 'Independent outcome'], [
    ['ZIP / manifest', '169 files; 168/168 manifest entries correct, with exact coverage excluding the manifest itself. No packaged build artifacts.'],
    ['Git history', 'Bundle verifies. All 169 project files equal commit aa484170a40e11a450fbff844f6d5fd4f927f153.'],
    ['Full / incremental patches', '117 / 39 changed files; each patch equals its Git diff, applies to its stated base, and reproduces the packaged tree.'],
    ['Historical bases / pins', 'v0.2.0 and v0.2.3 archives match the stated base commits. Lean/toolchain and dependency manifest are unchanged.'],
    ['Small optional patch', 'CLI-only targeted probes pass; no Lean proof change. Full baseline verification is assessed separately above.']
], [136, 362])
head(b, 'Identity anchors')
para(b, 'Release ZIP SHA-256: `60f6bf6989d5c15f2f8c4afe0ce3444c347acde0589083b25aec495f32af98fa`')
para(b, 'Book SHA-256: `758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567`; 523 pages. Lean: 4.24.0. Mathlib: `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.')
head(b, 'Source and audit references')
para(b, 'Taleb, [Statistical Consequences of Fat Tails, v4](https://arxiv.org/abs/2001.10488v4). Source pages inspected from the supplied PDF: Eq. (9.1), p.172 / PDF186; EVT forms, p.173 / PDF187; Pareto moment formula (21.7), p.382 / PDF396. The book revision date is also confirmed by the official arXiv record.')
para(b, 'Project evidence: ExtremeValueBridge.lean, GaussianBridge.lean, ProbabilityBridge.lean, the full 158-family JSON ledger, FABLE_REVIEW §14, verifier/scanner/runner source, supplied build records, patches and Git bundle. The audit package includes independent provenance results, family assessments, execution records and the optional runner patch. The uploaded release is preserved unchanged.')
para(b, 'No additional files are needed for this mathematical/source audit. Reviewing software deployment or a paper\'s empirical claim requires the separate application repository, revision, runnable command, input/output examples and exact claim.')

def md_inline(s): return s
md = []
for i,p in enumerate(pages):
    md += [('# ' if i == 0 else '## ') + p['title'], '', p['subtitle'], '']
    for typ, val in p['blocks']:
        if typ == 'p': md += [val, '']
        elif typ == 'h': md += ['### ' + val, '']
        elif typ == 'b': md += ['- ' + x for x in val] + ['']
        else:
            headers, rows, widths = val
            esc = lambda x: x.replace('|', '/')
            md += ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---']*len(headers)) + '|']
            md += ['| ' + ' | '.join(esc(x) for x in row) + ' |' for row in rows]
            md += ['']
md_text = '\n'.join(md)
assert '\u2014' not in md_text
(OUT/'Taleb_Fable_v0.2.4_Independent_Audit.md').write_text(md_text)

for n, f in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(n, '/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
styles = {
    'p': ParagraphStyle('p',fontName='Body',fontSize=9.1,leading=13.3,spaceAfter=8,textColor=colors.HexColor('#263445')),
    'h': ParagraphStyle('h',fontName='Bold',fontSize=11,leading=14,spaceBefore=6,spaceAfter=6,textColor=colors.HexColor('#0B5269')),
    'cell': ParagraphStyle('cell',fontName='Body',fontSize=8.2,leading=11.7,textColor=colors.HexColor('#263445')),
    'th': ParagraphStyle('th',fontName='Bold',fontSize=8.2,leading=11.7,textColor=colors.white),
    'title': ParagraphStyle('title',fontName='Bold',fontSize=24,leading=28,spaceAfter=9,textColor=colors.HexColor('#12283C')),
    'subtitle': ParagraphStyle('subtitle',fontName='Body',fontSize=9.2,leading=13,spaceAfter=18,textColor=colors.HexColor('#526878')),
}
def fmt(s):
    s=html.escape(s)
    s=re.sub(r'\[([^]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#0B5269">\1</link>',s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`(.+?)`',lambda m:'<font name="Mono" size="7.6">'+m.group(1)+'</font>',s)
    return s
def P(s,sty='p'): return Paragraph(fmt(s),styles[sty])
story=[]
for i,p in enumerate(pages):
    if i: story.append(PageBreak())
    story += [P(p['title'],'title'),P(p['subtitle'],'subtitle')]
    for typ,val in p['blocks']:
        if typ in ('p','h'): story.append(P(val,typ))
        elif typ=='b':
            for item in val:
                story.append(Paragraph('• '+fmt(item),styles['p']))
        else:
            headers,rows,widths=val
            data=[[P(x,'th') for x in headers]]+[[P(x,'cell') for x in row]for row in rows]
            t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
            row_padding=4 if headers[0]=='Fixture' else 8
            t.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#16445B')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F0F5F8'),colors.white]),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),
                ('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),row_padding),
                ('BOTTOMPADDING',(0,0),(-1,-1),row_padding),
                ('LINEBELOW',(0,-1),(-1,-1),0.4,colors.HexColor('#C9D5DF'))]))
            story += [t,Spacer(1,10)]
def decor(c,doc):
    c.saveState()
    c.setFillColor(colors.HexColor('#16445B')); c.rect(0,813.89,595.28,28,fill=1,stroke=0)
    c.setFillColor(colors.white);c.setFont('Bold',8)
    c.drawString(48,823,'INDEPENDENT AUDIT  /  TALEB LEAN v0.2.4')
    c.setStrokeColor(colors.HexColor('#C9D5DF'));c.line(48,42,547,42)
    c.setFont('Body',8);c.setFillColor(colors.HexColor('#526878'))
    c.drawString(48,28,'19 September 2026  |  Scope and evidence reviewed independently')
    c.drawRightString(547,28,str(doc.page));c.restoreState()
doc=SimpleDocTemplate(str(OUT/'Taleb_Fable_v0.2.4_Independent_Audit.pdf'),pagesize=(595.28,841.89),leftMargin=48,rightMargin=48,topMargin=49,bottomMargin=54,title='Taleb Lean v0.2.4 Independent Audit',author='Independent audit')
doc.build(story,onFirstPage=decor,onLaterPages=decor)

ledger=json.loads((ROOT/'docs/FORMALIZATION_BACKLOG.json').read_text())
review=json.loads((BASE/'ledger_review.json').read_text())
by_id={x['id']:x for x in review['families']}
full=[]
for original in ledger:
    entry={'original':original}
    if original['id'] in by_id: entry['audit']=by_id[original['id']]
    else: entry['audit']={'audited_status':original['status'],'scope':'Status tallied; no new proof credit or fresh full-family correctness audit in this release.'}
    full.append(entry)
progress={
    'release':'v0.2.4','audit_date':'2026-09-19','source_archive_sha256':'60f6bf6989d5c15f2f8c4afe0ce3444c347acde0589083b25aec495f32af98fa',
    'family_count':len(ledger),'status_counts':dict(collections.Counter(x['status'] for x in ledger)),
    'supported_families':11,'discharged_families':['T060'],'citation_pairs':71,'distinct_cited_declarations':70,
    'caution':'Unequal curated families, not an exhaustive atomic theorem census or an effort-completion percentage. States apply to scoped components; only discharged is a parent-family completion judgment.',
    'execution':execution,'families':full}
groups=collections.defaultdict(collections.Counter)
for r in ledger: groups[r['dependency_group']][r['status']]+=1
progress['dependency_group_counts']={g:dict(c) for g,c in sorted(groups.items())}
(OUT/'Taleb_Proof_Progress_v0.2.4.json').write_text(json.dumps(progress,indent=2,ensure_ascii=False)+'\n')
clean = lambda s: str(s).replace('\u2014','-').replace('\u2013','-').replace('|','/')
lines=['# Taleb proof progress, v0.2.4','',
    'Independent assessment, 19 September 2026. The full original rows and credited declaration lists are preserved in the companion JSON. This document adds audited scope for the eleven supported families and a readable index of all 158 families.','',
    '## Current position','',execution['verdict'],'',
    '| Status | Families |','|---|---:|']
for status in ['discharged','partial','reuse','missing','source-check','model-needed','empirical']:
    lines.append(f'| {status} | {progress["status_counts"][status]} |')
lines += ['','There is one closed family, T060, and ten additional partially supported families. T007 receives retrospective credit for its v0.2.3 Gaussian slice; T060 is the new v0.2.4 completion. The formal-proof working set is 140 families, alongside 15 model-needed and 3 empirical families.','',
    'These are unequal, curated obligation families, not an exhaustive atomic theorem census or a percentage of implementation effort. The 100 public checks, 189 scanned constants, 71 family/declaration citations and 70 distinct cited declarations describe different things. Delivery tags apply to scoped components and are not a completion ladder.','',
    '## Audited scope of the eleven supported families','']
for r in review['families']:
    lines += [f'### {r["id"]}: {r["title"]}','',f'**Status: {r["audited_status"]}.** Recorded states: '+', '.join(r['states'])+'.','',
        '**Assessment:** '+clean(r['audit_verdict']).replace('_',' '),'','**Delivered scope:** '+clean(r['audited_scope']),'',
        '**Recommended clarification:** '+clean(r['recommendation']),'','**Remaining target:** '+clean(r['remaining_target']),'']
lines += ['## Dependency-group position','',
    'Groups are the original ledger categories. CDF contains the newly closed generic extrema-law family; EVT contains the still-partial named-measure family. Remaining formal means reuse, missing and source-check rows together. Counts are not weighted by effort.','',
    '| Group | Families | Discharged | Partial | Source-check subset | Remaining formal | Model / empirical |',
    '|---|---:|---:|---:|---:|---:|---:|']
for g,c in sorted(groups.items()):
    values=[g,sum(c.values()),c['discharged'],c['partial'],c['source-check'],sum(c[s] for s in ['reuse','missing','source-check']),c['model-needed']+c['empirical']]
    lines.append('| '+' | '.join(str(v) for v in values)+' |')
lines += ['','The source-check column is a subset of remaining formal, not an additional category.','',
    '## Full 158-family index','',
    'Rows outside the eleven supported families are tallied here without a new full-family mathematical audit. Source locators are the release\'s recorded anchors. T060\'s exact maximum identity is Eq. (9.1), printed p.172 / PDF186; p.173 / PDF187 contains the EVT formulas.','',
    '| ID | Unit | Status | Group | Priority | Family | Printed pages |',
    '|---|---|---|---|---|---|---|']
for r in ledger:
    lines.append('| '+' | '.join(clean(r[k]) for k in ['id','unit','status','dependency_group','priority','title','printed_pages'])+' |')
lines += ['','## Next acceptance sequence','',
    '1. Apply/review the small runner CLI patch and clarify the ledger delivery scopes. Preserve the existing status counts.',
    '2. T061: complete Gumbel, Fréchet and reverse-Weibull construction children, including probability normalization and global CDF identities, then the recorded location/scale wrappers and concrete max-stability instantiations.',
    '3. T029: prove the finite log-tail exponent of nonnegative weighted sums by event inclusions. Exact convolution asymptotics remain separate.',
    '4. Exact Pareto survival, moments, divergence, excess and power pushforwards, using the existing Mathlib distribution. Credit the appropriate child slices without automatically closing broader parents.','',
    'See the independent audit for the T060 discharge reasoning, verifier findings, provenance and source limits. The evidence package includes the pinned T061 API note and optional runner repair.','']
(OUT/'Taleb_Proof_Progress_v0.2.4.md').write_text('\n'.join(lines))
print(json.dumps({'outputs':[str(p) for p in OUT.iterdir() if p.is_file()],'draft':not execution_path.exists()},indent=2))
