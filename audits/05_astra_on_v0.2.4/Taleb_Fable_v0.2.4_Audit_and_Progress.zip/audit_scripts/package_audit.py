from pathlib import Path
import hashlib, json, zipfile

BASE=Path(__file__).resolve().parent
OUT=BASE.parent/'output'
assert (BASE/'execution_summary.json').exists(), 'Final execution assessment required before packaging'
release_sha='60f6bf6989d5c15f2f8c4afe0ce3444c347acde0589083b25aec495f32af98fa'
readme=f'''# Taleb Lean v0.2.4 independent audit

Reviewed release ZIP SHA-256: `{release_sha}`.

The PDF and Markdown contain the consolidated assessment. The progress JSON preserves all
158 original family rows, with detailed audited scope for the eleven supported families.
The progress Markdown provides a readable full-family index and the same scope assessment.
The subreviews provide further file-level evidence. Final independent execution outcomes
are recorded in `evidence/execution_summary.json` and the accompanying reproduction files.
Supplied release logs and independently reproduced results are distinguished in the report.

## Optional runner repair

`repairs/optional_harness_cli.patch` addresses two low-priority CLI edge cases:
unknown/empty test selections and relative scratch paths. The uploaded release was not
edited. The patch also updates a stale verifier docstring without changing verifier logic.

From the `Taleb_Lean_Repairs` project root, after reviewing the patch:

```sh
git apply --check /path/to/repairs/optional_harness_cli.patch
git apply /path/to/repairs/optional_harness_cli.patch
```

The included Python-only probes validate the changed CLI behavior. Their positive control
explicitly stubs the verifier; it is not Lean proof evidence. Before applying the patch,
run the portable helper against a pristine v0.2.4 project:

```sh
python3 repairs/check_cli_patch.py --project /path/to/Taleb_Lean_Repairs --out ./cli_probe_results.json
```

Follow the project's ordinary verification gate after incorporating the patch:

```sh
lake exe cache get
lake build
python3 scripts/verify.py
python3 scripts/harness_regression.py
```

Use the unchanged Lean 4.24.0 / pinned Mathlib manifest. The full baseline suite result in
this audit concerns the received v0.2.4 runner, not a claim that the optional patch was run
through another full twelve-fixture Lean suite.

## Evidence boundaries

The audit accepts T060 against its original maximum-CDF/minimum-survival targets. T061
measure construction remains open. No upstream Mathlib merge, exhaustive atomic book
coverage, numerical implementation or deployment is certified. The Git bundle establishes
the packaged committed snapshot, not the author's original worktree or live remote state.

Compiler archives, dependency binaries, the source book and duplicated release archives
are excluded. SHA256SUMS records every included audit file except itself. Scripts retain
the observed audit workspace paths where they record execution evidence; they are not a
portable installer. Use the release's standard commands above for a fresh reproduction.
'''

files={}
for name in ['Taleb_Fable_v0.2.4_Independent_Audit.pdf','Taleb_Fable_v0.2.4_Independent_Audit.md','Taleb_Proof_Progress_v0.2.4.json','Taleb_Proof_Progress_v0.2.4.md']:
    files[name]=(OUT/name).read_bytes()
for name in ['math_t060_review.md','ledger_review.md','ledger_review.json','verifier_review.md','provenance_review.md','t061_api_note.md']:
    p=BASE/name
    if p.exists(): files['subreviews/'+name]=p.read_bytes()
for name in ['optional_harness_cli.patch','OPTIONAL_PATCH_README.md','test_optional_patch.py','optional_patch_probe_results.json','python_probe_results.json','check_cli_patch.py','portable_cli_probe_results.json']:
    p=BASE/'verifier_probe'/name
    files['repairs/'+name]=p.read_bytes()
for p in [BASE/'provenance/provenance.json',BASE/'provenance/check_provenance.py',BASE/'execution_summary.json']:
    files['evidence/'+p.name]=p.read_bytes()
for name in ['build_report.py','package_audit.py']:
    files['audit_scripts/'+name]=(BASE/name).read_bytes()
# Include selected small, relevant reproduction files, not caches or compiler archives.
for p in sorted((BASE/'reproduction').rglob('*')):
    if not p.is_file() or p.suffix not in {'.json','.md','.log','.py','.lean'}:
        continue
    if p.name in {'runtime_archive_diff.log','runtime_strace.log'} or p.stat().st_size>2_000_000:
        continue
    if any(s in p.parts for s in ['curl_config','__pycache__']):
        continue
    files['evidence/reproduction/'+str(p.relative_to(BASE/'reproduction'))]=p.read_bytes()
files['README.md']=readme.encode()
manifest=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items()))
files['SHA256SUMS']=manifest.encode()
target=OUT/'Taleb_Fable_v0.2.4_Audit_and_Progress.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()): z.writestr(name,data)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,data in files.items(): assert z.read(name)==data
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(OUT/(target.name+'.sha256')).write_text(digest+'  '+target.name+'\n')
print(json.dumps({'archive':str(target),'sha256':digest,'files':len(files),'bytes':target.stat().st_size},indent=2))
