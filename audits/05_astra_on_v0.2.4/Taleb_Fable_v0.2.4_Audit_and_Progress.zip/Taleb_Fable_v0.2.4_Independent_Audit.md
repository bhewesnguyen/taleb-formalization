# Taleb Lean v0.2.4

Independent audit | 19 September 2026 | Release, mathematics and progress ledger

### Assessment

**Accept T060 as the first discharged obligation family.** The new maximum-CDF and minimum-survival theorems meet the original stated targets. Specific EVT measure construction already belonged to T061; the target was not narrowed to obtain closure. No mathematical repair was identified in the new extrema proofs.

Independent clean build and verifier passed. The unchanged sequential regression suite passed all 12 fixtures with the intended outcomes. All 189 scanned project constants satisfy the standard three-axiom allowlist.

| Audit area | Assessment |
|---|---|
| New mathematics | 19 theorem declarations and 5 definitions added. Existing mathematical statements and proof bodies are unchanged. |
| Eleven supported families | Keep all recorded statuses. Clarify prerequisite-only credit for T118 and T047; give T060 a probability-law delivery label. |
| Prior verifier findings | Recursive source coverage and source/build restoration are implemented. Runtime evidence is detailed below. |
| New findings | Two low-priority regression-runner CLI defects, plus ledger and source-reference wording corrections. |
| Release identity | ZIP, manifest, Git snapshot and both patch routes match exactly. |

### Progress that this release actually records

**1 discharged / 10 partial / 4 reuse / 91 missing / 34 source-check / 15 model-needed / 3 empirical = 158 families.** T060 is the new mathematical completion. T007's move to partial recognizes Gaussian work already delivered in v0.2.3.

The 100 public checks and 189 scanned constants are implementation counts, not independent book theorems. The 158 ledger families differ greatly in size and are not an exhaustive atomic theorem census. Neither the closed-family fraction nor the supported-family fraction measures work completed across the book.

Proceed with the proposed T061 child tasks, with the small runner and documentation cleanup alongside them. This audit does not establish an upstream Mathlib contribution or operational readiness of the separate quantum/classical application.

## What T060 now proves

The closure claim is justified within its unchanged scope

Let the index type be finite and nonempty, let P be a probability measure, and let the real-valued coordinates Xᵢ be measurable, mutually independent, and share law ν. Write n for the number of coordinates. The code proves:

| Target | Delivered declaration and content |
|---|---|
| Maximum CDF | `AuditExtremes.cdf_map_maxRV`: cdf(P.map(maxRV X))(x) = cdf(ν)(x)^n. |
| Minimum survival | `AuditExtremes.measureReal_map_minRV_Ioi`: P(min Xᵢ > x) = ν((x, ∞))^n. |
| CDF complement form | `AuditExtremes.measureReal_map_minRV_Ioi_eq_one_sub_cdf`: P(min Xᵢ > x) = (1 - cdf(ν)(x))^n. |

`maxRV` and `minRV` are actual finite extrema of functions, with measurability proved. Their threshold preimages are connected to the events used by the independence lemmas. Equality of coordinate pushforward laws transfers probabilities of measurable sets to ν. The CDF theorem derives the needed probability-measure instances.

### Boundary and assumption checks

- Atoms are permitted. The maximum CDF uses ≤; minimum survival uses >, the exact complement convention. Separate product laws also cover < and ≥.
- Real-valued extrema require a nonempty finite index type. Empty-sample extrema are not assigned artificial real values. The one-coordinate and degenerate-law cases are allowed.
- Mutual independence is used through Mathlib's finite-intersection result. Pairwise independence is not substituted for it.
- Real/extended-real conversions are justified by the finite/probability hypotheses where needed. No infinite mass is silently treated as a real probability.
- The statements do not assume their desired maximum/minimum law as a premise. Ordinary independence, measurability and common-law hypotheses are appropriate for this generic theorem.

### Source correspondence and limits

The exact maximum identity is Eq. (9.1), **printed p.172 / PDF p.186**, in the supplied v4 book. The section starts with Pareto variables; the code validly generalizes to arbitrary common laws, including atomic ones. The minimum survival identity is a proved companion extension of the source discussion, not a verbatim displayed survival equation.

Correct the new theorem commentary that points to p.173 / PDF p.187: those pages contain the three EVT formulas. T060 does not close the density derivative, domains of attraction, or all of §9.1. Constructing named EVT measures and location/scale families remains T061.

## Delivery-state audit, part 1

All eleven supported families reviewed against their credited declarations

The delivery states are defensible as **nonexclusive evidence for named subparts**, not stages completed for an entire family. Only discharged is a whole-family completion judgment. The following assessments retain the recorded family statuses.

| Family / status | Recorded evidence | Audited scope and remaining work |
|---|---|---|
| T001 / partial | Formula; source review | Accurate. Ratio-limit RV closure/example lemmas are proved. Positive measurable RV and its connection to these weaker predicates remain open. The negative-constant diagnostic makes the distinction explicit. |
| T007 / partial | Actual law; source review | Accurate for the Gaussian slice α = 2, using Mathlib's Gaussian measure, including zero scale. No general stable-law existence or α < 2 realization is established. Reuse counts as realization, not novelty. |
| T008 / partial | Conditional law | Accurate scoped credit. A genuine self-convolution predicate and finite-exponent preservation theorem exist. Concrete subexponential examples and equivalent n-fold characterizations remain open. A finite exponent is assumed. |
| T029 / partial | Formula; source review | Accurate. The two-power-tail minimum exponent is an analytic formula theorem. The survival law of a nonnegative weighted random-variable sum still needs event-inclusion squeezing. Exact tail equivalence is a stronger task. |
| T032 / partial | Formula | Accurate. Exponent α/p is proved for the analytic power composition. The measurable random-variable power pushforward, inverse-event argument and law identification remain open. |

### How to make the ledger durable

Add a short `delivery_scope` and explicit remaining obligations, ideally per child task. For Gaussian credit, say which parameter slice is realized. For T118 and T047, say which prerequisite is proved. A declaration name existing in the environment is necessary evidence, but it does not establish that the declaration meets the family target.

The current labels are not a completion ladder: a generic law theorem need not construct a newly named distribution, and a source review is a human traceability judgment. A general `law_theorem` facet would distinguish ordinary theorem hypotheses from unresolved realization premises in a special CDF/CF bridge.

## Delivery-state audit, part 2

No additional family should be promoted to discharged

| Family / status | Recorded evidence | Audited scope and remaining work |
|---|---|---|
| T046 / partial | Formula; actual law; source review | Accurate with Gaussian-only realization. The stable bridge is instantiated with actual Gaussian laws. Cauchy remains a formula without a measure/characteristic-function identification. |
| T047 / partial | Conditional law | Keep partial, but say prerequisite-only: conditional stable sum/convolution infrastructure. No sample-average law, affine scaling/location rule, or convergence theorem is delivered. |
| T060 / discharged | Formula; source review; discharged | Closure accepted. The formula label underdescribes genuine generic probability-law theorems. Add a law_theorem facet; do not imply that a special-law existence premise is unresolved here. |
| T061 / partial | Formula; conditional law | Accurate. Fréchet/Gumbel identities and conditional maxima results exist. No Gumbel, Fréchet or reverse-Weibull measure or full location/scale family has been constructed. |
| T118 / partial | Formula | Keep prerequisite-only partial credit. Convexity of α ↦ c^(−α) is proved, not convexity of scale^p α/(α-p), its Pareto-moment identification, or integrated Jensen. This is the most important scope clarification. |
| T124 / partial | Formula; source review | Accurate. A corrected rational-expression difference and positivity regime are proved. The gamma inverse-moment expectation, mixture law and integrability/divergence results remain open. |

There are **71 family/declaration citation pairs but 70 distinct declarations**: the Gaussian characteristic-function identification correctly receives credit in both T007 and T046. It is still one implementation. State counts overlap and should not be added together as completed work.

Replace the stale backlog introduction saying that no row claims verification with: “Only rows marked discharged claim completion of their stated, reviewed scope.” T061's missing source-review tag may conservatively understate the reviewed formula slices; it does not change its partial status.

## Verifier and runner findings

Prior defects addressed; two small CLI repairs supplied separately

### Previous findings

**V1:** Recursive discovery now covers nested source modules under AuditRepairs and Proofs. Coverage is compared to actual imported modules, and private/internal constants remain in the axiom scan. The suite includes a nested orphan negative fixture and an imported nested theorem positive control.

**R1:** Each fixture restores source files and the project build directory from pristine snapshots, then checks the restored source hash before mutation. This removes the ordinary route by which a previous fixture's compiled proof could survive. It does not retrospectively prove the precise cause of the previous environment's interference.

The new backlog gate correctly checks whether each credited declaration exists. It does not certify state labels, mathematical entailment, source correspondence or family discharge. The generator validates some schema constraints; preserving that validation in the normal verification path would be useful.

### H1 | low | unknown test selector can produce zero-test success

`scripts/harness_regression.py` accepts an unknown `--only` ID, executes no fixtures, and returns exit 0 with `fixture_count: 0` and “ALL FIXTURES BEHAVED AS EXPECTED”. A mixed known/unknown selection silently omits the unknown ID. Validate requested IDs and reject empty effective selections before creating scratch directories.

### H2 | low | relative scratch path fails restoration

A relative `--scratch` path is later interpreted from the fixture directory by `cp`, so the pristine build snapshot cannot be found. Resolve a caller-supplied scratch path to an absolute path before use. The default temporary-directory path is unaffected.

Neither issue invalidates the documented full 12-fixture invocation. Both were reproduced on the unchanged runner in a small synthetic Python project. The optional patch applies cleanly; targeted probes confirm early rejection of malformed selections and successful relative-path restoration. The positive probe uses an explicit verifier stub, not Lean. No mathematical source is changed.

### Minor documentation cleanup

- Correct the T060 equation/page reference and stale “T060, part” module heading.
- At event level, strict/non-strict inequalities differ on boundary events; their probabilities differ by boundary mass. Avoid saying sets differ only “on atoms”.
- Replace “every finding is reproduced before repair” with wording that distinguishes reproduced failures from preventive repairs based on audit evidence.
- A Git bundle proves committed history and archive equality, not the author's original worktree cleanliness or live remote push state.

## Next milestone: construct the EVT laws

T061 child tasks with explicit acceptance boundaries

The proposed order is sound. Track the following as children of T061, preserving the parent's full scope. The suggested child labels below are planning labels, not new discharged ledger entries.

| Child | Required acceptance evidence |
|---|---|
| Gumbel | Global G(x) = exp(-exp(-x)); monotonicity, right continuity and endpoint limits; concrete measure; IsProbabilityMeasure; cdf equals G at every real x. |
| Fréchet | For ξ > 0, F(x) = 0 when x ≤ 0 and exp(-x^(−1/ξ)) when x > 0. Prove the boundary behavior at zero, measure construction, probability normalization and global CDF identity. |
| Reverse-Weibull | Support-correct upper-endpoint CDF with the declared positive shape parameter; endpoint behavior, probability measure and global CDF identity. A right-supported Weibull is not this EVT family. |
| Location / scale | Pushforwards under x ↦ μ + σx with σ > 0; CDF transformation and parameter correspondence for all three named families. |

The pinned Mathlib already supplies the construction route: `StieltjesFunction.measure`, its probability-normalization theorem, `cdf_measure_stieltjesFunction`, and `Measure.eq_of_cdf`. The included T061 API note gives exact source references. Gumbel can use this route without a density integral.

### Connect Gumbel and Fréchet to the existing bridge

Instantiate `cdf_map_maxRV` for measurable independent coordinates of the constructed common law. Combine the existing analytic max-stability identities with the new CDF identities to identify the maximum law with the correctly shifted/scaled named law. For a theorem claiming existence of iid realizations for every positive n, supply a finite product model and its coordinate maps.

Prefer “max-stability instantiated for the constructed laws” to “unconditional”. Construction discharges the unresolved CDF-realization premise; independence, measurability, common-law, shape and positive sample-size assumptions remain in the appropriate RV statements.

**Do not close T061 after Gumbel and Fréchet alone.** Reverse-Weibull and the recorded location/scale scope remain part of the family. Child-level completion provides useful progress without weakening the parent target.

### Following this milestone

T029: prove the finite log-tail exponent of nonnegative weighted sums using event inclusions. Independence is unnecessary for that squeeze argument. Keep exact convolution asymptotics separate. Then develop survival, moments, divergence and excess for the existing `paretoMeasure`, followed by power pushforwards. These slices advance broader families without automatically closing all their targets.

## Independent execution

Fresh build and verifier evidence, separated from supplied release logs

| Check | Independent outcome |
|---|---|
| Clean lake build | PASS; exit 0; 91.55 s; no compiler diagnostics. |
| Verifier | PASS; 83 theorems + 1 instance + 16 aliases = 100 checks; 189 constants, including 48 internal; 258.97 s. |
| Sequential regression | PASS; 12/12 expected outcomes; exit 0; 2,917.16 s (48 min 37 s) in this environment. |

The 161 received files outside regenerated evidence match byte-for-byte. All nine dependencies match their pinned revisions and have clean worktrees. Every fixture restored the pristine source hash and reset the project build snapshot. The allowlist is propext, Classical.choice and Quot.sound; no project axioms were found.

### Sequential regression suite

| Fixture | Verifier result | Expected behavior |
|---|---|---|
| valid | PASS | Positive control |
| private_sorry_theorem | FAIL | Diagnostics; sorryAx also scanned |
| private_sorry_def | FAIL | Diagnostics; sorryAx also scanned |
| private_axiom | FAIL | Forbidden project axiom |
| structure_namespace_theorem | FAIL | Public inventory mismatch |
| protected_theorem | FAIL | Public inventory mismatch |
| alias_map_mismatch | FAIL | Wrong alias target |
| alias_map_mismatch_optimized | FAIL | Wrong alias target under -O |
| orphan_module | FAIL | Unimported module |
| nested_orphan_module | FAIL | Nested unimported module |
| nested_imported_module | PASS | Imported nested theorem scanned |
| dirty_dependency | FAIL | Modified dependency |

The result column is the verifier outcome inside each fixture. Negative fixtures are successful regression checks when they reject the intended defect. The suite itself must exit 0 only when every selected fixture behaves as expected.

Reproduction uses the pinned compiler and dependency revisions. The initial setup failures and later command results are preserved in the audit evidence. No uploaded mathematical source or verifier gate was changed to obtain a pass.

## Release identity and evidence

Archive, committed history, source anchors and audit boundaries

| Release check | Independent outcome |
|---|---|
| ZIP / manifest | 169 files; 168/168 manifest entries correct, with exact coverage excluding the manifest itself. No packaged build artifacts. |
| Git history | Bundle verifies. All 169 project files equal commit aa484170a40e11a450fbff844f6d5fd4f927f153. |
| Full / incremental patches | 117 / 39 changed files; each patch equals its Git diff, applies to its stated base, and reproduces the packaged tree. |
| Historical bases / pins | v0.2.0 and v0.2.3 archives match the stated base commits. Lean/toolchain and dependency manifest are unchanged. |
| Small optional patch | CLI-only targeted probes pass; no Lean proof change. Full baseline verification is assessed separately above. |

### Identity anchors

Release ZIP SHA-256: `60f6bf6989d5c15f2f8c4afe0ce3444c347acde0589083b25aec495f32af98fa`

Book SHA-256: `758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567`; 523 pages. Lean: 4.24.0. Mathlib: `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.

### Source and audit references

Taleb, [Statistical Consequences of Fat Tails, v4](https://arxiv.org/abs/2001.10488v4). Source pages inspected from the supplied PDF: Eq. (9.1), p.172 / PDF186; EVT forms, p.173 / PDF187; Pareto moment formula (21.7), p.382 / PDF396. The book revision date is also confirmed by the official arXiv record.

Project evidence: ExtremeValueBridge.lean, GaussianBridge.lean, ProbabilityBridge.lean, the full 158-family JSON ledger, FABLE_REVIEW §14, verifier/scanner/runner source, supplied build records, patches and Git bundle. The audit package includes independent provenance results, family assessments, execution records and the optional runner patch. The uploaded release is preserved unchanged.

No additional files are needed for this mathematical/source audit. Reviewing software deployment or a paper's empirical claim requires the separate application repository, revision, runnable command, input/output examples and exact claim.
