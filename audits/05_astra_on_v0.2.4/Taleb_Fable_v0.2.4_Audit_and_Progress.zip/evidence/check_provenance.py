from pathlib import Path, PurePosixPath
import hashlib,json,subprocess,zipfile,collections,tarfile,io
root=Path('/workspace/scratch/c40a0826d9d8')
upload=root/'upload'
work=root/'audit_v024/provenance'
repo=work/'repo'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=repo):
 p=subprocess.run(['git',*args],cwd=cwd,text=True,capture_output=True)
 if p.returncode:raise RuntimeError(f'{args}: {p.stderr}')
 return p.stdout
zpath=upload/'Taleb_Lean_Implementation_Handoff_v0.2.4_fable.zip'
checksum=(upload/(zpath.name+'.sha256')).read_text().split()[0]
result={'archive':{'sha256':sha(zpath.read_bytes()),'expected_sha256':checksum},'bundle':{},'patches':{}}
with zipfile.ZipFile(zpath) as z:
 info=z.infolist();files=[f for f in info if not f.is_dir()];names=[f.filename for f in files]
 a={n:z.read(n) for n in names}
 result['archive'].update({'file_count':len(files),'duplicate_names':[n for n,c in collections.Counter(names).items() if c>1],'unsafe_paths':[n for n in names if PurePosixPath(n).is_absolute() or '..' in PurePosixPath(n).parts],'symlinks':[i.filename for i in files if (i.external_attr>>16)&0o170000==0o120000],'unexpected_build_paths':[n for n in names if any(x in PurePosixPath(n).parts for x in ('.lake','__pycache__')) or n.endswith(('.pyc','.olean','.ilean'))]})
 manifestname='Taleb_Lean_Repairs/SHA256SUMS';lines=a[manifestname].decode().splitlines();m={}
 for line in lines:
  digest,name=line.split('  ',1);m['Taleb_Lean_Repairs/'+name]=digest
 result['manifest']={'entry_count':len(m),'line_count':len(lines),'hash_mismatches':[n for n,d in m.items() if n not in a or sha(a[n])!=d],'missing_from_manifest':sorted(set(a)-set(m)-{manifestname}),'manifest_extras':sorted(set(m)-set(a))}
 result['archive']['hash_ok']=result['archive']['sha256']==checksum
tracked=git('ls-files','-z','--','Taleb_Lean_Repairs').split('\0')[:-1]
result['bundle']={'refs':git('show-ref').splitlines(),'head':git('rev-parse','HEAD').strip(),'clean_clone':not git('status','--porcelain'),'tracked_project_files':len(tracked),'archive_missing_tracked':sorted(set(tracked)-set(a)),'archive_untracked_extras':sorted(set(a)-set(tracked)),'tracked_byte_mismatches':[n for n in tracked if n in a and (repo/n).read_bytes()!=a[n]],'verify':git('bundle','verify',str(upload/'taleb-formalization_v0.2.4.bundle')),'log':git('log','--format=%H %s','--all').splitlines()}
result['pins']={p:{'head_sha256':sha(a['Taleb_Lean_Repairs/'+p]),'unchanged_from_v020':subprocess.check_output(['git','show',f'f6b1007:Taleb_Lean_Repairs/{p}'],cwd=repo)==a['Taleb_Lean_Repairs/'+p]}for p in ['lake-manifest.json','lean-toolchain']}
for label,base,patch in [('v020_to_v024','f6b1007','fable_changes_v0.2.4.patch'),('v023_to_v024','a5fe300','fable_changes_v0.2.3_to_v0.2.4.patch')]:
 target=work/label
 if target.exists():git('worktree','remove','--force',str(target))
 git('worktree','add','--detach',str(target),base)
 raw=(upload/patch).read_bytes()
 expected=subprocess.check_output(['git','diff',base,'aa48417','--','Taleb_Lean_Repairs'],cwd=repo)
 check=git('apply','--check',str(upload/patch),cwd=target)
 apply=git('apply',str(upload/patch),cwd=target)
 targetfiles={str(p.relative_to(target)):p.read_bytes() for p in (target/'Taleb_Lean_Repairs').rglob('*') if p.is_file()}
 result['patches'][label]={'base_full':git('rev-parse',base).strip(),'patch_sha256':sha(raw),'byte_equal_to_git_diff':raw==expected,'changed_file_count':len(git('diff','--name-only',base,'aa48417','--','Taleb_Lean_Repairs').splitlines()),'apply_check_ok':True,'apply_ok':True,'missing_files':sorted(set(a)-set(targetfiles)),'extra_files':sorted(set(targetfiles)-set(a)),'byte_mismatches':[n for n in a if n in targetfiles and a[n]!=targetfiles[n]]}
# The repository's received-artifact manifest is separate from the package.
man=repo/'audits/RECEIVED_ARTIFACTS.sha256'
if man.exists():
 entries=[]
 for line in man.read_text().splitlines():
  if not line.strip() or line.startswith('#'):continue
  digest,name=line.split('  ',1)
  p=man.parent/name
  entries.append({'path':name,'exists':p.exists(),'sha256_ok':p.exists() and sha(p.read_bytes())==digest})
 result['received_artifacts_manifest']={'count':len(entries),'all_ok':all(x['sha256_ok'] for x in entries),'entries':entries}
result['historical_archives']={}
for label,revision,path in [('v020','f6b1007',repo/'audits/02_handoff_v0.2.0/Taleb_Lean_Implementation_Handoff.zip'),('v023','a5fe300',repo/'deliverables/v0.2.3/Taleb_Lean_Implementation_Handoff_v0.2.3_fable.zip')]:
 with zipfile.ZipFile(path) as z: archive={i.filename:z.read(i.filename) for i in z.infolist() if not i.is_dir()}
 historical_tracked=git('ls-tree','-r','--name-only',revision,'--','Taleb_Lean_Repairs').splitlines()
 mismatches=[]
 for name in historical_tracked:
  if name in archive and archive[name]!=subprocess.check_output(['git','show',f'{revision}:{name}'],cwd=repo):mismatches.append(name)
 result['historical_archives'][label]={'sha256':sha(path.read_bytes()),'file_count':len(archive),'tracked_count':len(historical_tracked),'missing_in_archive':sorted(set(historical_tracked)-set(archive)),'extra_in_archive':sorted(set(archive)-set(historical_tracked)),'byte_mismatches':mismatches}
(work/'provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='bundle'},indent=2))
print(json.dumps({k:v for k,v in result['bundle'].items() if k!='log'},indent=2))
