import Lean
#eval 2+2
