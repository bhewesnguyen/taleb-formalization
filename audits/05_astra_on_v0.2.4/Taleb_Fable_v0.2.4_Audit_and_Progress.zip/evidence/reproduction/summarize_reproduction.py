from pathlib import Path
import json, hashlib, subprocess, shutil
base=Path(__file__).resolve().parent
received=base.parent/'received/Taleb_Lean_Repairs'
run=Path('/tmp/taleb_v024_audit_project')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted(p.relative_to(received) for p in received.rglob('*') if p.is_file() and not p.relative_to(received).as_posix().startswith('evidence/current/'))
comparisons=[{'path':str(p),'received_sha256':sha(received/p),'tested_sha256':sha(run/p),'identical':sha(received/p)==sha(run/p)} for p in paths]
(base/'source_comparison.json').write_text(json.dumps({'all_received_files_except_generated_evidence_identical':all(x['identical'] for x in comparisons),'compared_file_count':len(comparisons),'files':comparisons},indent=2)+'\n')
commands=json.loads((base/'reproduction.json').read_text())
verification=json.loads((run/'evidence/current/verification.json').read_text())
regression=json.loads((base/'regression/harness_regression.json').read_text())
deps=[]
for p in json.loads((received/'lake-manifest.json').read_text())['packages']:
 d=run/'.lake/packages'/p['name']
 rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=d,text=True).strip()
 dirty=subprocess.check_output(['git','status','--porcelain'],cwd=d,text=True).strip()
 deps.append({'name':p['name'],'manifest_rev':p['rev'],'actual_rev':rev,'revision_matches':rev==p['rev'],'working_tree_clean':dirty==''})
summary={'project':'Taleb Lean Repairs v0.2.4','tested_project':str(run),'runtime_version':(base/'runtime_version.log').read_text().strip(),'setup_note':'setup_notes.md','environment_overrides':{'PATH_prepend':'/tmp/taleb_v024_runtime/bin','TAR_OPTIONS':'--no-same-owner','CURL_HOME':str(base/'curl_config')},'commands':commands,'verification':verification,'all_lean_sources_and_pins_identical':all(x['identical'] for x in comparisons),'all_received_files_except_generated_evidence_identical':all(x['identical'] for x in comparisons),'compared_file_count':len(comparisons),'source_comparison':'source_comparison.json','dependency_revision_and_cleanliness':deps,'regression':{'fixture_count':regression['fixture_count'],'all_fixtures_behaved_as_expected':regression['all_fixtures_behaved_as_expected'],'pristine_tree_sha256':regression['pristine_tree_sha256'],'results':[{'id':r['id'],'verifier_exit_code':r['verifier_exit_code'],'verification_status':r['verification_status'],'verification_error':r['verification_error'],'behaved_as_expected':r['behaved_as_expected'],'seconds':r['seconds'],'restored_tree_sha256':r['restored_tree_sha256'],'restored_tree_matches_pristine':r['restored_tree_matches_pristine'],'build_dir_reset_from_snapshot':r['build_dir_reset_from_snapshot'],'note':r['note']} for r in regression['results']]}}
(base/'execution_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
dest=base/'verified_evidence';dest.mkdir(exist_ok=True)
for name in ['verification.json','build.log','axioms.log','inventory_environment.json','inventory_environment.log','inventory_regex.json']:
 src=run/'evidence/current'/name
 if src.exists():shutil.copy2(src,dest/name)
print(json.dumps({'all_commands_exit0':all(r['exit_code']==0 for r in commands),'verification_status':verification.get('status'),'fixtures':regression['fixture_count'],'all_fixtures_behaved_as_expected':regression['all_fixtures_behaved_as_expected'],'all_sources_and_pins_identical':summary['all_lean_sources_and_pins_identical'],'all_dependencies_correct_clean':all(d['revision_matches'] and d['working_tree_clean'] for d in deps)},indent=2))
