from pathlib import Path
import subprocess,time,json,os,sys
base=Path(__file__).resolve().parent
root=Path('/tmp/taleb_v024_audit_project')
env=dict(os.environ)
env['TAR_OPTIONS']='--no-same-owner'
env['CURL_HOME']=str(base/'curl_config')
env['PATH']='/tmp/taleb_v024_runtime/bin'+os.pathsep+env['PATH']
records=[]
commands=[('runtime_version',['lean','--version']),('cache',['lake', 'exe', 'cache', 'get', 'Mathlib.Analysis.Asymptotics.AsymptoticEquivalent', 'Mathlib.Analysis.Complex.Exponential', 'Mathlib.Analysis.Convex.SpecificFunctions.Basic', 'Mathlib.Analysis.SpecialFunctions.Exp', 'Mathlib.Analysis.SpecialFunctions.Log.Basic', 'Mathlib.Analysis.SpecialFunctions.Pow.Continuity', 'Mathlib.Analysis.SpecialFunctions.Pow.Real', 'Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic', 'Mathlib.Data.Real.Sign', 'Mathlib.MeasureTheory.Measure.CharacteristicFunction', 'Mathlib.MeasureTheory.Measure.Real', 'Mathlib.Probability.CDF', 'Mathlib.Probability.Distributions.Gaussian.Real', 'Mathlib.Probability.Independence.Basic', 'Mathlib.Topology.Algebra.Order.Field', 'Mathlib.Topology.Order.LiminfLimsup']),('clean_build',['lake','build']),('verify',['python3','scripts/verify.py']),('regression',['python3','scripts/harness_regression.py','--scratch','/tmp/taleb_v024_regression_scratch','--out',str(base/'regression')])]
for name,cmd in commands:
 t=time.monotonic()
 print('START',name,flush=True)
 with (base/(name+'.log')).open('w') as log:
  proc=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec={'name':name,'command':cmd,'cwd':str(root),'exit_code':proc.returncode,'seconds':round(time.monotonic()-t,2),'log':str(base/(name+'.log'))}
 records.append(rec)
 (base/'reproduction.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(rec),flush=True)
 if proc.returncode: sys.exit(proc.returncode)
