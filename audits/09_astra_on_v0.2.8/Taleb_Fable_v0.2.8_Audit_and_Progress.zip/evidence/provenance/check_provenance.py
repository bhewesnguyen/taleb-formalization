#!/usr/bin/env python3
"""Reproduce bounded archive, patch, pin, and retained-artifact provenance checks."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, re, stat, subprocess, zipfile
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'audit_v028/provenance'
REPO=OUT/'repo'
RECEIVED=ROOT/'audit_v028/received/Taleb_Lean_Repairs'
UPLOAD=ROOT/'upload'
PREFIX='Taleb_Lean_Repairs/'
def sha(b): return hashlib.sha256(b).hexdigest()
def run(args,env=None):
    p=subprocess.run(args,cwd=REPO,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    return p.stdout

def git(*a,env=None): return run(['git',*a],env)

def manifest(data,loader):
    rows=[]
    for line in data.decode().splitlines():
        if not line.strip(): continue
        h,n=line.split('  ',1)
        assert re.fullmatch(r'[0-9a-f]{64}',h)
        assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
        actual=sha(loader(n));rows.append({'path':n,'expected':h,'actual':actual,'match':h==actual})
    assert len({r['path'] for r in rows})==len(rows)
    assert all(r['match'] for r in rows)
    return rows

report={'inputs':{p.name:sha(p.read_bytes()) for p in sorted(UPLOAD.glob('*v0.2.8*')) if p.is_file()}}
zpath=UPLOAD/'Taleb_Lean_Implementation_Handoff_v0.2.8_fable.zip'
assert sha(zpath.read_bytes())=='696c5187ed87bb0ad428bbbdd78185758de5b437fb14a9e2411c07b32a8ccbb0'
assert (UPLOAD/(zpath.name+'.sha256')).read_text().split()[0]==sha(zpath.read_bytes())
with zipfile.ZipFile(zpath) as z:
    names=z.namelist(); assert len(set(names))==len(names)
    for info in z.infolist():
        p=PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts
        assert p.parts[0]=='Taleb_Lean_Repairs'
        assert not stat.S_ISLNK(info.external_attr>>16)
        assert '.lake' not in p.parts and '__pycache__' not in p.parts and '.git' not in p.parts
        assert p.suffix not in {'.olean','.ilean','.pyc','.o','.so'}
    files={n[len(PREFIX):]:z.read(n) for n in names if not n.endswith('/')}
    rows=manifest(files['SHA256SUMS'],lambda n:files[n])
    assert set(r['path'] for r in rows)==set(files)-{'SHA256SUMS'}
    extracted={str(p.relative_to(RECEIVED)):p.read_bytes() for p in RECEIVED.rglob('*') if p.is_file()}
    assert extracted==files
    report['zip']={'sha256':sha(zpath.read_bytes()),'entries':len(names),'files':len(files),'manifest_checks':len(rows),'safe_paths':True,'no_build_outputs':True,'extraction_bytes_equal':True}

bundle=UPLOAD/'taleb-formalization_v0.2.8.bundle'
p=subprocess.run(['git','bundle','verify',str(bundle)],cwd=REPO,text=True,capture_output=True,check=True)
(OUT/'bundle_verify.log').write_text(p.stdout+p.stderr)
assert 'complete history' in p.stdout+p.stderr
commit=git('rev-parse','main').decode().strip()
assert commit=='d086ce0cc9ac978e332df4d25bd92994e5f09230'
project_tree=git('rev-parse',commit+':Taleb_Lean_Repairs').decode().strip()
tracked=git('ls-tree','-r','--name-only',commit,'--','Taleb_Lean_Repairs').decode().splitlines()
assert {n[len(PREFIX):] for n in tracked}==set(files)
assert all(git('show',commit+':'+PREFIX+n)==b for n,b in files.items())
report['bundle']={'complete_history':True,'commit':commit,'project_tree':project_tree,'all_project_bytes_equal_archive':True,'ref':git('bundle','list-heads',str(bundle)).decode().strip()}
log=git('log','--format=%H %s','499e9e0..'+commit).decode().strip().splitlines()
report['history']={'commits_since_v027_deliverables_in_bundle':len(log),'commits':log,'claimed_fourth_deliverables_commit':'Explicitly outside bundle, not independently inspected','original_worktree_cleanliness_or_remote_state_verified':False}
(OUT/'recent_history.log').write_text(git('log','-14','--format=%H %s').decode())
report['patches']=[]
for label,base,pname,expected_count in [('full','f6b1007','fable_changes_v0.2.8.patch',186),('incremental','fe14519','fable_changes_v0.2.7_to_v0.2.8.patch',42)]:
    index=OUT/(label+'.index')
    if index.exists(): index.unlink()
    env=os.environ.copy(); env['GIT_INDEX_FILE']=str(index)
    git('read-tree',base,env=env)
    git('apply','--cached','--check',str(UPLOAD/pname),env=env)
    git('apply','--cached',str(UPLOAD/pname),env=env)
    result_tree=git('write-tree',env=env).decode().strip()
    result_project_tree=git('rev-parse',result_tree+':Taleb_Lean_Repairs').decode().strip()
    assert result_project_tree==project_tree
    paths=git('ls-tree','-r','--name-only',result_tree,'--','Taleb_Lean_Repairs').decode().splitlines()
    assert {n[len(PREFIX):] for n in paths}==set(files)
    assert all(git('show',result_tree+':'+PREFIX+n)==b for n,b in files.items())
    changed=git('diff','--name-only',base,result_tree,'--','Taleb_Lean_Repairs').decode().splitlines()
    assert len(changed)==expected_count
    report['patches'].append({'route':label,'base':git('rev-parse',base).decode().strip(),'patch_sha256':sha((UPLOAD/pname).read_bytes()),'changed_files':len(changed),'project_tree':result_project_tree,'matches_target_tree_and_all_bytes':True})
    index.unlink()

report['pins']={}
for n in ['lean-toolchain','lake-manifest.json']:
    current=files[n]
    same={b:git('show',b+':'+PREFIX+n)==current for b in ['f6b1007','fe14519']}
    assert all(same.values())
    report['pins'][n]={'sha256':sha(current),'byte_equal_to':same}
mathpaths=git('ls-tree','-r','--name-only','fe14519','--','Taleb_Lean_Repairs/AuditRepairs','Taleb_Lean_Repairs/Proofs').decode().splitlines()
mathpaths=[p for p in mathpaths if p.endswith('.lean')]
assert all(git('show','fe14519:'+p)==files[p[len(PREFIX):]] for p in mathpaths)
report['preexisting_mathematics']={'old_modules':len(mathpaths),'all_byte_identical':True,'new_module':'AuditRepairs/ParetoLaw.lean','root_import_added':'AuditRepairs.ParetoLaw','generated_AuditVerification_lean':'updated verification inventory'}
retained=manifest((REPO/'audits/RECEIVED_ARTIFACTS.sha256').read_bytes(),lambda n:(REPO/'audits'/n).read_bytes())
report['retained_artifacts']={'checks':len(retained),'all_pass':True,'rows':retained}
prior=REPO/'audits/08_astra_on_v0.2.7'
priorzip=prior/'Taleb_Fable_v0.2.7_Audit_and_Progress.zip'
assert sha(priorzip.read_bytes())=='279619ccf6126409880eaba2daeb3280c88d40e4939bbdcaac8000858263ac93'
with zipfile.ZipFile(priorzip) as z:
    oldrows=manifest(z.read('SHA256SUMS'),z.read)
    compare={}
    for n in ['Taleb_Fable_v0.2.7_Independent_Audit.pdf','Taleb_Proof_Progress_v0.2.7.md','Taleb_Fable_v0.2.7_Review_Handoff.md']:
        compare[n]={'zip_member_sha256':sha(z.read(n)),'standalone_sha256':sha((prior/n).read_bytes()),'byte_identical':z.read(n)==(prior/n).read_bytes()}
    (OUT/'prior_zip_report.pdf').write_bytes(z.read('Taleb_Fable_v0.2.7_Independent_Audit.pdf'))
report['previous_audit']={'zip_sha256':sha(priorzip.read_bytes()),'matches_visible_history_sha256':True,'internal_manifest_checks':len(oldrows),'all_internal_checks_pass':True,'comparisons':compare}
probe=json.loads(files['evidence/fable/v0.2.8/current_after_verify/backlog_schema_probes.json'])
assert len(probe['results'])==18 and all(r['behaved_as_expected'] for r in probe['results'])
report['supplied_probe_record']={'results':len(probe['results']),'all_behaved_as_expected':all(r['behaved_as_expected'] for r in probe['results'])}
oldlog='deliverables/v0.2.7/archive_validation_v0.2.7.log'
assert (REPO/oldlog).read_bytes()==git('show','499e9e0:'+oldlog)
prior_release_zip=REPO/'deliverables/v0.2.7/Taleb_Lean_Implementation_Handoff_v0.2.7_fable.zip'
assert sha(prior_release_zip.read_bytes())=='88ebaa078a18dc0e16bb46057969c5fec186c1fc958df1422b6d434e323d157b'
report['previous_release_zip_sha256']=sha(prior_release_zip.read_bytes())
report['d027_3_evidence']={'current_validation_log_says_json_derived_18': 'probes: 18 results, 18 behaved as expected, all: True' in (UPLOAD/'archive_validation_v0.2.8.log').read_text(),'old_validation_log_retained':True,'annotation_in_final_deliverables_index':'Not included in supplied pre-deliverables bundle; cannot inspect'}
(OUT/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['inputs','retained_artifacts','previous_audit']},indent=2))
