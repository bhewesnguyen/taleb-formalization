#!/usr/bin/env python3
"""Bounded Python checks of v0.2.8; external Lean/git results are replayed, not executed.

The unchanged shipped 18-probe suite and generator are actually executed. Replay
cases exercise verify.main with received logs standing in for external commands.
Independent real Lean execution is recorded separately by runtime028.
"""
import argparse
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file()}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def worker(project, case, record):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(project / 'scripts'))
    verify = load_module('verify_replayed', project / 'scripts/verify.py')
    schema = load_module('backlog_schema_review', project / 'scripts/backlog_schema.py')
    md_path = project / 'docs/FORMALIZATION_BACKLOG.md'
    json_path = project / 'docs/FORMALIZATION_BACKLOG.json'
    md = md_path.read_bytes()
    rows = json.loads(json_path.read_text())
    expected = 'PASS'
    fragment = ''
    if case in ('crlf', 'crlf_optimized'):
        md_path.write_bytes(md.replace(b'\n', b'\r\n'))
        expected, fragment = 'FAIL', 'is not the rendering'
    elif case == 'utf8_bom':
        md_path.write_bytes(b'\xef\xbb\xbf' + md)
        expected, fragment = 'FAIL', 'is not the rendering'
    elif case == 'missing_final_newline':
        md_path.write_bytes(md[:-1])
        expected, fragment = 'FAIL', 'is not the rendering'
    elif case == 'stale_markdown_status':
        new_md = md.replace(b'**P1 / discharged / EVT**', b'**P1 / partial / EVT**', 1)
        if new_md == md:
            raise RuntimeError('Mutation did not change the Markdown')
        md_path.write_bytes(new_md)
        expected, fragment = 'FAIL', 'is not the rendering'
    elif case == 'json_scope_without_rerender':
        rows[60]['delivery_scope'] = 'Only Gumbel and Frechet are delivered.'
        json_path.write_text(json.dumps(rows))
        expected, fragment = 'FAIL', 'is not the rendering'
    elif case == 'duplicate_id':
        rows[2]['id'] = 'T002'
        json_path.write_text(json.dumps(rows))
        expected, fragment = 'FAIL', 'schema violations'
    elif case == 'dangling_citation_consistent_render':
        rows[0]['declarations'].append('AuditMissing.unproved')
        json_path.write_text(json.dumps(rows))
        md_path.write_bytes(schema.render_markdown(rows).encode('utf-8'))
        expected, fragment = 'FAIL', 'declarations that do not exist'
    elif case != 'valid':
        raise RuntimeError('Unknown case ' + case)
    received = project / 'evidence/current'
    verification = json.loads((received / 'verification.json').read_text())
    source_logs = {name: (received / name).read_text() for name in
                   ['build.log', 'axioms.log', 'inventory_environment.log']}
    commands = []
    def replay(args, log=None):
        commands.append(args)
        if args == ['lake', 'env', 'lean', '--version']:
            output = verification['lean']
        elif args[0] == 'git' and args[-2:] == ['rev-parse', 'HEAD']:
            output = verification['dependency_commits'][Path(args[2]).name]
        elif args[0] == 'git' and args[-2:] == ['status', '--porcelain']:
            output = ''
        elif args == ['lake', 'build']:
            output = source_logs['build.log']
        elif args == ['lake', 'env', 'lean', 'AuditVerification.lean']:
            output = source_logs['axioms.log']
        elif args == ['lake', 'env', 'lean', 'scripts/FableInventory.lean']:
            output = source_logs['inventory_environment.log']
        else:
            raise RuntimeError('Unrecognized external command ' + repr(args))
        if log:
            (verify.OUT / log).write_text(output)
        return output.strip()
    verify.run = replay
    output = io.StringIO()
    try:
        with contextlib.redirect_stdout(output):
            verify.main()
        status, error = 'PASS', ''
    except verify.VerificationError as exc:
        status, error = 'FAIL', str(exc)
    ok = status == expected and (not fragment or fragment in error)
    record.write_text(json.dumps(dict(case=case, status=status, error=error,
        expected_status=expected, expected_error_fragment=fragment,
        behaved_as_expected=ok, python_optimized=not __debug__,
        external_commands_replayed=commands, actual_lean_execution=False,
        stdout=output.getvalue()), indent=2) + '\n')
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--worker')
    args = parser.parse_args()
    project, out = args.project.resolve(), args.out.resolve()
    if args.worker:
        return worker(project, args.worker, out)
    out.mkdir(parents=True, exist_ok=True)
    before = hashes(project)
    results = []
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    def execute(command, cwd, log_name):
        p = subprocess.run(command, cwd=cwd, env=environment, text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (out / log_name).write_text(p.stdout)
        return p
    with tempfile.TemporaryDirectory(prefix='taleb_v028_python_review_') as temporary:
        root = Path(temporary)
        clean = root / 'clean'
        shutil.copytree(project, clean)
        schema = load_module('backlog_schema_review', clean / 'scripts/backlog_schema.py')
        rows = json.loads((clean / 'docs/FORMALIZATION_BACKLOG.json').read_text())
        md = (clean / 'docs/FORMALIZATION_BACKLOG.md').read_bytes()
        results.append(dict(check='shipped_schema_and_literal_render', behaved_as_expected=
            schema.validate(rows) == [] and md == schema.render_markdown(rows).encode('utf-8'),
            families=len(rows), markdown_bytes=len(md), crlf_count=md.count(b'\r\n')))
        probe_out = out / 'shipped_suite'
        p = execute([sys.executable, 'scripts/backlog_schema_probes.py', '--out', str(probe_out)],
                    clean, 'shipped_probes.log')
        probe_record = json.loads((probe_out / 'backlog_schema_probes.json').read_text())
        results.append(dict(check='shipped_18_probe_suite', exit_code=p.returncode,
            count=len(probe_record['results']), behaved_as_expected=p.returncode == 0 and
            len(probe_record['results']) == 18 and probe_record['all_probes_behaved_as_expected']))
        crlf_project = root / 'crlf_probes'
        shutil.copytree(project, crlf_project)
        (crlf_project / 'docs/FORMALIZATION_BACKLOG.md').write_bytes(md.replace(b'\n', b'\r\n'))
        p = execute([sys.executable, 'scripts/backlog_schema_probes.py', '--out', str(out / 'crlf_suite')],
                    crlf_project, 'crlf_shipped_probes.log')
        crlf_probe = json.loads((out / 'crlf_suite/backlog_schema_probes.json').read_text())
        failed = [r['probe'] for r in crlf_probe['results'] if not r['behaved_as_expected']]
        results.append(dict(check='shipped_probe_detects_crlf', exit_code=p.returncode,
            failed_probes=failed, behaved_as_expected=p.returncode == 1 and
            failed == ['markdown_is_rendering_of_json']))
        for optimized in [False, True]:
            generator_project = root / ('generator_optimized' if optimized else 'generator')
            shutil.copytree(project, generator_project)
            documents = [generator_project / 'docs' / n for n in
                         ['FORMALIZATION_BACKLOG.json', 'FORMALIZATION_BACKLOG.md']]
            for path in documents:
                path.write_bytes(b'purposefully stale output\n')
            command = [sys.executable] + (['-O'] if optimized else []) + ['scripts/rebuild_curated_inventory.py']
            p = execute(command, generator_project, f'generator_{optimized}.log')
            same = all(path.read_bytes() == (project / 'docs' / path.name).read_bytes() for path in documents)
            results.append(dict(check='generator_rebuilds_both_outputs', optimized=optimized,
                exit_code=p.returncode, behaved_as_expected=p.returncode == 0 and same))
            script_path = generator_project / 'scripts/rebuild_curated_inventory.py'
            text = script_path.read_text()
            if text.count('|RV|P1|partial|states=') != 1:
                raise RuntimeError('Expected one raw generator row to mutate')
            script_path.write_text(text.replace('|RV|P1|partial|states=', '|RV|P1|bogus|states=', 1))
            snapshots = [path.read_bytes() for path in documents]
            p = execute(command, generator_project, f'generator_invalid_{optimized}.log')
            unchanged = all(path.read_bytes() == old for path, old in zip(documents, snapshots))
            results.append(dict(check='generator_invalid_status_refuses_before_write', optimized=optimized,
                exit_code=p.returncode, outputs_unchanged=unchanged,
                behaved_as_expected=p.returncode != 0 and unchanged))
        replay_results = []
        for case in ['valid', 'crlf', 'crlf_optimized', 'utf8_bom', 'missing_final_newline',
                     'stale_markdown_status', 'json_scope_without_rerender', 'duplicate_id',
                     'dangling_citation_consistent_render']:
            case_project = root / case
            shutil.copytree(project, case_project)
            record = out / ('replay_' + case + '.json')
            command = [sys.executable] + (['-O'] if case.endswith('_optimized') else []) + [
                str(Path(__file__).resolve()), '--project', str(case_project), '--out', str(record), '--worker', case]
            p = execute(command, case_project, 'replay_' + case + '.log')
            r = json.loads(record.read_text())
            r['worker_exit_code'] = p.returncode
            replay_results.append(r)
        results.append(dict(check='actual_verify_main_with_replayed_external_commands', count=len(replay_results),
            actual_lean_execution=False, behaved_as_expected=all(r['behaved_as_expected'] and
            r['worker_exit_code'] == 0 for r in replay_results), results=replay_results))
    after = hashes(project)
    results.append(dict(check='received_tree_unmodified', file_count=len(before),
        behaved_as_expected=before == after))
    report = dict(all_checks_behaved_as_expected=all(r['behaved_as_expected'] for r in results),
        scope='Python execution; external Lean/git commands replayed only in verify.main cases. '
              'This report does not constitute Lean reproduction.', results=results)
    (out / 'python_probe_results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['all_checks_behaved_as_expected', 'scope']}))
    return 0 if report['all_checks_behaved_as_expected'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
