# v0.2.8 verifier probe evidence

`check_verifier_python.py` checks the shipped ledger schema/rendering, executes the unchanged 18-probe suite, checks both generator outputs in ordinary and optimized Python, and executes nine verifier acceptance cases with external command results replayed from the supplied evidence.

The replay cases are Python-level tests only. They are explicitly marked `actual_lean_execution: false`; they must not be described as Lean runs or added to the shipped fourteen-fixture harness count. Real Lean reproduction and the extra CRLF CLI mutation are recorded separately in `../reproduction/`.

All project mutations occur in temporary copies that are removed afterward. The immutable received tree is hashed before and after. No received file, dependency checkout, harness fixture or acceptance allowlist is modified.

Run from the workspace root:

```sh
python3 audit_v028/verifier_probe/check_verifier_python.py --project audit_v028/received/Taleb_Lean_Repairs --out audit_v028/verifier_probe/results
```

The result JSON includes the exact outcomes. All checks passed in the independent review.
