#!/usr/bin/env python3
"""Auditor execution driver; received project and all shipped checks remain unchanged."""
import concurrent.futures, hashlib, json, os, re, shutil, subprocess, time
from pathlib import Path

HERE=Path(__file__).resolve().parent
AUDIT=HERE.parent
RECEIVED=AUDIT/'received/Taleb_Lean_Repairs'
PROJECT=Path('/tmp/taleb_v028_audit_project')
CACHE=Path('/tmp/taleb_v027_audit_project/.lake/packages')
RUNTIME=Path('/tmp/taleb_v026_runtime/bin')
ENV=dict(os.environ, PATH=str(RUNTIME)+':'+os.environ['PATH'], PYTHONDONTWRITEBYTECODE='1')
SUMMARY={'complete':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'commands':[]}

def save():
    (HERE/'execution_summary.json').write_text(json.dumps(SUMMARY,indent=2)+'\n')

def command(name,args,cwd=PROJECT):
    began=time.monotonic()
    logfile=HERE/(name+'.log')
    with logfile.open('w') as f:
        p=subprocess.run(args,cwd=cwd,env=ENV,stdout=f,stderr=subprocess.STDOUT)
    rec={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit_code':p.returncode,
         'elapsed_seconds':round(time.monotonic()-began,2),'log':logfile.name}
    SUMMARY['commands'].append(rec)
    save()
    print(json.dumps(rec),flush=True)
    if p.returncode: raise RuntimeError(f'{name} failed: {p.returncode}')
    return rec

def source_hashes(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file() and '.lake' not in p.relative_to(root).parts}

def dependency_state():
    rows=[]
    for d in json.loads((PROJECT/'lake-manifest.json').read_text())['packages']:
        p=PROJECT/'.lake/packages'/d['name']
        rev=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
        dirty=subprocess.check_output(['git','-C',str(p),'status','--porcelain'],text=True).strip()
        if rev!=d['rev'] or dirty: raise RuntimeError('Dependency mismatch: '+d['name'])
        rows.append({'name':d['name'],'expected':d['rev'],'actual':rev,'status_porcelain':dirty})
    return rows

def main():
    if PROJECT.exists(): raise RuntimeError('Fresh project already exists; refusing to reuse')
    received_initial=source_hashes(RECEIVED)
    shutil.copytree(RECEIVED,PROJECT)
    (PROJECT/'.lake').mkdir()
    command('copy_pinned_dependency_cache',['cp','-a',str(CACHE),str(PROJECT/'.lake/packages')])
    if (PROJECT/'.lake/build').exists(): raise RuntimeError('Project build outputs were not absent')
    SUMMARY['fresh_project_build_absent']=True
    SUMMARY['initial_dependencies']=dependency_state()
    command('runtime_identity',[str(RUNTIME/'lean'),'--version'])
    command('clean_lake_build',['lake','build'])
    build=(HERE/'clean_lake_build.log').read_text()
    diagnostics=[l for l in build.splitlines() if re.search(r'(^|\s)(warning|error):|\bsorryAx\b|declaration uses .sorry.',l)]
    SUMMARY['clean_build_diagnostics']=diagnostics
    if diagnostics: raise RuntimeError('Build diagnostics')
    command('normal_verify',['python3','scripts/verify.py'])
    dest=HERE/'normal_verification'
    shutil.copytree(PROJECT/'evidence/current',dest)
    SUMMARY['normal_verification']=json.loads((dest/'verification.json').read_text())
    command('backlog_schema_probes',['python3','scripts/backlog_schema_probes.py','--out',str(HERE/'schema_probes')])
    print('BUILD, NORMAL VERIFICATION, AND SCHEMA PROBES COMPLETE; STARTING THREE REGRESSION SHARDS',flush=True)
    save()
    groups=[
      ['valid','private_axiom','structure_namespace_theorem','orphan_module','dirty_dependency'],
      ['private_sorry_theorem','protected_theorem','alias_map_mismatch','nested_imported_module'],
      ['private_sorry_def','alias_map_mismatch_optimized','nested_orphan_module','namespace_section_theorem','backlog_duplicate_id']]
    def shard(item):
        i,ids=item
        scratch=Path('/tmp')/f'taleb_v028_regression_s{i}'
        out=HERE/f'regression_shard_{i}'
        return command(f'regression_shard_{i}', ['python3','scripts/harness_regression.py',
          '--only',','.join(ids),'--scratch',os.path.relpath(scratch,PROJECT),
          '--out',os.path.relpath(out,PROJECT)])
    start=time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(shard,enumerate(groups,1)))
    SUMMARY['regression_parallel_elapsed_seconds']=round(time.monotonic()-start,2)
    fixtures=[]
    for i in range(1,4):
        fixtures.extend(json.loads((HERE/f'regression_shard_{i}/harness_regression.json').read_text())['results'])
    SUMMARY['regression_results']=fixtures
    if len(fixtures)!=14 or len({r['id'] for r in fixtures})!=14 or not all(r['behaved_as_expected'] for r in fixtures):
        raise RuntimeError('Regression coverage or result mismatch')
    SUMMARY['final_dependencies']=dependency_state()
    SUMMARY['received_unchanged']=(received_initial==source_hashes(RECEIVED))
    current=source_hashes(PROJECT)
    SUMMARY['project_source_unchanged']=all(current.get(p)==h for p,h in received_initial.items() if not p.startswith('evidence/current/'))
    SUMMARY['source_sha256_received']=received_initial
    SUMMARY['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    SUMMARY['complete']=SUMMARY['received_unchanged'] and SUMMARY['project_source_unchanged']
    save()
    print('INDEPENDENT EXECUTION COMPLETE',flush=True)

if __name__=='__main__':
    try: main()
    except Exception as e:
        SUMMARY['error']=str(e);save();raise
