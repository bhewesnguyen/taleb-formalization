#!/usr/bin/env python3
"""Summarize completed independent execution without rerunning any checks."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
summary_path=HERE/'execution_summary.json'
s=json.loads(summary_path.read_text())
if not s.get('complete'): raise SystemExit('Runtime reproduction is not complete')
project=Path('/tmp/taleb_v028_audit_project')
actual={str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(project.rglob('*')) if p.is_file() and '.lake' not in p.relative_to(project).parts
    and not str(p.relative_to(project)).startswith('evidence/current/')}
expected={p:h for p,h in s['source_sha256_received'].items() if not p.startswith('evidence/current/')}
if actual!=expected: raise SystemExit('Exact final project source file set differs from received sources')
s['project_source_exact_match_received_outside_current_evidence']=True
crlf=json.loads((HERE/'crlf_markdown_cli_probe/result.json').read_text())
probes=json.loads((HERE/'schema_probes/backlog_schema_probes.json').read_text())
if not crlf['behaved_as_expected']: raise SystemExit('CRLF probe did not behave as expected')
if len(probes['results'])!=18 or not probes['all_probes_behaved_as_expected']:
    raise SystemExit('Schema probe results do not match 18 expected passes')
fixtures=s['regression_results']
if len(fixtures)!=14 or not all(r['behaved_as_expected'] for r in fixtures):
    raise SystemExit('Regression fixtures are incomplete')
if not all(r['restored_tree_matches_pristine'] and r['build_dir_reset_from_snapshot'] for r in fixtures):
    raise SystemExit('Fixture isolation evidence incomplete')
s['schema_probe_count']=18
s['schema_probes_all_behaved_as_expected']=True
s['supplementary_crlf_probe']=crlf
s['normal_evidence_inherited_records_excluded']=['harness_regression.log','harness_regression.json','backlog_schema_probes.json']
for name in s['normal_evidence_inherited_records_excluded']:
    (HERE/'normal_verification'/name).unlink(missing_ok=True)
summary_path.write_text(json.dumps(s,indent=2)+'\n')
v=s['normal_verification']; inv=v['environment_inventory']
commands={r['name']:r for r in s['commands']}
rows='\n'.join(f"| `{r['id']}` | {r['verifier_exit_code']} | {r['verification_status']} | {r['seconds']:.1f} | {r['expected_error_contains'] or 'Positive control'} |" for r in fixtures)
md=f'''# Independent runtime review: v0.2.8

Verdict: all independently executed runtime gates behaved as expected. No runtime finding was identified.

The received release was copied to a fresh `/tmp/taleb_v028_audit_project`. The project had no `.lake/build` before the first build. Previously obtained dependency caches were reused, with all nine Git revisions independently checked against the unchanged manifest and all nine worktrees clean before and after execution. Lean reports version 4.24.0, release commit `797c613eb9b6d4ec95db23e3e00af9ac6657f24b`. Executable SHA-256 hashes are recorded.

| Check | Independent result |
| --- | --- |
| Clean project `lake build` | Exit 0; {commands['clean_lake_build']['elapsed_seconds']:.2f} seconds; 2746 jobs; no compiler warning, error, or sorry diagnostics |
| Unchanged `python3 scripts/verify.py` | Exit 0; {commands['normal_verify']['elapsed_seconds']:.2f} seconds |
| Public axiom checks | {v['theorem_count']} theorems, {v['instance_count']} instances, {v['alias_count']} aliases: {v['checked_declarations']} total |
| Environment trust scan | {inv['constants_scanned']} project constants, including {inv['internal']} internal; all within `propext`, `Classical.choice`, `Quot.sound`; no project axioms |
| Project-module coverage | {inv['imported_project_modules']} imported project modules; all disk modules covered |
| Ledger | {inv['backlog_families']} valid families; {inv['backlog_cited_declaration_count']} family/declaration pairs over {inv['backlog_cited_distinct_declarations']} distinct declarations; literal Markdown rendering equality passed |
| Unchanged schema/render probe suite | 18/18 expected results; exit 0; {commands['backlog_schema_probes']['elapsed_seconds']:.2f} seconds |
| Unchanged regression harness | 14/14 expected results; all three shard invocations exit 0; {s['regression_parallel_elapsed_seconds']:.2f} seconds across the concurrent run |
| Supplementary CRLF-only Markdown CLI mutation | Correctly rejected at the raw-byte rendering gate; verifier exit 1; {crlf['elapsed_seconds']:.2f} seconds |
| Final integrity | Received files unchanged; temporary project sources unchanged; all nine pinned dependency worktrees clean |

## Regression results

The 14 shipped fixtures ran exactly once across three disjoint invocations of the unchanged harness. Each used real relative `--scratch` and `--out` arguments, its own dependency copy, and the harness's original source and project-build restoration checks. Every restored source hash matched its pristine hash and every fixture began from the pristine project build snapshot. The harness itself exited zero for all three shards. The individual verifier exits below intentionally differ for positive and negative cases.

| Fixture | Verifier exit | Record | Seconds | Expected diagnostic or positive control |
| --- | --- | --- | --- | --- |
{rows}

Both private-sorry fixtures also ran the Lean environment inventory directly and confirmed that their private constants carried `sorryAx`. The optimized alias-mismatch case used `PYTHONOPTIMIZE=1` and was still rejected. The nested imported-module positive control confirmed that both its module and its theorem were scanned. The namespace/section positive control passed with the theorem following a section end correctly discovered.

## Additional literal-byte test

Exactly one source file changed before the supplementary CLI invocation: `docs/FORMALIZATION_BACKLOG.md`. Its {crlf['line_count']} LF line endings became CRLF, with no textual change. Reversing that conversion recovers the original bytes. The actual unchanged verifier ran the ordinary Lean checks and then produced exit 1 with a FAIL record containing:

`{crlf['verification_record']['error']}`

This test is separate from both the 14 shipped regression fixtures and the 18 shipped schema/render probes.

## Evidence and bounds

`audit_v028/reproduction/execution_summary.json` records commands, working directories, timings, dependency revisions, all fixture results, and received-source hashes. `normal_verification/` contains only independently generated normal-verifier files; inherited supplied harness and schema records were excluded. The three `regression_shard_*/harness_regression.json` files retain exact errors, process exits, fixture isolation checks, and the harness's additional inventory notes. The CRLF mutation has its own command, hashes, result, and log.

This was a clean project build against pinned cached dependencies, not a rebuild of every dependency from source. No received source, shipped harness, fixture, verifier, or allowlist was modified to obtain a pass. The results certify the executable formal and bookkeeping checks described here; source-to-theorem interpretation is covered by the separate mathematical and ledger reviews.
'''
(HERE.parent/'runtime_review.md').write_text(md)
print(json.dumps({'runtime_complete':s['complete'],'fixture_count':len(fixtures),'probe_count':18,'crlf_expected_rejection':True,'report':str(HERE.parent/'runtime_review.md')},indent=2))
