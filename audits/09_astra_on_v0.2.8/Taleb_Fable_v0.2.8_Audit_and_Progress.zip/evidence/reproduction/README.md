# Independent runtime evidence for v0.2.8

These are auditor executions, not the supplied Fable logs. The received extraction is read only in this workflow. The execution driver creates a new project directory, copies the received sources and only the pinned dependency caches, confirms there are no project build outputs, then runs the shipped commands unchanged.

- `reproduce_runtime.py`: execution driver and the exact commands, including the three disjoint `--only` selections. Both `--scratch` and `--out` are passed as real relative paths.
- `finalize_runtime_review.py`: completes the evidence summary and runtime review after both execution scripts finish, checks the exact final source file set, and removes inherited supplied records from the normal-verification evidence directory. It does not rerun Lean or any fixture.
- `execution_summary.json`: machine-readable execution status, command timings, dependency revisions, source hashes, and every fixture result. `complete` stays false until the entire shipped suite finishes and final source/dependency checks pass.
- `clean_lake_build.log`: build from absent project build outputs. Cached pinned dependencies are reused; this is not a claim to have rebuilt all of Mathlib from source.
- `normal_verification/`: only files produced by the independent normal verifier run. Supplied harness and schema records inherited by the temporary project are intentionally excluded from this directory.
- `schema_probes/`: the independent 18-probe result from the unchanged shipped Python suite.
- `regression_shard_1/`, `regression_shard_2/`, `regression_shard_3/`: all 14 shipped fixtures exactly once across the unchanged harness. Each invocation makes its own dependency copy and restores both the pristine sources and project build snapshot before each fixture.
- `crlf_probe.py`, `crlf_markdown_cli_probe/`: one additional actual verifier CLI run on a separate copy with only Markdown LF line endings converted to CRLF. It is outside the counts of 14 fixtures and 18 probes. This copy shares an unmodified dependency cache and has its own project build tree.
- `runtime_identity.log`, `runtime_binaries.sha256`, `host_environment.json`: reused pinned Lean runtime identity and execution environment.

The authoritative per-fixture expected errors and process exits are in the three `harness_regression.json` files. A nonzero verifier exit is expected for each negative fixture; the harness itself must exit zero. Three positive fixtures must pass. The supplementary CRLF probe must fail at the literal-byte Markdown rendering gate, after the ordinary Lean checks have run.

No fixture, verifier, Lean source, allowlist, or received release artifact was modified to obtain a pass. Mutations occur only in disposable audit copies.
