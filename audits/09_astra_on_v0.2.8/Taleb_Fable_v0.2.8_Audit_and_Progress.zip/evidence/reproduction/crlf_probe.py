#!/usr/bin/env python3
"""One real verifier CLI mutation beyond the 14 shipped regression fixtures."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=Path('/tmp/taleb_v028_audit_project')
COPY=Path('/tmp/taleb_v028_crlf_probe')
OUT=HERE/'crlf_markdown_cli_probe'
ENV=dict(os.environ,PATH='/tmp/taleb_v026_runtime/bin:'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1')
def hashes(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
      for p in sorted(root.rglob('*')) if p.is_file() and '.lake' not in p.relative_to(root).parts}
def main():
    if json.loads((HERE/'normal_verification/verification.json').read_text())['status']!='PASS':
        raise RuntimeError('Normal verification must first pass')
    if COPY.exists(): raise RuntimeError('Refusing to reuse mutation directory')
    OUT.mkdir()
    shutil.copytree(BASE,COPY,ignore=shutil.ignore_patterns('.lake'))
    (COPY/'.lake').mkdir()
    (COPY/'.lake/packages').symlink_to(BASE/'.lake/packages',target_is_directory=True)
    shutil.copytree(BASE/'.lake/build',COPY/'.lake/build')
    before=hashes(COPY)
    relative='docs/FORMALIZATION_BACKLOG.md'
    p=COPY/relative
    original=p.read_bytes()
    assert b'\r\n' not in original and b'\n' in original
    mutated=original.replace(b'\n',b'\r\n')
    p.write_bytes(mutated)
    after=hashes(COPY)
    changed=[k for k in set(before)|set(after) if before.get(k)!=after.get(k)]
    assert changed==[relative]
    args=['python3','scripts/verify.py']
    began=time.monotonic()
    with (OUT/'verify_cli.log').open('w') as log:
        run=subprocess.run(args,cwd=COPY,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    elapsed=round(time.monotonic()-began,2)
    result=json.loads((COPY/'evidence/current/verification.json').read_text())
    shutil.copy2(COPY/'evidence/current/verification.json',OUT/'verification.json')
    shutil.copy2(COPY/'evidence/current/build.log',OUT/'build.log')
    expected='docs/FORMALIZATION_BACKLOG.md is not the rendering of docs/FORMALIZATION_BACKLOG.json'
    evidence={'command':args,'cwd':str(COPY),'independent_real_cli':True,
      'exit_code':run.returncode,'elapsed_seconds':elapsed,'verification_record':result,
      'changed_source_files_before_run':changed,'mutation':'LF to CRLF only',
      'line_count':original.count(b'\n'),'original_bytes':len(original),'mutated_bytes':len(mutated),
      'original_sha256':hashlib.sha256(original).hexdigest(),'mutated_sha256':hashlib.sha256(mutated).hexdigest(),
      'normalizes_to_original':mutated.replace(b'\r\n',b'\n')==original,
      'expected_error_contains':expected,'behaved_as_expected':run.returncode==1 and result.get('status')=='FAIL' and expected in result.get('error',''),
      'outside_shipped_fixture_count':True,'dependency_cache_read_only_shared':True}
    (OUT/'result.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(evidence,indent=2),flush=True)
    if not evidence['behaved_as_expected']: raise RuntimeError('Unexpected CRLF mutation result')
if __name__=='__main__': main()
