#!/usr/bin/env python3
"""Build progress artifacts from the independently reviewed v0.2.8 ledger.

No Lean commands are executed here. Absent an execution summary with complete=true,
outputs explicitly retain draft_execution_pending and never claim completed runtime QA.
"""
from __future__ import annotations
import argparse,copy,hashlib,json
from collections import Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent
VERSION='v0.2.8'
STATUSES=['discharged','partial','reuse','missing','source-check','model-needed','empirical']
FORBIDDEN_DASHES=('\u2014','\u2013','\u2011')
def clean(value):
 s=str(value)
 for c in FORBIDDEN_DASHES:s=s.replace(c,'-')
 return s
def cell(value):return clean(value).replace('|','\\|').replace('\n',' ')
def table(headers,records):
 return ['| '+' | '.join(map(cell,headers))+' |','| '+' | '.join('---' for _ in headers)+' |',*['| '+' | '.join(map(cell,r))+' |' for r in records],'']
def markdown(d):
 t=[f'# Taleb proof progress, {VERSION}','','Independent assessment, 21 September 2026. The companion JSON preserves every received field of all 158 families and adds audited scopes, source corrections, child obligations, and independent-execution evidence.','', '## Current position','',clean(d['independent_execution']['verdict']),'']
 if not d['execution_complete']:t+=['**Draft execution status:** independent runtime reproduction is not yet marked complete. The mathematical and ledger assessment below does not assert a completed clean build, verifier or regression run.','']
 t+=['**Exact Pareto Stage A is accepted.** The pinned Mathlib law now has exact support, CDF/survival, integrability and moment results, including infinite extended moments at and above the shape threshold. T021 and T028 move to partial. T060 and T061 remain discharged.','']
 t+=table(['Status','Received families','Recommended families'],[[s,d['status_counts'][s],d['recommended_status_counts'][s]] for s in STATUSES])
 t+=['Thirteen families have credited Lean work, up from eleven. The received ledger has **146 family/declaration pairs over 142 distinct names**, up from 123/122. Cross-crediting the already proved Pareto moment identification to T118 would make that 147/142 without a new theorem, supported family or closure. Of 140 formal-proof families, two are closed and 138 remain open; the other 18 need models or empirical work. These are scope counts, not an effort-completion percentage or a census of independent book theorems.','','Only T021, T028 and T029 changed in the JSON. The other 155 rows are identical to v0.2.7. The exact original rows are preserved in `ledger_rows`; recommendations are stored separately.','','## Pareto milestone and the two scope decisions','','Allowing every real moment order p below alpha is correct. With L > 0, the support is bounded away from zero, so negative powers introduce no singularity on the support. The finite moment is alpha*L^p/(alpha-p); p=0 gives one. For p >= alpha, the extended nonnegative integral is infinite. No totalized real-integral value is used to demonstrate finiteness.','','T028 may accurately move from source-check to partial because a concrete exact-law child is now proved. The general regularly varying moment theorem and its source-review gate remain open. For positive alpha, the critical moment of a general tail t^(-alpha)*L(t) depends on the integral of L(t)/t: a constant L diverges, while L(t)=(log t)^(-2) sufficiently far into the tail gives convergence. Exact-Pareto boundary divergence is not a theorem about every regularly varying law. These are explanatory examples, not additional formalized results.','']
 t+=table(['Child','State','Scope'],[[x['name'],x['status'],x['scope']] for x in d['Pareto_children']])
 t+=['T021 remains a broad multi-distribution family. Raw absolute moments E[|X|^p] are not the centered mean absolute deviation E[|X-E X|]. The Pareto MD/STD ratio needs the centered absolute-deviation integration as well as mean/variance and ratio algebra. Gaussian and Student moments also remain open.','','## T029 scope and child obligations','','The completed binary finite-log-exponent result retains its accepted scope: pointwise nonnegative coordinates, positive weights, finite real exponents, and no independence. The new theorem specializes its exponent premises to concrete Pareto marginal laws. It still assumes a common probability space and measurable pointwise nonnegative coordinates with those marginals; it does not export a joint realization theorem. That extra construction is not a retrospective acceptance condition for Stage A.','']
 t+=table(['Child','State','Scope and acceptance boundary'],[[x['name'],x['status'],x['scope']+' '+x.get('acceptance_note','')] for x in d['T029_children']])
 t+=['The stronger unequal-index RV target remains `S_(aX+bY)(t)/S_X(t/a) -> 1`, equivalently `S_(aX+bY)(t)/S_X(t) -> a^alpha`. The weight belongs in the denominator or the limiting coefficient. Exponent equality alone does not imply this ratio or regular variation. Equal-index dependent tails require a different statement.','','## Delivery facets','','Facets describe scoped components and overlap. Their counts must not be added as completed work.','']
 names=sorted(set(d['delivery_state_counts_nonexclusive'])|set(d['recommended_delivery_state_counts_nonexclusive']))
 t+=table(['Facet','Received count','Recommended count'],[[n,d['delivery_state_counts_nonexclusive'].get(n,0),d['recommended_delivery_state_counts_nonexclusive'].get(n,0)] for n in names])
 t+=['The only recommended facet-count change is for T118: its existing formula-level tail-kernel convexity can now be accompanied by law_theorem and actual_law_constructed for the exact Pareto moment identification. This reuses the existing Mathlib probability law. T029 retains its conditional-law facet for the general exponent theorem and realization credit scoped to its concrete Pareto marginals.','','## Completed EVT work and supplemental obligations','']
 t+=table(['T061 child','State'],[[x,'complete'] for x in d['completed_T061_children']])
 t+=['T060 covers independent maximum/minimum law identities. T061 covers the three separate EVT families and their location/scale maximum laws, not convergence to those laws. Global continuity of the guarded Frechet and reverse-Weibull CDFs is proved. The affine law definition allows any real scale; its CDF and maximum rules require positive scale.','']
 t+=table(['ID','State','Scope','Source'],[[x['id'],x['status'],x['scope'],x['source']] for x in d['supplemental_open_EVT_tasks']])
 t+=['S001 now has the explicit zero-shape Gumbel branch, correct off-support values and correct source pages. The unified endpoint is m-s/xi, with positive separate-family scales s/xi for positive xi and -s/xi for negative xi. S001 and S002 remain outside the fixed 158 families and do not reopen T061. Normalized-maxima convergence remains T011/T062; for Pareto shape alpha the proposed limit is frechetMeasure (1/alpha) under normalization M_n/(L*n^(1/alpha)).','','## Documentation corrections','']
 t+=table(['Finding','Priority','Correction'],[[x['id'],x['severity'],x['repair']] for x in d['findings']])
 t+=['For T118, Eq. (21.7) on printed p. 382 / PDF p. 396 is the exact moment formula now proved. Keep the future general-p convexity derivative as 2*p*L^p/(alpha-p)^3; the printed expression omits the factor p and replaces (alpha-p)^3 with (alpha-1)^3 while retaining L^p in the numerator. It coincides with the correct derivative at p=1. Jensen and mixing integrability remain open.','','The v0.2.8 validation log now reports 18 probe results from its machine-readable record. The claimed annotation to the historical v0.2.7 deliverables index lies outside the supplied pre-deliverables bundle and remains unconfirmed from these files. This is a bounded provenance caveat, not a defect in the mathematics or the corrected new count.','','## Audited supported families','']
 for f in d['families']:
  t += [f"### {f['id']}: {clean(f['title'])}",'',f"**Received status: {f['current_status']}. Recommended status: {f['recommended_status']}.**",'', '**Received facets:** '+', '.join(f['current_states'])+'.','', '**Recommended facets:** '+', '.join(f['recommended_states'])+'.','', '**Delivered scope:** '+clean(f['audited_scope']),'','**Recommendation:** '+clean(f['recommendation']),'','**Remaining target:** '+clean(f['remaining_target']),'']
 t+=['## Dependency-group position','','Other open formal combines reuse, missing and source-check. The source-check column is a subset of that total. Partial families also retain work.','']
 g=[]
 for n,x in d['dependency_group_counts'].items():
  c=x['status_counts'];g.append([n,x['total'],c['discharged'],c['partial'],c['source-check'],sum(c[s] for s in ['reuse','missing','source-check']),c['model-needed']+c['empirical']])
 t+=table(['Group','Families','Discharged','Partial','Source-check subset','Other open formal','Model / empirical'],g)
 t+=['## Recommended next mathematics','','Proceed to Pareto Stage B. For K >= L > 0, prove positivity of the tail mass and the normalized restricted-law equality with Pareto(K,alpha). The excess survival equals one below zero and (K/(K+y))^alpha for y >= 0. For alpha > 1, the conditional mean is alpha*K/(alpha-1) and mean excess K/(alpha-1); divergent cases require extended nonnegative integrals. Credit the exact-Pareto T005 slice only.','','For positive q, prove the equality of pushforward measures Pareto(L,alpha).map(x -> x^q) = Pareto(L^q,alpha/q). Include measurability and the inverse-event argument on the positive support. This is the exact-Pareto T032 slice; a general power-law transformation target may remain. Centered T021 ratios, the stronger T029 RV child and later EVT convergence remain separately scoped.','','## Full 158-family index','','Unsupported rows are tallied without a new full-family mathematical audit. Source locators below are the received release anchors. All original row fields remain unchanged in the companion JSON; the two recommended corrections are recorded separately.','']
 t+=table(['ID','Unit','Received status','Group','Priority','Family','Printed pages'],[[r[k] for k in ['id','unit','status','dependency_group','priority','title','printed_pages']] for r in d['ledger_rows']])
 t+=['## Interpretation limits','','This records formalization scope. It does not establish upstream Mathlib acceptance, an exhaustive census of every source statement, or operational readiness of the separate quantum/classical application. A family with no credited declaration may have reusable dependencies; a partial family may contain a substantial completed child.','']
 return clean('\n'.join(t))
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--review',type=Path,default=HERE/'ledger_review.json');p.add_argument('--execution',type=Path,default=HERE/'execution_summary.json');p.add_argument('--output-dir',type=Path,default=HERE.parent/'output');a=p.parse_args()
 original=json.loads(a.review.read_text());d=copy.deepcopy(original)
 d.update(artifact_type='independent_audit_progress_ledger',assessment_date='2026-09-21',source_review_sha256=hashlib.sha256(a.review.read_bytes()).hexdigest())
 if a.execution.exists():
  execution=json.loads(a.execution.read_text());execution.setdefault('verdict','Independent execution summary is attached; see its exact state and evidence.');d['execution_summary_sha256']=hashlib.sha256(a.execution.read_bytes()).hexdigest()
 else:execution={'complete':False,'verdict':'Independent execution pending: no completed runtime summary is attached to this draft.'};d['execution_summary_sha256']=None
 d['execution_complete']=execution.get('complete') is True;d['independent_execution']=execution;d['publication_state']='final' if d['execution_complete'] else 'draft_execution_pending'
 rows=d['ledger_rows'];assert rows==original['ledger_rows'];assert [r['id'] for r in rows]==[f'T{i:03}' for i in range(1,159)];assert Counter(r['status'] for r in rows)==d['status_counts'];assert len(d['families'])==13;assert len(d['dependency_group_counts'])==22;assert sum(g['total'] for g in d['dependency_group_counts'].values())==158
 assert sum(len(r['declarations']) for r in rows)==d['citation_pair_count']==146;assert len({n for r in rows for n in r['declarations']})==d['distinct_cited_declarations']==142
 received=HERE/'received/Taleb_Lean_Repairs/docs/FORMALIZATION_BACKLOG.json'
 if received.exists():assert rows==json.loads(received.read_text()),'Received rows changed'
 md=markdown(d);assert all(c not in md for c in FORBIDDEN_DASHES);assert md.endswith('\n')
 a.output_dir.mkdir(parents=True,exist_ok=True);jp=a.output_dir/f'Taleb_Proof_Progress_{VERSION}.json';mp=a.output_dir/f'Taleb_Proof_Progress_{VERSION}.md';jp.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n');mp.write_text(md)
 print(json.dumps({'json':str(jp.resolve()),'markdown':str(mp.resolve()),'publication_state':d['publication_state'],'family_count':len(rows),'supported_count':len(d['families']),'dependency_groups':len(d['dependency_group_counts']),'findings':[x['id'] for x in d['findings']]},indent=2))
if __name__=='__main__':main()
