"""Finalize only from completed independent runtime records."""
from pathlib import Path
import json,subprocess,sys
BASE=Path(__file__).resolve().parent
s=json.loads((BASE/'reproduction/execution_summary.json').read_text())
assert s['complete'] is True
assert s['fresh_project_build_absent'] and not s['clean_build_diagnostics']
assert s['received_unchanged'] and s['project_source_unchanged']
commands={r['name']:r for r in s['commands']}
assert all(r['exit_code']==0 for r in commands.values())
for name in ['initial_dependencies','final_dependencies']:
 assert len(s[name])==9 and all(r['expected']==r['actual'] and r['status_porcelain']=='' for r in s[name])
v=s['normal_verification'];inv=v['environment_inventory']
assert v['status']=='PASS' and v['build_diagnostics_clean']
assert (v['theorem_count'],v['instance_count'],v['alias_count'],v['checked_declarations'])==(160,8,16,184)
assert (inv['constants_scanned'],inv['internal'],inv['generated'],inv['defs'],inv['imported_project_modules'])==(321,83,102,34,29)
assert all(inv[k] for k in ['all_within_allowlist','no_project_axioms','all_disk_modules_imported','public_inventory_matches_regex','alias_targets_match_replacement_map','backlog_schema_valid','backlog_cited_declarations_exist'])
assert (inv['backlog_families'],inv['backlog_discharged'],inv['backlog_cited_declaration_count'],inv['backlog_cited_distinct_declarations'])==(158,2,146,142)
expected={'valid','private_sorry_theorem','private_sorry_def','private_axiom','structure_namespace_theorem','protected_theorem','alias_map_mismatch','alias_map_mismatch_optimized','orphan_module','nested_orphan_module','nested_imported_module','namespace_section_theorem','backlog_duplicate_id','dirty_dependency'}
fixtures=s['regression_results']
assert len(fixtures)==14 and {r['id'] for r in fixtures}==expected
assert all(r['behaved_as_expected'] for r in fixtures)
for i in range(1,4):
 shard=json.loads((BASE/f'reproduction/regression_shard_{i}/harness_regression.json').read_text())
 assert all(r['restored_tree_matches_pristine'] and r['restored_tree_sha256']==shard['pristine_tree_sha256'] and r['build_dir_reset_from_snapshot'] for r in shard['results'])
 args=commands[f'regression_shard_{i}']['argv']
 assert not Path(args[args.index('--scratch')+1]).is_absolute()
 assert not Path(args[args.index('--out')+1]).is_absolute()
probes=json.loads((BASE/'reproduction/schema_probes/backlog_schema_probes.json').read_text())
assert probes['all_probes_behaved_as_expected'] and len(probes['results'])==18
extra=json.loads((BASE/'reproduction/crlf_markdown_cli_probe/result.json').read_text())
assert extra['independent_real_cli'] and extra['behaved_as_expected'] and extra['exit_code']==1
assert extra['normalizes_to_original'] and extra['changed_source_files_before_run']==['docs/FORMALIZATION_BACKLOG.md']
n=sum(not p.startswith('evidence/current/') for p in s['source_sha256_received'])
seconds=s['regression_parallel_elapsed_seconds']
x={'complete':True,
 'verdict':'Independent reproduction passed: clean build, 184 public checks, all 321 project constants within the allowed axioms, 18 schema/rendering probes and all 14 shipped regression fixtures. An additional real CRLF-only Markdown mutation was correctly rejected.',
 'rows':[
  ['Clean build',f"PASS; exit 0, {commands['clean_lake_build']['elapsed_seconds']:.2f} s; 2746 Lake jobs and no compiler warnings/errors."],
  ['Normal verifier',f"PASS; exit 0, {commands['normal_verify']['elapsed_seconds']:.2f} s; 160 theorems, 8 instances and 16 aliases."],
  ['Trust and ledger','321 constants, 83 internal; only propext, Classical.choice, Quot.sound. 158 valid families; 146 citations over 142 names; raw-byte rendering gate passes.'],
  ['Schema/rendering probes','PASS 18/18: sixteen malformed cases rejected and two valid controls accepted.'],
  ['Shipped regression',f'PASS 14/14 exactly once; {seconds/60:.1f} min across three isolated disjoint harness invocations. All source and build restoration checks pass.'],
  ['Additional real CLI case',f"CRLF-only Markdown rejected at raw-byte rendering gate; exit 1, {extra['elapsed_seconds']:.2f} s; received files unchanged."],
  ['Source and dependencies',f'All {n} received files outside generated evidence match the tested project. Received extraction unchanged; all nine dependencies pinned and clean.']],
 'detail':'Official Lean 4.24.0 and exact pinned dependency caches were reused; the project build began without project build outputs. The unchanged harness ran in three disjoint --only shards with separate copies and relative scratch/output arguments. This is full fixture coverage, not one sequential invocation. Both private-sorry cases also exposed sorryAx in standalone scans. The CRLF mutation used its own disposable copy.',
 'counts':{'public_checks':184,'theorems':160,'instances':8,'aliases':16,'constants':321,'internal_constants':83,'generated_constants':102,'public_definitions':34,'imported_project_modules':29,'families':158,'discharged_families':2,'citation_pairs':146,'distinct_citations':142,'regression_fixtures':14,'schema_rendering_probes':18,'additional_real_cli_mutations':1,'received_file_count':len(s['source_sha256_received']),'source_files_compared':n},
 'regression_elapsed_seconds':seconds,'regression_mode':'Three isolated disjoint --only invocations of the unchanged harness; all shipped fixtures exactly once.',
 'fixture_results':fixtures,'all_source_restoration_hashes_match':True,'all_build_snapshots_restored':True,
 'additional_real_cli_mutation':extra,
 'independent_raw_record':'evidence/reproduction/execution_summary.json'}
(BASE/'execution_summary.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
for script in ['build_report.py','build_progress.py']:
 subprocess.run([sys.executable,str(BASE/script)],check=True)
print(json.dumps({'complete':True,'regression_seconds':seconds,'compared_files':n},indent=2))
