#!/usr/bin/env python3
"""Compute the v0.2.8 ledger audit while preserving received rows exactly."""
import copy, hashlib, json
from collections import Counter, defaultdict
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE/'received/Taleb_Lean_Repairs'
rows=json.loads((ROOT/'docs/FORMALIZATION_BACKLOG.json').read_text())
prev=json.loads((HERE/'prior_audit/Taleb_Proof_Progress_v0.2.7.json').read_text())
old={r['id']:r for r in prev['ledger_rows']}
prior_family={r['id']:r for r in prev['families']}
statuses=['discharged','partial','reuse','missing','source-check','model-needed','empirical']
status_counts={s:sum(r['status']==s for r in rows) for s in statuses}
citations=Counter(n for r in rows for n in r['declarations'])
inv=json.loads((ROOT/'evidence/current/inventory_environment.json').read_text())
inv_names={c['name'] for c in inv['constants']}
groups={}
for g in sorted({r['dependency_group'] for r in rows}):
 rr=[r for r in rows if r['dependency_group']==g]
 groups[g]={'total':len(rr),'status_counts':{s:sum(r['status']==s for r in rr) for s in statuses}}
findings=[{
 'id':'D028-1','severity':'low','kind':'ledger_undercredit_stale_remaining_prerequisite',
 'summary':'T118 still says that the Pareto moment identification is not delivered and leaves its identification open, although integral_rpow_paretoMeasure now proves that prerequisite.',
 'locations':['scripts/rebuild_curated_inventory.py: T118 delivered scope and remaining text','docs/FORMALIZATION_BACKLOG.json: T118','docs/FORMALIZATION_BACKLOG.md: T118'],
 'repair':'Cross-credit AuditPareto.integral_rpow_paretoMeasure to T118 and describe the exact Pareto moment identification as complete. Add law_theorem and actual_law_constructed for that scoped prerequisite, keeping formula_proved for the earlier tail-kernel convexity. Update the source range to printed pp. 381-382 / PDF pp. 395-396, citing Proposition 21.1 and Eq. (21.7). Leave moment-function convexity and integrated Jensen open and keep T118 partial. Regenerate both ledger files.',
 'effect':'One additional family/declaration citation, no new distinct declaration, no status or supported-family change.'
},{
 'id':'D028-2','severity':'low','kind':'precise_source_anchor',
 'summary':'T028 delivery_scope places the exact constant-factor tail P(X>x)=C x^(-alpha) on printed p. 97, where the source instead displays asymptotic regular variation with a slowly varying factor.',
 'locations':['scripts/rebuild_curated_inventory.py: T028 delivery_scope','docs/FORMALIZATION_BACKLOG.json: T028','docs/FORMALIZATION_BACKLOG.md: T028'],
 'repair':'Cite printed p. 95 / PDF p. 109 for the constant-factor Pareto tail, printed pp. 96-97 / PDF pp. 110-111 for the slowly varying formulation and Definition 5.1, and printed p. 86 / PDF p. 100 for the exact Pareto density. The parent range 95-98 already contains the correct source page.',
 'effect':'Citation precision only; no theorem, status or source-gate change.'
}]
families=[]
for row in rows:
 if not row['declarations']:continue
 r=copy.deepcopy(row)
 prior=prior_family.get(r['id'],{})
 for k in ['audited_scope','recommendation','remaining_target']:
  r[k]=prior.get(k,r['delivery_scope'] if k=='audited_scope' else r['remaining_obligations'])
 r.update(audited_status=r['status'],audit_verdict='accurate',current_status=r['status'],recommended_status=r['status'],current_states=copy.deepcopy(r['states']),recommended_states=copy.deepcopy(r['states']),recommended_additional_declarations=[])
 if r['id']=='T021':
  r.update(audit_verdict='partial_transition_accepted',audited_scope='Exact pinned Pareto raw and absolute moments: extended integral finite with the closed formula for every real p < alpha, infinite for p >= alpha, integrability iff p < alpha, and zeroth moment one. L > 0 and alpha > 0. Negative orders are included correctly because the support is bounded away from zero.',recommendation='Accept missing to partial. Retain the general Gaussian/Student and centered Pareto MD/STD work as open. Raw absolute moments are not centered mean absolute deviations.',remaining_target='Gaussian and Student absolute moments; Pareto mean/variance and the centered mean absolute deviation E[|X-E X|], then the MD/STD ratio; correct scale conventions. Raw E[|X|^p] does not itself compute centered MD.')
 if r['id']=='T028':
  r.update(audit_verdict='partial_transition_accepted_source_anchor_needs_correction',audited_scope='The actual pinned Pareto law has support at and above L, no endpoint atom, exact global CDF and strict survival, finite log-tail exponent alpha, and the finite/infinite moment threshold including divergence at p = alpha for this exact law.',recommendation='Accept source-check to partial because a genuine reviewed exact-law child is proved; explicitly retain the general regularly varying statement-review gate. Correct the exact-tail source anchor from printed p. 97 to p. 95 (D028-2).',remaining_target=r['remaining_obligations'])
 if r['id']=='T029':
  r.update(audit_verdict='accepted_with_explicit_marginal_realization_scope',audited_scope='Previously completed binary weighted-sum finite-exponent theorem and measurable pushforward version, now specialized to concrete pinned Pareto marginal laws. No independence. The general theorem assumes finite-exponent properties; the Pareto corollary discharges those properties from the actual marginal laws but assumes the joint P and pointwise nonnegative measurable X and Y with those marginals.',recommendation='Retain partial. Accept the repaired conditional_law_theorem allocation and actual_law_constructed scoped to concrete Pareto marginal laws. Say specialization to concrete Pareto marginals when describing the new corollary; no explicit joint realization is proved. That extra realization is not a retrospective acceptance gate. The stronger unequal-index regularly varying ratio theorem remains open.',remaining_target=r['remaining_obligations'])
  r['facet_note']='The new Pareto corollary can also support law_theorem under ordinary specified-marginal hypotheses. The received text assigns that facet only to survivalRV_eq_survival_map; expanding that credit is optional and does not change the facet count.'
 if r['id']=='T118':
  r.update(audit_verdict='understated_prerequisite_delivery',audited_scope='The earlier tail-kernel convexity remains. In v0.2.8, AuditPareto.integral_rpow_paretoMeasure also supplies the exact moment identification needed here, even though T118 does not yet credit it. Convexity of alpha -> L^p alpha/(alpha-p) and the integrated Jensen step are not delivered.',recommendation='Apply D028-1: cross-credit the existing exact Pareto moment theorem, update delivered/remaining text and facets, and retain partial. Do not reimplement the moment calculation.',remaining_target='For fixed p > 0 and L > 0, prove convexity of alpha -> L^p alpha/(alpha-p) on alpha > p, then justify Jensen under the stated random-index support and integrability or extended-expectation hypotheses. The general second derivative is 2*p*L^p/(alpha-p)^3; the printed expression omits the factor p and replaces (alpha-p)^3 with (alpha-1)^3 while retaining L^p in the numerator. It coincides with the correct derivative at p=1.')
  r['recommended_states']=['formula_proved','law_theorem','actual_law_constructed']
  r['recommended_additional_declarations']=['AuditPareto.integral_rpow_paretoMeasure']
 families.append(r)
children=copy.deepcopy(prev['T029_children'])
children.extend([
 {'id':'T029.C6','name':'Concrete Pareto marginal specialization','status':'complete','scope':'Specified Pareto marginal laws discharge the finite-exponent premises; pointwise nonnegative measurable coordinates on a common probability space are still hypotheses. No independence.','introduced':'v0.2.8','acceptance_note':'A joint sample-space realization is not claimed or imposed as a new acceptance gate.'},
 {'id':'T029.C7','name':'Extended-real exponent API','status':'open','scope':'Account for the source\'s informal infinite-exponent convention.','acceptance_note':'Recorded future interface extension; not a missing premise of the finite-exponent theorem.'}
])
for x in children:
 if x['id']=='T029.C4':x['scope']='For 0 <= alpha < beta (a positive-alpha first slice is acceptable), nonnegative measurable coordinates with regularly varying tails and a,b > 0, prove S_(aX+bY)(t)/S_X(t/a) -> 1, equivalently S_(aX+bY)(t)/S_X(t) -> a^alpha; no independence. Equal-index dependent tails require a different statement.'
stages=[
 {'id':'Pareto.A','name':'Exact Pareto Stage A','status':'complete','introduced':'v0.2.8','families':['T021','T028'],'scope':'Pinned law, support and endpoint, global CDF/survival, all-real-order finite/divergent extended moments, integrability iff p < alpha, real/absolute moment formula in the integrable range, actual tail exponent.'},
 {'id':'Pareto.B1','name':'Conditional threshold and excess law','status':'open','families':['T005'],'scope':'For K >= L > 0 and alpha > 0, normalized restricted law above K equals Pareto(K,alpha), with global excess survival. Conditional-moment corollaries are optional follow-ons to the core law identities. This credits an exact-Pareto slice only.'},
 {'id':'Pareto.B2','name':'Positive-power pushforward law','status':'open','families':['T032'],'scope':'For q > 0, paretoMeasure L alpha mapped by x -> x^q equals paretoMeasure (L^q) (alpha/q). Include measurability, support and inverse-event identities; do not infer law equality from an exponent formula.'}
]
supp=copy.deepcopy(prev['supplemental_open_EVT_tasks'])
for x in supp:x['specification_repair_needed']=False
facet=Counter(s for r in rows for s in r['states'])
recommended_facet=Counter(s for r in families for s in r['recommended_states'])
d={
 'version':'v0.2.8','method':'Independent source/signature and scope comparison with the preserved v0.2.7 audit, supplied v0.2.8 ledger/inventory, and recovered arXiv v4 book pages. Runtime checks are audited separately. Unsupported unchanged rows are tallied, not represented as newly proved.',
 'family_count':len(rows),'supported_count':len(families),'discharged_count':2,'formal_proof_working_set':140,'no_credited_declaration_count':145,
 'status_counts':status_counts,'recommended_status_counts':status_counts.copy(),
 'delivery_state_counts_nonexclusive':dict(sorted(facet.items())),'recommended_delivery_state_counts_nonexclusive':dict(sorted(recommended_facet.items())),
 'citation_pair_count':sum(citations.values()),'distinct_cited_declarations':len(citations),'recommended_citation_pair_count':147,'recommended_distinct_cited_declarations':142,
 'duplicate_pair_count':sum(len(r['declarations'])-len(set(r['declarations'])) for r in rows),
 'missing_from_supplied_environment_inventory':sorted(set(citations)-inv_names),
 'shared_declaration_credit':{n:[r['id'] for r in rows if n in r['declarations']] for n,c in citations.items() if c>1},
 'changed_rows_since_v027':[{'id':r['id'],'fields':sorted(k for k in set(r)|set(old[r['id']]) if r.get(k)!=old[r['id']].get(k))} for r in rows if r!=old[r['id']]],
 'unchanged_rows_since_v027':sum(r==old[r['id']] for r in rows),'new_family_closures':[],
 'status_transitions':[{'id':'T021','from':'missing','to':'partial','decision':'accepted'},{'id':'T028','from':'source-check','to':'partial','decision':'accepted_exact_slice_general_statement_gate_retained'}],
 'T028_scope_decision':{'status':'partial','decision':'accepted','source_review_gate_retained':True,'critical_boundary':'For positive alpha, exact Pareto diverges at q=alpha because its slowly varying factor is constant. For general RV tails the critical integral is proportional to integral L(t)/t dt and may converge or diverge. Do not transfer the exact-Pareto boundary to all RV laws.','negative_orders':'The all-real-p exact theorem is accepted: L>0 removes any lower-end singularity. This extension does not change the general nonnegative-moment order convention.'},
 'T029_scope_decision':{'current_status':'partial','recommended_status':'partial','binary_milestone':'accepted_complete','pareto_specialization':'accepted_complete','realization_scope':'Concrete Pareto marginal laws, with joint coordinates and pointwise nonnegativity assumed. No explicit joint realization theorem supplied or required for Stage A.','stronger_RV_child':'open'},
 'T029_children':children,'Pareto_children':stages,
 'completed_T061_children':copy.deepcopy(prev['completed_T061_children']),'open_T061_children':[],
 'supplemental_open_EVT_tasks':supp,'dependency_group_counts':groups,'findings':findings,'families':families,'ledger_rows':rows,
 'prior_audit_responses':[
  {'id':'D027-1','state':'accepted','scope':'Stale sentence removed in generator and both renderings; conditional exponent facet assigned; concrete marginal realization scoped separately.'},
  {'id':'D027-2','state':'accepted','scope':'S001 explicit zero-shape Gumbel branch, off-support conventions, corrected pp.172-173/PDF186-187 and endpoint coordinate table.'},
  {'id':'D027-3','state':'new_count_confirmed_historical_annotation_not_in_supplied_bundle','scope':'New external validation log reads 18 results from machine-readable record. Claimed annotation to deliverables/README.md is outside the supplied pre-deliverables bundle and is not independently confirmed by these files.'}
 ],
 'ledger_json_sha256':hashlib.sha256((ROOT/'docs/FORMALIZATION_BACKLOG.json').read_bytes()).hexdigest(),
 'source_pdf_sha256':hashlib.sha256((HERE/'source/2001.10488v4(1).pdf').read_bytes()).hexdigest(),
 'source_pages_reviewed':{'T021':'printed86/PDF100','T028':'printed95-98/PDF109-112; exact constant-factor tail on printed95/PDF109','T029':'printed99/PDF113; inherited previous audit scope accepted','S001':'printed172-173/PDF186-187','T118':'Proposition21.1 printed381/PDF395; exact formula Eq.(21.7) printed382/PDF396'},
 'execution_complete':False
}
assert [r['id'] for r in rows]==[f'T{i:03}' for i in range(1,159)]
assert len(families)==13 and len(groups)==22 and sum(citations.values())==146 and len(citations)==142
assert not d['missing_from_supplied_environment_inventory'] and d['unchanged_rows_since_v027']==155
(HERE/'ledger_review.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:d[k] for k in ['status_counts','supported_count','citation_pair_count','distinct_cited_declarations','changed_rows_since_v027']},indent=2))
