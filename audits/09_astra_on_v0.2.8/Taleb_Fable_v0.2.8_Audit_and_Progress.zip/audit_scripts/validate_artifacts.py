"""Validate the published audit against received rows and independent runtime."""
from pathlib import Path
import collections
import hashlib
import json
import zipfile
import fitz

BASE = Path(__file__).resolve().parent
OUT = BASE.parent / 'output'
x = json.loads((OUT / 'Taleb_Proof_Progress_v0.2.8.json').read_text())
r = json.loads((BASE / 'received/Taleb_Lean_Repairs/docs/FORMALIZATION_BACKLOG.json').read_text())
assert x['ledger_rows'] == r
assert [f['id'] for f in r] == [f'T{i:03}' for i in range(1, 159)]
expected = {'discharged': 2, 'partial': 11, 'reuse': 4, 'missing': 90,
            'source-check': 33, 'model-needed': 15, 'empirical': 3}
assert x['status_counts'] == dict(collections.Counter(f['status'] for f in r)) == expected
assert x['recommended_status_counts'] == expected
assert [f['id'] for f in r if f['status'] == 'discharged'] == ['T060', 'T061']
assert len(x['completed_T061_children']) == 4
assert len(x['families']) == 13 and len(x['dependency_group_counts']) == 22
assert sum(v['total'] for v in x['dependency_group_counts'].values()) == 158
pairs = {(f['id'], d) for f in r for d in f['declarations']}
assert len(pairs) == 146 and len({d for _, d in pairs}) == 142
assert x['recommended_citation_pair_count'] == 147
assert x['recommended_distinct_cited_declarations'] == 142
assert x['independent_execution']['complete'] is True and x['publication_state'] == 'final'
assert x['execution_summary_sha256'] == hashlib.sha256((BASE / 'execution_summary.json').read_bytes()).hexdigest()
for name in ['Taleb_Fable_v0.2.8_Independent_Audit.md',
             'Taleb_Proof_Progress_v0.2.8.md', 'Taleb_Fable_v0.2.8_Review_Handoff.md']:
    content = (OUT / name).read_text()
    assert not any(ch in content for ch in ['\u2014', '\u2013', '\u2011']), name
    for stale in ['pending final', 'execution pending', 'draft execution status',
                  'pending runtime', 'pending final record']:
        assert stale not in content.lower(), (name, stale)
pdf = fitz.open(OUT / 'Taleb_Fable_v0.2.8_Independent_Audit.pdf')
assert len(pdf) == 8, len(pdf)
for page in pdf:
    assert '\ufffd' not in page.get_text()
    for block in page.get_text('blocks'):
        if 45 < block[1] < 780 and block[4].strip():
            assert block[3] < 786, block
zpath = OUT / 'Taleb_Fable_v0.2.8_Audit_and_Progress.zip'
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    names = set(z.namelist())
    manifest = z.read('SHA256SUMS').decode().splitlines()
    assert len(manifest) == len(names) - 1
    for line in manifest:
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
    for name in ['Taleb_Fable_v0.2.8_Independent_Audit.pdf',
                 'Taleb_Fable_v0.2.8_Independent_Audit.md',
                 'Taleb_Proof_Progress_v0.2.8.json',
                 'Taleb_Proof_Progress_v0.2.8.md',
                 'Taleb_Fable_v0.2.8_Review_Handoff.md']:
        assert z.read(name) == (OUT / name).read_bytes()
    for name in ['evidence/reproduction/execution_summary.json',
                 'evidence/reproduction/crlf_markdown_cli_probe/result.json',
                 'evidence/reproduction/runtime_binaries.sha256']:
        assert name in names, name
    for i in range(1, 4):
        assert f'evidence/reproduction/regression_shard_{i}/harness_regression.json' in names
    assert not any('/repo/' in n or '/.lake/' in n or '/.git/' in n for n in names)
checksum = (OUT / (zpath.name + '.sha256')).read_text().split()[0]
assert hashlib.sha256(zpath.read_bytes()).hexdigest() == checksum
print(json.dumps({'all_checks_passed': True, 'pages': len(pdf),
                  'original_family_rows_preserved': 158, 'supported_scopes': 13,
                  'dependency_groups': 22, 'zip_sha256': checksum}, indent=2))
