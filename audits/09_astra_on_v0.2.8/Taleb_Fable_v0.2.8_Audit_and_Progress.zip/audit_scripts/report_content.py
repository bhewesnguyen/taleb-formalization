"""Independent v0.2.8 assessment; actual execution is inserted separately."""
def make_pages(execution):
    pages=[]
    def page(title,subtitle):
        b=[];pages.append({'title':title,'subtitle':subtitle,'blocks':b});return b
    def p(b,s):b.append(('p',s))
    def h(b,s):b.append(('h',s))
    def t(b,heads,rows,widths):b.append(('t',(heads,rows,widths)))

    b=page('Taleb Lean v0.2.8','Independent audit | 21 September 2026 | Exact Pareto laws, moments and proof progress')
    h(b,'Assessment')
    p(b,'**Accept Pareto Stage A and both scope decisions.** No defect was found in the twenty new theorems or the extended-moment definition. The all-real moment-order formulation is correct. Moving T028 from source-check to partial is justified because its exact-Pareto slice is proved and the general boundary review remains explicit. Two low-priority ledger corrections remain.')
    p(b,execution['verdict'])
    t(b,['Area','Independent assessment'],[
        ['Actual Pareto law','The development reuses pinned Mathlib paretoMeasure, with correct positive parameters, support, endpoint mass, strict survival and global CDF.'],
        ['Moments and divergence','For every real p, integrability holds exactly when p < α. The finite value is α L^p/(α-p); the extended integral is +∞ for p ≥ α, including equality.'],
        ['Negative orders','Valid without additional hypotheses: L > 0 keeps all mass away from the singularity at zero. This is a useful generalization of the requested p ≥ 0 slice.'],
        ['T029 specialization','The actual Pareto survival exponent supplies the former tail-property premises. The result specializes the weighted-sum theorem to concrete Pareto marginal laws, without independence.'],
        ['Remaining corrections','T118 still calls the now-proved Pareto moment formula missing. T028 locates the exact constant-factor tail on p.97 instead of p.95. Neither affects the Lean proofs.']
    ],[116,382])
    h(b,'Broader progress')
    p(b,'**2 discharged / 11 partial / 4 reuse / 90 missing / 33 source-check / 15 model-needed / 3 empirical = 158 families.** T021 and T028 join the supported set, which grows from 11 to 13 families. T060 and T061 remain discharged; no parent family is newly closed.')
    p(b,'The release has **146 family/declaration pairs over 142 distinct names**, up from 123/122. Public checks rise from 164 to 184. Cross-crediting the existing moment theorem to T118 would raise citation pairs to 147 without adding a declaration or a closed family. None of these unequal counts measures effort completed.')

    b=page('Law, support and tail exponent','The formulas are proved against the actual pinned Mathlib measure')
    p(b,'For L > 0 and α > 0, paretoMeasure L α is volume.withDensity with density α L^α x^(-α-1) on [L,+∞). The source uses this scale convention at printed p.86 / PDF p.100. The implementation uses Mathlib\'s normalization lemma locally and introduces no competing Pareto measure.')
    t(b,['Claim','Reviewed argument'],[
        ['No mass below L','The density is zero below its lower endpoint. The Iic x result for x < L and the Iio L result are valid even without the probability-parameter restrictions.'],
        ['No mass at L','Absolute continuity with respect to Lebesgue measure makes the singleton null. The non-strict density branch at L therefore creates no atom.'],
        ['Strict survival','S(x)=1 below L and S(x)=(L/x)^α for x ≥ L. Tail integration uses an integrable positive power density; S(L)=1 is explicitly proved.'],
        ['Global CDF','F(x)=0 below L and F(x)=1-(L/x)^α for x ≥ L. The probability complement identity uses Ioi/Iic exactly, and F(L)=0 is explicitly proved.'],
        ['Actual tail exponent','The actual survival function eventually equals L^α x^(-α). Eventual equality transfers both positivity and the finite log-ratio limit, giving exponent α.']
    ],[132,366])
    h(b,'What the weighted-sum specialization establishes')
    p(b,'For measurable, pointwise nonnegative X,Y on a probability space, positive weights a,b, and marginal laws Pareto(L1,α1), Pareto(L2,α2) with positive parameters, the law of aX+bY has finite log-tail exponent min(α1,α2). The proof invokes the general weighted-sum bridge and replaces each finite-exponent premise with the newly checked Pareto law theorem. Independence is not assumed.')
    p(b,'The actual_law_constructed facet is defensible under the project glossary, which expressly permits reuse of a concrete Mathlib law. Scope it to the realized Pareto marginal laws. The weighted-sum theorem still assumes a joint space and coordinates with those marginals; it does not export a product-space construction of the coordinates. Pointwise nonnegativity is also an explicit premise, whereas law equality alone gives the corresponding support property only almost everywhere.')
    p(b,'This is a correct specialization to concrete laws. An explicit joint realization or an almost-sure version could be added later, but neither is a new acceptance gate for Stage A. T029 remains partial for its separately named stronger regular-variation child; the binary finite-exponent child stays complete.')
    p(b,'No exact convolution asymptotic, finite-family extension, conditional Pareto law or power-map equality is claimed by these declarations. The next Stage B targets are therefore genuine follow-on work.')

    b=page('Moments and the critical boundary','All real orders below the shape are valid; exact Pareto does not settle general regular variation')
    p(b,'momentLintegral L α p is the extended nonnegative integral of ofReal(x^p) under paretoMeasure. On the positive support, multiplying by the density gives α L^α x^(p-α-1). The reduction uses measurable nonnegative integrands and removes only a Lebesgue-null endpoint.')
    t(b,['Range','Independent assessment'],[
        ['p < α','The density-weighted exponent is below -1, so the improper integral on (L,+∞) is integrable. The proof establishes this before using the real integral formula, then returns ofReal(α L^p/(α-p)).'],
        ['p = α','The integrand is α L^α / x. Mathlib\'s integrability criterion excludes exponent -1. Nonnegativity and measurability convert this nonintegrability into an extended integral equal to +∞.'],
        ['p > α','The same criterion excludes all exponents greater than -1. The positive multiplicative constant cannot hide divergence.'],
        ['Real and absolute moments','The integrability equivalence is proved first. Real formulas are restricted to p < α; absolute moments agree almost everywhere because the law has positive support. The p=0 value is 1.']
    ],[132,366])
    h(b,'Ruling on negative orders')
    p(b,'**Accept the stronger all-real statement.** Negative powers can be singular at zero, but L > 0 excludes a neighborhood of zero from the support. At infinity they decay, so every negative order is finite. No extra assumption p ≥ 0 is needed for this exact Pareto theorem. This does not automatically generalize negative moments to arbitrary nonnegative laws whose mass can approach zero.')
    h(b,'Ruling on T028')
    p(b,'**Accept source-check → partial.** A parent can have a completed exact-law slice while retaining a statement-review gate on its general child. The current remaining-obligations field does retain that gate. The status change must not be read as proving the general regularly varying threshold or resolving its boundary.')
    p(b,'For α > 0 and a nonnegative law with survival asymptotic to t^(-α) ℓ(t), the critical α-moment depends on the tail integral of ℓ(t)/t. A constant ℓ produces divergence. By contrast, for t ≥ e, the valid survival S(t)=e^α t^(-α)/(log t)^2, continued as 1 below e, has the same regular-variation index and a finite α-moment. This example is explanatory mathematics, not a newly formalized result.')
    p(b,'T021 also remains partial. E[|X|^p] on this positive support is a raw absolute moment; it is not the centered mean absolute deviation E[|X-E X|]. The MAD/STD ratio needs that centered calculation, as well as mean, variance and ratio algebra. Gaussian and Student moment targets remain open.')

    b=page('Audit responses and corrections','Two small ledger edits; no Lean repair requested')
    h(b,'Prior responses')
    p(b,'D027-1 is repaired at the generator and both renderings: T029 credits the completed binary child, names the stronger ratio target, and distinguishes conditional_law_theorem from the generic law identity. D027-2 is repaired: S001 now specifies the ξ=0 Gumbel branch, the nonzero-shape support branches, the correct pp.172-173 / PDF186-187 anchors and the endpoint reparameterization.')
    p(b,'For D027-3, the current validation log reports eighteen probes using the JSON result count. The promised annotation of the old count in deliverables/README.md belongs to the final deliverables commit, which is outside the supplied bundle. That retrospective annotation is therefore not independently inspectable here; the corrected current count is verified. This is an evidence limit, not a mathematical blocker.')
    p(b,'The verifier now compares the UTF-8 rendering to raw Markdown bytes. This strengthens the line-ending convention: the previous gate already detected stale content, while the new one also rejects a CRLF-only conversion. Schema, inventory scanner and fourteen-fixture harness behavior are otherwise preserved. The independent Python checks distinguish actual generator execution from replayed external-command results.')
    h(b,'D028-1 | low | T118 under-credits an available prerequisite')
    p(b,'T118 still says the Pareto p-th moment formula is not delivered and lists identifying it as remaining. AuditPareto.integral_rpow_paretoMeasure now identifies exactly that formula for a positive scale and shape with p < α. The claim became stale when the new module landed; the formula is already credited under T021.')
    p(b,'**Repair:** cross-credit that declaration in the authoritative T118 row and update both rendered ledgers. Under T118\'s p > 0 and α > p hypotheses, it applies directly. Record the formula as delivered with scoped law/realization facets; retain partial status because convexity and integrated Jensen remain unproved. Extend the source anchor to Proposition 21.1 and Eq. (21.7), printed pp.381-382 / PDF395-396; the latter explicitly states this moment formula.')
    p(b,'For future T118 work, m_p(α)=L^p α/(α-p) has second derivative 2 L^p p/(α-p)^3. The source display on p.382 omits the factor p and replaces (α-p)^3 with (α-1)^3; it agrees at p=1. Keep the corrected formula in the remaining specification. The restriction p > 0 matters; negative orders do not inherit convexity. Mixing support and integration hypotheses still need proof.')
    h(b,'D028-2 | low | exact-tail source locator is off by two pages')
    p(b,'T028\'s delivery_scope attributes the exact constant-factor tail P(X>x)=C x^(-α) to printed p.97 / PDF p.111. That display is on printed p.95 / PDF p.109. Printed p.96 introduces the slowly varying factor; p.97 gives the exponent discussion and Definition 5.1.')
    p(b,'**Repair:** cite p.95/PDF109 for the exact tail, p.86/PDF100 for the density, and retain p.97/PDF111 for the exponent and regular-variation class where relevant. Change the generating row and regenerate both formats. No new expensive Lean fixture or proof rewrite is needed for either correction.')

    b=page('Position in the broader ledger','Thirteen supported families, with two newly delivered Pareto slices')
    t(b,['Family','Status','Reviewed delivery and remaining scope'],[
        ['T001','Partial','Ratio-only variation API; positive measurable convention and its bridge remain.'],
        ['T007','Partial','Gaussian stable-law realization at index 2; general stable existence remains.'],
        ['T008','Partial','Conditional subexponential tail result; concrete-law examples remain.'],
        ['T021','Partial','NEW: exact Pareto raw/absolute moments and divergence. Gaussian, Student and centered MAD/STD remain.'],
        ['T028','Partial','NEW: exact Pareto support, CDF, survival, exponent and moment threshold. General RV theorem/boundary remain.'],
        ['T029','Partial','Binary exponent child complete, now specialized to Pareto marginal laws. Stronger RV child remains.'],
        ['T032','Partial','Analytic power-transform exponent; actual law pushforward is next Stage B work.'],
        ['T046','Partial','Actual Gaussian characteristic-function/convolution bridge; Cauchy remains.'],
        ['T047','Partial','Prerequisite sum/convolution infrastructure; average-law scaling/convergence remain.'],
        ['T060','Discharged','Generic maximum CDF and minimum survival laws under ordinary probability hypotheses.'],
        ['T061','Discharged','Three EVT laws, exact CDFs, affine families and maximum-law measure equalities.'],
        ['T118','Partial','Tail-kernel convexity; moment identification now available for cross-credit. Moment convexity/Jensen remain.'],
        ['T124','Partial','Repaired rational algebra and positivity; gamma inverse-moment integration remains.']
    ],[57,77,364])
    p(b,'The parent changes are T021 missing → partial and T028 source-check → partial. There are **140 formal-proof families: 2 discharged and 138 open**. The other eighteen require models or empirical work. The supported-family count rises to thirteen, while the discharged count remains two.')
    p(b,'The release\'s 146 citation pairs cover 142 distinct declarations. Recommended T118 cross-credit would produce 147/142 without another theorem. The companion JSON preserves all 158 received rows and records recommendations separately, with all 22 dependency-group tallies and completed/open child scopes.')
    p(b,'S001 and S002 remain separately open outside the fixed 158-family count. This curated inventory is not an exhaustive atomic theorem census, an effort-completion percentage, evidence of an upstream Mathlib merge or evidence that the separate quantum/classical application is operational.')

    b=page('Next milestone: Pareto Stage B','Reuse the pinned conditioning API and prove equalities of actual laws')
    p(b,'The natural next package is the conditional/excess law and positive-power pushforward. Use L > 0, α > 0 throughout. Mathlib already defines ProbabilityTheory.cond μ A = (μ A)^(-1) • μ.restrict A and supplies a probability instance when the conditioning event has positive finite measure. Reuse this API.')
    t(b,['Core result','Precise acceptance target'],[
        ['Threshold law','For K ≥ L, prove cond (paretoMeasure L α) (Ioi K) = paretoMeasure K α. Establish positive finite tail mass explicitly; K=L must work because the endpoint has zero mass.'],
        ['Excess law','Map that conditional law by x ↦ x-K. Its strict survival is 1 for y < 0 and (K/(K+y))^α for y ≥ 0. Include y=0, where the value is 1, and identify its CDF if using CDF equality.'],
        ['Positive-power law','For q > 0, prove (paretoMeasure L α).map (x ↦ x^q) = paretoMeasure (L^q) (α/q). Establish measurability and use positive support for the inverse-event argument.']
    ],[122,376])
    p(b,'Power preimages must not be rewritten by an unrestricted identity over all real x: Lean real powers on negative bases are totalized, and the desired monotonic inverse argument belongs to the positive support. Splitting the target CDF below and above L^q is a suitable route; both measures must have the appropriate probability instances.')
    h(b,'Moment corollaries should use Stage A')
    p(b,'The conditional raw p-th moment becomes α K^p/(α-p) for p < α, with extended divergence otherwise. For α > 1, the conditional mean is αK/(α-1), while the mean excess is K/(α-1). Keep those two quantities distinct. If divergence of excess moments is claimed, prove it through an extended nonnegative integral; do not subtract a constant from a totalized divergent real integral.')
    p(b,'The power-law identity implies a p-th moment threshold q p < α, consistent with shape α/q. These are useful corollaries when contained, but the three law-level targets above define the core Stage B package. Do not expand this milestone into general Karamata theory or all centered-moment ratios.')
    h(b,'Credit only the completed slices')
    p(b,'Stage B supports exact-Pareto children of T005 and T032. T005\'s general tail-integral/conditional identities and T032\'s broader transformation work remain open unless actually proved. T021\'s centered Pareto MAD/STD calculation can follow; it needs an absolute-deviation integral, not just the first two raw moments.')
    p(b,'T029\'s stronger unequal-index ratio target stays separate: S_(aX+bY)(t)/S_X(t/a) → 1, with relative factor a^α against S_X(t), under the previously recorded regular-variation hypotheses. Later Pareto maximum convergence uses frechetMeasure (1/α), normalized by L n^(1/α). Neither follows solely from the new moment formulas.')

    b=page('Independent execution','Compiler execution, Python probes and added mutation checks are recorded separately')
    t(b,['Check','Observed outcome'],execution['rows'],[132,366])
    p(b,execution['detail'])
    t(b,['Fixture','Expected behavior'],[
        ['valid','Accept the pristine project.'],
        ['namespace_section_theorem','Accept declarations after section boundaries.'],
        ['nested_imported_module','Accept and scan an imported nested module.'],
        ['private_sorry_theorem / private_sorry_def','Reject; standalone scans expose sorryAx.'],
        ['private_axiom','Reject the added project axiom.'],
        ['structure_namespace_theorem / protected_theorem','Reject public-inventory mismatch.'],
        ['alias_map_mismatch / optimized variant','Reject alias mismatch, including Python -O.'],
        ['orphan_module / nested_orphan_module','Reject unimported project modules.'],
        ['dirty_dependency','Reject the modified dependency checkout.'],
        ['backlog_duplicate_id','Reject the duplicate ledger ID.']
    ],[234,264])
    p(b,'Fourteen shipped names are grouped above for space. The additional real CRLF-only Markdown CLI check is separate. Eighteen shipped Python probes and nine bounded verify.main replays are also separate; the latter replay external-command output and are not additional Lean proof checks.')

    b=page('Provenance and audit boundaries','Archive, patches and committed history agree; final delivery metadata has a narrower scope')
    t(b,['Item','Independently checked'],[
        ['Release ZIP','SHA-256 696c5187ed87bb0ad428bbbdd78185758de5b437fb14a9e2411c07b32a8ccbb0; 238 regular files, 269 entries.'],
        ['Manifest and paths','237/237 manifest checks; exact extraction and bundled project bytes; no unsafe paths, symlinks or project build outputs.'],
        ['Bundled snapshot','Commit d086ce0cc9ac978e332df4d25bd92994e5f09230; project tree ebfa0c527eff18df29851727a3032f5786f16dc7.'],
        ['Both patch routes','The v0.2.0 full patch changes 186 files and the v0.2.7 incremental patch 42; both apply cleanly and reproduce the exact tree and file bytes.'],
        ['Preserved mathematics','All 27 pre-existing math modules are byte-identical to v0.2.7. ParetoLaw.lean is new. Pins remain Lean 4.24.0 and Mathlib f897ebcf72cd16f89ab4577d0c826cd14afaafc7.'],
        ['Source edition','arXiv:2001.10488v4, 523 pages; source SHA-256 758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567. Visually checked relevant source pages.']
    ],[118,380])
    p(b,'All 22 retained-artifact hashes pass. The retained v0.2.7 audit ZIP matches the original independently recorded checksum and its 65 internal manifest entries. The standalone prior PDF differs in metadata/binary representation, but all nine page texts and every 150-dpi rendered RGB pixel buffer match the PDF inside that ZIP. No substantive page change was found.')
    h(b,'What the bundle proves')
    p(b,'The bundle has complete history to its advertised packaged commit, including three commits after the v0.2.7 deliverables commit. The announced fourth commit adds current deliverables and is explicitly outside this bundle. The original worktree\'s clean state and push state are not established by a clean audit checkout. The later deliverables-index annotation cannot be inspected from these bytes.')
    h(b,'Scope of acceptance')
    p(b,'This audit accepts the reviewed Stage A propositions and the stated ledger transitions, subject to the two small documentation corrections. It does not certify every claim in the source book, general regular-variation moment theory, Stage B laws or the separately tracked application. The received release was not modified.')
    p(b,'The evidence ZIP contains the PDF and editable audit, full progress ledger, Fable handoff, mathematical and verifier subreviews, independent execution records and provenance scripts/results. It excludes the compiler, dependency caches, full source book, temporary Git worktrees and duplicate supplied archives. SHA256SUMS covers all included files except itself.')
    return pages
