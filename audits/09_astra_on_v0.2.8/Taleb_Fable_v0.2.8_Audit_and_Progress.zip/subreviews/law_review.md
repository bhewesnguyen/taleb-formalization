# v0.2.8 Pareto law and weighted-sum review

Source review completed against the received `AuditRepairs/ParetoLaw.lean`, the relevant existing `ProbabilityBridge.lean` and `WeightedSums.lean`, and the pinned Mathlib Pareto and conditional-probability sources. This review does not claim an independent Lean execution; the runtime review owns that evidence. The integral and divergence proofs have a separate detailed review.

## Verdict

Accept the delivered support, survival, CDF and tail-exponent mathematics. No mathematical defect was found in these proofs. The Pareto specialization of the weighted-sum theorem is also correct with exactly its stated hypotheses, including pointwise nonnegativity. It is a specialization to concrete Pareto marginal laws, not a new joint sample-space construction.

The new `actual_law_constructed` facet for T029 is acceptable under the ledger's explicit convention that reuse of a Mathlib law counts as realization, provided it is read as credit for the Pareto marginal laws and their proved tail properties. It should not be described as a separately constructed joint Pareto model or a theorem deriving pointwise nonnegativity from law equality. This is a scope clarification, not a reason to reject Stage A or remove credit for the concrete Pareto laws.

## Checked statements

| Source | Result | Assessment |
|---|---|---|
| `ParetoLaw.lean:45` | Zero mass on `Iic x` when `x < L` | The density vanishes throughout this set. Correct even without positive parameter hypotheses, which are needed later for probability normalization. |
| `ParetoLaw.lean:51` | Zero mass on `Iio L` | Correct use of the pinned density integral lemma. |
| `ParetoLaw.lean:56` | Zero mass at the singleton endpoint | Correct consequence of absolute continuity with respect to Lebesgue measure. No strict/non-strict endpoint ambiguity remains. |
| `ParetoLaw.lean:65` | Tail integral algebra | Positivity assumptions ensure all divisions and real-power identities are used in their valid ranges. |
| `ParetoLaw.lean:73` | Strict survival equals 1 below L and `(L/x)^α` from L onward | Correct. The proof installs the actual probability instance, integrates the density over `Ioi x`, and converts the nonnegative finite integral without losing infinity information. |
| `ParetoLaw.lean:100` | Strict survival at L is 1 | Correct: the support endpoint has zero mass. |
| `ParetoLaw.lean:105` | CDF equals 0 below L and `1 - (L/x)^α` from L onward | Correct complement is `Iic x` versus `Ioi x`; the probability instance justifies the real-measure complement calculation. |
| `ParetoLaw.lean:114` | CDF at L is 0 | Correct and explicitly proved. |
| `ParetoLaw.lean:245` | Actual Pareto survival has finite log-tail exponent α | Correct eventual equality with `L^α x^(-α)`. Eventual `x >= L > 0` supplies the positivity required by real-power division and inversion. Both eventual positivity and the limit are transferred. |
| `ParetoLaw.lean:261` | Weighted Pareto coordinates have minimum tail exponent | Correct application of the previously checked probability bridge, after rewriting both coordinate pushforward measures to their Pareto laws. No independence assumption is introduced or needed. |

The pinned API defines `paretoMeasure L α` as `volume.withDensity (paretoPDF L α)`, with the density branch active on `L <= x`. The new module uses that exact measure rather than an independently defined substitute. The local probability instances use the pinned theorem `isProbabilityMeasure_paretoMeasure`; its required `L > 0` and `α > 0` hypotheses are supplied.

The phrase "below the endpoint (including at x = L)" in two short docstrings is informal about the piecewise branch but harmless: the theorem uses `x < L`, and the separate endpoint theorems establish that the same numerical values persist at equality. Rewriting this wording is optional and is not a new audit finding.

## Precise scope of the T029 specialization

The new theorem assumes all of the following:

- A probability measure `P` on a measurable sample space.
- Measurable real functions `X` and `Y`.
- Pointwise nonnegativity of both functions, not merely almost-sure nonnegativity.
- Positive weights and positive Pareto endpoints and exponents.
- Exact law equalities `P.map X = paretoMeasure L1 α1` and `P.map Y = paretoMeasure L2 α2`.

It concludes the finite log-tail exponent of the actual pushforward law of the weighted sum. The coordinate finite-exponent premises no longer have to be assumed separately: the new Pareto survival theorem discharges them. This is substantive progress beyond a formula-level power-tail identity.

However, no theorem in this module constructs `P`, `X`, and `Y` meeting all those hypotheses. In particular, equality to a positive-support law implies almost-sure support, not pointwise support on every sample point. The received theorem correctly keeps the stronger pointwise condition explicit.

Recommended bounded wording:

> T029 now has a checked specialization to concrete Mathlib Pareto marginal laws, with the marginal finite-exponent premises discharged. The weighted-sum result assumes measurable, pointwise nonnegative coordinates with those laws. An explicit joint realization and an almost-sure-nonnegativity wrapper are not part of this release.

The ledger's ordinary `law_theorem` facet could also credit this new specialization, because specified marginal laws are ordinary distributional hypotheses under its own legend. Leaving that facet attributed only to the existing event/pushforward identity is conservative rather than an overstatement.

If an explicit joint example becomes useful later, a natural route is the product of the two Pareto measures with coordinates `max L1 fst` and `max L2 snd`. These coordinates are pointwise positive and agree almost everywhere with the ordinary projections, so their pushforwards are the original marginals. This is a proposed route, not a delivered Lean theorem and not an added acceptance gate for Stage A.

## Stage B: precise next statements

The proposed next milestone is mathematically correct after writing its domains explicitly. Reuse the pinned `Mathlib.Probability.ConditionalProbability` API, rather than introducing a second notion of conditioning. It already defines

`ProbabilityTheory.cond ν s = (ν s)⁻¹ • ν.restrict s`

and supplies `cond_isProbabilityMeasure`, `cond_apply` and `cond_apply'`.

For `L > 0`, `α > 0` and `K >= L`, target an equality of measures:

`cond (paretoMeasure L α) (Ioi K) = paretoMeasure K α`.

The strict conditioning event has positive finite probability `(L/K)^α`. The case `K = L` is included and agrees with the original law because the endpoint has zero mass. This conditional result does not hold with lower endpoint K when K is below L; in that case the event already has probability 1 and the law remains Pareto(L, α).

For the conditional excess `X - K`, give the global strict survival explicitly:

| Excess threshold y | Survival under the conditional law |
|---|---|
| `y < 0` | `1` |
| `y >= 0` | `(K/(K+y))^α` |

The formula branch gives 1 at zero, matching the constant branch's limiting value. Carry the explicit `y >= 0` qualifier from the full specification into the next handoff. Without that qualifier the expression can exceed 1 or have a zero denominator for negative y. The received next-task list is an abbreviated pointer to Stage B, so this is not a new finding against delivered Stage A.

For `α > 1`, distinguish the conditional mean `αK/(α-1)` from the conditional excess mean `K/(α-1)`. Any divergence claims for `α <= 1` should use the extended nonnegative integral, as Stage A already does.

For the power map, require `q > 0` and prove the actual measure equality:

`(paretoMeasure L α).map (fun x => x ^ q) = paretoMeasure (L ^ q) (α / q)`.

The endpoint and shape on the right are then positive. A proof via exact CDF identities and `Measure.eq_of_cdf` is appropriate, using positivity on the source support for the inverse-event identity. The case `q = 0` would instead be a point mass at 1, and negative q gives a different, bounded-above support; neither is included in this target.

These are exact-Pareto slices of T005 and T032. They do not by themselves discharge the general tail-integral identity in T005 or a general power-transformation theorem for all nonnegative heavy-tailed laws in T032.

## Source correspondence and one locator correction

After the root audit recovered `audit_v028/source/2001.10488v4(1).pdf`, this review extracted the relevant primary-source pages and visually inspected rendered PDF pages 100, 109 and 111. The rendered inspection files are `audit_v028/source/law_pdf100.png`, `law_pdf109.png` and `law_pdf111.png`.

| Claim | Verified primary-source location |
|---|---|
| Pareto density `α L^α x^(-α-1)` and standard deviation | Printed p. 86 / PDF 100. The density and endpoint/scale convention match the pinned Mathlib law. |
| Constant-factor tail `P(X>x) = C x^(-α)` | Printed p. 95 / PDF 109, near the bottom of the page. |
| Slowly varying factor definition | Printed p. 96 / PDF 110. |
| Log-tail exponent and Definition 5.1 of the regular-variation class | Printed p. 97 / PDF 111. |
| Property 5.1 finite weighted sums and the sign error in its display | Printed p. 99 / PDF 113. The new Pareto specialization remains a binary, finite-exponent result with the correct sign and nonnegative summands. |
| Property 5.2 and the power-transformation discussion | Printed p. 100 / PDF 114. Stage B's exact positive-power equality is a properly restricted instance. |
| General tail-integral identity | Printed p. 18 / PDF 32, equation (2.10); proof displayed on printed p. 260 / PDF 274 after the section heading on p. 259. A Pareto conditional-law instance alone does not prove that general identity. |

One low source-locator correction is warranted: T028's new `delivery_scope` says "p. 97 (PDF 111) Paretian tail P(X > x) = C x^(-alpha)". The exact constant-factor expression is on printed p. 95 / PDF 109. Update the authoritative generator row to cite p. 95 for that expression and, if desired, keep p. 97 separately for the log-tail exponent and regular-variation class. Regenerate the JSON and Markdown together. This changes a locator, not the mathematical result or family status.

The review also inspected printed pp. 381 and 382 / PDF 395 and 396 for the T118 cross-credit identified by the ledger review; PDF 396 was rendered and visually inspected in `law_pdf396.png`. Equation (21.7) on printed p. 382 is exactly `E[X^p] = x0^p * α / (α - p)`, so the new `integral_rpow_paretoMeasure` theorem directly discharges that identification child for `x0 = L > 0`. The later second-derivative display on that page has the p = 1 specialization in its denominator and numerator. For general `p > 0`, differentiating the checked moment function gives `2 * p * L^p / (α - p)^3` on `α > p`. Record that corrected future specification, while leaving convexity and Jensen open. No delivered Lean theorem imports the erroneous general-p derivative expression.
