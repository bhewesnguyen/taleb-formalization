# v0.2.8 Pareto moment review

Verdict: accept the Stage A moment results as stated. No mathematical defect, missing hypothesis, misuse of a totalized real integral, or unsupported extension to negative orders was found in the reviewed declarations. This is a source-level review; independent compilation and trust-scan results belong to the runtime review.

Reviewed project source: `AuditRepairs/ParetoLaw.lean`, principally `momentLintegral`, `momentLintegral_eq`, `momentLintegral_of_lt`, `momentLintegral_eq_top`, `ae_nonneg_rpow_paretoMeasure`, `integrable_rpow_paretoMeasure_iff`, `integral_rpow_paretoMeasure`, `integral_rpow_zero_paretoMeasure`, and `integral_abs_rpow_paretoMeasure`.

Reviewed pinned Mathlib source: `Probability/Distributions/Pareto.lean`, `Analysis/SpecialFunctions/ImproperIntegrals.lean`, `MeasureTheory/Measure/WithDensity.lean`, `MeasureTheory/Function/L1Space/HasFiniteIntegral.lean`, and `MeasureTheory/Integral/Bochner/Basic.lean` in the unchanged dependency checkout.

## 1. Mathematical content and hypothesis review

For `L > 0`, `alpha > 0`, and every real `p`, the implementation proves

```
momentLintegral L alpha p =
  ofReal (alpha * L^p / (alpha - p))  if p < alpha,
  top                                if alpha <= p.
```

It also proves `Integrable (fun x => x^p) (paretoMeasure L alpha) <-> p < alpha`, and the corresponding real and absolute-moment formulas under `p < alpha`.

The positive lower endpoint is essential and present. Negative orders are legitimate: the support is contained in `[L, infinity)` with `L > 0`, so no singularity at zero is encountered. For `p < 0`, the positive function `x^p` is bounded above on the support by `L^p` and decays at infinity. The formula `alpha * L^p / (alpha - p)` therefore has the expected finite, positive value. Requiring `p >= 0` would unnecessarily weaken this theorem.

The implementation does not silently assume a conventional complex power or a real power on positive inputs everywhere. It uses Lean's real power function on all reals, proves that the Pareto law gives zero mass to the problematic region below the positive endpoint, and performs power algebra only on positive support points. This is sufficient for every claimed integral identity.

## 2. Density conversion is valid

`momentLintegral_eq` uses the existing Mathlib measure `volume.withDensity (paretoPDF L alpha)`. It introduces no replacement distribution.

Both the integrand and density are shown measurable. The with-density identity converts the moment to the Lebesgue integral of the product. The contribution on `Iio L` vanishes because the density is zero there. On `Ici L`, positivity follows from `L > 0`, and the proof uses the positive-base real-power product rule to obtain the exponent `p - alpha - 1`.

Changing `Ici L` to `Ioi L` uses equality almost everywhere with respect to Lebesgue measure. It correctly discards only the endpoint singleton. The conversion does not assume the target moment is finite and is therefore usable in the divergent branch.

The use of `ENNReal.ofReal` is also justified. It cannot hide negative values relevant to the moment because the integrand is nonnegative almost everywhere under the Pareto law; that fact is proved separately and used in the later integrability equivalence.

## 3. Finite range and real formula

`momentLintegral_of_lt` proves integrability of the density-weighted function before invoking an ordinary real improper integral. Its power exponent satisfies

```
p - alpha - 1 < -1 <-> p < alpha.
```

The pinned Mathlib integral on `(L, infinity)` gives the boundary term, and the algebra simplifies it to `alpha * L^p / (alpha - p)`. The proof supplies nonzero denominators and positive `L^alpha`; it does not rely on division by zero collapsing a bad case.

`integral_rpow_paretoMeasure` converts the already established finite extended integral using `toReal`. Mathlib's general conversion lemma is itself totalized outside the integrable range, but the project's invocation has `p < alpha` and immediately replaces the extended integral by a finite `ofReal` value. Consequently, this proof does not infer finiteness from a real-valued equality.

The separate integrability equivalence establishes the same finiteness fact directly, so callers need not reverse-engineer it from the formula. At `p = 0`, `alpha > 0` implies the finite-range hypothesis and the formula simplifies to `1`, as required of a probability measure.

## 4. Divergence, including the boundary

`momentLintegral_eq_top` first proves that the density-weighted function cannot be integrable when `alpha <= p`. The constant `alpha * L^alpha` is nonzero, so integrability of the weighted function would imply integrability of `x^(p - alpha - 1)`. The pinned theorem `integrableOn_Ioi_rpow_iff` says that this is possible exactly for an exponent less than `-1`. This contradicts `alpha <= p`.

At `p = alpha`, the exponent is exactly `-1`. The pinned Mathlib proof explicitly reduces the excluded range to nonintegrability of the reciprocal on a positive half-line, so the logarithmically divergent boundary is covered, rather than merely inferred from an open-range claim.

Measurability and almost-everywhere nonnegativity then identify finiteness of the extended integral with finite integral norm. Assuming the extended integral is not `top` would provide integrability and contradict the preceding result. No ordinary real integral is used as evidence of divergence or finiteness.

This settles the boundary for the exact Pareto law. It does not settle the boundary for every regularly varying survival function, where a slowly varying factor can change convergence at the critical order. The broader T028 source-review obligation should remain recorded.

## 5. Absolute moments and scope

`ae_nonneg_rpow_paretoMeasure` obtains its almost-everywhere statement from the zero mass of `Iio L`, without unnecessarily requiring a positive shape in this intermediate support fact. The main formulas and integrability theorem do require `alpha > 0`.

`integral_abs_rpow_paretoMeasure` proves equality almost everywhere of `|x|^p` and `x^p` on the support before transferring the integral formula. This is valid for negative orders as well. An additional separately named integrability theorem for `|x|^p` could be convenient later, but its absence is not a defect or an unmet Stage A requirement.

The module provides the exact Pareto slice of broader moment families. Gaussian or Student moments, centered absolute deviations, variance formulas, and distributional ratio claims do not follow merely from declaration counts and are not discharged by this slice.

## 6. Stage B implications

The moment results are ready to support the next stage, but Stage B law identities remain independent work.

- Threshold conditioning should assume `K >= L`, with `L > 0` and `alpha > 0`, and identify the normalized restriction to `Ioi K` with `paretoMeasure K alpha`. The case `K = L` is valid because the strict survival at the lower endpoint is `1`. Without `K >= L`, the proposed Pareto endpoint `K` would generally be wrong.
- The excess law is the conditional law pushed forward by `x -> x - K`. Its strict survival is `1` for `y < 0` and `(K / (K + y))^alpha` for `y >= 0`, including value `1` at `y = 0`.
- Positive-power pushforward should assume `q > 0` and prove equality of measures with `paretoMeasure (L^q) (alpha/q)`. Real powers need monotonicity only on the positive support, not on all of the real line.
- The present all-real-order moment theorem makes the transformed moment threshold consistent: an order `p` moment after the power map is finite exactly when `q*p < alpha`, equivalently `p < alpha/q`. This is a useful cross-check on Stage B, not a substitute for proving the law equality.

No proof rewrite or additional test fixture is requested on the basis of this review. Existing proof structure is clear, suitably factored, and uses the pinned Mathlib integration API appropriately.
