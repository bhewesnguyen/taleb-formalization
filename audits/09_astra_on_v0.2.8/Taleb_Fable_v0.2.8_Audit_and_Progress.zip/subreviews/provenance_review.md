# v0.2.8 provenance review

Review date: 21 September 2026. This review executed archive, manifest, bundle, patch, byte-comparison, and previous-report comparison checks. It did not execute Lean; runtime reproduction is a separate audit workstream.

## Verdict

No packaging or source-provenance blocker found. The supplied archive, both patch routes, and the bundled project tree agree exactly. The release brief correctly limits what the bundle can establish.

| Check | Independently observed result |
|---|---|
| ZIP SHA-256 | `696c5187ed87bb0ad428bbbdd78185758de5b437fb14a9e2411c07b32a8ccbb0` |
| Archive contents | 269 entries, 238 regular files, 237 of 237 manifest hashes match |
| Path/output hygiene | No duplicate names, absolute/traversing paths, symlinks, `.lake`, `.git`, bytecode, or compiled Lean outputs |
| Extraction | All extracted file bytes equal archive members |
| Bundled commit | `d086ce0cc9ac978e332df4d25bd92994e5f09230` |
| Project tree | `ebfa0c527eff18df29851727a3032f5786f16dc7` |
| Bundle | Verifies and records complete history; all 238 project files equal the archive |
| Full patch | Applies to `f6b100762540655184b96dd4e0c8f8fd0233da28`; 186 changed files; exact target project tree and all file bytes |
| Incremental patch | Applies to `fe14519deafc0bab2ba6c696932419c7dd55d8d9`; 42 changed files; exact target project tree and all file bytes |
| Toolchain/dependency pins | `lean-toolchain` and `lake-manifest.json` byte-identical to both v0.2.0 and v0.2.7 |
| Existing mathematical modules | All 27 pre-existing `.lean` files under `AuditRepairs/` and `Proofs/` byte-identical to v0.2.7 |
| New Lean source | `AuditRepairs/ParetoLaw.lean`; root imports and generated verification inventory updated |
| Retained audit artifacts | All 22 checks in `audits/RECEIVED_ARTIFACTS.sha256` pass |
| Prior release archive | Retained v0.2.7 archive matches SHA-256 `88ebaa078a18dc0e16bb46057969c5fec186c1fc958df1422b6d434e323d157b` |
| Prior independent audit ZIP | Matches visible-history SHA-256 `279619ccf6126409880eaba2daeb3280c88d40e4939bbdcaac8000858263ac93`; all 65 internal manifest entries pass |

The patch checks use separate temporary Git indexes. They check patch applicability, the resulting Git project tree, the exact file set, and each resulting file's bytes. The received extraction is untouched.

## Commit-count and evidence boundaries

Three commits after the v0.2.7 deliverables commit `499e9e0` are visible in the supplied bundle:

1. `e744e3b`: received v0.2.7 audit artifacts.
2. `07b8e8a`: v0.2.8 corrections and Pareto Stage A.
3. `d086ce0`: final evidence and manifest.

The brief explicitly says the fourth, v0.2.8 deliverables commit comes after the bundle. The claim of four commits including that final delivery commit is consistent with the described packaging process, but only three are independently inspectable here. Neither original worktree cleanliness nor remote/push state follows from a Git bundle.

The attached v0.2.8 brief and fresh-extraction validation log also fall outside the packaged project tree. Their SHA-256 values are recorded as supplied inputs; the audit does not present them as files authenticated by the project tree.

## D027-3 count correction

The supplied v0.2.8 validation log explicitly records the JSON-derived count as 18 results, all behaved as expected. The shipped JSON has exactly 18 such results. The previous v0.2.7 validation log remains byte-identical to its delivered version, preserving the historical miscount.

There is one bounded evidence limitation: the promised retrospective annotation in `deliverables/README.md` belongs to the excluded fourth deliverables commit. The bundled index still names v0.2.7 as current and contains no such annotation. Therefore the new count is independently checked against the record, while the later index annotation is not independently inspectable from these seven supplied files. This is not a blocker for the project or a request to repackage the Lean archive. If documentation-complete closure of that subclaim is desired, include the final index or commit in the next handoff.

## Previous PDF consistency

The retained standalone v0.2.7 PDF differs at the byte level from the PDF preserved inside the prior audit ZIP:

- ZIP member: `ea8ea63e4c6a9e78945c1f822a6387d9ba5f2d92b25dfea078b86b540159a651`.
- Standalone: `6180c5caf3e95e9cbfd751e180952896ec8ba63f463f224eefc7dec090b0c5c8`.

Both have nine pages. Poppler layout text is identical, and every page's 150 dpi RGB pixel buffer is identical. No substantive page change was found; the cause of the representation change is not established by this check. The standalone progress Markdown and handoff Markdown are byte-identical to their prior ZIP members. This difference does not weaken the current Lean archive comparison.

## Reproduction evidence

- `provenance/check_provenance.py`: archive, manifest, bundle, patch, pins, retained-artifact and count checks.
- `provenance/check_provenance.log`, `provenance/provenance.json`, `provenance/bundle_verify.log`, `provenance/recent_history.log`: results.
- `provenance/compare_previous_pdf.py`, `provenance/compare_previous_pdf.log`, `provenance/previous_pdf_comparison.json`: prior PDF text and pixel comparison.

The temporary repository, PDFs, and page PNGs are working material and need not be copied into the final audit evidence ZIP. Scripts, JSON results and logs are sufficient to reproduce the checks from the supplied bundle and archive.
