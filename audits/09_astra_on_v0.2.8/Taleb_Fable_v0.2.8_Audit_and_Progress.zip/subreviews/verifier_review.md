# v0.2.8 verifier and rendering review

Verdict: the verifier change is correct, tightly bounded and does not weaken any acceptance condition. No new verifier defect was found. The previous structural ledger repair remains intact. The byte-level comparison now makes the existing description literally accurate.

This review covers Python execution, source inspection and the independently executed real CLI CRLF mutation described below. The independent clean Lean build, normal verifier execution and fourteen regression fixtures belong to `runtime_review.md` and `reproduction/`. The nine replay cases below are not substitutes for those executions.

## Source comparison

Compared with `/tmp/taleb_v027_audit_project`, `scripts/verify.py` changes exactly one acceptance expression:

```python
(ROOT/'docs/FORMALIZATION_BACKLOG.md').read_bytes() == render_markdown(backlog).encode('utf-8')
```

Previously the comparison used `read_text()`, which normalizes line endings. Both versions detected stale content. v0.2.8 additionally rejects changes consisting only of LF-to-CRLF conversion. This is a precision improvement following an auditor's wording remark, not a repair of an unsound Lean acceptance path in v0.2.7.

The shipped probe loader similarly uses `read_bytes().decode('utf-8')`, preserving CRLF rather than normalizing it. Comparing this decoded string with the renderer is equivalent to comparing valid UTF-8 bytes; invalid UTF-8 raises an error and cannot produce a pass.

The following files are byte-identical to v0.2.7:

| File | SHA-256 |
|---|---|
| `scripts/backlog_schema.py` | `7155c49d904afb2743bd5cca551f955e20f685908e6b7cc576b2992a491e41bc` |
| `scripts/FableInventory.lean` | `2b4be85a8d667b26a773066de6a7f286a92d543e3513b77545fce9accfc87349` |
| `scripts/harness_regression.py` | `dd63330848ad0bc00fce2545a18e0da3ffa8aa4b7a2e78982c1f5232874a27d3` |

Thus the allowlist, full-environment trust scan, module coverage, public inventory cross-check, alias targets, dependency checks and fourteen regression fixtures have not been replaced or relaxed. The shared schema still validates all 158 rows and checks the full ID sequence, field types and vocabulary, status/state/Boolean agreement, and delivery-field co-presence. Semantic sufficiency of a declaration for a family remains a review responsibility, not a claim made by the schema.

## Independently executed Python checks

All checks ran on disposable copies of the 238-file received tree. Hashing the complete received tree before and after established that the review did not change it.

| Check | Observed result |
|---|---|
| Shipped JSON against shared schema | Valid, 158 rows |
| Shipped Markdown against UTF-8 renderer | Literal byte equality; 77,062 bytes; zero CRLF sequences |
| Unchanged shipped probe suite | Exit 0, all 18 results behave as expected |
| CRLF-only Markdown copy through unchanged shipped probe suite | Exit 1; only `markdown_is_rendering_of_json` fails |
| Generator after deliberately corrupting both ledger outputs | Exit 0; both restored to the exact shipped bytes |
| Same generator test with Python `-O` | Same successful result |
| Invalid raw generator status, ordinary Python | Nonzero exit before writing either output |
| Same invalid raw status with Python `-O` | Nonzero exit; shared validator rejects it; neither output changes |

The 18 shipped probe results comprise 12 malformed-schema cases, one clean-schema control, four rendering mutations and one clean-rendering control. There are not 18 negative tests. The v0.2.8 supplied archive-validation log correctly reports 18 results and says its count comes from the JSON record. The annotation preserving the historical v0.2.7 log is a separate provenance check.

## Bounded `verify.main` replay checks

The review executed the unchanged `verify.main` Python logic with external Lean and git command outputs replayed from the received evidence. Each case used a fresh copy. These cases test Python acceptance conditions and error routing; they do not independently establish the supplied Lean evidence.

| Case | Expected and observed |
|---|---|
| Unmodified project | PASS |
| CRLF-only Markdown | FAIL at rendering gate |
| CRLF-only Markdown with Python `-O` | FAIL at rendering gate |
| UTF-8 BOM inserted in Markdown | FAIL at rendering gate |
| Final newline removed | FAIL at rendering gate |
| Stale Markdown status | FAIL at rendering gate |
| Changed JSON scope without regenerating Markdown | FAIL at rendering gate |
| Duplicate family ID | FAIL at schema gate |
| Nonexistent declaration, with synchronized JSON and Markdown | FAIL at declaration-existence gate |

All nine behaved as expected. The final case confirms that keeping both ledgers synchronized does not bypass the separate requirement that credited declarations occur in the scanned environment. As before, synchronization itself does not establish that a credited declaration proves the prose target.

## Real CLI CRLF check

The runtime reviewer executed the unchanged `python3 scripts/verify.py` in an isolated project copy with exactly one source file changed: `docs/FORMALIZATION_BACKLOG.md`. All 1,430 LF sequences were converted to CRLF, increasing the file from 77,062 to 78,492 bytes. Reversing that conversion returns the original bytes exactly.

The actual verifier process exited 1 after 296.11 seconds. Its build completed successfully, and its final `verification.json` records `FAIL` with the expected message:

```text
docs/FORMALIZATION_BACKLOG.md is not the rendering of docs/FORMALIZATION_BACKLOG.json (run scripts/rebuild_curated_inventory.py)
```

The review inspected `reproduction/crlf_markdown_cli_probe/result.json`, `verification.json`, `verify_cli.log` and `build.log`. This is direct CLI evidence for the new byte-level gate, separate from the shipped fourteen fixtures, the eighteen Python probes and the nine replay cases. It is one additional adversarial check, not an extra shipped harness fixture.

## Evidence and reproduction

- `verifier_probe/check_verifier_python.py`: self-contained Python check driver.
- `verifier_probe/results/python_probe_results.json`: aggregate results and all nine replay outcomes.
- `verifier_probe/results/shipped_suite/backlog_schema_probes.json`: independently executed unchanged suite.
- `verifier_probe/results/crlf_suite/backlog_schema_probes.json`: unchanged suite on a CRLF-only ledger copy.
- `verifier_probe/results/generator_*.log`: ordinary and optimized generator runs and malformed-input rejections.
- `verifier_probe/results/replay_*.json`: replayed external command list, precise error and optimization mode per case.

Reproduce from the workspace root:

```sh
python3 audit_v028/verifier_probe/check_verifier_python.py --project audit_v028/received/Taleb_Lean_Repairs --out audit_v028/verifier_probe/results
```

No new heavyweight regression fixtures are requested. Existing gates are adequate for this release's change; the one extra CRLF CLI execution supplies direct evidence of the new branch.
