# Independent ledger and scope review: v0.2.8

Assessment date: 21 September 2026. This review checks the received ledger, its generating rows, the new Lean signatures, the prior v0.2.7 audit, and the recovered arXiv v4 book. It does not substitute supplied evidence for independent runtime execution.

## Verdict

Accept the exact-Pareto Stage A milestone, the all-real-order moment range, and both status transitions. T021 moves from missing to partial; T028 moves from source-check to partial because a genuine exact-law child is now complete. The general regularly varying moment theorem and its critical-boundary statement-review gate remain explicitly open. T060 and T061 stay discharged. No additional parent family closes.

The ledger has 158 families: 2 discharged, 11 partial, 4 reuse, 90 missing, 33 source-check, 15 model-needed, and 3 empirical. Thirteen families have credited Lean declarations. There are 146 family/declaration pairs over 142 distinct names, compared with 123/122 in v0.2.7. All credited names appear in the supplied environment inventory; that static name check is separate from independent Lean reproduction.

Only T021, T028 and T029 changed among the 158 JSON rows. The other 155 are identical to the prior release. The companion JSON preserves every received row exactly, records all 13 supported-family assessments, and supplies all 22 dependency-group tallies. These counts describe recorded scope, not percentages of effort completed.

## Two low documentation findings

### D028-1: T118 understates a completed prerequisite

T118 still describes its work as only tail-kernel convexity and says the Pareto moment identification is not delivered. Its remaining text asks for the identification `E[X^p] = L^p alpha/(alpha-p)`. The new `AuditPareto.integral_rpow_paretoMeasure` proves that exact prerequisite for `L > 0`, `alpha > 0` and `p < alpha`.

Cross-credit that existing theorem to T118; update delivered and remaining text; retain `partial`. Keep `formula_proved` for the older kernel convexity, add `law_theorem` and `actual_law_constructed` for the moment identification against the existing Mathlib law. One extra citation produces 147 family/declaration pairs while the distinct-name count stays 142. This is bookkeeping, not an additional mathematical milestone.

The exact formula also matches Eq. (21.7), printed p. 382 / PDF p. 396. Proposition 21.1 is on printed p. 381 / PDF p. 395. Still open are convexity in the tail exponent and the justified integrated Jensen argument. For the future convexity proof, the derivative for general `p > 0` is `2*p*L^p/(alpha-p)^3`; the source's later display omits the factor `p` and replaces `(alpha-p)^3` with `(alpha-1)^3`, while retaining `L^p` in the numerator. It coincides with the correct derivative at `p = 1`. Do not copy it as the general-order derivative. No new convexity claim is made by v0.2.8.

### D028-2: T028's exact-tail page is 95, not 97

The delivery-scope sentence cites printed p. 97 / PDF p. 111 for the exact constant-factor tail `P(X>x)=C*x^(-alpha)`. That display is on printed p. 95 / PDF p. 109. Printed p. 96 introduces `L(x)*x^(-alpha)` and the slowly varying ratio; printed p. 97 contains the logarithmic exponent discussion and Definition 5.1's asymptotic regular-variation class.

Correct the authoritative generator row, then regenerate JSON and Markdown. The parent source range 95-98 already contains the right page. The density source, printed p. 86 / PDF p. 100, is correct. This finding changes no theorem or status.

## T028: exact boundary versus general regular variation

For positive `alpha`, exact Pareto has a constant slowly varying factor, so its `p = alpha` moment diverges. The new extended nonnegative integral theorem proves this case; no totalized real-integral value is used as evidence of finiteness.

For a general tail `S(t) ~ t^(-alpha) L(t)` with positive alpha, the critical moment depends on the tail integral of `L(t)/t`. A constant factor gives divergence. A tail proportional to `t^(-alpha)/(log t)^2` for sufficiently large t has the same regular-variation index and a finite alpha-order moment. Thus the exact-Pareto proof cannot close the general boundary. These examples are explanatory mathematics, not additional Lean theorems in this release.

The status vocabulary allows partial rows to retain source-review work. Moving this row to partial is accurate and does not erase the remaining gate. For general nonnegative laws, keep the intended nonnegative-order convention and specify positive alpha in the critical-integral statement. The exact-Pareto theorem may correctly allow all real p: because `L > 0`, the support is bounded away from zero and every negative-order moment is finite. No new acceptance condition is needed.

## T029: repaired facets and the Pareto specialization

D027-1 is repaired: the stale open-probabilistic-statement sentence is replaced, the delivered binary exponent child is complete, and the stronger regular-variation child is stated with the weighted denominator and the correct limiting coefficient. Conditional-law credit is assigned to the general exponent theorems, which assume finite-exponent properties.

The new Pareto corollary specializes those premises to actual Mathlib Pareto marginal laws. Its remaining assumptions are a probability space, measurable pointwise nonnegative coordinates, and equality of their pushforward laws with the specified Pareto laws. Independence is absent. Accept `actual_law_constructed` when scoped to these concrete marginal laws; describing the result as a specialization to concrete Pareto marginals is most precise. No explicit joint sample-space realization theorem is supplied, and none was required for Stage A. Do not impose one retrospectively to reject the milestone.

The new specialized law theorem can also support the existing `law_theorem` facet under ordinary specified-marginal hypotheses. The received scope text credits that facet only to the earlier generic event-to-pushforward identity; broadening that attribution is optional and changes no count. T029 remains partial while the stronger unequal-index regular-variation ratio theorem remains open.

## Other scope checks

T021's raw moments and absolute moments `E[|X|^p]` agree on the positive support. They are not centered mean absolute deviations `E[|X-E X|]`. The remaining Pareto MD/STD ratio requires both mean/variance work and the centered absolute-deviation integration, followed by ratio algebra. Gaussian and Student moments remain open. Merely knowing the first two moments does not determine mean absolute deviation in general.

T005 remains missing: no conditional law, mean-excess or general tail-integral theorem landed. T032 remains formula-only partial: a general moment formula does not establish a power-transform pushforward equality. T047 remains a convolution prerequisite rather than a sample-average theorem. T007/T046 retain only the actual Gaussian slice. T008 still assumes subexponentiality. T124 remains algebraic mixture support. These scopes are not inflated by the new Pareto results.

T060/T061 remain discharged within their previously reviewed scopes. S001 and S002 remain open outside the 158-family count. D027-2 is repaired: S001 now has the explicit zero-shape Gumbel branch, appropriate off-support values, correct printed pp. 172-173 / PDF pp. 186-187, and the endpoint-coordinate reparameterization. It does not reopen T061.

## Evidence-summary repair

The new v0.2.8 external validation log explicitly reports 18 results read from its machine-readable probe record. The supplied pre-deliverables bundle does not contain the claimed new annotation to the historical v0.2.7 log in `deliverables/README.md`; that annotation may be in the excluded fourth deliverables commit. Treat its presence as unconfirmed from these files. The historical log itself is preserved. This bounded provenance caveat is separate from the corrected new count and is not a mathematical blocker.

## Next contained work

Proceed to Pareto Stage B: for `K >= L > 0`, identify the normalized restricted law above K with `Pareto(K, alpha)`; derive the support-correct excess survival and conditional/excess moments. For `q > 0`, identify the power pushforward as `Pareto(L^q, alpha/q)` as an equality of measures. Credit only the exact-Pareto slices of T005 and T032. Keep their general targets, the stronger T029 ratio child, centered T021 ratios, S001/S002, and domains of attraction separately open.
