# Independent runtime review: v0.2.8

Verdict: all independently executed runtime gates behaved as expected. No runtime finding was identified.

The received release was copied to a fresh `/tmp/taleb_v028_audit_project`. The project had no `.lake/build` before the first build. Previously obtained dependency caches were reused, with all nine Git revisions independently checked against the unchanged manifest and all nine worktrees clean before and after execution. Lean reports version 4.24.0, release commit `797c613eb9b6d4ec95db23e3e00af9ac6657f24b`. Executable SHA-256 hashes are recorded.

| Check | Independent result |
| --- | --- |
| Clean project `lake build` | Exit 0; 138.00 seconds; 2746 jobs; no compiler warning, error, or sorry diagnostics |
| Unchanged `python3 scripts/verify.py` | Exit 0; 282.30 seconds |
| Public axiom checks | 160 theorems, 8 instances, 16 aliases: 184 total |
| Environment trust scan | 321 project constants, including 83 internal; all within `propext`, `Classical.choice`, `Quot.sound`; no project axioms |
| Project-module coverage | 29 imported project modules; all disk modules covered |
| Ledger | 158 valid families; 146 family/declaration pairs over 142 distinct declarations; literal Markdown rendering equality passed |
| Unchanged schema/render probe suite | 18/18 expected results; exit 0; 0.06 seconds |
| Unchanged regression harness | 14/14 expected results; all three shard invocations exit 0; 1622.97 seconds across the concurrent run |
| Supplementary CRLF-only Markdown CLI mutation | Correctly rejected at the raw-byte rendering gate; verifier exit 1; 296.11 seconds |
| Final integrity | Received files unchanged; temporary project sources unchanged; all nine pinned dependency worktrees clean |

## Regression results

The 14 shipped fixtures ran exactly once across three disjoint invocations of the unchanged harness. Each used real relative `--scratch` and `--out` arguments, its own dependency copy, and the harness's original source and project-build restoration checks. Every restored source hash matched its pristine hash and every fixture began from the pristine project build snapshot. The harness itself exited zero for all three shards. The individual verifier exits below intentionally differ for positive and negative cases.

| Fixture | Verifier exit | Record | Seconds | Expected diagnostic or positive control |
| --- | --- | --- | --- | --- |
| `valid` | 0 | PASS | 300.4 | Positive control |
| `private_axiom` | 1 | FAIL | 401.0 | outside the axiom allowlist |
| `structure_namespace_theorem` | 1 | FAIL | 425.5 | Environment/regex inventory mismatch |
| `orphan_module` | 1 | FAIL | 295.1 | not imported into the environment |
| `dirty_dependency` | 1 | FAIL | 0.9 | working-tree modifications |
| `private_sorry_theorem` | 1 | FAIL | 119.3 | Compiler diagnostics in lake build |
| `protected_theorem` | 1 | FAIL | 404.5 | Environment/regex inventory mismatch |
| `alias_map_mismatch` | 1 | FAIL | 291.3 | Alias targets differ |
| `nested_imported_module` | 0 | PASS | 397.8 | Positive control |
| `private_sorry_def` | 1 | FAIL | 145.5 | Compiler diagnostics in lake build |
| `alias_map_mismatch_optimized` | 1 | FAIL | 290.7 | Alias targets differ |
| `nested_orphan_module` | 1 | FAIL | 291.4 | not imported into the environment |
| `namespace_section_theorem` | 0 | PASS | 392.7 | Positive control |
| `backlog_duplicate_id` | 1 | FAIL | 294.0 | schema violations |

Both private-sorry fixtures also ran the Lean environment inventory directly and confirmed that their private constants carried `sorryAx`. The optimized alias-mismatch case used `PYTHONOPTIMIZE=1` and was still rejected. The nested imported-module positive control confirmed that both its module and its theorem were scanned. The namespace/section positive control passed with the theorem following a section end correctly discovered.

## Additional literal-byte test

Exactly one source file changed before the supplementary CLI invocation: `docs/FORMALIZATION_BACKLOG.md`. Its 1430 LF line endings became CRLF, with no textual change. Reversing that conversion recovers the original bytes. The actual unchanged verifier ran the ordinary Lean checks and then produced exit 1 with a FAIL record containing:

`docs/FORMALIZATION_BACKLOG.md is not the rendering of docs/FORMALIZATION_BACKLOG.json (run scripts/rebuild_curated_inventory.py)`

This test is separate from both the 14 shipped regression fixtures and the 18 shipped schema/render probes.

## Evidence and bounds

`audit_v028/reproduction/execution_summary.json` records commands, working directories, timings, dependency revisions, all fixture results, and received-source hashes. `normal_verification/` contains only independently generated normal-verifier files; inherited supplied harness and schema records were excluded. The three `regression_shard_*/harness_regression.json` files retain exact errors, process exits, fixture isolation checks, and the harness's additional inventory notes. The CRLF mutation has its own command, hashes, result, and log.

This was a clean project build against pinned cached dependencies, not a rebuild of every dependency from source. No received source, shipped harness, fixture, verifier, or allowlist was modified to obtain a pass. The results certify the executable formal and bookkeeping checks described here; source-to-theorem interpretation is covered by the separate mathematical and ledger reviews.
