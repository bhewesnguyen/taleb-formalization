# Taleb Lean v0.2.8 independent audit

Reviewed release ZIP SHA-256:
`696c5187ed87bb0ad428bbbdd78185758de5b437fb14a9e2411c07b32a8ccbb0`.

Accept exact Pareto Stage A. No Lean proof repair was identified. The all-real-order
moment formula is correct for p < alpha because the positive lower support bound
also permits negative orders. Accept T028's move to partial for its exact-Pareto
child while retaining the general regularly varying boundary-review gate. T029
remains partial; its Pareto specialization uses concrete marginal laws. T060 and
T061 remain the only discharged parent families. The received release is unchanged.

## Contents and corrections

The PDF and editable Markdown contain the consolidated audit. Progress Markdown has
the complete 158-family index; JSON preserves all received rows alongside thirteen
audited scopes, 22 dependency-group tallies, child tasks and supplemental S001/S002.
The received rows retain the two stale documentation statements; recommendations
are separate from the preserved evidence.

- D028-1: T118 should cross-credit the now-proved Pareto moment identification,
  while retaining the remaining convexity and integrated Jensen obligations.
- D028-2: T028's exact constant-factor tail locator is printed p.95/PDF109,
  not p.97/PDF111.

The handoff gives precise repairs and the next Stage B targets: threshold
conditioning, the excess law, and the positive-power pushforward as actual laws.
It records the corrected derivative for future T118 work. These are specifications,
not applied changes to the received proof project.

## Independent execution

`evidence/reproduction/` contains actual build, verifier, schema and regression logs
with commands and timings. All fourteen shipped fixtures ran exactly once in three
concurrent disjoint --only invocations of the unchanged harness. Each used its own
copies, real relative scratch/output arguments and original restoration checks.
This is full partitioned fixture coverage, not one sequential suite invocation.

`evidence/reproduction/crlf_markdown_cli_probe/` records an additional real verifier
CLI check. Only Markdown line endings changed; the verifier correctly rejected it
at the literal-byte rendering gate. This is separate from the fourteen fixtures
and eighteen shipped Python probes.

`evidence/verifier_probe/` contains actual Python generator/schema/rendering checks.
Nine bounded verify.main cases replay recorded external-command output to isolate
Python control flow. They do not run Lean and are not additional proof evidence.
`evidence/provenance/` records archive, bundle, patch and retained-artifact checks.

## Scope and reproducibility

The project uses Lean 4.24.0 and its unchanged pinned dependencies. Standard gates
are lake build, python3 scripts/verify.py, python3 scripts/backlog_schema_probes.py,
and python3 scripts/harness_regression.py. Exact local commands and paths remain in
the evidence. Audit setup scripts are execution records, not portable installers.
Pinned dependency caches were reused; the project build started without project
build outputs. This does not claim every dependency was rebuilt from source.

The reviewed source is arXiv:2001.10488v4, 523 pages, SHA-256
`758e18b7337840104db93296144d67cf5514bf2de128fe557dc84bc32a0ad567`.
Book pages, compiler/dependency caches, temporary worktrees and duplicate input
archives are excluded from this evidence ZIP.

The bundle proves its included snapshot/history, not the author's live worktree
or remote push state. Its final deliverables commit is excluded. The promised
retrospective count annotation in that commit's deliverables index cannot be
inspected here; the corrected current count is independently confirmed. The prior
standalone audit PDF and its ZIP member differ in representation, but all nine
page texts and rendered RGB buffers match. No substantive page change was found.

These results do not certify exhaustive atomic book coverage, upstream Mathlib
integration, empirical claims or operation of the separate quantum/classical app.
SHA256SUMS covers every included file except itself.
